package fr.vspgps.app

import android.content.Context
import com.valhalla.config.ValhallaConfigBuilder
import com.valhalla.valhalla.Valhalla
import com.valhalla.api.models.RouteRequest
import com.valhalla.api.models.RoutingWaypoint
import com.valhalla.api.models.CostingModel
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream

/**
 * Moteur Valhalla local de VSP GPS.
 *
 * Le fichier valhalla_tiles.tar est fourni dans :
 * app/src/main/assets/
 *
 * Au premier lancement, il est copié dans le stockage interne
 * de l'application puis utilisé par Valhalla.
 */
class LocalValhallaRouter(
    context: Context
) : Closeable {

    private val appContext = context.applicationContext

    private val valhallaDir =
        File(appContext.filesDir, "valhalla")

    private val bundledTileArchive =
        File(valhallaDir, TILE_ARCHIVE_NAME)

    private val mapPackManager = OfflineMapPackManager(appContext)

    /**
     * Étape 62 : un pack France installé hors APK devient prioritaire.
     * En son absence, le pack historique embarqué reste utilisé sans régression.
     */
    private fun selectedTileArchive(): File {
        val france = mapPackManager.francePack()
        if (france.installed) return france.file
        val regional = mapPackManager.regionalPack()
        if (regional.installed) return regional.file
        return bundledTileArchive
    }

    fun activePackDescription(): String {
        val file = selectedTileArchive()
        val source = when (file) {
            mapPackManager.francePack().file -> "France externe"
            mapPackManager.regionalPack().file -> "Régional externe"
            else -> "Pack embarqué"
        }
        val mib = if (file.isFile) file.length() / (1024.0 * 1024.0) else 0.0
        return "$source • ${"%.1f".format(java.util.Locale.FRANCE, mib)} Mo • ${file.name}"
    }

    private fun installPackSafely(
        id: String,
        input: java.io.InputStream,
        validateCoverage: (() -> Unit)? = null
    ): Result<String> = runCatching {
        close()
        val before = mapPackManager.info(id)
        val backup = mapPackManager.backupFile(id)
        if (backup.exists()) backup.delete()
        if (before.installed) {
            before.file.copyTo(backup, overwrite = true)
        }

        try {
            val info = mapPackManager.install(id, input)
            require(info.sizeBytes > 100L * 1024L * 1024L) {
                "Pack trop petit (${info.sizeBytes} octets)"
            }
            val init = initialize()
            if (init is InitializationResult.Failed) error(init.message)
            validateCoverage?.invoke()
            if (backup.exists()) backup.delete()
            activePackDescription()
        } catch (error: Throwable) {
            close()
            mapPackManager.remove(id)
            if (backup.isFile) {
                mapPackManager.restoreBackup(id)
            }
            // Toujours tenter de revenir à la carte qui fonctionnait auparavant.
            initialize()
            throw IllegalStateException(
                "Pack refusé, ancienne carte restaurée : ${error.message ?: error.javaClass.simpleName}",
                error
            )
        }
    }

    @Synchronized
    fun installRegionalPack(input: java.io.InputStream): Result<String> =
        installPackSafely(OfflineMapPackManager.REGIONAL_PACK_ID, input)

    private data class FranceCoverageCheck(
        val label: String,
        val startLatitude: Double,
        val startLongitude: Double,
        val endLatitude: Double,
        val endLongitude: Double
    )

    private val franceCoverageChecks = listOf(
        FranceCoverageCheck("Paris", 48.8566, 2.3522, 48.8738, 2.2950),
        FranceCoverageCheck("Lyon", 45.7640, 4.8357, 45.7485, 4.8467),
        FranceCoverageCheck("Bordeaux", 44.8378, -0.5792, 44.8490, -0.5710),
        FranceCoverageCheck("Marseille", 43.2965, 5.3698, 43.2854, 5.3761)
    )

    // ETAPE 132 : la présence de quelques villes isolées ne prouve pas qu'un pack
    // couvre réellement la France. Ces contrôles traversent plusieurs régions afin
    // de détecter une archive composée de zones disjointes ou incomplètes.
    private val franceContinuityChecks = listOf(
        FranceCoverageCheck("Paris → Lyon", 48.8566, 2.3522, 45.7640, 4.8357),
        FranceCoverageCheck("Paris → Bordeaux", 48.8566, 2.3522, 44.8378, -0.5792),
        FranceCoverageCheck("Lyon → Marseille", 45.7640, 4.8357, 43.2965, 5.3698)
    )

    /**
     * ETAPE 131 : diagnostic hors ligne du pack actif sur plusieurs zones françaises.
     * Ce test ne télécharge rien et ne modifie aucune carte : il indique seulement
     * si l'archive actuellement utilisée contient suffisamment de tuiles pour calculer
     * de petits trajets dans plusieurs régions éloignées.
     */
    @Synchronized
    fun currentFranceCoverageDiagnostic(): Result<String> = runCatching {
        val initialization = initialize()
        if (initialization is InitializationResult.Failed) error(initialization.message)

        val passed = mutableListOf<String>()
        val failed = mutableListOf<String>()
        franceCoverageChecks.forEach { check ->
            when (val result = calculateTestRoute(
                startLatitude = check.startLatitude,
                startLongitude = check.startLongitude,
                endLatitude = check.endLatitude,
                endLongitude = check.endLongitude
            )) {
                is LocalRouteResult.Success -> passed += check.label
                is LocalRouteResult.Failed -> failed += check.label
            }
        }

        if (failed.isEmpty()) {
            "✓ Couverture France validée sur ${passed.size}/${franceCoverageChecks.size} zones : ${passed.joinToString(", ")}"
        } else {
            "Couverture partielle : ${passed.size}/${franceCoverageChecks.size} zones OK" +
                (if (passed.isNotEmpty()) " (${passed.joinToString(", ")})" else "") +
                " • absentes/invalides : ${failed.joinToString(", ")}"
        }
    }

    /**
     * ETAPE 133 : verdict simple sur la capacité hors ligne du pack actif.
     * On combine la présence de plusieurs zones éloignées et la continuité
     * inter-régions. Le résultat n'active ni ne modifie aucun pack.
     */
    @Synchronized
    fun currentPackReadinessDiagnostic(): Result<String> = runCatching {
        val coverage = currentFranceCoverageDiagnostic().getOrThrow()
        val continuity = currentFranceContinuityDiagnostic().getOrThrow()
        val franceReady = coverage.startsWith("✓") && continuity.startsWith("✓")
        if (franceReady) {
            "✓ PACK FRANCE PRÊT HORS LIGNE\n" +
                "Couverture multi-régions et continuité longue distance validées.\n" +
                activePackDescription()
        } else {
            "⚠ PACK RÉGIONAL / PARTIEL\n" +
                "Les trajets hors zone peuvent nécessiter Internet.\n" +
                coverage + "\n" + continuity + "\n" +
                activePackDescription()
        }
    }

    /**
     * ETAPE 132 : contrôle volontaire des liaisons inter-régions du pack actif.
     * Le test reste hors ligne et n'altère aucun trajet de navigation affiché.
     */
    @Synchronized
    fun currentFranceContinuityDiagnostic(): Result<String> = runCatching {
        val initialization = initialize()
        if (initialization is InitializationResult.Failed) error(initialization.message)

        val passed = mutableListOf<String>()
        val failed = mutableListOf<String>()
        franceContinuityChecks.forEach { check ->
            when (calculateTestRoute(
                startLatitude = check.startLatitude,
                startLongitude = check.startLongitude,
                endLatitude = check.endLatitude,
                endLongitude = check.endLongitude
            )) {
                is LocalRouteResult.Success -> passed += check.label
                is LocalRouteResult.Failed -> failed += check.label
            }
        }

        if (failed.isEmpty()) {
            "✓ Continuité France validée : ${passed.joinToString(" • ")}"
        } else {
            "Continuité France incomplète : ${passed.size}/${franceContinuityChecks.size} liaison(s) OK" +
                (if (passed.isNotEmpty()) " (${passed.joinToString(", ")})" else "") +
                " • échec : ${failed.joinToString(", ")}"
        }
    }

    /**
     * ETAPE 132 : vérifie la destination choisie avec le moteur local uniquement.
     * Cela permet, avant de partir, de savoir si le trajet restera disponible sans
     * connexion Internet et s'il passe le verrou motorway local.
     */
    @Synchronized
    fun currentDestinationOfflineDiagnostic(
        startLatitude: Double,
        startLongitude: Double,
        endLatitude: Double,
        endLongitude: Double
    ): Result<String> = runCatching {
        val json = calculateRouteJson(
            startLatitude = startLatitude,
            startLongitude = startLongitude,
            endLatitude = endLatitude,
            endLongitude = endLongitude
        ).getOrThrow()
        val trip = json.optJSONObject("trip") ?: error("Trajet local sans trip")
        val summary = trip.optJSONObject("summary")
        val km = summary?.optDouble("length", Double.NaN)?.takeIf { it.isFinite() }
        val rawSeconds = summary?.optDouble("time", Double.NaN)?.takeIf { it.isFinite() }
        val minutes = rawSeconds?.let { kotlin.math.ceil(it / 60.0).toInt() }
        val validation = json.optJSONObject("_vsp_validation")
        val motorway = validation?.optInt("motorway", -1) ?: -1
        buildString {
            append("✓ Destination disponible hors ligne")
            if (km != null) append(" • ").append(String.format(java.util.Locale.FRANCE, "%.1f km", km))
            if (minutes != null) append(" • ~").append(minutes).append(" min")
            if (motorway >= 0) append(" • motorway=").append(motorway)
            append("\nPack : ").append(activePackDescription())
        }
    }

    /** Espace libre réellement disponible dans le stockage interne de l'application. */
    fun availableMapStorageBytes(): Long = appContext.filesDir.usableSpace

    /**
     * ETAPE 132 : l'installation écrit d'abord le nouveau .part et conserve une
     * sauvegarde du pack remplacé. On réserve en plus 256 Mio de marge pour éviter
     * un téléphone rempli à 100 % pendant l'import.
     */
    fun requiredFreeBytesForImport(targetFrance: Boolean, incomingBytes: Long): Long {
        val existing = if (targetFrance) mapPackManager.francePack() else mapPackManager.regionalPack()
        val backupBytes = if (existing.installed) existing.sizeBytes else 0L
        return incomingBytes.coerceAtLeast(0L) + backupBytes + 256L * 1024L * 1024L
    }

    @Synchronized
    fun installFrancePack(input: java.io.InputStream): Result<String> =
        installPackSafely(OfflineMapPackManager.FRANCE_PACK_ID, input) {
            // ETAPE 131 : ne plus valider un soi-disant pack France uniquement autour
            // de Paris. On exige plusieurs zones éloignées avant de remplacer la carte
            // qui fonctionne déjà. En cas d'échec, installPackSafely restaure l'ancien pack.
            val diagnostic = currentFranceCoverageDiagnostic().getOrThrow()
            require(diagnostic.startsWith("✓")) {
                "Couverture France non validée : $diagnostic"
            }
            val continuity = currentFranceContinuityDiagnostic().getOrThrow()
            require(continuity.startsWith("✓")) {
                "Continuité France non validée : $continuity"
            }
        }

    fun francePackInstalled(): Boolean = mapPackManager.francePack().installed

    @Synchronized
    fun removeFrancePack(): Result<String> = runCatching {
        close()
        mapPackManager.remove(OfflineMapPackManager.FRANCE_PACK_ID)
        val init = initialize()
        if (init is InitializationResult.Failed) error(init.message)
        activePackDescription()
    }

    private var engine: Valhalla? = null

    val isInitialized: Boolean
        get() = engine != null

    val tilesAreInstalled: Boolean
        get() = selectedTileArchive().let { it.isFile && it.length() > 0L }

    val tileArchivePath: String
        get() = selectedTileArchive().absolutePath

    /**
     * Copie valhalla_tiles.tar depuis assets vers le stockage
     * interne de l'application si nécessaire.
     */
    private fun installTilesFromAssets() {

        // Le pack France externe, s'il existe, ne doit jamais être écrasé par l'asset.
        if (mapPackManager.francePack().installed || mapPackManager.regionalPack().installed ||
            (bundledTileArchive.isFile && bundledTileArchive.length() > 0L)) {
            return
        }

        if (!valhallaDir.exists()) {
            valhallaDir.mkdirs()
        }

        appContext.assets.open(TILE_ARCHIVE_NAME).use { input ->

            FileOutputStream(bundledTileArchive).use { output ->

                input.copyTo(
                    out = output,
                    bufferSize = 1024 * 1024
                )
            }
        }
    }

    /**
     * Initialise le moteur Valhalla local.
     */
    @Synchronized
    fun initialize(): InitializationResult {

        if (engine != null) {
            return InitializationResult.Ready(
                selectedTileArchive().absolutePath
            )
        }

        return try {

            installTilesFromAssets()

            val archive = selectedTileArchive()
            val config =
                ValhallaConfigBuilder()
                    .withTileExtract(archive.absolutePath)
                    .build()

            engine = Valhalla(
                appContext,
                config
            )

            InitializationResult.Ready(
                archive.absolutePath
            )

        } catch (error: Throwable) {

            engine = null

            InitializationResult.Failed(
                message = error.message
                    ?: error.javaClass.simpleName,
                cause = error
            )
        }
    }

    /**
     * Test de calcul réellement hors ligne, sans appel au serveur public.
     * Appeler depuis Dispatchers.IO (initialisation/calcule potentiellement longs).
     * La vérification des routes interdites aux VSP reste indispensable avant
     * toute utilisation de cette réponse pour guider un conducteur.
     */
    @Synchronized
    fun calculateTestRoute(
        startLatitude: Double,
        startLongitude: Double,
        endLatitude: Double,
        endLongitude: Double
    ): LocalRouteResult {
        val initialization = initialize()
        if (initialization is InitializationResult.Failed) {
            return LocalRouteResult.Failed(
                "Initialisation Valhalla locale : ${initialization.message}"
            )
        }
        return try {
            val request = RouteRequest(
                locations = listOf(
                    RoutingWaypoint(lat = startLatitude, lon = startLongitude),
                    RoutingWaypoint(lat = endLatitude, lon = endLongitude)
                ),
                // Étape 13 : profil auto conservé tant qu'un vrai costing VSP
                // et la validation des arêtes ne sont pas disponibles.
                // Ne PAS considérer ce trajet comme autorisé pour une VSP.
                costing = CostingModel.auto
            )
            val result = requireNotNull(engine).route(request)
            // La signature exacte de l'enveloppe de réponse dépend de la
            // version de valhalla-mobile. Pour ce test, on conserve la réponse
            // native sans supposer une sous-classe ou un champ inexistants.
            LocalRouteResult.Success(result)
        } catch (error: Exception) {
            LocalRouteResult.Failed(error.message ?: error.javaClass.simpleName)
        }
    }

    /**
     * Calcul local réutilisable par le GPS principal.
     * Cette étape expose volontairement la réponse native telle quelle :
     * aucune dépendance JSON supplémentaire n'est ajoutée tant que le format
     * exact de valhalla-mobile 0.6.4 n'a pas été validé sur l'appareil.
     */
    @Synchronized
    fun calculateRoute(
        startLatitude: Double,
        startLongitude: Double,
        endLatitude: Double,
        endLongitude: Double
    ): LocalRouteResult = calculateTestRoute(
        startLatitude = startLatitude,
        startLongitude = startLongitude,
        endLatitude = endLatitude,
        endLongitude = endLongitude
    )

    /**
     * Diagnostic de la réponse native, sans Moshi ni hypothèse sur les noms
     * des classes de valhalla-mobile 0.6.4. Ne sert pas encore au guidage.
     */
    fun describeRouteResponse(response: Any): String {
        fun properties(value: Any): List<String> = value.javaClass.methods
            .filter { it.parameterCount == 0 && it.name.startsWith("get") &&
                it.name != "getClass" && !it.isSynthetic }
            .map { it.name.removePrefix("get").replaceFirstChar { c -> c.lowercase() } }
            .distinct().sorted()

        val envelopeProperties = properties(response)
        val inner = response.javaClass.methods.firstOrNull {
            it.parameterCount == 0 && it.name in listOf("getJsonResponse", "getRouteResponse")
        }?.let { runCatching { it.invoke(response) }.getOrNull() }
        val innerProperties = inner?.let { properties(it) }.orEmpty()
        val trip = inner?.javaClass?.methods?.firstOrNull {
            it.name == "getTrip" && it.parameterCount == 0
        }?.let { runCatching { it.invoke(inner) }.getOrNull() }
        val tripProperties = trip?.let { properties(it) }.orEmpty()
        val summary = trip?.javaClass?.methods?.firstOrNull {
            it.name == "getSummary" && it.parameterCount == 0
        }?.let { runCatching { it.invoke(trip) }.getOrNull() }
        val summaryProperties = summary?.let { properties(it) }.orEmpty()
        return buildString {
            append("Type: ").append(response.javaClass.simpleName)
            append(" | enveloppe: ").append(envelopeProperties.take(8).joinToString(","))
            append(" | réponse: ").append(innerProperties.take(12).joinToString(","))
            append(" | trajet: ").append(tripProperties.take(12).joinToString(","))
            append(" | résumé: ").append(summaryProperties.take(12).joinToString(","))
        }
    }


    /**
     * Convertit la réponse native valhalla-mobile en JSON sans dépendance externe.
     * Les modèles de valhalla-models exposent leurs champs par getters ; cette
     * conversion permet de réutiliser le parseur/guidage historique de VSP GPS.
     */
    fun routeResponseAsJson(response: Any): org.json.JSONObject {
        fun convert(value: Any?, depth: Int): Any? {
            if (value == null) return org.json.JSONObject.NULL
            if (depth > 12) return org.json.JSONObject.NULL
            return when (value) {
                is String, is Number, is Boolean -> value
                is Enum<*> -> value.name.lowercase()
                is Iterable<*> -> org.json.JSONArray().apply {
                    value.forEach { put(convert(it, depth + 1)) }
                }
                is Array<*> -> org.json.JSONArray().apply {
                    value.forEach { put(convert(it, depth + 1)) }
                }
                else -> org.json.JSONObject().apply {
                    value.javaClass.methods
                        .asSequence()
                        .filter { it.parameterCount == 0 && it.name.startsWith("get") &&
                            it.name != "getClass" && !it.isSynthetic }
                        .forEach { getter ->
                            val key = getter.name.removePrefix("get")
                                .replaceFirstChar { c -> c.lowercase() }
                            runCatching { getter.invoke(value) }.getOrNull()?.let { child ->
                                put(key, convert(child, depth + 1))
                            }
                        }
                }
            }
        }

        val envelope = response.javaClass.methods.firstOrNull {
            it.parameterCount == 0 && it.name in listOf("getJsonResponse", "getRouteResponse")
        }?.let { runCatching { it.invoke(response) }.getOrNull() } ?: response

        return convert(envelope, 0) as? org.json.JSONObject
            ?: throw IllegalStateException("Réponse Valhalla locale non convertible en JSON")
    }

    /**
     * Étape 9 : conversion ciblée de la réponse native vers le format JSON
     * déjà consommé par MainActivity. On ne sérialise plus tout le graphe
     * d'objets (qui pouvait rencontrer des propriétés internes/cycliques).
     */
    private fun routeResponseForGps(response: Any): org.json.JSONObject {
        fun getter(value: Any, name: String): Any? = value.javaClass.methods
            .firstOrNull { it.parameterCount == 0 && it.name == "get$name" }
            ?.let { runCatching { it.invoke(value) }.getOrNull() }

        fun list(value: Any?, name: String): List<Any> = when (val v = value?.let { getter(it, name) }) {
            is Iterable<*> -> v.filterNotNull()
            is Array<*> -> v.filterNotNull()
            else -> emptyList()
        }

        fun number(value: Any, name: String): Number? = getter(value, name) as? Number
        fun string(value: Any, name: String): String? = getter(value, name)?.toString()

        val envelope = response.javaClass.methods.firstOrNull {
            it.parameterCount == 0 && it.name in listOf("getJsonResponse", "getRouteResponse")
        }?.let { runCatching { it.invoke(response) }.getOrNull() } ?: response
        val trip = getter(envelope, "Trip")
            ?: throw IllegalStateException("Réponse Valhalla locale sans trip")
        val summary = getter(trip, "Summary")
            ?: throw IllegalStateException("Réponse Valhalla locale sans summary")

        val summaryJson = org.json.JSONObject().apply {
            number(summary, "Length")?.let { put("length", it) }
            number(summary, "Time")?.let { put("time", it) }
        }
        val legsJson = org.json.JSONArray()
        list(trip, "Legs").forEach { leg ->
            val legJson = org.json.JSONObject()
            val shape = string(leg, "Shape")
                ?: throw IllegalStateException("Tronçon Valhalla local sans shape")
            legJson.put("shape", shape)
            val maneuversJson = org.json.JSONArray()
            list(leg, "Maneuvers").forEach { maneuver ->
                val m = org.json.JSONObject()
                number(maneuver, "Type")?.let { m.put("type", it) }
                string(maneuver, "Instruction")?.let { m.put("instruction", it) }
                string(maneuver, "VerbalPreTransitionInstruction")?.let {
                    m.put("verbal_pre_transition_instruction", it)
                }
                number(maneuver, "BeginShapeIndex")?.let { m.put("begin_shape_index", it) }
                number(maneuver, "EndShapeIndex")?.let { m.put("end_shape_index", it) }
                number(maneuver, "RoundaboutExitCount")?.let { m.put("roundabout_exit_count", it) }
                number(maneuver, "Length")?.let { m.put("length", it) }
                number(maneuver, "Time")?.let { m.put("time", it) }
                // Étape 20 : inventaire prudent des attributs simples réellement exposés
                // par le modèle natif. On n'invente aucun highway/access absent.
                val nativeFields = org.json.JSONObject()
                maneuver.javaClass.methods.asSequence()
                    .filter { it.parameterCount == 0 && it.name.startsWith("get") &&
                        it.name != "getClass" && !it.isSynthetic }
                    .forEach { getterMethod ->
                        val key = getterMethod.name.removePrefix("get")
                            .replaceFirstChar { c -> c.lowercase() }
                        val value = runCatching { getterMethod.invoke(maneuver) }.getOrNull()
                        when (value) {
                            is String, is Number, is Boolean -> nativeFields.put(key, value)
                            is Enum<*> -> nativeFields.put(key, value.name.lowercase())
                        }
                    }
                m.put("native_fields", nativeFields)
                val streetNames = list(maneuver, "StreetNames")
                if (streetNames.isNotEmpty()) {
                    m.put("street_names", org.json.JSONArray().apply {
                        streetNames.forEach { put(it.toString()) }
                    })
                }
                maneuversJson.put(m)
            }
            legJson.put("maneuvers", maneuversJson)
            legsJson.put(legJson)
        }
        if (legsJson.length() == 0) throw IllegalStateException("Réponse Valhalla locale sans legs")
        return org.json.JSONObject().put("trip", org.json.JSONObject()
            .put("summary", summaryJson)
            .put("legs", legsJson))
    }

    /** Étape 28 : appel brut de l'acteur local pour pouvoir transmettre les options
     * VSP et des exclude_locations sans repasser par les modèles générés. */
    private fun rawLocalRoute(
        startLatitude: Double,
        startLongitude: Double,
        endLatitude: Double,
        endLongitude: Double,
        excluded: List<Pair<Double, Double>>,
        startHeadingDegrees: Double? = null,
        startRadiusMeters: Int = 120
    ): org.json.JSONObject {
        val e = requireNotNull(engine)
        val actorField = e.javaClass.declaredFields.firstOrNull { it.name == "valhallaActor" }
            ?: throw IllegalStateException("Acteur Valhalla local introuvable")
        actorField.isAccessible = true
        val actor = actorField.get(e) ?: throw IllegalStateException("Acteur Valhalla local nul")
        val method = actor.javaClass.methods.firstOrNull {
            it.name == "route" && it.parameterTypes.contentEquals(arrayOf(String::class.java))
        } ?: throw IllegalStateException("API route(String) locale indisponible")

        val request = org.json.JSONObject().apply {
            put("locations", org.json.JSONArray().apply {
                put(org.json.JSONObject().apply {
                    put("lat", startLatitude)
                    put("lon", startLongitude)
                    put("radius", startRadiusMeters.coerceIn(25, 200))
                    // ETAPE 125 : ne PAS transmettre heading/heading_tolerance au moteur
                    // Valhalla embarqué. Sur la version native actuellement intégrée, cette
                    // option peut provoquer un crash natif du processus Android. Le cap GPS
                    // reste utilisé après calcul pour contrôler le sens du trajet, et le
                    // secours Internet conserve sa contrainte heading lorsqu'elle est sûre.
                })
                put(org.json.JSONObject().put("lat", endLatitude).put("lon", endLongitude).put("radius", 120))
            })
            if (excluded.isNotEmpty()) {
                put("exclude_locations", org.json.JSONArray().apply {
                    excluded.forEach { (lat, lon) ->
                        put(org.json.JSONObject().put("lat", lat).put("lon", lon).put("radius", 90))
                    }
                })
            }
            put("costing", "auto")
            put("costing_options", org.json.JSONObject().put("auto", org.json.JSONObject()
                .put("use_highways", 0.0)
                .put("use_tolls", 0.0)
                .put("use_ferry", 0.0)
                .put("top_speed", 45)
                .put("fixed_speed", 45)
                .put("ignore_access", false)
                .put("ignore_restrictions", false)
                .put("ignore_closures", false)))
            put("directions_options", org.json.JSONObject()
                .put("language", "fr-FR")
                .put("units", "kilometers")
                // ETAPE 49 : demander explicitement les manœuvres de sortie de rond-point.
                // Certaines versions embarquées de Valhalla ne doivent pas dépendre de la
                // valeur par défaut si l’on veut garantir que chaque rond-point intermédiaire
                // reste présent dans la liste de guidage.
                .put("roundabout_exits", true))
        }
        val raw = method.invoke(actor, request.toString()) as? String
            ?: throw IllegalStateException("Réponse route locale non textuelle")
        val root = org.json.JSONObject(raw)
        if (root.has("error") || root.has("error_code") || (root.has("code") && !root.has("trip"))) {
            throw IllegalStateException("Valhalla local : ${root.optString("error", root.optString("message", root.optString("error_code")))}")
        }
        return root
    }

    private fun decodePolyline6Local(encoded: String): List<Pair<Double, Double>> {
        val points = mutableListOf<Pair<Double, Double>>()
        var index = 0; var lat = 0; var lon = 0
        while (index < encoded.length) {
            fun nextDelta(): Int {
                var result = 0; var shift = 0; var b: Int
                do {
                    b = encoded[index++].code - 63
                    result = result or ((b and 0x1f) shl shift)
                    shift += 5
                } while (b >= 0x20 && index < encoded.length)
                return if ((result and 1) != 0) (result shr 1).inv() else result shr 1
            }
            lat += nextDelta(); if (index > encoded.length) break
            lon += nextDelta()
            points += lat / 1_000_000.0 to lon / 1_000_000.0
        }
        return points
    }

    private fun forbiddenMotorwayAvoidancePoints(shape: String, edges: List<TraceEdgeDiagnostic>): List<Pair<Double, Double>> {
        val points = decodePolyline6Local(shape)
        if (points.size < 2) return emptyList()
        val total = edges.sumOf { it.lengthKm ?: 0.0 }.takeIf { it > 0.0 } ?: return emptyList()
        var cumulative = 0.0
        val result = mutableListOf<Pair<Double, Double>>()
        edges.forEach { edge ->
            val len = edge.lengthKm ?: 0.0
            if (edge.roadClass?.equals("motorway", ignoreCase = true) == true) {
                val fraction = ((cumulative + len / 2.0) / total).coerceIn(0.0, 1.0)
                val idx = (fraction * (points.lastIndex)).toInt().coerceIn(0, points.lastIndex)
                val p = points[idx]
                if (result.none { kotlin.math.abs(it.first - p.first) < 0.0007 && kotlin.math.abs(it.second - p.second) < 0.0007 }) result += p
            }
            cumulative += len
        }
        return result.take(6)
    }

    /** Calcul local compatible avec le parseur JSON existant, avec recalcul automatique.
     * Étape 76 : seule la classe motorway est un rejet automatique dans les attributs
     * actuellement exposés par Valhalla. Une classe trunk, une bretelle ou une vitesse
     * élevée restent signalées au diagnostic mais ne prouvent pas à elles seules une
     * interdiction réglementaire pour une VSP. Chaque candidat est revalidé par
     * trace_attributes et tout motorway déclenche un recalcul avec zone d'évitement. */
    fun calculateRouteJson(
        startLatitude: Double,
        startLongitude: Double,
        endLatitude: Double,
        endLongitude: Double,
        startHeadingDegrees: Double? = null,
        startRadiusMeters: Int = 120
    ): Result<org.json.JSONObject> = runCatching {
        val initialization = initialize()
        if (initialization is InitializationResult.Failed) error(initialization.message)
        val excluded = mutableListOf<Pair<Double, Double>>()
        var lastMotorwayCount = 0
        var lastCheckedEdges = 0
        // ETAPE 125 : le rayon sert à privilégier la route réellement occupée sans
        // transmettre de champ heading au moteur natif. Si le premier candidat repart
        // à l'opposé du cap GPS, une seconde tentative locale utilise 35 m.
        var effectiveStartRadius = startRadiusMeters.coerceIn(25, 200)
        repeat(6) { attempt ->
            val json = rawLocalRoute(
                startLatitude, startLongitude, endLatitude, endLongitude, excluded,
                startHeadingDegrees = null,
                startRadiusMeters = effectiveStartRadius
            )
            val legs = json.optJSONObject("trip")?.optJSONArray("legs")
                ?: throw IllegalStateException("VSP_VALIDATION_IMPOSSIBLE: réponse locale sans legs")
            var checkedEdges = 0
            var motorwayEdges = 0
            var trunkEdges = 0
            val candidateEdges = mutableListOf<TraceEdgeDiagnostic>()
            val newlyExcluded = mutableListOf<Pair<Double, Double>>()
            for (i in 0 until legs.length()) {
                val shape = legs.optJSONObject(i)?.optString("shape").orEmpty()
                if (shape.isBlank()) throw IllegalStateException("VSP_VALIDATION_IMPOSSIBLE: géométrie locale absente")
                val (edges, status) = traceAttributesForShape(shape)
                if (edges.isEmpty()) throw IllegalStateException("VSP_VALIDATION_IMPOSSIBLE: $status")
                checkedEdges += edges.size
                candidateEdges += edges
                motorwayEdges += edges.count { it.roadClass?.equals("motorway", ignoreCase = true) == true }
                trunkEdges += edges.count { it.roadClass?.equals("trunk", ignoreCase = true) == true }
                newlyExcluded += forbiddenMotorwayAvoidancePoints(shape, edges)
            }
            lastMotorwayCount = motorwayEdges
            lastCheckedEdges = checkedEdges
            if (motorwayEdges == 0) {
                // ETAPE 125 : contrôle directionnel APRES le calcul local. Cela évite
                // le crash natif observé avec heading dans la requête embarquée tout en
                // empêchant de publier un trajet qui repart derrière le véhicule.
                if (startHeadingDegrees != null && startHeadingDegrees.isFinite()) {
                    val firstShape = legs.optJSONObject(0)?.optString("shape").orEmpty()
                    val routePoints = decodePolyline6Local(firstShape)
                    val departureHeading = routeDepartureBearingLocal(routePoints)
                        ?: throw IllegalStateException("LOCAL_REROUTE_DIRECTION_UNKNOWN: cap de départ introuvable")
                    val difference = headingDifferenceLocal(startHeadingDegrees, departureHeading)
                    if (difference > 70.0) {
                        if (effectiveStartRadius > 35 && attempt < 5) {
                            effectiveStartRadius = 35
                            return@repeat
                        }
                        throw IllegalStateException(
                            "LOCAL_REROUTE_WRONG_DIRECTION: écart ${"%.0f".format(java.util.Locale.FRANCE, difference)}°"
                        )
                    }
                    json.put("_vsp_reroute_direction", org.json.JSONObject().apply {
                        put("gps_heading", startHeadingDegrees)
                        put("route_heading", departureHeading)
                        put("difference", difference)
                        put("snap_radius_m", effectiveStartRadius)
                        put("heading_sent_to_native", false)
                    })
                }

                // Étape 29 : attacher au trajet réellement retenu la preuve technique
                // issue du trace_attributes de CE candidat, pas d'un ancien aperçu.
                val rampCandidates = candidateEdges.filter { it.use?.equals("ramp", ignoreCase = true) == true }
                val rampEdges = rampCandidates.size
                val highSpeedCandidates = candidateEdges.filter { (it.speedLimit ?: it.speed ?: 0.0) > 70.0 }
                val highSpeedEdges = highSpeedCandidates.size
                val accessFields = candidateEdges.sumOf { edge -> edge.exposedFields.count { it.contains("access", ignoreCase = true) } }
                // ETAPE 105 : calculer la topologie de chaque rond-point sur CE trajet puis
                // appliquer immédiatement le compteur corrigé aux manœuvres 26/27.
                // Ainsi affichage, voix et tests lisent tous la même valeur.
                val roundaboutAudit105 = org.json.JSONArray()
                for (legIndex in 0 until legs.length()) {
                    val leg = legs.optJSONObject(legIndex)
                    val legShape = leg?.optString("shape").orEmpty()
                    val audit = if (legShape.isNotBlank()) roundaboutExitAuditForShape(legShape) else org.json.JSONArray()
                    if (leg != null && audit.length() > 0) {
                        applyRoundaboutTopologyV105(leg, audit)
                    }
                    roundaboutAudit105.put(audit)
                }
                json.put("_vsp_roundabout_audit", roundaboutAudit105)
                json.put("_vsp_validation", org.json.JSONObject().apply {
                    put("attempt", attempt + 1)
                    put("checked_edges", checkedEdges)
                    put("motorway", 0)
                    put("trunk", trunkEdges)
                    put("ramps", rampEdges)
                    // Étape 78 : conserver le détail des bretelles du candidat retenu.
                    // Une bretelle n'est pas rejetée sur son seul usage="ramp" : son
                    // road_class, son nom et ses vitesses sont exposés pour audit.
                    put("ramp_edges", org.json.JSONArray().apply {
                        rampCandidates.forEach { edge ->
                            put(org.json.JSONObject().apply {
                                put("index", edge.index)
                                put("name", edge.names.firstOrNull() ?: "voie non nommée")
                                put("road_class", edge.roadClass ?: "inconnu")
                                put("use", edge.use ?: "inconnu")
                                edge.speed?.let { put("speed", it) }
                                edge.speedLimit?.let { put("speed_limit", it) }
                                edge.lengthKm?.let { put("length_km", it) }
                                edge.toll?.let { put("toll", it) }
                                edge.traversability?.let { put("traversability", it) }
                            })
                        }
                    })
                    put("high_speed", highSpeedEdges)
                    put("high_speed_edges", org.json.JSONArray().apply {
                        highSpeedCandidates.forEach { edge ->
                            put(org.json.JSONObject().apply {
                                put("index", edge.index)
                                put("name", edge.names.firstOrNull() ?: "voie non nommée")
                                put("road_class", edge.roadClass ?: "inconnu")
                                put("use", edge.use ?: "inconnu")
                                edge.speed?.let { put("speed", it) }
                                edge.speedLimit?.let { put("speed_limit", it) }
                                edge.lengthKm?.let { put("length_km", it) }
                                edge.toll?.let { put("toll", it) }
                                edge.traversability?.let { put("traversability", it) }
                            })
                        }
                    })
                    put("access_fields", accessFields)
                    put("status", "ACCEPTED_VSP_ZERO_MOTORWAY_TRUNK_CONTROL_ONLY")
                })
                return@runCatching json
            }
            if (attempt < 5) {
                newlyExcluded.forEach { p ->
                    if (excluded.none { kotlin.math.abs(it.first - p.first) < 0.0007 && kotlin.math.abs(it.second - p.second) < 0.0007 }) excluded += p
                }
                if (newlyExcluded.isEmpty()) throw IllegalStateException("VSP_REJECT_MOTORWAY: motorway=$motorwayEdges sur $checkedEdges ; détour local impossible")
            }
        }
        throw IllegalStateException("VSP_REJECT_MOTORWAY: des voies motorway restent présentes sur $lastCheckedEdges après 6 tentatives locales")
    }

    /**
     * ETAPE 124 : autotest du recalcul directionnel, sans modifier la navigation affichée.
     *
     * 1) calcule un trajet local de référence dans la zone du pack régional ;
     * 2) choisit un point situé plus loin sur ce trajet ;
     * 3) décale ce point d'environ 20 m pour simuler un GPS qui vient de quitter l'axe ;
     * 4) recalcule avec un rayon d'accrochage de 70 m, puis 35 m si nécessaire ;
     * 5) contrôle le cap du nouveau trajet après calcul, sans envoyer heading au moteur natif.
     *
     * Le test n'écrit dans aucun état de navigation et peut donc être lancé à l'arrêt.
     */
    @Synchronized
    fun runDirectionalRerouteSelfTest(): Result<String> = runCatching {
        val startLat = 50.425
        val startLon = 2.710
        val endLat = 50.429
        val endLon = 2.831

        val baseline = calculateRouteJson(
            startLatitude = startLat,
            startLongitude = startLon,
            endLatitude = endLat,
            endLongitude = endLon
        ).getOrThrow()

        fun firstShape(json: org.json.JSONObject): String =
            json.optJSONObject("trip")
                ?.optJSONArray("legs")
                ?.optJSONObject(0)
                ?.optString("shape")
                .orEmpty()

        val baselinePoints = decodePolyline6Local(firstShape(baseline))
        require(baselinePoints.size >= 8) { "Trajet de référence trop court pour tester le recalcul" }

        val testIndex = (baselinePoints.lastIndex * 0.28).toInt()
            .coerceIn(2, baselinePoints.lastIndex - 3)
        val lookAheadIndex = (testIndex + 5).coerceAtMost(baselinePoints.lastIndex)
        val base = baselinePoints[testIndex]
        val ahead = baselinePoints[lookAheadIndex]
        val expectedHeading = bearingDegreesLocal(base.first, base.second, ahead.first, ahead.second)

        // Décalage latéral volontaire : environ 20 m à droite du sens de circulation.
        // Cela imite une position GPS / une déviation proche d'une rue parallèle tout en
        // restant dans le rayon strict de 70 m utilisé par le recalcul.
        val shifted = offsetPointLocal(
            latitude = base.first,
            longitude = base.second,
            bearingDegrees = expectedHeading + 90.0,
            meters = 20.0
        )

        val reroute = calculateRouteJson(
            startLatitude = shifted.first,
            startLongitude = shifted.second,
            endLatitude = endLat,
            endLongitude = endLon,
            startHeadingDegrees = expectedHeading,
            startRadiusMeters = 70
        ).getOrThrow()

        val reroutePoints = decodePolyline6Local(firstShape(reroute))
        require(reroutePoints.size >= 2) { "Recalcul sans géométrie exploitable" }
        val actualHeading = routeDepartureBearingLocal(reroutePoints)
            ?: error("Cap de départ du recalcul introuvable")
        val difference = headingDifferenceLocal(expectedHeading, actualHeading)
        require(difference <= 70.0) {
            "Recalcul local refusé : écart ${"%.0f".format(java.util.Locale.FRANCE, difference)}° (> 70°)"
        }

        "✓ Recalcul directionnel local OK • écart ${"%.0f".format(java.util.Locale.FRANCE, difference)}° • contrôle post-calcul • aucun heading natif"
    }

    private fun headingDifferenceLocal(a: Double, b: Double): Double {
        var diff = kotlin.math.abs((a - b) % 360.0)
        if (diff > 180.0) diff = 360.0 - diff
        return diff
    }

    private fun bearingDegreesLocal(
        lat1: Double,
        lon1: Double,
        lat2: Double,
        lon2: Double
    ): Double {
        val phi1 = Math.toRadians(lat1)
        val phi2 = Math.toRadians(lat2)
        val dLon = Math.toRadians(lon2 - lon1)
        val y = kotlin.math.sin(dLon) * kotlin.math.cos(phi2)
        val x = kotlin.math.cos(phi1) * kotlin.math.sin(phi2) -
            kotlin.math.sin(phi1) * kotlin.math.cos(phi2) * kotlin.math.cos(dLon)
        return (Math.toDegrees(kotlin.math.atan2(y, x)) + 360.0) % 360.0
    }

    private fun distanceMetersLocal(a: Pair<Double, Double>, b: Pair<Double, Double>): Double {
        val result = FloatArray(1)
        android.location.Location.distanceBetween(a.first, a.second, b.first, b.second, result)
        return result[0].toDouble()
    }

    private fun routeDepartureBearingLocal(points: List<Pair<Double, Double>>): Double? {
        if (points.size < 2) return null
        val first = points.first()
        var travelled = 0.0
        for (i in 1 until points.size) {
            travelled += distanceMetersLocal(points[i - 1], points[i])
            if (travelled >= 35.0) {
                val p = points[i]
                return bearingDegreesLocal(first.first, first.second, p.first, p.second)
            }
        }
        val last = points.last()
        return bearingDegreesLocal(first.first, first.second, last.first, last.second)
    }

    private fun offsetPointLocal(
        latitude: Double,
        longitude: Double,
        bearingDegrees: Double,
        meters: Double
    ): Pair<Double, Double> {
        val radius = 6_371_000.0
        val angular = meters / radius
        val bearing = Math.toRadians(((bearingDegrees % 360.0) + 360.0) % 360.0)
        val lat1 = Math.toRadians(latitude)
        val lon1 = Math.toRadians(longitude)
        val lat2 = kotlin.math.asin(
            kotlin.math.sin(lat1) * kotlin.math.cos(angular) +
                kotlin.math.cos(lat1) * kotlin.math.sin(angular) * kotlin.math.cos(bearing)
        )
        val lon2 = lon1 + kotlin.math.atan2(
            kotlin.math.sin(bearing) * kotlin.math.sin(angular) * kotlin.math.cos(lat1),
            kotlin.math.cos(angular) - kotlin.math.sin(lat1) * kotlin.math.sin(lat2)
        )
        return Math.toDegrees(lat2) to Math.toDegrees(lon2)
    }

    /** Étape 15 : géométries de comparaison, sans effet sur la navigation. */
    data class PreviewManeuver(
        val instruction: String,
        val beginShapeIndex: Int,
        val endShapeIndex: Int,
        val streetNames: List<String>,
        val lengthKm: Double,
        val timeSeconds: Double,
        val maneuverType: Int,
        val exposedFields: List<String>,
        val nativeFields: Map<String, String>
    )

    data class TraceEdgeDiagnostic(
        val index: Int,
        val names: List<String>,
        val roadClass: String?,
        val use: String?,
        val speed: Double?,
        val speedLimit: Double?,
        val lengthKm: Double?,
        val toll: Boolean?,
        val traversability: String?,
        val exposedFields: List<String>
    )

    data class ProfilePreview(
        val label: String,
        val info: String,
        val encodedShape: String,
        val instructions: List<String>,
        val maneuvers: List<PreviewManeuver>,
        val traceEdges: List<TraceEdgeDiagnostic>,
        val traceStatus: String
    )

    /** Étape 22 : appelle trace_attributes entièrement hors ligne via l'acteur natif
     * déjà embarqué dans valhalla-mobile 0.6.4. Le chemin par réflexion évite de
     * dépendre ici des modèles générés : si l'API native change, le diagnostic
     * l'indique au lieu d'inventer des attributs. */
    private fun traceAttributesForShape(encodedShape: String): Pair<List<TraceEdgeDiagnostic>, String> {
        return try {
            val e = requireNotNull(engine)
            val actorField = e.javaClass.declaredFields.firstOrNull { it.name == "valhallaActor" }
                ?: return emptyList<TraceEdgeDiagnostic>() to "trace_attributes indisponible : acteur natif introuvable"
            actorField.isAccessible = true
            val actor = actorField.get(e)
                ?: return emptyList<TraceEdgeDiagnostic>() to "trace_attributes indisponible : acteur natif nul"
            val method = actor.javaClass.methods.firstOrNull { it.name == "traceAttributes" && it.parameterTypes.contentEquals(arrayOf(String::class.java)) }
                ?: return emptyList<TraceEdgeDiagnostic>() to "trace_attributes indisponible dans cette bibliothèque"

            val request = org.json.JSONObject()
                .put("encoded_polyline", encodedShape)
                .put("shape_match", "edge_walk")
                .put("costing", "auto")
                .put("filters", org.json.JSONObject()
                    .put("action", "include")
                    .put("attributes", org.json.JSONArray(listOf(
                        "edge.names", "edge.road_class", "edge.use", "edge.length",
                        "edge.speed", "edge.speed_limit", "edge.toll", "edge.traversability",
                        "edge.drive_on_right", "edge.surface", "edge.unpaved", "edge.osm_id"
                    ))))
            val raw = method.invoke(actor, request.toString()) as? String
                ?: return emptyList<TraceEdgeDiagnostic>() to "trace_attributes : réponse native non textuelle"
            val root = org.json.JSONObject(raw)
            if (root.has("error") || root.has("error_code"))
                return emptyList<TraceEdgeDiagnostic>() to "trace_attributes refusé : ${root.optString("error", root.optString("error_code"))}"
            val edges = root.optJSONArray("edges")
                ?: return emptyList<TraceEdgeDiagnostic>() to "trace_attributes répond mais n'expose pas de tableau edges"
            val parsed = (0 until edges.length()).mapNotNull { i ->
                val edge = edges.optJSONObject(i) ?: return@mapNotNull null
                val namesArray = edge.optJSONArray("names")
                val names = (0 until (namesArray?.length() ?: 0)).mapNotNull { j -> namesArray?.optString(j)?.takeIf(String::isNotBlank) }
                fun d(key: String): Double? = if (edge.has(key) && !edge.isNull(key)) edge.optDouble(key).takeIf { it.isFinite() } else null
                fun b(key: String): Boolean? = if (edge.has(key) && !edge.isNull(key)) edge.optBoolean(key) else null
                fun st(key: String): String? = edge.optString(key).takeIf { it.isNotBlank() }
                TraceEdgeDiagnostic(i + 1, names, st("road_class"), st("use"), d("speed"), d("speed_limit"), d("length"), b("toll"), st("traversability"), edge.keys().asSequence().toList().sorted())
            }
            parsed to "trace_attributes local OK • ${parsed.size} arête(s)"
        } catch (t: Throwable) {
            emptyList<TraceEdgeDiagnostic>() to "trace_attributes local en échec : ${t.cause?.message ?: t.message ?: t.javaClass.simpleName}"
        }
    }

    /** ETAPE 105 : compte le numéro de sortie à partir de la topologie DU CHEMIN.
     *
     * Point clé découvert sur le cas réel Route de Béthune : au dernier noeud du
     * rond-point, l'arête choisie par notre trajet est le "to-edge" et n'apparait
     * donc pas dans intersecting_edges. En revanche, la continuation NON choisie
     * de l'anneau peut apparaitre dans intersecting_edges et avait été comptée à tort
     * comme une sortie par V95-V99.
     *
     * V105 ne compte donc les branches latérales que sur les noeuds intermédiaires
     * du rond-point (jamais sur le dernier noeud), puis ajoute exactement +1 pour la
     * sortie réellement empruntée par le trajet. Sur un rond-point réduit à une seule
     * arête de chemin, cela donne naturellement "1re sortie".
     *
     * Sur un noeud intermédiaire, la continuation de l'anneau est le to-edge du chemin
     * et est absente de intersecting_edges. Les intersecting_edges restant sont donc
     * de vraies branches latérales. On ne retient que celles carrossables DEPUIS le
     * noeud (driveability=forward/both), en excluant les accès non routiers / parking
     * / desserte privée, puis on déduplique les voies quasi parallèles d'une même branche.
     */
    private fun roundaboutExitAuditForShape(encodedShape: String): org.json.JSONArray {
        return try {
            val e = requireNotNull(engine)
            val actorField = e.javaClass.declaredFields.firstOrNull { it.name == "valhallaActor" }
                ?: return org.json.JSONArray()
            actorField.isAccessible = true
            val actor = actorField.get(e) ?: return org.json.JSONArray()
            val method = actor.javaClass.methods.firstOrNull {
                it.name == "traceAttributes" && it.parameterTypes.contentEquals(arrayOf(String::class.java))
            } ?: return org.json.JSONArray()

            val attrs = listOf(
                "edge.roundabout", "edge.begin_shape_index", "edge.end_shape_index",
                "edge.road_class", "edge.use", "edge.traversability",
                "node.intersecting_edge.begin_heading", "node.intersecting_edge.driveability",
                "node.intersecting_edge.use", "node.intersecting_edge.road_class"
            )
            val request = org.json.JSONObject()
                .put("encoded_polyline", encodedShape)
                .put("shape_match", "edge_walk")
                .put("costing", "auto")
                .put("filters", org.json.JSONObject()
                    .put("action", "include")
                    .put("attributes", org.json.JSONArray(attrs)))
            val raw = method.invoke(actor, request.toString()) as? String ?: return org.json.JSONArray()
            val edges = org.json.JSONObject(raw).optJSONArray("edges") ?: return org.json.JSONArray()

            fun angularDistance105(a: Double, b: Double): Double {
                val d = kotlin.math.abs(a - b) % 360.0
                return kotlin.math.min(d, 360.0 - d)
            }

            // Les accès de desserte/parking ne doivent pas devenir une "sortie" vocale.
            // Les routes normales (residential, tertiary, secondary, primary...) restent comptées.
            val excludedUses105 = setOf(
                "footway", "sidewalk", "steps", "cycleway", "path", "pedestrian",
                "parking_aisle", "driveway", "service_road", "drive_through",
                "emergency_access", "track", "alley"
            )

            val out = org.json.JSONArray()
            var i = 0
            while (i < edges.length()) {
                val first = edges.optJSONObject(i)
                if (first?.optBoolean("roundabout", false) != true) {
                    i++
                    continue
                }

                val startEdge = i
                var endEdge = i
                while (endEdge + 1 < edges.length() &&
                    edges.optJSONObject(endEdge + 1)?.optBoolean("roundabout", false) == true) {
                    endEdge++
                }

                val entryShapeIndex = edges.optJSONObject(startEdge)?.optInt("begin_shape_index", -1) ?: -1
                val exitShapeIndex = edges.optJSONObject(endEdge)?.optInt("end_shape_index", -1) ?: -1
                var priorUsableExits = 0
                val branchDebug = org.json.JSONArray()

                // IMPORTANT V105 : endEdge est EXCLU.
                // Au dernier noeud, le to-edge est notre sortie et la continuation de l'anneau
                // devient un intersecting_edge. La compter ici transformerait une 1re sortie en 2e.
                for (edgeIndex in startEdge until endEdge) {
                    val edge = edges.optJSONObject(edgeIndex) ?: continue
                    val intersections = edge.optJSONObject("end_node")?.optJSONArray("intersecting_edges")
                        ?: continue
                    val uniqueHeadings = mutableListOf<Double>()

                    for (j in 0 until intersections.length()) {
                        val branch = intersections.optJSONObject(j) ?: continue
                        val driveability = branch.optString("driveability", "")
                            .lowercase(java.util.Locale.ROOT)
                        if (driveability != "forward" && driveability != "both") continue

                        val use = branch.optString("use", "").lowercase(java.util.Locale.ROOT)
                        val roadClass = branch.optString("road_class", "").lowercase(java.util.Locale.ROOT)
                        if (use in excludedUses105 || roadClass.isBlank()) continue

                        val heading = branch.optDouble("begin_heading", Double.NaN)
                        if (!heading.isFinite()) continue

                        // Une chaussée divisée / deux arêtes parallèles au même noeud représentent
                        // souvent une seule sortie physique. 25° garde les branches distinctes tout
                        // en supprimant ce doublonnage de graphe.
                        if (uniqueHeadings.none { angularDistance105(it, heading) < 25.0 }) {
                            uniqueHeadings += heading
                        }
                    }

                    priorUsableExits += uniqueHeadings.size
                    if (uniqueHeadings.isNotEmpty()) {
                        branchDebug.put(org.json.JSONObject().apply {
                            put("edge_index", edgeIndex)
                            put("shape_index", edge.optInt("end_shape_index", -1))
                            put("count", uniqueHeadings.size)
                            put("headings", org.json.JSONArray(uniqueHeadings))
                        })
                    }
                }

                if (entryShapeIndex >= 0 && exitShapeIndex >= 0) {
                    out.put(org.json.JSONObject().apply {
                        put("entry_edge", startEdge)
                        put("exit_edge", endEdge)
                        put("entry_shape_index", entryShapeIndex)
                        put("exit_shape_index", exitShapeIndex)
                        put("exit_count", priorUsableExits + 1)
                        put("prior_usable_exits", priorUsableExits)
                        put("branches", branchDebug)
                        put("source", "v105_path_topology")
                    })
                }

                i = endEdge + 1
            }
            out
        } catch (_: Throwable) {
            org.json.JSONArray()
        }
    }

    /** ETAPE 105 : remplace le compteur Odin uniquement quand la topologie locale
     * du même trajet a fourni un groupe de rond-point non ambigu. La valeur est
     * appliquée au couple ENTER(26)/EXIT(27), ce qui donne une source unique à
     * l'affichage, la voix et au banc de tests sans réintroduire les heuristiques V95-V99. */
    private fun applyRoundaboutTopologyV105(
        leg: org.json.JSONObject,
        audit: org.json.JSONArray
    ) {
        val maneuvers = leg.optJSONArray("maneuvers") ?: return
        for (a in 0 until audit.length()) {
            val item = audit.optJSONObject(a) ?: continue
            val entryShape = item.optInt("entry_shape_index", -1)
            val exitShape = item.optInt("exit_shape_index", -1)
            val topologyCount = item.optInt("exit_count", 0)
            if (entryShape < 0 || exitShape < 0 || topologyCount !in 1..12) continue

            var enterIndex = -1
            var exitIndex = -1
            var bestEnterDelta = Int.MAX_VALUE
            var bestExitDelta = Int.MAX_VALUE

            for (m in 0 until maneuvers.length()) {
                val maneuver = maneuvers.optJSONObject(m) ?: continue
                when (maneuver.optInt("type", -1)) {
                    26 -> {
                        val delta = kotlin.math.abs(maneuver.optInt("begin_shape_index", -1000000) - entryShape)
                        if (delta < bestEnterDelta) {
                            bestEnterDelta = delta
                            enterIndex = m
                        }
                    }
                    27 -> {
                        val delta = kotlin.math.abs(maneuver.optInt("begin_shape_index", -1000000) - exitShape)
                        if (delta < bestExitDelta) {
                            bestExitDelta = delta
                            exitIndex = m
                        }
                    }
                }
            }

            // Les indices du trace_attributes et des directions proviennent de la même
            // shape Valhalla. Une tolérance de 2 points couvre seulement les coupures de
            // forme internes, sans risquer d'associer le rond-point voisin.
            if (enterIndex >= 0 && bestEnterDelta <= 2) {
                maneuvers.optJSONObject(enterIndex)?.let { maneuver ->
                    item.put("odin_exit_count", maneuver.optInt("roundabout_exit_count", 0))
                    maneuver.put("roundabout_exit_count", topologyCount)
                    maneuver.put("_vsp_roundabout_exit_source", "v105_path_topology")
                }
            }
            if (exitIndex >= 0 && bestExitDelta <= 2) {
                maneuvers.optJSONObject(exitIndex)?.apply {
                    put("roundabout_exit_count", topologyCount)
                    put("_vsp_roundabout_exit_source", "v105_path_topology")
                }
            }
        }
    }

    @Synchronized
    fun previewProfiles(startLatitude: Double, startLongitude: Double, endLatitude: Double, endLongitude: Double): Result<List<ProfilePreview>> = runCatching {
        val init = initialize()
        if (init is InitializationResult.Failed) error(init.message)
        listOf("auto" to CostingModel.auto, "motor_scooter" to CostingModel.motor_scooter).map { (label, model) ->
            val request = RouteRequest(
                locations = listOf(RoutingWaypoint(lat = startLatitude, lon = startLongitude), RoutingWaypoint(lat = endLatitude, lon = endLongitude)),
                costing = model
            )
            val json = routeResponseForGps(requireNotNull(engine).route(request)).getJSONObject("trip")
            val summary = json.getJSONObject("summary")
            val legs = json.getJSONArray("legs")
            require(legs.length() > 0) { "Aucun tronçon $label" }
            val leg = legs.getJSONObject(0)
            val maneuvers = leg.optJSONArray("maneuvers")
            val previewManeuvers = (0 until (maneuvers?.length() ?: 0)).map { index ->
                val maneuver = maneuvers!!.getJSONObject(index)
                val namesJson = maneuver.optJSONArray("street_names")
                val names = (0 until (namesJson?.length() ?: 0)).map { namesJson!!.optString(it) }.filter { it.isNotBlank() }
                PreviewManeuver(
                    instruction = maneuver.optString("instruction"),
                    beginShapeIndex = maneuver.optInt("begin_shape_index", -1),
                    endShapeIndex = maneuver.optInt("end_shape_index", -1),
                    streetNames = names,
                    lengthKm = maneuver.optDouble("length", Double.NaN),
                    timeSeconds = maneuver.optDouble("time", Double.NaN),
                    maneuverType = maneuver.optInt("type", -1),
                    exposedFields = maneuver.keys().asSequence().toList().sorted(),
                    nativeFields = maneuver.optJSONObject("native_fields")?.let { nf ->
                        nf.keys().asSequence().associateWith { key -> nf.opt(key)?.toString().orEmpty() }
                    }.orEmpty()
                )
            }
            val instructions = previewManeuvers.map { it.instruction }.filter { it.isNotBlank() }
            val km = summary.getDouble("length")
            val minutes = summary.getDouble("time") / 60.0
            val encodedShape = leg.getString("shape")
            val (traceEdges, traceStatus) = traceAttributesForShape(encodedShape)
            ProfilePreview(label, "${"%.2f".format(java.util.Locale.FRANCE, km)} km • ${"%.0f".format(java.util.Locale.FRANCE, minutes)} min (moteur)", encodedShape, instructions, previewManeuvers, traceEdges, traceStatus)
        }
    }

    /** Étape 14 : comparaison expérimentale, sans modifier le guidage principal. */
    @Synchronized
    fun compareProfiles(
        startLatitude: Double, startLongitude: Double,
        endLatitude: Double, endLongitude: Double
    ): String {
        val init = initialize()
        if (init is InitializationResult.Failed) return "Initialisation : ${init.message}"
        fun test(label: String, model: CostingModel): String = try {
            val request = RouteRequest(
                locations = listOf(
                    RoutingWaypoint(lat = startLatitude, lon = startLongitude),
                    RoutingWaypoint(lat = endLatitude, lon = endLongitude)
                ),
                costing = model
            )
            val json = routeResponseForGps(requireNotNull(engine).route(request))
            val summary = json.getJSONObject("trip").getJSONObject("summary")
            val distance = summary.optDouble("length", Double.NaN)
            val seconds = summary.optDouble("time", Double.NaN)
            if (!distance.isFinite() || !seconds.isFinite()) "$label : résumé incomplet"
            else "$label : ${"%.2f".format(java.util.Locale.FRANCE, distance)} km • ${"%.0f".format(java.util.Locale.FRANCE, seconds / 60.0)} min (moteur)"
        } catch (error: Exception) {
            "$label : échec (${error.message ?: error.javaClass.simpleName})"
        }
        return test("auto", CostingModel.auto) + "\n" +
            test("motor_scooter", CostingModel.motor_scooter) +
            "\nComparaison expérimentale : aucun itinéraire certifié VSP."
    }

    /** Étape 10 : vérifie aussi la conversion utilisée par le GPS principal. */
    fun validateResponseForGps(response: Any): Result<String> = runCatching {
        val json = routeResponseForGps(response)
        val trip = json.getJSONObject("trip")
        val legs = trip.getJSONArray("legs")
        "conversion GPS OK • legs=${legs.length()}"
    }

    sealed interface LocalRouteResult {
        data class Success(val response: Any) : LocalRouteResult
        data class Failed(val message: String) : LocalRouteResult
    }

    @Synchronized
    override fun close() {
        engine?.close()
        engine = null
    }

    sealed interface InitializationResult {

        data class Ready(
            val tileArchivePath: String
        ) : InitializationResult

        data class Failed(
            val message: String,
            val cause: Throwable? = null
        ) : InitializationResult
    }

    companion object {
        const val TILE_ARCHIVE_NAME =
            "valhalla_tiles.tar"
    }
}