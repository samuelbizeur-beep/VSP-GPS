package fr.vspgps.app

import android.content.Context
import org.osmdroid.util.GeoPoint

/**
 * ETAPE 122 — reprise minimale et sûre d'un trajet après recréation du processus.
 *
 * On ne sérialise volontairement pas le gros tracé Valhalla : au redémarrage, le GPS
 * recalcule depuis la position réellement courante vers la destination conservée.
 * Cela évite de restaurer un ancien tracé devenu faux après un déplacement ou une longue pause.
 */
internal data class StoredActiveTrip(
    val destination: Destination,
    val energyType: EnergyType,
    val savedAtMillis: Long
)

private const val ACTIVE_TRIP_PREFS = "vsp_active_trip"
private const val KEY_ACTIVE = "active"
private const val KEY_LABEL = "label"
private const val KEY_LAT = "lat"
private const val KEY_LON = "lon"
private const val KEY_ENERGY = "energy"
private const val KEY_SAVED_AT = "saved_at"
private const val ACTIVE_TRIP_MAX_AGE_MS = 6L * 60L * 60L * 1000L

internal fun saveStoredActiveTrip(
    context: Context,
    destination: Destination,
    energyType: EnergyType
) {
    context.getSharedPreferences(ACTIVE_TRIP_PREFS, Context.MODE_PRIVATE)
        .edit()
        .putBoolean(KEY_ACTIVE, true)
        .putString(KEY_LABEL, destination.label)
        .putLong(KEY_LAT, java.lang.Double.doubleToRawLongBits(destination.point.latitude))
        .putLong(KEY_LON, java.lang.Double.doubleToRawLongBits(destination.point.longitude))
        .putString(KEY_ENERGY, energyType.name)
        .putLong(KEY_SAVED_AT, System.currentTimeMillis())
        .apply()
}

internal fun clearStoredActiveTrip(context: Context) {
    context.getSharedPreferences(ACTIVE_TRIP_PREFS, Context.MODE_PRIVATE)
        .edit().clear().apply()
}

internal fun loadStoredActiveTrip(context: Context): StoredActiveTrip? {
    val prefs = context.getSharedPreferences(ACTIVE_TRIP_PREFS, Context.MODE_PRIVATE)
    if (!prefs.getBoolean(KEY_ACTIVE, false)) return null

    val savedAt = prefs.getLong(KEY_SAVED_AT, 0L)
    val age = System.currentTimeMillis() - savedAt
    if (savedAt <= 0L || age < 0L || age > ACTIVE_TRIP_MAX_AGE_MS) {
        clearStoredActiveTrip(context)
        return null
    }

    val label = prefs.getString(KEY_LABEL, null)?.trim().orEmpty()
    if (label.isBlank() || !prefs.contains(KEY_LAT) || !prefs.contains(KEY_LON)) {
        clearStoredActiveTrip(context)
        return null
    }

    val latitude = java.lang.Double.longBitsToDouble(prefs.getLong(KEY_LAT, 0L))
    val longitude = java.lang.Double.longBitsToDouble(prefs.getLong(KEY_LON, 0L))
    if (!latitude.isFinite() || !longitude.isFinite() ||
        latitude !in -90.0..90.0 || longitude !in -180.0..180.0
    ) {
        clearStoredActiveTrip(context)
        return null
    }

    val energy = runCatching {
        EnergyType.valueOf(prefs.getString(KEY_ENERGY, EnergyType.ELECTRIC.name)!!)
    }.getOrDefault(EnergyType.ELECTRIC)

    return StoredActiveTrip(
        destination = Destination(label, GeoPoint(latitude, longitude)),
        energyType = energy,
        savedAtMillis = savedAt
    )
}
