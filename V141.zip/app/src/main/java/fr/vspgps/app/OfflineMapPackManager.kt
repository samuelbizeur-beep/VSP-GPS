package fr.vspgps.app

import android.content.Context
import java.io.File
import java.io.InputStream

/**
 * Prépare VSP GPS à recevoir des packs cartographiques Valhalla hors APK.
 *
 * Étape 61 : cette classe n'est volontairement pas encore branchée sur le
 * moteur de navigation validé. Le routeur continue donc d'utiliser le pack
 * Hauts-de-France embarqué. Une étape ultérieure pourra télécharger/importer
 * un pack France puis l'activer après contrôle d'intégrité.
 */
class OfflineMapPackManager(context: Context) {
    private val root = File(context.applicationContext.filesDir, "map_packs")

    data class PackInfo(
        val id: String,
        val file: File,
        val sizeBytes: Long,
        val installed: Boolean
    )

    fun francePack(): PackInfo = info(FRANCE_PACK_ID)
    fun regionalPack(): PackInfo = info(REGIONAL_PACK_ID)

    fun info(id: String): PackInfo {
        val file = File(root, "$id.tar")
        return PackInfo(id, file, if (file.isFile) file.length() else 0L, file.isFile && file.length() > 0L)
    }

    /**
     * Installation atomique : on écrit d'abord .part puis on renomme.
     * Cela évite qu'un téléchargement interrompu soit pris pour une carte valide.
     */
    fun install(id: String, input: InputStream): PackInfo {
        if (!root.exists() && !root.mkdirs()) error("Impossible de créer ${root.absolutePath}")
        val target = File(root, "$id.tar")
        val part = File(root, "$id.tar.part")
        if (part.exists()) part.delete()
        input.use { source -> part.outputStream().buffered(1024 * 1024).use { source.copyTo(it, 1024 * 1024) } }
        require(part.length() > 0L) { "Pack cartographique vide" }
        if (target.exists() && !target.delete()) error("Impossible de remplacer le pack existant")
        if (!part.renameTo(target)) error("Impossible de finaliser le pack cartographique")
        return info(id)
    }

    fun remove(id: String): Boolean {
        File(root, "$id.tar.part").delete()
        val target = File(root, "$id.tar")
        return !target.exists() || target.delete()
    }

    fun backupFile(id: String): File = File(root, "$id.tar.bak")

    fun restoreBackup(id: String): Boolean {
        val backup = backupFile(id)
        if (!backup.isFile) return false
        val target = File(root, "$id.tar")
        if (target.exists() && !target.delete()) return false
        return backup.renameTo(target)
    }

    companion object {
        const val FRANCE_PACK_ID = "france_valhalla"
        const val REGIONAL_PACK_ID = "regional_valhalla"
    }
}
