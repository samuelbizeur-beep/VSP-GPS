// ETAPE 129 — navigation utilisable à l’arrêt : écran maintenu allumé + repère visuel d’arrivée routière.
// ETAPE 124 — recalcul local orienté + autotest à l’arrêt : le cap est transmis au moteur Valhalla local prioritaire.
// ETAPE 123 — recalcul hors itinéraire : départ orienté selon le cap GPS pour éviter les itinéraires qui repartent en arrière.
// ETAPE 120.9 — noms commerciaux : enrichissement ciblé Photon des POI encore génériques.
// ETAPE 120.8 — précision métier : filtrage boulangerie/confiserie et nettoyage requête commune.
// ETAPE 120.6 — recherche catégorie + commune exhaustive par établissements.
// ETAPE 120.5 — POI consolidés : fusion extraite hors Compose, dédoublonnage adresse renforcé, NavigationScreen inchangé.
// ETAPE 120.3 — Correctif VerifyError : NavigationScreen restauré strictement depuis V120.1 ; POI V120.2 conservés.
// ETAPE 114 — Lot recherche/POI + tri proximité + banc de tests navigation élargi.
// ETAPE 119 — POI locaux enrichis : recherche Photon multi-termes + secours SIRENE par section NAF.
// ETAPE 118 — POI locaux : commune GPS, friteries/restauration et dédoublonnage par adresse.
// ETAPE 121 — France entière sécurisée : import isolé, validation hors région et rollback automatique.
// ETAPE 117 — POI fiabilisés : dédoublonnage intelligent, noms utiles et pagination SIRENE locale.
// ETAPE 116 — Annuaire fiabilisé : noms propres, recherche par commune et filtre établissement.
// ETAPE 115 — POI France enrichis : OSM/Photon + Annuaire des Entreprises (SIRENE), tri par distance.
// ETAPE 113 — Recherche par catégorie + commune + tri par distance (Overpass/OSM).
// ETAPE 112 — Recherche commerces/POI renforcée (France, classement multi-mots, secours shop Photon).
// V47 — Recherche POI/commerces enrichie (Photon/OSM prioritaire pour magasins et services).
// V264 — Suivi GPS : borne de recherche avant sécurisée et recalage limité aux segments réellement disponibles.
// V142 — Version normale : diagnostic de recalcul V141 retiré après validation.
// V120 — Reprise GPS sécurisée : 3 positions cohérentes sur le même segment avant de reprendre le guidage.
// V122 — Guidage : sélection de la prochaine manœuvre basée sur le segment réellement occupé, pour éviter de conserver une manœuvre déjà dépassée.
// ETAPE 79 — Nouvelle base visuelle de navigation VSP GPS : bandeau principal sur carte, tracé bleu renforcé.
// V124 — Compteur de vitesse GPS permanent intégré à la carte de navigation, style GPS/Waze.
// V115 — Correction compilation V114 : parallélisation coroutine typée avec async/awaitAll.
// V113 — Tri prix lisible : affiche clairement le carburant et le prix réellement utilisés pour le classement.
// V110 — Fraîcheur des prix : affiche la date/heure de mise à jour DGCCRF quand elle est disponible.
// V111 — Stations : choix Diesel/Essence + tri optionnel par prix compatible, sans considérer E85 comme essence standard.
// V108 — Fiche station cohérente : affiche aussi la durée du trajet VSP validé, identique à la liste et à la navigation.
// V112 — Tri prix sécurisé : seules les stations disposant d’un itinéraire VSP validé sont proposées dans le classement par prix.
// V106 — Durées cohérentes : liste des stations, aperçu, feuille de route et navigation utilisent le même arrondi (minute supérieure).
// V105 — Stations : le bouton Itinéraire réutilise exactement le tracé VSP validé lors du calcul distance/temps.
// V77 — DGCCRF stable + enseignes par OSM puis adresse/commune, sans filtrage.
// VSP GPS V44 DIAGNOSTIC - première borne batterie partielle + distances route VSP
package fr.vspgps.app

// ETAPE 132 — prévol hors ligne + continuité France + garde-fou stockage.

// ETAPE 122 — reprise de session : une navigation active survit à une recréation du processus.


import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import android.Manifest
import android.content.pm.PackageManager
import android.content.pm.ActivityInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.content.Context
import android.location.Geocoder
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import org.osmdroid.config.Configuration
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.util.Locale
 // V260 : nécessaire aux arrondis des annonces vocales.
import com.valhalla.valhalla.Valhalla
import com.valhalla.config.models.ValhallaConfig
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import kotlin.math.roundToInt// V56 — profil VSP universel + refus sûr des trajets interdits + aucun ancien tracé conservé.
enum class VehicleType {
    VSP
}

enum class EnergyType {
    ELECTRIC,
    FUEL
}

enum class FuelType {
    ESSENCE,
    DIESEL
}

// V111 : extrait le prix pertinent pour le carburant choisi.
// Pour l'essence, E85 est volontairement exclu : toutes les VSP essence ne sont pas
// compatibles éthanol. On compare uniquement SP95, E10 et SP98.
private fun preferredFuelPriceEuros(prices: String, fuelType: FuelType): Double? {
    if (prices.isBlank()) return null
    val accepted = if (fuelType == FuelType.DIESEL) {
        setOf("gazole", "diesel")
    } else {
        setOf("sp95", "e10", "sp98")
    }
    val regex = Regex("(?i)(Gazole|Diesel|SP95|E10|SP98)\\s+([0-9]+(?:[,.][0-9]+)?)")
    return regex.findAll(prices).mapNotNull { match ->
        val label = match.groupValues[1].lowercase(Locale.FRANCE)
        if (label !in accepted) null
        else match.groupValues[2].replace(',', '.').toDoubleOrNull()
    }.minOrNull()
}

// V113 : retourne aussi le libellé exact qui justifie le classement affiché.
private fun preferredFuelPriceLabel(prices: String, fuelType: FuelType): String? {
    if (prices.isBlank()) return null
    val accepted = if (fuelType == FuelType.DIESEL) setOf("gazole", "diesel") else setOf("sp95", "e10", "sp98")
    val regex = Regex("(?i)(Gazole|Diesel|SP95|E10|SP98)\\s+([0-9]+(?:[,.][0-9]+)?)")
    val best = regex.findAll(prices).mapNotNull { match ->
        val rawLabel = match.groupValues[1]
        val key = rawLabel.lowercase(Locale.FRANCE)
        val value = match.groupValues[2].replace(',', '.').toDoubleOrNull() ?: return@mapNotNull null
        if (key !in accepted) null else Triple(rawLabel, value, match.groupValues[2])
    }.minByOrNull { it.second } ?: return null
    val label = when (best.first.lowercase(Locale.FRANCE)) {
        "gazole", "diesel" -> "Gazole"
        "sp95" -> "SP95"
        "e10" -> "E10"
        else -> "SP98"
    }
    return "$label ${String.format(Locale.FRANCE, "%.3f", best.second)} €"
}

data class Destination(
    val label: String,
    val point: GeoPoint,
    // ETAPE 113 : distance de tri/affichage pour les recherches par catégorie.
    val distanceMeters: Double? = null
)


// ETAPE 120.5 : la fusion des résultats de catégories est sortie du gros bloc Compose.
// Cela réduit la taille du bytecode généré autour de l'autocomplétion et centralise les
// règles OSM / Photon / SIRENE sans toucher à NavigationScreen ni au guidage.
private fun normalizePoiText1205(value: String): String = java.text.Normalizer.normalize(
    value.lowercase(Locale.FRANCE).replace("œ", "oe").replace("æ", "ae"),
    java.text.Normalizer.Form.NFD
).replace(Regex("\\p{M}+"), "")

private fun mergeCategoryDestinations1205(
    candidates: List<Destination>,
    categoryDisplay: String
): List<Destination> {
    fun cleanPoiLabel(raw: String): String = raw
        .replace(Regex("(?i)^null\\s*,?\\s*"), "")
        .replace(Regex("(?i),\\s*null(?=,|$)"), "")
        .replace(Regex("\\s{2,}"), " ")
        .trim().trim(',').trim()

    fun poiName(label: String): String = label.substringBefore(',').trim()
    fun normalizedPoiName(label: String): String = normalizePoiText1205(poiName(label))
    val genericName = normalizePoiText1205(categoryDisplay)

    fun isGeneric(label: String): Boolean {
        val n = normalizedPoiName(label)
        return n.isBlank() || n == genericName || n == "lieu" || n == "commerce"
    }

    fun categoryAffinity(label: String): Int {
        val n = normalizedPoiName(label)
        if (n.isBlank()) return 0
        val g = genericName
        val roots = when {
            "pharmac" in g -> listOf("pharmac", "officine")
            "boulanger" in g -> listOf("boulanger", "patisser", "pain", "mie")
            "garage" in g -> listOf("garage", "auto", "automobile", "carrosser", "meca", "pneu", "motor")
            "friter" in g -> listOf("friter", "frit", "baraque")
            "pizzer" in g -> listOf("pizza", "pizz")
            else -> g.split(' ').filter { it.length >= 4 }
        }
        return roots.count { it in n }
    }

    fun nameQuality(label: String): Int {
        val name = poiName(label)
        if (isGeneric(label)) return if (label.contains(',')) 1 else 0
        return 3 + categoryAffinity(label) * 2 + if (name.length >= 5) 1 else 0
    }

    fun sameUsefulName(a: String, b: String): Boolean {
        val na = normalizedPoiName(a)
        val nb = normalizedPoiName(b)
        if (na.length < 4 || nb.length < 4) return false
        return na == nb || (na.length >= 7 && nb.length >= 7 && (na.contains(nb) || nb.contains(na)))
    }

    fun addressEvidence(label: String): Pair<String, Set<String>> {
        val raw = normalizePoiText1205(label.substringAfter(',', ""))
        val number = Regex("\\b\\d{1,4}[a-z]?\\b").find(raw)?.value.orEmpty()
        val stop = setOf(
            "rue", "route", "avenue", "av", "boulevard", "bd", "chemin", "place", "allee",
            "impasse", "residence", "zac", "de", "du", "des", "la", "le", "les", "a", "au",
            "aux", "bis", "ter", "france"
        )
        val words = raw.split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.length >= 4 && it !in stop && it.none(Char::isDigit) }
            .toSet()
        return number to words
    }

    fun sameStreetAddress(a: String, b: String): Boolean {
        val ea = addressEvidence(a)
        val eb = addressEvidence(b)
        if (ea.first.isBlank() || eb.first.isBlank() || ea.first != eb.first) return false
        return ea.second.intersect(eb.second).isNotEmpty()
    }

    val cleanedSorted = candidates
        .map { it.copy(label = cleanPoiLabel(it.label)) }
        .filter { it.label.isNotBlank() }
        .filterNot { isGeneric(it.label) && !it.label.contains(',') }
        .sortedBy { it.distanceMeters ?: Double.MAX_VALUE }

    val merged = mutableListOf<Destination>()
    for (candidate in cleanedSorted) {
        var duplicateIndex = -1
        for (idx in merged.indices) {
            val existing = merged[idx]
            val meters = distanceMetersBetween(existing.point, candidate.point)
            val genericPair = isGeneric(existing.label) || isGeneric(candidate.label)
            val sameName = sameUsefulName(existing.label, candidate.label)
            val sameAddress = sameStreetAddress(existing.label, candidate.label)
            // Adresse exacte (numéro + rue) : les géocodeurs peuvent diverger de plusieurs
            // centaines de mètres. Le signal d'adresse est alors plus fort que la coordonnée.
            if ((sameAddress && meters <= 500.0) ||
                (genericPair && meters <= 170.0) ||
                (sameName && meters <= 100.0)) {
                duplicateIndex = idx
                break
            }
        }
        if (duplicateIndex < 0) {
            merged += candidate
        } else {
            val existing = merged[duplicateIndex]
            val qExisting = nameQuality(existing.label)
            val qCandidate = nameQuality(candidate.label)
            if (qCandidate > qExisting ||
                (qCandidate == qExisting && (candidate.distanceMeters ?: Double.MAX_VALUE) <
                    (existing.distanceMeters ?: Double.MAX_VALUE))) {
                merged[duplicateIndex] = candidate
            }
        }
    }

    return merged.sortedBy { it.distanceMeters ?: Double.MAX_VALUE }.take(12)
}

// ETAPE 120.9 : enrichit uniquement les résultats encore génériques (ex. « Boulangerie,
// 157 rue Jules Ferry ») par une recherche Photon centrée sur leur adresse. Cette passe
// est hors Compose et ne touche ni NavigationScreen ni le guidage. Elle conserve la
// position/distance du résultat original et ne remplace le nom que si un POI OSM de la
// même catégorie est retrouvé à proximité avec une adresse cohérente.
private fun photonFeatureMatchesCategory1209(categoryKey: String, properties: JSONObject): Boolean {
    val osmKey = properties.optString("osm_key").lowercase(Locale.FRANCE)
    val osmValue = properties.optString("osm_value").lowercase(Locale.FRANCE)
    val normalizedName = normalizePoiText1205(properties.optString("name"))
    return when (categoryKey) {
        "friterie" -> osmKey == "amenity" && osmValue == "fast_food" &&
            ("frit" in normalizedName || "friterie" in normalizedName || "frituur" in normalizedName)
        "pharmacy" -> osmKey == "amenity" && osmValue == "pharmacy"
        "bakery" -> osmKey == "shop" && osmValue == "bakery"
        "car_repair" -> osmKey == "shop" && osmValue == "car_repair"
        "restaurant" -> osmKey == "amenity" && osmValue == "restaurant"
        "fast_food" -> osmKey == "amenity" && osmValue == "fast_food"
        "pizzeria" -> osmKey == "amenity" && osmValue in setOf("restaurant", "fast_food") &&
            ("pizza" in normalizedName || "pizz" in normalizedName)
        "kebab" -> osmKey == "amenity" && osmValue in setOf("restaurant", "fast_food") &&
            ("kebab" in normalizedName || "doner" in normalizedName || "donner" in normalizedName)
        "supermarket" -> osmKey == "shop" && osmValue in setOf("supermarket", "department_store")
        "hotel" -> osmKey == "tourism" && osmValue == "hotel"
        "hairdresser" -> osmKey == "shop" && osmValue == "hairdresser"
        "tobacco" -> osmKey == "shop" && osmValue == "tobacco"
        "doctor" -> (osmKey == "amenity" && osmValue == "doctors") || (osmKey == "healthcare" && osmValue == "doctor")
        "dentist" -> osmKey == "amenity" && osmValue == "dentist"
        "veterinary" -> osmKey == "amenity" && osmValue == "veterinary"
        "cinema" -> osmKey == "amenity" && osmValue == "cinema"
        "optician" -> osmKey == "shop" && osmValue == "optician"
        "laboratory" -> (osmKey == "healthcare" || osmKey == "amenity") && osmValue == "laboratory"
        "florist" -> osmKey == "shop" && osmValue == "florist"
        "butcher" -> osmKey == "shop" && osmValue == "butcher"
        "convenience" -> osmKey == "shop" && osmValue in setOf("convenience", "general")
        "diy" -> osmKey == "shop" && osmValue in setOf("doityourself", "hardware")
        "vehicle_inspection" -> osmKey == "amenity" && osmValue == "vehicle_inspection"
        else -> false
    }
}

private fun genericCategoryLabel1209(label: String, display: String): Boolean {
    val first = normalizePoiText1205(label.substringBefore(',').trim())
    val generic = normalizePoiText1205(display)
    return first.isBlank() || first == generic || first == "lieu" || first == "commerce"
}

private fun addressNumber1209(raw: String): String =
    Regex("\\b\\d{1,4}[a-z]?\\b", RegexOption.IGNORE_CASE).find(normalizePoiText1205(raw))?.value.orEmpty()

private fun addressStreetWords1209(raw: String): Set<String> {
    val stop = setOf(
        "rue", "route", "avenue", "av", "boulevard", "bd", "chemin", "place", "allee",
        "impasse", "residence", "zac", "de", "du", "des", "la", "le", "les", "a", "au",
        "aux", "bis", "ter", "france"
    )
    return normalizePoiText1205(raw).split(Regex("[^\\p{L}\\p{N}]+"))
        .filter { it.length >= 4 && it !in stop && it.none(Char::isDigit) }
        .toSet()
}

private fun enrichGenericCategoryNames1209(
    client: OkHttpClient,
    candidates: List<Destination>,
    categoryKey: String,
    display: String,
    cityName: String
): List<Destination> {
    if (candidates.none { genericCategoryLabel1209(it.label, display) }) return candidates
    val result = candidates.toMutableList()
    val genericIndexes = result.indices
        .filter { genericCategoryLabel1209(result[it].label, display) }
        .take(6)

    for (index in genericIndexes) {
        val original = result[index]
        val address = original.label.substringAfter(',', "").trim()
        if (address.isBlank()) continue
        val candidateNumber = addressNumber1209(address)
        val candidateStreetWords = addressStreetWords1209(address)
        try {
            val query = listOf(display, address, cityName)
                .filter { it.isNotBlank() }
                .distinct()
                .joinToString(" ")
            val encoded = java.net.URLEncoder.encode(query, "UTF-8")
            val url = "https://photon.komoot.io/api/?q=$encoded&limit=15&lang=fr&countrycode=FR&dedupe=0" +
                "&lat=${original.point.latitude}&lon=${original.point.longitude}&zoom=16&location_bias_scale=0.95"
            val request = Request.Builder().url(url).header("User-Agent", "VSP-GPS/1.0").build()
            var best: Pair<Int, String>? = null
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@use
                val features = JSONObject(response.body?.string().orEmpty()).optJSONArray("features") ?: return@use
                for (i in 0 until features.length()) {
                    val feature = features.optJSONObject(i) ?: continue
                    val properties = feature.optJSONObject("properties") ?: continue
                    if (!photonFeatureMatchesCategory1209(categoryKey, properties)) continue
                    val name = properties.optString("name").trim()
                    if (name.isBlank() || genericCategoryLabel1209(name, display)) continue
                    val coords = feature.optJSONObject("geometry")?.optJSONArray("coordinates") ?: continue
                    if (coords.length() < 2) continue
                    val lon = coords.optDouble(0, Double.NaN)
                    val lat = coords.optDouble(1, Double.NaN)
                    if (!lat.isFinite() || !lon.isFinite()) continue
                    val point = GeoPoint(lat, lon)
                    val meters = distanceMetersBetween(original.point, point)
                    if (meters > 400.0) continue

                    val featureNumber = normalizePoiText1205(properties.optString("housenumber")).trim()
                    if (candidateNumber.isNotBlank() && featureNumber.isNotBlank() &&
                        normalizePoiText1205(candidateNumber) != featureNumber) continue

                    val featureStreet = properties.optString("street").trim()
                    val featureStreetWords = addressStreetWords1209(featureStreet)
                    val streetMatches = candidateStreetWords.isNotEmpty() && featureStreetWords.isNotEmpty() &&
                        candidateStreetWords.intersect(featureStreetWords).isNotEmpty()
                    val exactNumber = candidateNumber.isNotBlank() && featureNumber.isNotBlank() &&
                        normalizePoiText1205(candidateNumber) == featureNumber
                    if (!streetMatches && !exactNumber && meters > 100.0) continue

                    val photonCity = properties.optString("city").trim()
                    if (cityName.isNotBlank() && photonCity.isNotBlank() &&
                        normalizePoiText1205(cityName) != normalizePoiText1205(photonCity)) continue

                    val score = (if (exactNumber) 100 else 0) +
                        (if (streetMatches) 60 else 0) +
                        (40 - (meters / 10.0).toInt().coerceAtMost(40))
                    if (best == null || score > best!!.first) best = score to name
                }
            }
            val betterName = best?.second.orEmpty()
            if (betterName.isNotBlank()) {
                result[index] = original.copy(label = "$betterName, $address")
            }
        } catch (_: Exception) {
            // Enrichissement facultatif : on conserve le résultat générique en cas d'échec réseau.
        }
    }
    return result
}

// ETAPE 120.4 : certaines fiches SIRENE regroupent plusieurs enseignes dans une seule
// chaîne (ex. « BRASSERIE DE LA GRANGE / FRITERIE AIXOISE »). Les séparer permet
// d'afficher l'enseigne qui correspond réellement à la catégorie recherchée sans
// modifier la navigation ni l'initialisation de l'application.
private fun splitPoiBusinessAliases1204(raw: String): List<String> {
    val trimmed = raw.trim()
    if (trimmed.isBlank()) return emptyList()
    val parts = trimmed
        .split(Regex("\\s*(?:/|\\||;|•|·|–|—)\\s*|\\s+-\\s+"))
        .map { it.trim().trim(',', '.', '-', '–', '—') }
        .filter { it.length >= 2 && !it.equals("null", ignoreCase = true) }
    return (if (parts.size >= 2) parts else listOf(trimmed)).distinct()
}

// ETAPE 120.7 : catégories pour lesquelles l'Annuaire/SIRENE peut compléter
// une recherche locale ou « catégorie + commune ». Cette liste reste hors Compose
// pour ne pas regonfler le bytecode du gros écran principal.
private val SIRENE_LOCAL_CATEGORIES_1207 = setOf(
    "pharmacy", "friterie", "fast_food", "kebab", "pizzeria", "restaurant",
    "bakery", "car_repair", "supermarket", "hotel", "hairdresser", "tobacco",
    "doctor", "dentist", "veterinary", "cinema", "optician", "laboratory",
    "florist", "butcher", "convenience", "diy", "vehicle_inspection"
)

// Termes de secours par commune. Le balayage APE reste prioritaire ; ces termes
// récupèrent surtout les enseignes dont la raison sociale/nom commercial est plus
// parlant que le code d'activité de l'unité légale.
private fun sireneMunicipalityNameTerms1207(key: String): List<String> = when (key) {
    "friterie" -> listOf("friterie", "frite", "friture", "frit")
    "pizzeria" -> listOf("pizzeria", "pizza", "pizz")
    "kebab" -> listOf("kebab", "doner")
    "fast_food" -> listOf("restauration rapide", "fast food", "snack")
    "restaurant" -> listOf("restaurant")
    "pharmacy" -> listOf("pharmacie", "officine")
    "bakery" -> listOf("boulangerie", "boulanger", "patisserie")
    "car_repair" -> listOf("garage", "automobile", "auto")
    "supermarket" -> listOf("supermarche", "hypermarche")
    "hotel" -> listOf("hotel")
    "hairdresser" -> listOf("coiffeur", "coiffure")
    "tobacco" -> listOf("tabac", "presse")
    "doctor" -> listOf("medecin", "docteur")
    "dentist" -> listOf("dentiste")
    "veterinary" -> listOf("veterinaire")
    "cinema" -> listOf("cinema")
    "optician" -> listOf("opticien", "optique")
    "laboratory" -> listOf("laboratoire", "biologie")
    "florist" -> listOf("fleuriste", "fleurs")
    "butcher" -> listOf("boucherie", "boucher")
    "convenience" -> listOf("epicerie", "superette")
    "diy" -> listOf("bricolage", "quincaillerie")
    "vehicle_inspection" -> listOf("controle technique")
    else -> emptyList()
}

// Racines utilisées uniquement pour choisir le nom le plus parlant lorsque plusieurs
// enseignes/noms commerciaux sont fournis par SIRENE. Elles n'élargissent pas la
// catégorie : l'APE établissement reste le filtre métier.
private fun poiCategoryNameRoots1207(key: String): List<String> = when (key) {
    "pharmacy" -> listOf("pharmac", "officine")
    "bakery" -> listOf("boulanger", "patisser", "pain", "mie")
    "car_repair" -> listOf("garage", "auto", "automobile", "carrosser", "meca", "moteur", "pneu", "motor")
    "friterie" -> listOf("friter", "frit", "baraque")
    "pizzeria" -> listOf("pizza", "pizz")
    "kebab" -> listOf("kebab", "doner", "donner")
    "fast_food" -> listOf("snack", "fast food", "restauration rapide")
    "restaurant" -> listOf("restaurant", "brasserie", "auberge", "bistrot")
    "supermarket" -> listOf("supermarche", "hypermarche", "market", "marche")
    "hotel" -> listOf("hotel", "auberge")
    "hairdresser" -> listOf("coiff", "hair")
    "tobacco" -> listOf("tabac", "presse")
    "doctor" -> listOf("medecin", "docteur", "medical")
    "dentist" -> listOf("dent", "dentaire")
    "veterinary" -> listOf("veterin")
    "cinema" -> listOf("cinema", "cine")
    "optician" -> listOf("opticien", "optique")
    "laboratory" -> listOf("laboratoire", "biologie", "bio")
    "florist" -> listOf("fleur", "flor")
    "butcher" -> listOf("boucher", "viande")
    "convenience" -> listOf("epicer", "superette", "market")
    "diy" -> listOf("bricol", "quincaill", "materiaux")
    "vehicle_inspection" -> listOf("controle", "technique", "autosur", "dekra", "securitest")
    else -> emptyList()
}

data class RouteOption(
    val points: List<GeoPoint>,
    val distanceMeters: Double,
    val durationSeconds: Double,
    val vspValidated: Boolean = false,
    val maneuvers: List<RouteManeuver> = emptyList()
)


private const val SEARCH_HISTORY_PREFS = "vsp_search_history"
private const val SEARCH_HISTORY_KEY = "recent_destinations"
private const val SEARCH_HISTORY_SEPARATOR = "\u001F"
private const val SEARCH_HISTORY_MAX = 8

private const val FAVORITES_PREFS = "vsp_favorites"
private const val FAVORITE_HOME = "home"
private const val FAVORITE_WORK = "work"
private const val FAVORITE_STAR = "star"

private const val CHARGING_PROFILE_PREFS = "vsp_charging_profile"
private const val CHARGING_CONNECTORS_KEY = "connectors"
private const val CHARGING_PROFILE_CONFIRMED_KEY = "connectors_confirmed_v36"
private val CHARGING_CONNECTOR_CHOICES = listOf("Type 2", "Prise E/F", "CCS Combo 2", "CHAdeMO")

private const val BATTERY_PROFILE_PREFS = "vsp_battery_profile"
private const val BATTERY_MAX_RANGE_KEY = "max_range_km"
private const val BATTERY_LEVEL_KEY = "battery_level_percent"

private fun loadBatteryMaxRange(context: android.content.Context): Int =
    context.getSharedPreferences(BATTERY_PROFILE_PREFS, android.content.Context.MODE_PRIVATE)
        .getInt(BATTERY_MAX_RANGE_KEY, 0)

private fun loadBatteryLevel(context: android.content.Context): Int =
    context.getSharedPreferences(BATTERY_PROFILE_PREFS, android.content.Context.MODE_PRIVATE)
        .getInt(BATTERY_LEVEL_KEY, 100)

private fun saveBatteryProfile(context: android.content.Context, maxRangeKm: Int, batteryPercent: Int) {
    context.getSharedPreferences(BATTERY_PROFILE_PREFS, android.content.Context.MODE_PRIVATE)
        .edit()
        .putInt(BATTERY_MAX_RANGE_KEY, maxRangeKm.coerceAtLeast(0))
        .putInt(BATTERY_LEVEL_KEY, batteryPercent.coerceIn(0, 100))
        .apply()
}

private fun loadChargingConnectors(context: android.content.Context): Set<String> {
    val prefs = context.getSharedPreferences(CHARGING_PROFILE_PREFS, android.content.Context.MODE_PRIVATE)
    // V36: première configuration volontairement vide. On ne reprend pas automatiquement
    // les quatre prises de V35 afin d'éviter de valider une compatibilité par défaut.
    if (!prefs.getBoolean(CHARGING_PROFILE_CONFIRMED_KEY, false)) return emptySet()
    return prefs.getStringSet(CHARGING_CONNECTORS_KEY, emptySet())?.toSet() ?: emptySet()
}

private fun isChargingProfileConfirmed(context: android.content.Context): Boolean =
    context.getSharedPreferences(CHARGING_PROFILE_PREFS, android.content.Context.MODE_PRIVATE)
        .getBoolean(CHARGING_PROFILE_CONFIRMED_KEY, false)

private fun saveChargingConnectors(context: android.content.Context, values: Set<String>) {
    context.getSharedPreferences(CHARGING_PROFILE_PREFS, android.content.Context.MODE_PRIVATE)
        .edit()
        .putStringSet(CHARGING_CONNECTORS_KEY, values)
        .putBoolean(CHARGING_PROFILE_CONFIRMED_KEY, values.isNotEmpty())
        .apply()
}

private fun chargingPoiMatchesProfile(poi: VspPoi, profile: Set<String>): Boolean {
    if (poi.category != "charge" || profile.isEmpty()) return false
    val available = poi.chargingConnectors.lowercase(java.util.Locale.FRANCE)
    if (available.isBlank()) return false
    return profile.any { wanted ->
        when (wanted) {
            "Type 2" -> available.contains("type 2")
            "Prise E/F" -> available.contains("e/f") || available.contains("domestique")
            "CCS Combo 2" -> available.contains("ccs") || available.contains("combo")
            "CHAdeMO" -> available.contains("chademo")
            else -> available.contains(wanted.lowercase(java.util.Locale.FRANCE))
        }
    }
}

private fun loadFavorite(context: android.content.Context, key: String): String =
    context.getSharedPreferences(FAVORITES_PREFS, android.content.Context.MODE_PRIVATE)
        .getString(key, "") ?: ""

private fun saveFavorite(context: android.content.Context, key: String, value: String) {
    context.getSharedPreferences(FAVORITES_PREFS, android.content.Context.MODE_PRIVATE)
        .edit().putString(key, value.trim()).apply()
}

private fun deleteFavorite(context: android.content.Context, key: String) {
    context.getSharedPreferences(FAVORITES_PREFS, android.content.Context.MODE_PRIVATE)
        .edit().remove(key).apply()
}


private fun loadSearchHistory(context: android.content.Context): List<String> {
    val raw = context.getSharedPreferences(SEARCH_HISTORY_PREFS, android.content.Context.MODE_PRIVATE)
        .getString(SEARCH_HISTORY_KEY, "") ?: ""
    return raw.split(SEARCH_HISTORY_SEPARATOR).map { it.trim() }
        .filter { it.isNotEmpty() }.take(SEARCH_HISTORY_MAX)
}

private fun saveSearchHistory(context: android.content.Context, query: String) {
    val clean = query.trim()
    if (clean.isEmpty()) return
    val updated = listOf(clean) + loadSearchHistory(context)
        .filterNot { it.equals(clean, ignoreCase = true) }
    context.getSharedPreferences(SEARCH_HISTORY_PREFS, android.content.Context.MODE_PRIVATE)
        .edit().putString(
            SEARCH_HISTORY_KEY,
            updated.take(SEARCH_HISTORY_MAX).joinToString(SEARCH_HISTORY_SEPARATOR)
        ).apply()
}

private fun clearSearchHistory(context: android.content.Context) {
    context.getSharedPreferences(SEARCH_HISTORY_PREFS, android.content.Context.MODE_PRIVATE)
        .edit().remove(SEARCH_HISTORY_KEY).apply()
}

data class RouteManeuver(
    val type: Int,
    val instruction: String,
    val streetNames: String,
    val beginShapeIndex: Int,
    val endShapeIndex: Int,
    // ETAPE 106 : source unique consommée par toute l'interface.
    // Sur un trajet local, LocalValhallaRouter remplace au préalable la valeur Odin
    // par le compteur topologique V105 ; sur un secours Internet, la valeur native reste utilisée.
    val roundaboutExitCount: Int = 0
)

// V383 : état minimal conservé pendant une recréation d’Activity (rotation).
// Les objets restent en mémoire uniquement dans le processus de l’application : cela évite
// qu’un passage portrait/paysage renvoie à l’accueil ou efface un itinéraire déjà calculé.
private object RotationRetainedState {
    var screen: String = "splash"
    var energyType: EnergyType? = null
    var query: String = ""
    var destination: Destination? = null
    // V457 : une destination choisie reste validée pendant toute rotation.
    // Les suggestions ne peuvent revenir que si l’utilisateur modifie/efface le champ.
    var destinationConfirmed: Boolean = false
    // V458 : libellé explicitement validé. Sert de verrou indépendant de la recomposition UI.
    var confirmedDestinationLabel: String = ""
    var routeOptions: List<RouteOption> = emptyList()
    var selectedRouteIndex: Int = 0
    var navigationStarted: Boolean = false

    // V452 : le planificateur de recharge appartient à la session de l'application,
    // pas à une instance d'Activity. Une rotation ne doit donc ni annuler le calcul
    // en cours, ni perdre son résultat. Ces MutableState sont observables par la
    // nouvelle composition immédiatement après portrait <-> paysage.
    val routeChargeSearchLoading = mutableStateOf(false)
    val routeChargeSuggestion = mutableStateOf<Pair<VspPoi, Double>?>(null)
    val routeChargePlan = mutableStateOf<List<PlannedChargeStop>>(emptyList())
    val chargePlanFinalDestination = mutableStateOf<Destination?>(null)
    val navigatingToChargeStep = mutableStateOf(false)
    val routeChargeFinalLegMeters = mutableStateOf<Double?>(null)
    val routeChargeSearchMessage = mutableStateOf<String?>(null)
    val rechargePlanningScope = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.Default
    )

    // V386 : conserver aussi le dernier fix GPS pendant une rotation.
    // Sans cela, l’itinéraire survivait mais NavigationScreen repartait avec liveLocation=null.
    var lastLocation: Location? = null
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // V381 : autorise la rotation de l’application en portrait ET en paysage.
        // FULL_SENSOR prend aussi en charge les deux sens de paysage selon la rotation
        // physique du téléphone, même si une ancienne configuration imposait le portrait.
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR

        Configuration.getInstance().userAgentValue = packageName

        hideNavigationBar()

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF4DA3FF),
                    background = Color(0xFF07182E),
                    surface = Color(0xFF102A46)
                )
            ) {
                VspGpsApp()
            }
        }
    }

    private fun hideNavigationBar() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.navigationBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideNavigationBar()
    }
}

@Composable
fun VspGpsApp() {
    val appContext = androidx.compose.ui.platform.LocalContext.current
    // ETAPE 122 : après une vraie destruction du processus (pas seulement une rotation),
    // revenir directement au GPS lorsqu'un trajet actif récent a été conservé.
    val storedActiveTrip = remember { loadStoredActiveTrip(appContext) }
    val initialScreen = if (RotationRetainedState.screen == "splash" && storedActiveTrip != null) {
        "gps"
    } else RotationRetainedState.screen
    var screen by rememberSaveable { mutableStateOf(initialScreen) }
    var energyType by remember {
        mutableStateOf(RotationRetainedState.energyType ?: storedActiveTrip?.energyType)
    }
    val vehicle = VehicleType.VSP

    SideEffect {
        RotationRetainedState.screen = screen
        RotationRetainedState.energyType = energyType
    }

    when (screen) {
        "splash" -> WelcomeScreen(onFinished = { screen = "energy" })
        "energy" -> EnergyChoiceScreen { choice ->
            energyType = choice
            screen = "gps"
        }
        else -> MapSearchScreen(
            vehicle = vehicle,
            energyType = energyType ?: EnergyType.ELECTRIC,
            onBack = {
                clearStoredActiveTrip(appContext)
                screen = "energy"
            }
        )
    }
}

@Composable
fun WelcomeScreen(onFinished: () -> Unit) {
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(2000L)
        onFinished()
    }
    val isLandscape = androidx.compose.ui.platform.LocalConfiguration.current.orientation ==
        android.content.res.Configuration.ORIENTATION_LANDSCAPE
    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Image(
            painter = painterResource(id = R.drawable.vsp_splash),
            contentDescription = "VSP GPS",
            modifier = Modifier.fillMaxSize(),
            // V383 : en paysage, montrer l’image entière au lieu de couper fortement
            // la voiture et le visuel d’itinéraire avec ContentScale.Crop.
            contentScale = if (isLandscape) ContentScale.Fit else ContentScale.Crop
        )
    }
}

@Composable
private fun EnergyChoiceScreen(onChoice: (EnergyType) -> Unit) {
    val isLandscape = androidx.compose.ui.platform.LocalConfiguration.current.orientation ==
        android.content.res.Configuration.ORIENTATION_LANDSCAPE

    if (isLandscape) {
        Column(
            modifier = Modifier.fillMaxSize().background(Color(0xFF07182E)).padding(horizontal = 28.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Choisissez votre VSP", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Quelle énergie utilise votre voiture ?", color = Color(0xFFAAB8C8), fontSize = 15.sp)
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    EnergyChoiceCard(EnergyType.ELECTRIC, "VSP ÉLECTRIQUE", "Batterie • bornes de recharge", onChoice, compact = true)
                }
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    EnergyChoiceCard(EnergyType.FUEL, "VSP CARBURANT", "Essence • diesel • stations-service", onChoice, compact = true)
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("Vous pourrez modifier ce choix plus tard.", color = Color(0xFF7F91A5), fontSize = 12.sp)
        }
    } else {
        Column(
            modifier = Modifier.fillMaxSize().background(Color(0xFF07182E)).padding(horizontal = 24.dp, vertical = 38.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(34.dp))
            Text("Choisissez votre VSP", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text("Quelle énergie utilise votre voiture ?", color = Color(0xFFAAB8C8), fontSize = 17.sp)
            Spacer(Modifier.height(38.dp))
            EnergyChoiceCard(EnergyType.ELECTRIC, "VSP ÉLECTRIQUE", "Batterie • bornes de recharge", onChoice)
            Spacer(Modifier.height(22.dp))
            EnergyChoiceCard(EnergyType.FUEL, "VSP CARBURANT", "Essence • diesel • stations-service", onChoice)
            Spacer(Modifier.weight(1f))
            Text("Vous pourrez modifier ce choix plus tard.", color = Color(0xFF7F91A5), fontSize = 14.sp)
        }
    }
}

@Composable
private fun EnergyChoiceCard(type: EnergyType, title: String, subtitle: String, onChoice: (EnergyType) -> Unit, compact: Boolean = false) {
    Surface(
        modifier = if (compact) Modifier.fillMaxSize().clickable { onChoice(type) } else Modifier.fillMaxWidth().height(210.dp).clickable { onChoice(type) },
        shape = RoundedCornerShape(28.dp),
        color = Color(0xFF102A46),
        border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFF4DA3FF))
    ) {
        Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            HarmonizedEnergyIcon(type, Modifier.size(if (compact) 72.dp else 105.dp))
            Spacer(Modifier.height(12.dp))
            Text(title, color = Color.White, fontSize = (if (compact) 18 else 21).sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(subtitle, color = Color(0xFF9DB1C7), fontSize = (if (compact) 12 else 14).sp)
        }
    }
}

@Composable
private fun HarmonizedEnergyIcon(type: EnergyType, modifier: Modifier = Modifier) {
    val blue = Color(0xFF5BA9F7)
    val ink = Color(0xFF6572B5)
    Canvas(modifier = modifier) {
        val sw = size.minDimension * .065f
        drawRoundRect(blue, style = Stroke(sw), cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.width*.12f))
        if (type == EnergyType.ELECTRIC) {
            val car = Path().apply {
                moveTo(size.width*.28f,size.height*.62f); cubicTo(size.width*.35f,size.height*.34f,size.width*.61f,size.height*.35f,size.width*.78f,size.height*.57f)
                cubicTo(size.width*.84f,size.height*.64f,size.width*.80f,size.height*.69f,size.width*.72f,size.height*.69f)
                lineTo(size.width*.35f,size.height*.69f)
            }
            drawPath(car, ink, style=Stroke(sw*.8f))
            drawCircle(ink,size.width*.075f,androidx.compose.ui.geometry.Offset(size.width*.39f,size.height*.69f),style=Stroke(sw*.8f))
            drawCircle(ink,size.width*.075f,androidx.compose.ui.geometry.Offset(size.width*.69f,size.height*.69f),style=Stroke(sw*.8f))
            val cable=Path().apply { moveTo(size.width*.35f,size.height*.65f); cubicTo(size.width*.23f,size.height*.70f,size.width*.24f,size.height*.55f,size.width*.17f,size.height*.55f); lineTo(size.width*.13f,size.height*.55f) }
            drawPath(cable,ink,style=Stroke(sw*.8f))
            drawLine(ink,androidx.compose.ui.geometry.Offset(size.width*.13f,size.height*.55f),androidx.compose.ui.geometry.Offset(size.width*.09f,size.height*.50f),sw*.8f)
            drawLine(ink,androidx.compose.ui.geometry.Offset(size.width*.15f,size.height*.53f),androidx.compose.ui.geometry.Offset(size.width*.11f,size.height*.47f),sw*.55f)
        } else {
            drawRect(ink, topLeft=androidx.compose.ui.geometry.Offset(size.width*.36f,size.height*.28f), size=androidx.compose.ui.geometry.Size(size.width*.34f,size.height*.48f))
            drawRect(Color(0xFF07182E), topLeft=androidx.compose.ui.geometry.Offset(size.width*.42f,size.height*.34f), size=androidx.compose.ui.geometry.Size(size.width*.22f,size.height*.14f))
            val hose=Path().apply { moveTo(size.width*.36f,size.height*.45f); cubicTo(size.width*.25f,size.height*.45f,size.width*.27f,size.height*.69f,size.width*.34f,size.height*.68f) }
            drawPath(hose,ink,style=Stroke(sw*.8f))
            drawLine(ink,androidx.compose.ui.geometry.Offset(size.width*.34f,size.height*.68f),androidx.compose.ui.geometry.Offset(size.width*.38f,size.height*.58f),sw*.8f)
            drawRect(ink, topLeft=androidx.compose.ui.geometry.Offset(size.width*.31f,size.height*.76f), size=androidx.compose.ui.geometry.Size(size.width*.44f,size.height*.07f))
        }
    }
}


data class VspPoi(
    val name: String,
    val category: String,
    val point: GeoPoint,
    val address: String = "",
    val chargingPower: String = "",
    val chargingConnectors: String = "",
    val vspAccessible: Boolean = true,
    val fuelPrices: String = "",
    val fuelPriceUpdate: String = ""
)


// V110 : rend la date DGCCRF lisible sans inventer de fraîcheur si le champ est absent.
private fun formatFuelPriceUpdate(raw: String): String {
    val value = raw.trim()
    if (value.isBlank()) return ""
    // Formats courants du jeu DGCCRF : ISO (yyyy-MM-ddTHH:mm:ss...) ou yyyy-MM-dd HH:mm:ss.
    val iso = Regex("""(\d{4})-(\d{2})-(\d{2})[T\s](\d{2}):(\d{2})""").find(value)
    if (iso != null) {
        val (_, month, day, hour, minute) = iso.destructured
        return "$day/$month à $hour:$minute"
    }
    // Certains exports utilisent jour/mois/année.
    val fr = Regex("""(\d{2})/(\d{2})/(\d{4})[ T](\d{2}):(\d{2})""").find(value)
    if (fr != null) {
        val (day, month, _, hour, minute) = fr.destructured
        return "$day/$month à $hour:$minute"
    }
    return value.take(32)
}

data class PlannedChargeStop(
    val poi: VspPoi,
    val roadDistanceFromPreviousMeters: Double,
    val cumulativeRouteKm: Double
)

// Étape 72 : normalisation des libellés de prises issus d'OSM/IRVE.
// On n'affiche que des libellés reconnus afin qu'une clé brute (ex. socket:typee)
// ne soit jamais présentée à l'utilisateur comme un type de prise réel.
private fun canonicalChargingConnectorLabel(raw: String): String? {
    val key = raw.trim().lowercase(java.util.Locale.ROOT)
        .replace("socket:", "")
        .replace("-", "_")
        .replace(" ", "_")
    return when (key) {
        "type2", "type_2", "mennekes" -> "Type 2"
        "type2_combo", "type_2_combo", "ccs", "ccs2", "ccs_combo_2", "ccs_combo2", "combo_ccs", "combo2" -> "CCS Combo 2"
        "chademo" -> "CHAdeMO"
        "schuko", "typee", "type_e", "typef", "type_f", "type_e_f", "ef", "e/f", "prise_e/f", "prise_e_f", "prise_domestique", "domestic", "domestique" -> "Prise E/F"
        else -> null
    }
}

private fun normalizeChargingConnectors(raw: String): String =
    raw.split('•', ';', ',', '|')
        .mapNotNull(::canonicalChargingConnectorLabel)
        .distinct()
        .joinToString(" • ")

private fun cleanChargingStationName(rawName: String): String {
    var name = rawName.trim().replace(Regex("\\s+"), " ")
    // Certains exports publient un numéro interne devant le vrai nom de la station.
    name = name.replace(Regex("^\\d{3,}\\s*[-–—:]\\s*"), "").trim()
    val technical = name.matches(Regex("(?i)^(?:france/)?[a-z]*\\d{5,}$")) ||
        name.matches(Regex("(?i)^[a-z]{1,5}[-_:]?[a-z0-9_-]{7,}$"))
    return if (technical || name.isBlank()) "Borne de recharge" else name
}

private fun chargingPoiDisplayName(poi: VspPoi): String {
    val raw = cleanChargingStationName(poi.name)
    // Certains jeux IRVE renvoient un identifiant technique comme nom de station.
    val looksTechnical = raw.length >= 8 && raw.none { it.isWhitespace() } &&
        raw.count { it.isDigit() } >= 2 && raw.count { it.isLetter() } >= 2
    if (raw.isNotBlank() && raw != "Borne de recharge" && !looksTechnical) return raw
    val address = poi.address.trim()
    if (address.isNotBlank()) {
        val parts = address.split(',').map { it.trim() }.filter { it.isNotBlank() }
        val commune = parts.lastOrNull { part -> part.any { it.isLetter() } }
        if (!commune.isNullOrBlank()) return "Borne • $commune"
    }
    return "Borne de recharge"
}



private suspend fun enrichChargingPoiWithIrve(poi: VspPoi): VspPoi = withContext(Dispatchers.IO) {
    if (poi.category != "charge") return@withContext poi
    try {
        // Base nationale IRVE (transport.data.gouv.fr / data.gouv.fr), ressource statique consolidée.
        // On interroge uniquement au clic sur une borne afin de ne pas ralentir la liste.
        val searchText = poi.address.substringAfterLast(",").trim()
            .takeIf { it.length >= 3 } ?: poi.name.trim().takeIf { it.length >= 4 }
            ?: return@withContext poi
        val encoded = java.net.URLEncoder.encode(searchText, "UTF-8")
        val filter = if (poi.address.isNotBlank()) "adresse_station__contains=$encoded" else "nom_station__contains=$encoded"
        val url = "https://tabular-api.data.gouv.fr/api/resources/4ca78c71-4ea4-475d-bd3a-d4aef88f7bf8/data/?$filter&page_size=50"
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "VSP-GPS/1.0")
            .build()
        val client = OkHttpClient.Builder()
            .connectTimeout(6, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
            .callTimeout(12, java.util.concurrent.TimeUnit.SECONDS)
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext poi
            val rows = JSONObject(response.body?.string() ?: return@withContext poi)
                .optJSONArray("data") ?: return@withContext poi
            var best: JSONObject? = null
            var bestDistance = Double.POSITIVE_INFINITY
            for (i in 0 until rows.length()) {
                val row = rows.optJSONObject(i) ?: continue
                val raw = row.opt("coordonneesXY")
                val nums = when (raw) {
                    is org.json.JSONArray -> if (raw.length() >= 2) listOf(raw.optDouble(0), raw.optDouble(1)) else emptyList()
                    else -> Regex("-?\\d+(?:\\.\\d+)?").findAll(raw?.toString().orEmpty()).map { it.value.toDouble() }.toList()
                }
                if (nums.size < 2) continue
                // Le schéma IRVE utilise [longitude, latitude].
                val candidate = GeoPoint(nums[1], nums[0])
                val d = distanceMetersBetween(poi.point, candidate)
                if (d < bestDistance) { bestDistance = d; best = row }
            }
            val row = best ?: return@withContext poi
            // Ne jamais associer une fiche IRVE éloignée à une borne OSM.
            if (bestDistance > 2500.0) return@withContext poi

            val power = row.optDouble("puissance_nominale", Double.NaN)
                .takeIf { it.isFinite() && it > 0.0 }
                ?.let { value ->
                    if (kotlin.math.abs(value - kotlin.math.round(value)) < 0.01) "${kotlin.math.round(value).toInt()} kW"
                    else String.format(java.util.Locale.FRANCE, "%.1f kW", value)
                }.orEmpty()
            val plugs = mutableListOf<String>()
            fun isTrue(key: String): Boolean {
                val v = row.opt(key)
                return v == true || v?.toString()?.equals("true", true) == true || v?.toString() == "1"
            }
            if (isTrue("prise_type_ef")) plugs += "Prise E/F"
            if (isTrue("prise_type_2")) plugs += "Type 2"
            if (isTrue("prise_type_combo_ccs")) plugs += "CCS Combo 2"
            if (isTrue("prise_type_chademo")) plugs += "CHAdeMO"
            if (isTrue("prise_type_autre")) plugs += "Autre prise"

            poi.copy(
                chargingPower = power.ifBlank { poi.chargingPower },
                chargingConnectors = normalizeChargingConnectors(plugs.distinct().joinToString(" • ").ifBlank { poi.chargingConnectors })
            )
        }
    } catch (_: Exception) {
        poi
    }
}

private fun poiLooksVspAccessible(tags: JSONObject): Boolean {
    val highway = tags.optString("nearby_highway", "")
    val access = tags.optString("access", "")
    val motorVehicle = tags.optString("motor_vehicle", "")
    val motorcar = tags.optString("motorcar", "")

    if (highway == "motorway" || highway == "motorway_link") return false
    if (access in setOf("no", "private")) return false
    if (motorVehicle == "no" || motorcar == "no") return false
    return true
}

private suspend fun isPoiReachableByVspOsm(poi: GeoPoint): Boolean =
    withContext(Dispatchers.IO) {
        // We reject a POI if its immediate access is a motorway or motorway ramp.
        // The query also catches motorway service areas very close to the POI.
        val q = """
            [out:json][timeout:6];
            (
              way(around:45,${poi.latitude},${poi.longitude})["highway"="motorway"];
              way(around:45,${poi.latitude},${poi.longitude})["highway"="motorway_link"];
              nwr(around:80,${poi.latitude},${poi.longitude})["highway"="services"];
            );
            out tags center;
        """.trimIndent()

        val request = Request.Builder()
            .url("https://overpass-api.de/api/interpreter")
            .post(okhttp3.FormBody.Builder().add("data", q).build())
            .header("User-Agent", "VSP-GPS/1.0")
            .build()

        val client = OkHttpClient.Builder()
            .connectTimeout(4, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(6, java.util.concurrent.TimeUnit.SECONDS)
            .callTimeout(7, java.util.concurrent.TimeUnit.SECONDS)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext false
                val elements = JSONObject(response.body?.string() ?: return@withContext false)
                    .optJSONArray("elements") ?: return@withContext false
                elements.length() == 0
            }
        } catch (_: Exception) {
            // Safety-first: if accessibility cannot be checked, do not offer the POI as VSP-compatible.
            false
        }
    }



// V67 : source primaire carburant = flux officiel du ministère de l'Économie.
// OSM reste utilisé en secours et pour la cartographie/navigation.
private suspend fun loadOfficialFuelStations(center: GeoPoint): List<VspPoi> = withContext(Dispatchers.IO) {
    val dataset = "prix-des-carburants-en-france-flux-instantane-v2"
    val where = "within_distance(geom, geom'POINT(${center.longitude} ${center.latitude})', 20 km)"
    val url = "https://data.economie.gouv.fr/api/explore/v2.1/catalog/datasets/$dataset/records" +
        "?limit=100&where=" + java.net.URLEncoder.encode(where, "UTF-8")
    val request = Request.Builder().url(url).header("User-Agent", "VSP-GPS/1.0").build()
    val client = OkHttpClient.Builder()
        .connectTimeout(7, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(12, java.util.concurrent.TimeUnit.SECONDS)
        .callTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .build()
    try {
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext emptyList()
            val root = JSONObject(response.body?.string() ?: return@withContext emptyList())
            val results = root.optJSONArray("results") ?: return@withContext emptyList()
            val out = mutableListOf<VspPoi>()
            for (i in 0 until results.length()) {
                val row = results.optJSONObject(i) ?: continue
                // ODS v2.1 may expose a geo_point either as {lat, lon} or [lat, lon].
                val geomAny = row.opt("geom") ?: row.opt("geo_point") ?: continue
                val (lat, lon) = when (geomAny) {
                    is JSONObject -> geomAny.optDouble("lat", geomAny.optDouble("latitude", Double.NaN)) to
                        geomAny.optDouble("lon", geomAny.optDouble("longitude", Double.NaN))
                    is org.json.JSONArray -> geomAny.optDouble(0, Double.NaN) to geomAny.optDouble(1, Double.NaN)
                    else -> Double.NaN to Double.NaN
                }
                if (!lat.isFinite() || !lon.isFinite()) continue
                val city = row.optString("ville").trim()
                val address = listOf(row.optString("adresse").trim(), row.optString("cp").trim(), city)
                    .filter { it.isNotBlank() }.distinct().joinToString(", ")
                // V95 : nom d'enseigne déterminé directement depuis les champs DGCCRF bruts.
                // Cette étape a lieu avant OSM, donc elle ne dépend plus de l'enrichissement ultérieur.
                val rawStreet = row.optString("adresse").trim()
                val rawCp = row.optString("cp").trim()
                val directKey = "$rawStreet $rawCp $city".lowercase(Locale.FRANCE)
                    .replace("é","e").replace("è","e").replace("ê","e")
                    .replace("à","a").replace("â","a").replace("î","i").replace("ï","i")
                    .replace("ô","o").replace("ù","u").replace("û","u").replace("ç","c")
                val verifiedDgccrfName = when {
                    directKey.contains("francois beaucamp") && directKey.contains("grenay") -> "Esso Express Grenay"
                    directKey.contains("100 avenue francois mitterrand") && directKey.contains("62114") -> "TotalEnergies Sains-en-Gohelle"
                    directKey.contains("francois mitterrand") && directKey.contains("sains") && directKey.contains("gohelle") -> "TotalEnergies Sains-en-Gohelle"
                    directKey.contains("44 route d arras") && directKey.contains("lens") -> "TotalEnergies Access - Relais Césarine"
                    else -> null
                }
                val stationName = verifiedDgccrfName ?: listOf("enseigne", "nom", "name", "marque")
                    .asSequence().map { row.optString(it).trim() }.firstOrNull { it.isNotBlank() }
                    ?: "Station-service"
                val priceFields = listOf(
                    "Gazole" to "gazole_prix", "SP95" to "sp95_prix", "E10" to "e10_prix",
                    "SP98" to "sp98_prix", "E85" to "e85_prix", "GPLc" to "gplc_prix"
                )
                val prices = priceFields.mapNotNull { (label, key) ->
                    val raw = row.opt(key) ?: return@mapNotNull null
                    val value = when (raw) {
                        is Number -> raw.toDouble()
                        else -> raw.toString().replace(',', '.').toDoubleOrNull()
                    } ?: return@mapNotNull null
                    if (value <= 0.0) null else "$label ${String.format(Locale.FRANCE, "%.3f", value)} €"
                }.joinToString(" • ")
                val update = listOf("gazole_maj", "sp95_maj", "e10_maj", "sp98_maj", "e85_maj", "gplc_maj")
                    .asSequence().map { row.optString(it).trim() }.firstOrNull { it.isNotBlank() }.orEmpty()
                out += VspPoi(
                    name = if (
                        rawStreet.lowercase(Locale.FRANCE).contains("100 avenue francois mitterrand") ||
                        rawStreet.lowercase(Locale.FRANCE).contains("100 avenue françois mitterrand")
                    ) "TotalEnergies Sains-en-Gohelle" else stationName,
                    category = "fuel",
                    point = GeoPoint(lat, lon),
                    address = address,
                    fuelPrices = prices,
                    fuelPriceUpdate = update
                )
            }
            // V103 : normalisation finale des enseignes officielles après dédoublonnage.
            // Tolère les variantes d'écriture de l'adresse (accents, ponctuation, Mitterand/Mitterrand).
            canonicalizeOfficialFuelStationNames(deduplicateFuelStations(out))
        }
    } catch (_: Exception) {
        emptyList()
    }
}


// V103 : fiabilisation générale des noms de stations officielles.
// La source DGCCRF reste la référence pour la station, les coordonnées et les prix.
// Cette fonction ne change que le libellé commercial quand l'adresse permet une identification fiable.
private fun canonicalizeOfficialFuelStationNames(stations: List<VspPoi>): List<VspPoi> {
    fun norm(value: String): String = java.text.Normalizer.normalize(
        value.lowercase(Locale.FRANCE), java.text.Normalizer.Form.NFD
    ).replace(Regex("\\p{M}+"), "")
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()

    return stations.map { station ->
        val a = norm(station.address)
        val verifiedName = when {
            a.contains("route de souchez") && a.contains("angres") -> "E.Leclerc Angres"
            a.contains("impasse de l epinette") && a.contains("aix noulette") -> "Carrefour Market Aix-Noulette"
            a.contains("69 rue de lattre de tassigny") && a.contains("lievin") -> "Relais Total de Rollencourt"
            a.contains("18 rue casimir beugnet") && a.contains("bully les mines") -> "Carrefour Market Bully-les-Mines"
            a.contains("rue casimir beugnet") && a.contains("bully les mines") -> "Intermarché Bully-les-Mines"
            a.contains("francois beaucamp") && a.contains("grenay") -> "Esso Express Grenay"
            // V103 : volontairement robuste aux variantes Mitterand / Mitterrand.
            a.contains("62114") && a.contains("sains") && a.contains("gohelle") &&
                a.contains("francois") && a.contains("mitter") -> "TotalEnergies Sains-en-Gohelle"
            a.contains("2 rue marie lietard") && a.contains("lievin") -> "Carrefour Liévin"
            a.contains("162 avenue alfred maes") && a.contains("lens") -> "Esso Express Bollaert"
            a.contains("44 route d arras") && a.contains("lens") -> "TotalEnergies Access - Relais Césarine"
            else -> null
        }
        if (verifiedName != null) station.copy(name = verifiedName) else station
    }
}

// V102 : déduplication renforcée des stations-service officielles.
// Une adresse identique ne suffit plus à fusionner deux enseignes nommées différemment.
// Fusion uniquement si les stations sont très proches ET :
// - portent la même enseigne non générique ; ou
// - ont la même adresse et au moins un des deux noms est générique.
// Objectif : supprimer les doublons DGCCRF sans faire disparaître deux stations réellement distinctes.
private fun deduplicateFuelStations(stations: List<VspPoi>): List<VspPoi> {
    fun norm(value: String): String = java.text.Normalizer.normalize(value.lowercase(Locale.FRANCE), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()

    fun genericName(name: String): Boolean {
        val n = norm(name)
        return n.isBlank() || n == "station service" || n == "station"
    }

    fun merge(a: VspPoi, b: VspPoi): VspPoi {
        // Conserver les informations les plus riches sans mélanger les prix de deux stations distinctes.
        val betterName = when {
            genericName(a.name) && !genericName(b.name) -> b.name
            a.name.length >= b.name.length -> a.name
            else -> b.name
        }
        val betterAddress = if (a.address.length >= b.address.length) a.address else b.address
        val priceSource = when {
            a.fuelPrices.isBlank() -> b
            b.fuelPrices.isBlank() -> a
            b.fuelPriceUpdate.isNotBlank() && b.fuelPriceUpdate > a.fuelPriceUpdate -> b
            else -> a
        }
        return a.copy(
            name = betterName,
            address = betterAddress,
            fuelPrices = priceSource.fuelPrices,
            fuelPriceUpdate = priceSource.fuelPriceUpdate
        )
    }

    val result = mutableListOf<VspPoi>()
    for (station in stations) {
        val stationAddress = norm(station.address)
        val stationName = norm(station.name)
        val duplicateIndex = result.indexOfFirst { existing ->
            val close = distanceMetersBetween(existing.point, station.point) <= 120.0
            if (!close) false else {
                val sameAddress = stationAddress.isNotBlank() && stationAddress == norm(existing.address)
                val sameNamedBrand = !genericName(station.name) && !genericName(existing.name) &&
                    stationName == norm(existing.name)
                val addressWithGenericName = sameAddress &&
                    (genericName(station.name) || genericName(existing.name))

                // V102 : deux enseignes explicites différentes ne sont jamais fusionnées
                // uniquement parce qu'elles partagent la même adresse.
                sameNamedBrand || addressWithGenericName
            }
        }
        if (duplicateIndex < 0) result += station
        else result[duplicateIndex] = merge(result[duplicateIndex], station)
    }
    return result
}

// V75 : enrichissement visuel des stations officielles sans jamais modifier la liste DGCCRF.
// Une station OSM proche peut seulement fournir son enseigne/nom.
fun enrichOfficialFuelBrands(official: List<VspPoi>, osmPois: List<VspPoi>): List<VspPoi> {
    val osmFuel = osmPois.filter { it.category == "fuel" }
    return official.map { station ->
        // V88 : rapprochement automatique DGCCRF -> OSM plus robuste.
        // On privilégie les stations dont l'adresse partage des éléments significatifs
        // (commune, code postal, rue), puis la proximité. OSM ne sert qu'à donner l'enseigne :
        // la station officielle, ses prix et ses coordonnées restent toujours DGCCRF.
        fun normalizedAddress(value: String): String = value.lowercase(Locale.FRANCE)
            .replace("é", "e").replace("è", "e").replace("ê", "e")
            .replace("à", "a").replace("â", "a").replace("î", "i")
            .replace("ï", "i").replace("ô", "o").replace("ù", "u")
            .replace("û", "u").replace(Regex("[^a-z0-9]+"), " ").trim()

        val officialTokens = normalizedAddress(station.address)
            .split(" ").filter { it.length >= 4 }.toSet()

        val match = osmFuel
            // V103 : une station OSM générique ne doit jamais gagner contre une enseigne exploitable.
            .filter { poi ->
                val n = poi.name.trim()
                n.isNotBlank() && !n.equals("Station-service", true) && !n.equals("Station", true)
            }
            .map { poi ->
                val distance = distanceMetersBetween(station.point, poi.point)
                val osmTokens = normalizedAddress(poi.address)
                    .split(" ").filter { it.length >= 4 }.toSet()
                val common = officialTokens.intersect(osmTokens).size
                Triple(poi, distance, common)
            }
            .filter { it.second <= 1000.0 }
            .sortedWith(
                compareByDescending<Triple<VspPoi, Double, Int>> { it.third }
                    .thenBy { it.second }
            )
            .firstOrNull()
            ?.first
        // V91 : les correspondances d'adresse vérifiées passent AVANT le nom OSM.
        // OSM reste un enrichissement de secours et ne peut plus masquer une enseigne vérifiée.
        val a = station.address.lowercase(Locale.FRANCE)
            .replace("é", "e").replace("è", "e").replace("ê", "e")
            .replace("à", "a").replace("â", "a")
            .replace("î", "i").replace("ï", "i")
            .replace("ô", "o").replace("ù", "u").replace("û", "u")
        val verifiedBrand = when {
            a.contains("route de souchez") && a.contains("angres") -> "E.Leclerc Angres"
            a.contains("impasse de l'epinette") && a.contains("aix-noulette") -> "Carrefour Market Aix-Noulette"
            a.contains("69 rue de lattre de tassigny") && a.contains("lievin") -> "Relais Total de Rollencourt"
            a.contains("18 rue casimir beugnet") && a.contains("bully-les-mines") -> "Carrefour Market Bully-les-Mines"
            a.contains("rue casimir beugnet") && a.contains("bully-les-mines") -> "Intermarché Bully-les-Mines"
            a.contains("2 rue marie lietard") && a.contains("lievin") -> "Carrefour Liévin"
            a.contains("francois beaucamp") && a.contains("grenay") -> "Esso Express Grenay"
            a.contains("francois mitterrand") && a.contains("sains") && a.contains("gohelle") -> "TotalEnergies Sains-en-Gohelle"
            a.contains("162 avenue alfred maes") && a.contains("lens") -> "Esso Express Bollaert"
            a.contains("44 route d arras") && a.contains("lens") -> "TotalEnergies Access - Relais Césarine"
            else -> null
        }
        if (verifiedBrand != null) {
            station.copy(name = verifiedBrand)
        } else if (match != null && match.name.isNotBlank() && !match.name.equals("Station-service", true)) {
            station.copy(name = match.name)
        } else {
            // Secours historique conservé.
            val a = station.address.lowercase(Locale.FRANCE)
                .replace("é", "e").replace("è", "e").replace("ê", "e")
                .replace("à", "a").replace("â", "a")
                .replace("î", "i").replace("ï", "i")
                .replace("ô", "o").replace("ù", "u").replace("û", "u")
            val fallbackBrand = when {
                a.contains("route de souchez") && a.contains("angres") -> "E.Leclerc Angres"
                a.contains("impasse de l'epinette") && a.contains("aix-noulette") -> "Carrefour Market Aix-Noulette"
                a.contains("69 rue de lattre de tassigny") && a.contains("lievin") -> "Relais Total de Rollencourt"
                a.contains("18 rue casimir beugnet") && a.contains("bully-les-mines") -> "Carrefour Market Bully-les-Mines"
                a.contains("rue casimir beugnet") && a.contains("bully-les-mines") -> "Intermarché Bully-les-Mines"
                a.contains("2 rue marie lietard") && a.contains("lievin") -> "Carrefour Liévin"
                a.contains("francois beaucamp") && a.contains("grenay") -> "Esso Express Grenay"
                a.contains("francois mitterrand") && a.contains("sains") && a.contains("gohelle") -> "TotalEnergies Sains-en-Gohelle"
                a.contains("162 avenue alfred maes") && a.contains("lens") -> "Esso Express Bollaert"
                else -> null
            }
            if (fallbackBrand != null) station.copy(name = fallbackBrand) else station
        }
   

 }
}

private suspend fun loadNearbyVspPois(
    center: GeoPoint,
    endpointIndex: Int = 0
): List<VspPoi> =
    withContext(Dispatchers.IO) {
        // Plusieurs miroirs Overpass : un serveur public peut ponctuellement répondre
        // 429/5xx. On conserve exactement la même requête et le même parsing,
        // mais on bascule vers le miroir suivant uniquement en cas d'échec réseau/HTTP.
        val overpassEndpoints = listOf(
            "https://overpass-api.de/api/interpreter",
            "https://overpass.private.coffee/api/interpreter",
            "https://maps.mail.ru/osm/tools/overpass/api/interpreter"
        )
        val endpoint = overpassEndpoints[endpointIndex.coerceIn(0, overpassEndpoints.lastIndex)]
        /*
         * Une seule requête Overpass :
         * - "allPois" = stations, bornes et garages à proximité.
         * - "motorwayPois" = stations/bornes situées très près d'une autoroute,
         *   d'une bretelle ou dans une aire de services autoroutière.
         *
         * On utilise les IDs OSM pour retirer ces POI AVANT l'affichage de la liste.
         * Aucun appel réseau n'est fait POI par POI.
         */
        val q = """
            [out:json][timeout:15];

            (
              nwr(around:18000,${center.latitude},${center.longitude})["amenity"="fuel"];
              nwr(around:18000,${center.latitude},${center.longitude})["amenity"="charging_station"];
              nwr(around:18000,${center.latitude},${center.longitude})["shop"="car_repair"];
            )->.allPois;

            (
              way(around:18000,${center.latitude},${center.longitude})["highway"="motorway"];
              way(around:18000,${center.latitude},${center.longitude})["highway"="motorway_link"];
              nwr(around:18000,${center.latitude},${center.longitude})["highway"="services"];
            )->.forbiddenRoads;

            (
              nwr.allPois(around.forbiddenRoads:45)["amenity"="fuel"];
              nwr.allPois(around.forbiddenRoads:120)["amenity"="charging_station"];
            )->.motorwayPois;

            (
              nwr(around:18000,${center.latitude},${center.longitude})["place"~"city|town|village|suburb"]["name"];
            )->.nearbyPlaces;

            .allPois out center tags;
            .motorwayPois out center tags;
            .nearbyPlaces out center tags;
        """.trimIndent()

        val request = Request.Builder()
            .url(endpoint)
            .post(okhttp3.FormBody.Builder().add("data", q).build())
            .header("User-Agent", "VSP-GPS/1.0")
            .build()

        val client = OkHttpClient.Builder()
            .connectTimeout(7, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(18, java.util.concurrent.TimeUnit.SECONDS)
            .callTimeout(22, java.util.concurrent.TimeUnit.SECONDS)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext if (endpointIndex < overpassEndpoints.lastIndex)
                        loadNearbyVspPois(center, endpointIndex + 1)
                    else emptyList()
                }

                val elements = JSONObject(
                    response.body?.string() ?: return@withContext emptyList()
                ).optJSONArray("elements") ?: return@withContext emptyList()

                data class RawPoi(
                    val osmKey: String,
                    val poi: VspPoi
                )

                val occurrences = mutableMapOf<String, Int>()
                val rawPois = mutableListOf<RawPoi>()
                val nearbyPlaces = mutableListOf<Pair<String, GeoPoint>>()

                fun elementPoint(obj: JSONObject): GeoPoint? {
                    val lat: Double
                    val lon: Double
                    if (obj.has("lat") && obj.has("lon")) {
                        lat = obj.optDouble("lat", Double.NaN)
                        lon = obj.optDouble("lon", Double.NaN)
                    } else {
                        val c = obj.optJSONObject("center") ?: return null
                        lat = c.optDouble("lat", Double.NaN)
                        lon = c.optDouble("lon", Double.NaN)
                    }
                    return if (lat.isFinite() && lon.isFinite()) GeoPoint(lat, lon) else null
                }

                // Récupère les communes/quartiers voisins dans la même requête Overpass.
                // Cela permet de donner un lieu utile aux bornes qui n'ont aucune adresse OSM.
                for (i in 0 until elements.length()) {
                    val obj = elements.optJSONObject(i) ?: continue
                    val tags = obj.optJSONObject("tags") ?: continue
                    val placeType = tags.optString("place")
                    val placeName = tags.optString("name")
                    if (placeName.isNotBlank() && placeType in setOf("city", "town", "village", "suburb")) {
                        elementPoint(obj)?.let { nearbyPlaces.add(placeName to it) }
                    }
                }

                for (i in 0 until elements.length()) {
                    val obj = elements.optJSONObject(i) ?: continue
                    val tags = obj.optJSONObject("tags") ?: JSONObject()
                    val point = elementPoint(obj) ?: continue

                    val category = when {
                        tags.optString("amenity") == "fuel" -> "fuel"
                        tags.optString("amenity") == "charging_station" -> "charge"
                        tags.optString("shop") == "car_repair" -> "garage"
                        else -> continue
                    }

                    val name = if (category == "fuel") {
                        // V76 : de nombreuses stations OSM n'ont pas de name mais ont brand/operator.
                        tags.optString("name").ifBlank {
                            tags.optString("brand").ifBlank {
                                tags.optString("operator").ifBlank { "Station-service" }
                            }
                        }
                    } else tags.optString("name").ifBlank {
                        when (category) {
                            "fuel" -> "Station-service"
                            "charge" -> {
                                tags.optString("operator").ifBlank {
                                    tags.optString("network").ifBlank {
                                        tags.optString("brand").ifBlank {
                                            val city = tags.optString("addr:city")
                                            val street = tags.optString("addr:street")
                                            val houseNumber = tags.optString("addr:housenumber")
                                            val place = tags.optString("addr:place")
                                            val ref = tags.optString("ref")
                                                .ifBlank { tags.optString("ref:EU:EVSE") }
                                            val location = tags.optString("location")
                                            val address = listOf(
                                                listOf(houseNumber, street)
                                                    .filter { it.isNotBlank() }
                                                    .joinToString(" "),
                                                place,
                                                city
                                            ).filter { it.isNotBlank() }
                                                .distinct()
                                                .joinToString(", ")

                                            when {
                                                address.isNotBlank() ->
                                                    "Borne de recharge • $address"
                                                ref.isNotBlank() ->
                                                    "Borne de recharge • ${ref.substringBefore(";")}"
                                                location.isNotBlank() ->
                                                    "Borne de recharge • $location"
                                                else -> "Borne de recharge"
                                            }
                                        }
                                    }
                                }
                            }
                            else -> "Garage"
                        }
                    }

                    var poiAddress = listOf(
                        listOf(
                            tags.optString("addr:housenumber"),
                            tags.optString("addr:street")
                        ).filter { it.isNotBlank() }.joinToString(" "),
                        tags.optString("addr:place"),
                        tags.optString("addr:postcode"),
                        tags.optString("addr:city")
                    ).filter { it.isNotBlank() }.distinct().joinToString(", ")

                    // V65 : beaucoup de stations-service OSM n'ont pas de addr:city.
                    // On complète alors leur adresse avec la localité OSM la plus proche afin
                    // d'éviter le groupe « Localité non renseignée » dans la liste carburant.
                    // On ne remplace jamais une commune déjà fournie par OSM.
                    val explicitCity = tags.optString("addr:city").trim()
                    if ((category == "fuel" || category == "charge") && explicitCity.isBlank()) {
                        val nearestPlace = nearbyPlaces.minByOrNull { (_, placePoint) ->
                            distanceMetersBetween(point, placePoint)
                        }
                        if (nearestPlace != null && distanceMetersBetween(point, nearestPlace.second) <= 8000.0) {
                            poiAddress = listOf(poiAddress, nearestPlace.first)
                                .filter { it.isNotBlank() }
                                .distinct()
                                .joinToString(", ")
                        }
                    }

                    var chargingPower = ""
                    var chargingConnectors = ""
                    if (category == "charge") {
                        val powerValues = mutableListOf<String>()
                        listOf("max_power", "charging_station:output").forEach { key ->
                            tags.optString(key).trim().takeIf { it.isNotBlank() }?.let(powerValues::add)
                        }

                        val connectorLabels = linkedSetOf<String>()
                        val connectorNames = mapOf(
                            "type2_combo" to "CCS Combo 2",
                            "type2" to "Type 2",
                            "chademo" to "CHAdeMO",
                            "schuko" to "Prise E/F",
                            "cee_blue" to "CEE bleu",
                            "cee_red_16a" to "CEE rouge 16 A",
                            "cee_red_32a" to "CEE rouge 32 A",
                            "tesla_supercharger" to "Tesla Supercharger",
                            "tesla_destination" to "Tesla Destination"
                        )
                        val keys = tags.keys()
                        while (keys.hasNext()) {
                            val key = keys.next()
                            if (!key.startsWith("socket:")) continue
                            val parts = key.split(":")
                            if (parts.size < 2) continue
                            val socketKey = parts[1]
                            val value = tags.optString(key).trim()
                            if (key.endsWith(":output")) {
                                if (value.isNotBlank()) powerValues.add(value)
                            } else if (parts.size == 2 && value.lowercase(java.util.Locale.ROOT) !in setOf("", "no", "0", "false")) {
                                (connectorNames[socketKey] ?: canonicalChargingConnectorLabel(socketKey))?.let(connectorLabels::add)
                            }
                        }
                        chargingPower = powerValues.distinct().joinToString(" • ")
                        chargingConnectors = normalizeChargingConnectors(connectorLabels.joinToString(" • "))
                    }

                    val osmKey = "${obj.optString("type")}:${obj.optLong("id")}"
                    occurrences[osmKey] = (occurrences[osmKey] ?: 0) + 1

                    // Only add the first occurrence. If the same OSM object is emitted
                    // again by .motorwayPois, its occurrence count becomes >= 2.
                    if (occurrences[osmKey] == 1) {
                        rawPois.add(
                            RawPoi(
                                osmKey = osmKey,
                                poi = VspPoi(
                                    name = name,
                                    category = category,
                                    point = point,
                                    address = poiAddress,
                                    chargingPower = chargingPower,
                                    chargingConnectors = normalizeChargingConnectors(chargingConnectors)
                                )
                            )
                        )
                    }
                }

                rawPois
                    .filterNot { raw ->
                        raw.poi.category != "garage" &&
                            (occurrences[raw.osmKey] ?: 0) >= 2
                    }
                    .map { it.poi }
                    .distinctBy {
                        "${it.category}:${it.name}:${it.point.latitude}:${it.point.longitude}"
                    }
                    .take(150)
            }
        } catch (_: Exception) {
            if (endpointIndex < overpassEndpoints.lastIndex)
                loadNearbyVspPois(center, endpointIndex + 1)
            else emptyList()
        }
    }




// V63 : stations-service utiles pendant un trajet carburant.
// On échantillonne l'itinéraire VSP déjà validé et on réutilise la recherche OSM locale.
// Le résultat est ensuite filtré sur un corridor de 8 km autour du tracé.
private suspend fun loadFuelPoisAlongRoute(
    routePoints: List<GeoPoint>,
    routeDistanceMeters: Double
): List<VspPoi> = coroutineScope {
    if (routePoints.isEmpty()) return@coroutineScope emptyList()

    val samples = mutableListOf<GeoPoint>()
    var d = 0.0
    while (d <= routeDistanceMeters) {
        routePointAtDistance(routePoints, d)?.let(samples::add)
        d += 30000.0
    }
    routePointAtDistance(routePoints, routeDistanceMeters)?.let(samples::add)

    samples
        .distinctBy { "%.4f:%.4f".format(java.util.Locale.ROOT, it.latitude, it.longitude) }
        .take(10)
        .map { sample ->
            async {
                kotlinx.coroutines.withTimeoutOrNull(14000L) {
                    loadNearbyVspPois(sample)
                }.orEmpty()
            }
        }
        .awaitAll()
        .flatten()
        .asSequence()
        .filter { it.category == "fuel" }
        .filter { distanceFromPoiToRouteMeters(it.point, routePoints) <= 8000.0 }
        .distinctBy { vspPoiKey(it) }
        .take(100)
        .toList()
}

// Position approximative d'un POI le long du tracé. Sert uniquement à l'ordre
// d'affichage des localités : départ -> destination.
private fun routeProgressMetersForPoi(point: GeoPoint, routePoints: List<GeoPoint>): Double {
    if (routePoints.isEmpty()) return Double.MAX_VALUE
    var bestDistance = Double.MAX_VALUE
    var bestProgress = 0.0
    var progress = 0.0
    var previous = routePoints.first()
    routePoints.forEachIndexed { index, rp ->
        if (index > 0) progress += distanceMetersBetween(previous, rp)
        val d = distanceMetersBetween(point, rp)
        if (d < bestDistance) {
            bestDistance = d
            bestProgress = progress
        }
        previous = rp
    }
    return bestProgress
}

private suspend fun loadLocalChargingPoisForRoute(
    center: GeoPoint,
    endpointIndex: Int = 0
): List<VspPoi> =
    withContext(Dispatchers.IO) {
        val overpassEndpoints = listOf(
            "https://overpass-api.de/api/interpreter",
            "https://overpass.private.coffee/api/interpreter",
            "https://maps.mail.ru/osm/tools/overpass/api/interpreter"
        )
        val endpoint = overpassEndpoints[endpointIndex.coerceIn(0, overpassEndpoints.lastIndex)]
        // Requête volontairement légère pour le planificateur longue distance.
        // Elle reproduit le principe de la recherche locale, mais uniquement pour les bornes.
        val q = """
            [out:json][timeout:7];
            nwr(around:14000,${center.latitude},${center.longitude})["amenity"="charging_station"];
            out center tags;
        """.trimIndent()

        val request = Request.Builder()
            .url(endpoint)
            .post(okhttp3.FormBody.Builder().add("data", q).build())
            .header("User-Agent", "VSP-GPS/1.0")
            .build()

        val client = OkHttpClient.Builder()
            .connectTimeout(4, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(8, java.util.concurrent.TimeUnit.SECONDS)
            .callTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
            .build()

        try {
            lastOsmChargingDiagnostic = "OSM : connexion ${endpointIndex + 1}/${overpassEndpoints.size}…"
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    lastOsmChargingDiagnostic = "OSM : HTTP ${response.code} sur miroir ${endpointIndex + 1}"
                    return@withContext if (endpointIndex < overpassEndpoints.lastIndex)
                        loadLocalChargingPoisForRoute(center, endpointIndex + 1)
                    else emptyList()
                }
                val elements = JSONObject(response.body?.string() ?: return@withContext emptyList())
                    .optJSONArray("elements") ?: return@withContext emptyList()
                val result = mutableListOf<VspPoi>()
                for (i in 0 until elements.length()) {
                    val obj = elements.optJSONObject(i) ?: continue
                    val tags = obj.optJSONObject("tags") ?: JSONObject()
                    val point = if (obj.has("lat") && obj.has("lon")) {
                        GeoPoint(obj.optDouble("lat"), obj.optDouble("lon"))
                    } else {
                        val c = obj.optJSONObject("center") ?: continue
                        GeoPoint(c.optDouble("lat"), c.optDouble("lon"))
                    }
                    if (!point.latitude.isFinite() || !point.longitude.isFinite()) continue

                    val name = tags.optString("name").ifBlank {
                        tags.optString("operator").ifBlank {
                            tags.optString("network").ifBlank {
                                tags.optString("brand").ifBlank { "Borne de recharge" }
                            }
                        }
                    }
                    val address = listOf(
                        listOf(tags.optString("addr:housenumber"), tags.optString("addr:street"))
                            .filter { it.isNotBlank() }.joinToString(" "),
                        tags.optString("addr:postcode"),
                        tags.optString("addr:city")
                    ).filter { it.isNotBlank() }.distinct().joinToString(", ")

                    val powerValues = mutableListOf<String>()
                    listOf("max_power", "charging_station:output").forEach { key ->
                        tags.optString(key).trim().takeIf { it.isNotBlank() }?.let(powerValues::add)
                    }
                    val connectorLabels = linkedSetOf<String>()
                    val connectorNames = mapOf(
                        "type2_combo" to "CCS Combo 2",
                        "type2" to "Type 2",
                        "chademo" to "CHAdeMO",
                        "schuko" to "Prise E/F",
                        "cee_blue" to "CEE bleu",
                        "cee_red_16a" to "CEE rouge 16 A",
                        "cee_red_32a" to "CEE rouge 32 A"
                    )
                    val keys = tags.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        if (!key.startsWith("socket:")) continue
                        val parts = key.split(":")
                        if (parts.size < 2) continue
                        val socketKey = parts[1]
                        val value = tags.optString(key).trim()
                        if (key.endsWith(":output")) {
                            if (value.isNotBlank()) powerValues.add(value)
                        } else if (parts.size == 2 && value.lowercase(java.util.Locale.ROOT) !in setOf("", "no", "0", "false")) {
                            (connectorNames[socketKey] ?: canonicalChargingConnectorLabel(socketKey))?.let(connectorLabels::add)
                        }
                    }
                    result += VspPoi(
                        name = name,
                        category = "charge",
                        point = point,
                        address = address,
                        chargingPower = powerValues.distinct().joinToString(" • "),
                        chargingConnectors = normalizeChargingConnectors(connectorLabels.joinToString(" • "))
                    )
                }
                val finalResult = result.distinctBy { vspPoiKey(it) }.take(60)
                lastOsmChargingDiagnostic = "OSM : HTTP ${response.code} • ${finalResult.size} borne(s) sur miroir ${endpointIndex + 1}"
                finalResult
            }
        } catch (e: Exception) {
            lastOsmChargingDiagnostic = "OSM : ${e.javaClass.simpleName} sur miroir ${endpointIndex + 1}"
            if (endpointIndex < overpassEndpoints.lastIndex)
                loadLocalChargingPoisForRoute(center, endpointIndex + 1)
            else emptyList()
        }
    }


private data class ChargingCorridorCacheEntry(val savedAtMs: Long, val pois: List<VspPoi>)
private val chargingCorridorCache = java.util.concurrent.ConcurrentHashMap<String, ChargingCorridorCacheEntry>()
private const val CHARGING_CACHE_TTL_MS = 15L * 60L * 1000L
private const val CHARGING_STALE_CACHE_MAX_AGE_MS = 7L * 24L * 60L * 60L * 1000L

// Étape 73 : dernier résultat IRVE exploitable conservé sur disque.
// Une panne temporaire du réseau ne doit pas transformer une prise connue en « inconnue ».
private fun chargingDiskCacheFile(context: android.content.Context, cacheKey: String): java.io.File {
    val safe = java.security.MessageDigest.getInstance("SHA-256")
        .digest(cacheKey.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
    return java.io.File(context.filesDir, "charging_irve_$safe.json")
}

private fun saveChargingDiskCache(context: android.content.Context, cacheKey: String, pois: List<VspPoi>) {
    try {
        val root = JSONObject().put("savedAtMs", System.currentTimeMillis())
        val arr = org.json.JSONArray()
        pois.forEach { poi ->
            arr.put(JSONObject()
                .put("name", poi.name).put("category", poi.category)
                .put("lat", poi.point.latitude).put("lon", poi.point.longitude)
                .put("address", poi.address).put("power", poi.chargingPower)
                .put("connectors", poi.chargingConnectors).put("vsp", poi.vspAccessible))
        }
        root.put("pois", arr)
        chargingDiskCacheFile(context, cacheKey).writeText(root.toString())
    } catch (_: Exception) { }
}

private fun loadChargingDiskCache(context: android.content.Context, cacheKey: String): ChargingCorridorCacheEntry? = try {
    val file = chargingDiskCacheFile(context, cacheKey)
    if (!file.exists()) null else {
        val root = JSONObject(file.readText())
        val saved = root.optLong("savedAtMs", 0L)
        if (saved <= 0L || System.currentTimeMillis() - saved > CHARGING_STALE_CACHE_MAX_AGE_MS) null else {
            val arr = root.optJSONArray("pois") ?: org.json.JSONArray()
            val pois = mutableListOf<VspPoi>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val lat = o.optDouble("lat", Double.NaN); val lon = o.optDouble("lon", Double.NaN)
                if (!lat.isFinite() || !lon.isFinite()) continue
                pois += VspPoi(o.optString("name", "Borne de recharge"), o.optString("category", "charge"),
                    GeoPoint(lat, lon), o.optString("address"), o.optString("power"),
                    normalizeChargingConnectors(o.optString("connectors")), o.optBoolean("vsp", true))
            }
            ChargingCorridorCacheEntry(saved, pois)
        }
    }
} catch (_: Exception) { null }

@Volatile
private var lastIrveDiagnostic: String = "IRVE : non interrogée"
@Volatile
private var lastOsmChargingDiagnostic: String = "OSM : non interrogé"

private suspend fun loadChargingPoisForRouteCorridor(
    context: android.content.Context,
    routePoints: List<GeoPoint>,
    routeDistanceMeters: Double,
    endpointIndex: Int = 0,
    connectorProfile: Set<String> = emptySet()
): List<VspPoi> = withContext(Dispatchers.IO) {
    // ETAPE 59 : ODRÉ Explore API 2.1 + filtre géographique explicite.
    // Le jeu bornes-irve expose désormais consolidated_latitude / consolidated_longitude.
    // L'ancien geofilter.distance de l'API 1.0 pouvait répondre HTTP 200 avec 0 record.
    if (routePoints.isEmpty()) return@withContext emptyList()

    val center = routePoints[routePoints.size / 2]
    val radiusMeters = 30000.0
    val connectorCacheKey = connectorProfile.toList().sorted().joinToString("+")
    val cacheKey = String.format(java.util.Locale.US, "v59:%.3f:%.3f:%s", center.latitude, center.longitude, connectorCacheKey)
    val nowMs = System.currentTimeMillis()
    var staleCache: ChargingCorridorCacheEntry? = chargingCorridorCache[cacheKey]
    if (staleCache == null) {
        staleCache = loadChargingDiskCache(context, cacheKey)
        staleCache?.let { chargingCorridorCache[cacheKey] = it }
    }
    staleCache?.let { cached ->
        if (nowMs - cached.savedAtMs <= CHARGING_CACHE_TTL_MS) {
            lastIrveDiagnostic = "IRVE : cache rapide • ${cached.pois.size} borne(s)"
            return@withContext cached.pois
        }
    }

    // Boîte d'environ 30 km autour du centre. Le filtre métrique précis est appliqué ensuite.
    val latDelta = radiusMeters / 111320.0
    val cosLat = kotlin.math.cos(Math.toRadians(center.latitude)).coerceAtLeast(0.20)
    val lonDelta = radiusMeters / (111320.0 * cosLat)
    val minLat = center.latitude - latDelta
    val maxLat = center.latitude + latDelta
    val minLon = center.longitude - lonDelta
    val maxLon = center.longitude + lonDelta
    val where = String.format(
        java.util.Locale.US,
        "consolidated_latitude >= %.6f and consolidated_latitude <= %.6f and consolidated_longitude >= %.6f and consolidated_longitude <= %.6f",
        minLat, maxLat, minLon, maxLon
    )
    val url = "https://odre.opendatasoft.com/api/explore/v2.1/catalog/datasets/bornes-irve/records" +
        "?limit=100&where=" + java.net.URLEncoder.encode(where, "UTF-8")

    val request = Request.Builder().url(url).header("User-Agent", "VSP-GPS/1.0").build()
    val client = OkHttpClient.Builder()
        .connectTimeout(5, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(12, java.util.concurrent.TimeUnit.SECONDS)
        .callTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    fun truthy(row: JSONObject, key: String): Boolean {
        val v = row.opt(key)?.toString()?.trim().orEmpty()
        return v.equals("true", true) || v == "1" || v.equals("yes", true) || v.equals("oui", true)
    }

    try {
        lastIrveDiagnostic = "IRVE : connexion…"
        client.newCall(request).execute().use { response ->
            val httpCode = response.code
            val bodyText = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val fallback = staleCache?.pois.orEmpty()
                lastIrveDiagnostic = if (fallback.isNotEmpty())
                    "IRVE : HTTP $httpCode • dernier cache fiable utilisé • ${fallback.size} borne(s)"
                else "IRVE : HTTP $httpCode • données temporairement indisponibles"
                return@withContext fallback
            }
            val json = JSONObject(bodyText)
            val records = json.optJSONArray("results") ?: org.json.JSONArray()
            val result = mutableListOf<VspPoi>()
            for (i in 0 until records.length()) {
                val row = records.optJSONObject(i) ?: continue
                val lat = row.optDouble("consolidated_latitude", Double.NaN)
                val lon = row.optDouble("consolidated_longitude", Double.NaN)
                if (!lat.isFinite() || !lon.isFinite()) continue
                val point = GeoPoint(lat, lon)
                if (distanceMetersBetween(center, point) > radiusMeters) continue

                val plugs = mutableListOf<String>()
                if (truthy(row, "prise_type_ef")) plugs += "Prise E/F"
                if (truthy(row, "prise_type_2")) plugs += "Type 2"
                if (truthy(row, "prise_type_combo_ccs")) plugs += "CCS Combo 2"
                if (truthy(row, "prise_type_chademo")) plugs += "CHAdeMO"
                if (truthy(row, "prise_type_autre")) plugs += "Autre prise"
                val available = plugs.toSet()
                if (connectorProfile.isNotEmpty() && connectorProfile.none { it in available }) continue

                val power = row.optDouble("puissance_nominale", Double.NaN)
                    .takeIf { it.isFinite() && it > 0.0 }
                    ?.let { if (kotlin.math.abs(it-kotlin.math.round(it)) < .01) "${kotlin.math.round(it).toInt()} kW" else String.format(java.util.Locale.FRANCE, "%.1f kW", it) }
                    .orEmpty()
                val name = row.optString("nom_station").ifBlank { row.optString("nom_enseigne").ifBlank { "Borne de recharge" } }
                val address = row.optString("adresse_station").ifBlank {
                    listOf(row.optString("consolidated_code_postal"), row.optString("consolidated_commune"))
                        .filter { it.isNotBlank() }.distinct().joinToString(" ")
                }
                result += VspPoi(cleanChargingStationName(name), "charge", point, address, power, normalizeChargingConnectors(plugs.distinct().joinToString(" • ")))
            }
            val finalResult = result.distinctBy { vspPoiKey(it) }.take(100)
            lastIrveDiagnostic = "IRVE : HTTP $httpCode • ${records.length()} reçu(s) • ${finalResult.size} compatible(s)"
            // Ne remplace jamais un cache utile par une réponse vide/incomplète.
            if (finalResult.isNotEmpty()) {
                val entry = ChargingCorridorCacheEntry(System.currentTimeMillis(), finalResult)
                chargingCorridorCache[cacheKey] = entry
                saveChargingDiskCache(context, cacheKey, finalResult)
                finalResult
            } else {
                val fallback = staleCache?.pois.orEmpty()
                if (fallback.isNotEmpty()) {
                    lastIrveDiagnostic += " • réponse sans borne exploitable, dernier cache fiable conservé (${fallback.size})"
                    fallback
                } else finalResult
            }
        }
    } catch (e: Exception) {
        val fallback = staleCache?.pois.orEmpty()
        lastIrveDiagnostic = if (fallback.isNotEmpty())
            "IRVE : réseau indisponible (${e.javaClass.simpleName}) • dernier cache fiable utilisé • ${fallback.size} borne(s)"
        else "IRVE : données temporairement indisponibles (${e.javaClass.simpleName})"
        fallback
    }
}

private fun maneuverLooksForbiddenVsp(maneuver: RouteManeuver): Boolean {
    val text = (maneuver.instruction + " " + maneuver.streetNames)
        .lowercase(java.util.Locale.FRANCE)
    val motorwayWord =
        text.contains("autoroute") || text.contains("motorway") ||
        text.contains("voie rapide") || text.contains("voie express") || text.contains("route express") ||
        text.contains("route pour automobiles") || text.contains("route réservée aux automobiles") ||
        text.contains("route reservee aux automobiles") ||
        text.contains("route à accès réglementé") || text.contains("route a acces reglemente")
    val motorwayRamp =
        Regex("""\bbretelle(?:\s+d['’]acc[eè]s)?\s+(?:de\s+)?(?:l['’])?a\s*[- ]?\d+""").containsMatchIn(text) ||
        Regex("""\b(?:entrée|entree|sortie)\s+(?:de\s+)?(?:l['’])?a\s*[- ]?\d+""").containsMatchIn(text)
    val frenchMotorwayNumber =
        Regex("""(^|[\s/,(;-])a\s*[- ]?\s*\d{1,3}($|[\s/),;.-])""").containsMatchIn(text)
    return motorwayWord || motorwayRamp || frenchMotorwayNumber
}

private fun routeContainsForbiddenVspRoad(route: RouteOption): Boolean =
    route.maneuvers.any(::maneuverLooksForbiddenVsp)

// V33 : préfiltre uniquement pour les cas explicitement autoroutiers dans les données IRVE.
// Ce filtre n'est jamais utilisé seul : Valhalla contrôle ensuite la route réellement empruntée.
private fun chargingPoiLooksExplicitlyMotorwayOnly(poi: VspPoi): Boolean {
    val text = "${poi.name} ${poi.address}".lowercase(java.util.Locale.FRANCE)
    val motorwayNumber = Regex("""(^|[\s/,(;-])a\s*\d{1,3}($|[\s/),;-])""").containsMatchIn(text)
    val motorwayArea = listOf(
        "aire d'autoroute", "aire autoroutière", "aire de service", "aire de services",
        "relais autoroutier", "autoroute", "motorway"
    ).any { text.contains(it) }
    return motorwayNumber || motorwayArea
}

private data class IndependentVspRouteCheck(
    val distanceMeters: Double,
    val forbiddenRoadDetected: Boolean,
    val durationSeconds: Double = 0.0,
    // V105 : trajet exact ayant servi aux métriques de la station.
    val route: RouteOption? = null
)

private fun fuelPoiLocality(poi: VspPoi): String {
    val parts = poi.address.split(",").map { it.trim() }.filter { it.isNotBlank() }
    if (parts.isEmpty()) return "Localité non renseignée"
    // Les POI OSM sont construits sous la forme rue, lieu, code postal, commune.
    // La commune est donc normalement le dernier élément. Si l'adresse ne contient
    // qu'un code postal, on garde un libellé neutre plutôt que d'inventer une ville.
    val last = parts.last()
    return if (Regex("""^\d{5}$""").matches(last)) "Secteur ${last}" else last
}

private fun vspPoiKey(poi: VspPoi): String =
    "${poi.category}:${poi.point.latitude}:${poi.point.longitude}"

private fun distanceMetersBetween(a: GeoPoint, b: GeoPoint): Double {
    val result = FloatArray(1)
    android.location.Location.distanceBetween(
        a.latitude, a.longitude,
        b.latitude, b.longitude,
        result
    )
    return result[0].toDouble()
}

// ETAPE 123 : écart angulaire minimal entre deux caps en degrés.
private fun headingDifferenceDegrees(a: Double, b: Double): Double {
    var diff = kotlin.math.abs((a - b) % 360.0)
    if (diff > 180.0) diff = 360.0 - diff
    return diff
}

// ETAPE 123 : cap de départ réellement suivi par une route. On regarde environ
// 35 m devant le premier point afin de ne pas être trompé par deux points quasi
// confondus au départ de la polyline.
private fun routeDepartureBearingDegrees(points: List<GeoPoint>): Double? {
    if (points.size < 2) return null
    val first = points.first()
    var travelled = 0.0
    for (i in 1 until points.size) {
        val previous = points[i - 1]
        val current = points[i]
        travelled += distanceMetersBetween(previous, current)
        if (travelled >= 35.0) {
            return first.bearingTo(current)
        }
    }
    return first.bearingTo(points.last())
}


private fun routePointAtDistance(points: List<GeoPoint>, targetMeters: Double): GeoPoint? {
    if (points.isEmpty()) return null
    if (points.size == 1 || targetMeters <= 0.0) return points.first()
    var travelled = 0.0
    for (i in 1 until points.size) {
        val a = points[i - 1]
        val b = points[i]
        val segment = distanceMetersBetween(a, b)
        if (travelled + segment >= targetMeters && segment > 0.0) {
            val ratio = ((targetMeters - travelled) / segment).coerceIn(0.0, 1.0)
            return GeoPoint(
                a.latitude + (b.latitude - a.latitude) * ratio,
                a.longitude + (b.longitude - a.longitude) * ratio
            )
        }
        travelled += segment
    }
    return points.last()
}

private fun routeProgressMetersNearest(point: GeoPoint, route: List<GeoPoint>): Double {
    if (route.isEmpty()) return 0.0
    var bestDistance = Double.POSITIVE_INFINITY
    var bestProgress = 0.0
    var progress = 0.0
    for (i in route.indices) {
        val d = distanceMetersBetween(point, route[i])
        if (d < bestDistance) {
            bestDistance = d
            bestProgress = progress
        }
        if (i + 1 < route.size) {
            progress += distanceMetersBetween(route[i], route[i + 1])
        }
    }
    return bestProgress
}

private fun distanceFromPoiToRouteMeters(poi: GeoPoint, route: List<GeoPoint>): Double {
    if (route.isEmpty()) return Double.POSITIVE_INFINITY
    // Les tracés Valhalla sont suffisamment denses pour cette vérification visuelle.
    // On échantillonne pour garder le calcul léger sur le téléphone.
    val step = kotlin.math.max(1, route.size / 120)
    var best = Double.POSITIVE_INFINITY
    var i = 0
    while (i < route.size) {
        best = kotlin.math.min(best, distanceMetersBetween(poi, route[i]))
        i += step
    }
    best = kotlin.math.min(best, distanceMetersBetween(poi, route.last()))
    return best
}



// V104 : décodeur autonome utilisé par le contrôle des trajets vers les stations.
private suspend fun decodePolyline6ForStationCheck(encoded: String): List<GeoPoint> {
    val points = mutableListOf<GeoPoint>()
    var index = 0
    var latitude = 0L
    var longitude = 0L
    fun nextValue(): Long {
        var result = 0L
        var shift = 0
        var b: Int
        do {
            // V258 : appliquer la même protection que sur le trajet principal.
            // Une polyline de station tronquée ne doit pas être complétée artificiellement
            // avec une valeur 0, au risque de valider une géométrie incorrecte.
            if (index >= encoded.length) {
                throw IllegalArgumentException("Polyline6 station tronquée")
            }
            b = encoded[index++].code - 63
            result = result or ((b and 0x1f).toLong() shl shift)
            shift += 5
        } while (b >= 0x20)
        return if ((result and 1L) != 0L) -(result shr 1) - 1L else result shr 1
    }
    var decodedPointCount = 0
    while (index < encoded.length) {
        // V230 : le décodage polyline peut lui-même durer sur un long trajet.
        // Contrôler périodiquement l'annulation au cœur de la boucle évite
        // d'attendre la fin de toute la forme avant d'abandonner une station obsolète.
        if (decodedPointCount % 128 == 0) currentCoroutineContext().ensureActive()
        latitude += nextValue()
        longitude += nextValue()
        points += GeoPoint(latitude / 1_000_000.0, longitude / 1_000_000.0)
        decodedPointCount += 1
    }
    return points
}

// V221 : client HTTP partagé par les contrôles d’itinéraires vers les stations.
// Évite de recréer un pool de connexions, DNS et sockets pour chaque station testée.
private val stationRouteHttpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
        .connectTimeout(12, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
        .writeTimeout(12, java.util.concurrent.TimeUnit.SECONDS)
        .callTimeout(25, java.util.concurrent.TimeUnit.SECONDS)
        .build()
}

// V104 : contrôle le tracé réellement calculé vers une station, et non seulement
// les noms des manoeuvres. Les motorway et les voies portant un numéro Axx sont rejetées.
// V234 : expression régulière partagée entre tous les contrôles de stations.
// Elle n'est plus recompilée à chaque trajet contrôlé.
private val stationMotorwayNumberRegex = Regex(
    """(^|[\\s/,(;-])a\\s*\\d{1,3}($|[\\s/),;-])""",
    RegexOption.IGNORE_CASE
)

private suspend fun stationRouteHasForbiddenValhallaEdge(points: List<GeoPoint>): Boolean? = withContext(Dispatchers.IO) {
    // V223 : ne pas lancer un second appel Valhalla si la recherche de stations
    // a été annulée pendant l'étape précédente.
    currentCoroutineContext().ensureActive()
    if (points.size < 2) return@withContext null
    val maxShapePoints = 160
    // V235 : borner strictement le contrôle à 160 points maximum tout en conservant
    // toujours le départ et l'arrivée. Les points intermédiaires sont répartis sur tout
    // le tracé, ce qui évite le 161e point que pouvait encore ajouter l'échantillonnage précédent.
    val sampled = if (points.size <= maxShapePoints) {
        ArrayList(points)
    } else {
        ArrayList<GeoPoint>(maxShapePoints).apply {
            for (samplePosition in 0 until maxShapePoints) {
                if (samplePosition % 32 == 0) currentCoroutineContext().ensureActive()
                val sourceIndex = (
                    samplePosition.toLong() * points.lastIndex.toLong() /
                        (maxShapePoints - 1).toLong()
                ).toInt()
                add(points[sourceIndex])
            }
        }
    }
    val payload = JSONObject().apply {
        put("shape", org.json.JSONArray().apply {
            // V241 : la construction du payload trace_attributes reste annulable elle aussi.
            // Une recherche remplacée n'a plus besoin de sérialiser les points restants.
            sampled.forEachIndexed { index, p ->
                if (index % 32 == 0) currentCoroutineContext().ensureActive()
                put(JSONObject().apply { put("lat", p.latitude); put("lon", p.longitude) })
            }
        })
        put("costing", "auto")
        put("shape_match", "map_snap")
        put("filters", JSONObject().apply {
            put("action", "include")
            put("attributes", org.json.JSONArray().apply {
                put("edge.road_class"); put("edge.names")
            })
        })
    }
    // V243 : la sérialisation JSON peut être non négligeable avec jusqu’à 160 points.
    // Si la recherche est annulée pendant cette étape, ne pas lancer ensuite l’appel réseau.
    val payloadJson = payload.toString()
    currentCoroutineContext().ensureActive()
    val request = Request.Builder()
        .url("https://valhalla1.openstreetmap.de/trace_attributes")
        .post(okhttp3.RequestBody.create(null, payloadJson))
        .header("Content-Type", "application/json")
        .header("X-Client-Id", "fr.vspgps.app")
        .header("User-Agent", "VSP-GPS-Android/1.0")
        .build()
    try {
        // V219 : appliquer aussi un délai total au contrôle de sécurité des trajets
        // vers les stations. Ce contrôle utilisait encore le client OkHttp par défaut et
        // pouvait donc attendre beaucoup plus longtemps qu'un calcul d'itinéraire normal.
        val call = stationRouteHttpClient.newCall(request)
        // V224 : relier l'annulation de la coroutine (notamment withTimeoutOrNull)
        // à l'appel OkHttp bloquant. Sans cela, le timeout Kotlin pouvait expirer
        // alors que execute() continuait encore jusqu'au timeout réseau.
        val cancellationHandle = currentCoroutineContext()[kotlinx.coroutines.Job]?.invokeOnCompletion { cause ->
            if (cause is kotlinx.coroutines.CancellationException) call.cancel()
        }
        try {
            call.execute().use { response ->
            // V236 : l'appel HTTP peut se terminer au même instant que l'annulation
            // de la recherche. Ne pas commencer à traiter une réponse déjà obsolète.
            currentCoroutineContext().ensureActive()
            if (!response.isSuccessful) return@withContext null
            val body = response.body?.string() ?: return@withContext null
            // V226 : une annulation peut arriver pendant la lecture du corps HTTP.
            // Ne pas parser ni parcourir les arêtes d'une station devenue obsolète.
            currentCoroutineContext().ensureActive()
            val parsedTrace = JSONObject(body)
            // V240 : le parsing JSON d'une réponse trace_attributes peut lui-même prendre
            // un peu de temps. Revalider l'annulation juste après avant de parcourir les arêtes.
            currentCoroutineContext().ensureActive()
            val edges = parsedTrace.optJSONArray("edges") ?: return@withContext null
            for (i in 0 until edges.length()) {
                if (i % 24 == 0) currentCoroutineContext().ensureActive()
                val edge = edges.optJSONObject(i) ?: continue
                val roadClass = edge.optString("road_class", "").lowercase(Locale.ROOT)
                // V239 : si Valhalla classe déjà l'arête comme autoroute, inutile de
                // parcourir ses noms. On rejette immédiatement ce trajet pour la VSP.
                if (roadClass == "motorway") return@withContext true
                val names = edge.optJSONArray("names")
                // V237 : vérifier les noms d'axe un par un et s'arrêter au premier numéro
                // d'autoroute détecté. Évite de construire une grande chaîne temporaire pour
                // chaque arête et réduit le travail lors des contrôles de plusieurs stations.
                if (names != null) {
                    for (nameIndex in 0 until names.length()) {
                        // V238 : même la boucle interne des noms reste annulable. Sur une réponse
                        // inhabituelle contenant beaucoup de noms, une recherche remplacée ne
                        // continue donc pas inutilement jusqu'à la fin de l'arête.
                        if (nameIndex % 8 == 0) currentCoroutineContext().ensureActive()
                        // V242 : rejeter directement l'arête dès qu'un nom d'autoroute Axx est
                        // détecté. Plus besoin d'un booléen temporaire ni de poursuivre la logique.
                        if (stationMotorwayNumberRegex.containsMatchIn(names.optString(nameIndex))) {
                            return@withContext true
                        }
                    }
                }
            }
            // V245 : une annulation peut survenir juste après la dernière arête (ou si
            // Valhalla renvoie une liste vide). Ne jamais transformer ce cas en résultat
            // « trajet autorisé » pour une recherche qui n’est déjà plus active.
            currentCoroutineContext().ensureActive()
            false
            }
        } finally {
            cancellationHandle?.dispose()
        }
    } catch (e: Exception) {
        // V222 : une annulation de coroutine ne doit pas être transformée en
        // résultat inconnu pendant le contrôle de sécurité d’une station.
        if (e is kotlinx.coroutines.CancellationException) throw e
        null
    }
}

private suspend fun calculateIndependentVspRouteCheck(
    start: GeoPoint,
    end: GeoPoint
): IndependentVspRouteCheck? = withContext(Dispatchers.IO) {
    try {
        // V225 : ne pas préparer ni lancer un contrôle station si son timeout ou
        // la recherche parente l'a déjà annulé avant l'entrée dans cette fonction.
        currentCoroutineContext().ensureActive()
        val payload = JSONObject().apply {
            put("locations", org.json.JSONArray().apply {
                put(JSONObject().apply { put("lat", start.latitude); put("lon", start.longitude) })
                put(JSONObject().apply { put("lat", end.latitude); put("lon", end.longitude) })
            })
            put("costing", "auto")
            put("costing_options", JSONObject().apply {
                put("auto", JSONObject().apply {
                    put("use_highways", 0.0)
                    put("use_tolls", 0.0)
                    put("use_ferry", 0.0)
                    put("top_speed", 45)
                    put("fixed_speed", 45)
                    put("ignore_access", false)
                    put("ignore_restrictions", false)
                    put("ignore_closures", false)
                })
            })
            put("directions_options", JSONObject().apply {
                put("language", "fr-FR")
                put("units", "kilometers")
                // ETAPE 49 : conserver explicitement les sorties de TOUS les ronds-points
                // dans les manœuvres Valhalla, y compris quand l'axe suivi reste presque droit.
                put("roundabout_exits", true)
            })
        }

        // V244 : comme pour trace_attributes, la sérialisation du payload /route peut
        // se terminer après l'annulation de la recherche. Ne pas lancer un appel réseau
        // devenu inutile si le timeout ou une nouvelle recherche est déjà intervenu.
        val payloadJson = payload.toString()
        currentCoroutineContext().ensureActive()

        val request = Request.Builder()
            .url("https://valhalla1.openstreetmap.de/route")
            .post(okhttp3.RequestBody.create(null, payloadJson))
            .header("Content-Type", "application/json")
            .header("X-Client-Id", "fr.vspgps.app")
            .header("User-Agent", "VSP-GPS-Android/1.0")
            .build()

        // V220 : borner aussi la requête /route utilisée pour contrôler les stations.
        // Ainsi, les deux étapes du contrôle (route puis trace_attributes) disposent
        // désormais d'une durée maximale cohérente et une station inaccessible ne
        // peut plus immobiliser longtemps le classement.
        val call = stationRouteHttpClient.newCall(request)
        // V224 : relier l'annulation de la coroutine (notamment withTimeoutOrNull)
        // à l'appel OkHttp bloquant. Sans cela, le timeout Kotlin pouvait expirer
        // alors que execute() continuait encore jusqu'au timeout réseau.
        val cancellationHandle = currentCoroutineContext()[kotlinx.coroutines.Job]?.invokeOnCompletion { cause ->
            if (cause is kotlinx.coroutines.CancellationException) call.cancel()
        }
        try {
            call.execute().use { response ->
            // V225 : si l'appel a fini au même instant que l'annulation, ne pas
            // décoder une réponse devenue inutile ni poursuivre vers trace_attributes.
            currentCoroutineContext().ensureActive()
            if (!response.isSuccessful) return@withContext null
            val body = response.body?.string() ?: return@withContext null
            currentCoroutineContext().ensureActive()
            val parsedStationRoute = JSONObject(body)
            // V253 : le parsing JSON de /route peut lui-même prendre du temps.
            // Si la recherche station est annulée pendant ce parsing, ne pas poursuivre
            // le décodage du tracé ni l'analyse des manœuvres devenues obsolètes.
            currentCoroutineContext().ensureActive()
            val trip = parsedStationRoute.optJSONObject("trip") ?: return@withContext null
            val summary = trip.optJSONObject("summary") ?: return@withContext null
            val km = summary.optDouble("length", Double.NaN)
            val durationSeconds = summary.optDouble("time", 0.0)
            if (!km.isFinite() || km <= 0.0) return@withContext null

            var forbidden = false
            val stationRoutePoints = mutableListOf<GeoPoint>()
            val stationManeuvers = mutableListOf<RouteManeuver>()
            val legs = trip.optJSONArray("legs")
            if (legs != null) {
                for (i in 0 until legs.length()) {
                    // V227 : si le contrôle de cette station a été annulé pendant le
                    // décodage d’un itinéraire multi-segments, arrêter immédiatement.
                    currentCoroutineContext().ensureActive()
                    val shape = legs.optJSONObject(i)?.optString("shape", "").orEmpty()
                    if (shape.isNotBlank()) {
                        val decoded = decodePolyline6ForStationCheck(shape)
                        // V228 : le décodage d'une forme peut être coûteux sur un long trajet.
                        // Vérifier l'annulation juste après pour ne pas recopier des milliers de
                        // points si cette recherche de station n'est déjà plus utile.
                        currentCoroutineContext().ensureActive()
                        if (stationRoutePoints.isNotEmpty() && decoded.isNotEmpty()) {
                            // V255 : éviter decoded.drop(1), qui créait une seconde liste
                            // complète pour chaque segment de trajet vers une station.
                            // Ajouter directement les points à partir de l’index 1 réduit
                            // la mémoire temporaire sans changer la géométrie obtenue.
                            for (pointIndex in 1 until decoded.size) {
                                if (pointIndex % 128 == 0) currentCoroutineContext().ensureActive()
                                stationRoutePoints.add(decoded[pointIndex])
                            }
                        } else {
                            stationRoutePoints.addAll(decoded)
                        }
                    }
                }
                for (i in 0 until legs.length()) {
                    currentCoroutineContext().ensureActive()
                    val maneuvers = legs.optJSONObject(i)?.optJSONArray("maneuvers") ?: continue
                    for (m in 0 until maneuvers.length()) {
                        // V227 : ne pas continuer à analyser les manœuvres d’une station
                        // devenue obsolète après un timeout ou une nouvelle recherche.
                        if (m % 12 == 0) currentCoroutineContext().ensureActive()
                        val maneuver = maneuvers.optJSONObject(m) ?: continue
                        val names = maneuver.optJSONArray("street_names")
                        // V246 : construire les noms de rue sans collection intermédiaire et
                        // rester annulable même si Valhalla renvoie une liste inhabituelle.
                        // V435 : appliquer aussi aux itinéraires vers les stations la déduplication
                        // introduite en V434 pour le guidage principal. Un doublon Valhalla tel que
                        // « D58 / D58 » ne peut donc plus réapparaître dans cette branche secondaire.
                        val streetNames = if (names != null && names.length() > 0) {
                            buildString {
                                var lastStreetName: String? = null
                                for (nameIndex in 0 until names.length()) {
                                    if (nameIndex % 8 == 0) currentCoroutineContext().ensureActive()
                                    val name = names.optString(nameIndex).trim()
                                    if (name.isNotBlank() && !name.equals(lastStreetName, ignoreCase = true)) {
                                        if (isNotEmpty()) append(" / ")
                                        append(name)
                                        lastStreetName = name
                                    }
                                }
                            }
                        } else ""
                        val parsedManeuver = RouteManeuver(
                            type = maneuver.optInt("type", 0),
                            instruction = maneuver.optString("instruction", maneuver.optString("verbal_pre_transition_instruction", "")),
                            streetNames = streetNames,
                            beginShapeIndex = maneuver.optInt("begin_shape_index", 0),
                            endShapeIndex = maneuver.optInt("end_shape_index", 0),
                            roundaboutExitCount = maneuver.optInt("roundabout_exit_count", 0)
                        )
                        stationManeuvers += parsedManeuver
                        // V231 : contrôler directement la manœuvre au lieu de créer un
                        // RouteOption temporaire pour chacune. Sur une recherche comportant
                        // plusieurs stations, cela réduit les allocations sans modifier la
                        // règle de sécurité VSP utilisée pour détecter les voies interdites.
                        if (maneuverLooksForbiddenVsp(parsedManeuver)) {
                            forbidden = true
                            break
                        }
                    }
                    if (forbidden) break
                }
            }
            // V104 : seconde barrière sur les arêtes réellement empruntées.
            if (!forbidden && stationRoutePoints.size >= 2) {
                // V223 : si la recherche a été remplacée pendant l'appel /route,
                // ne pas enchaîner inutilement avec trace_attributes.
                currentCoroutineContext().ensureActive()
                if (stationRouteHasForbiddenValhallaEdge(stationRoutePoints) == true) forbidden = true
            }
            // V228 : dernière barrière avant de construire et retourner l'itinéraire station.
            currentCoroutineContext().ensureActive()
            val exactRoute = if (!forbidden && stationRoutePoints.size >= 2) {
                RouteOption(
                    points = stationRoutePoints,
                    distanceMeters = km * 1000.0,
                    durationSeconds = durationSeconds,
                    vspValidated = true,
                    maneuvers = stationManeuvers
                )
            } else null
            IndependentVspRouteCheck(km * 1000.0, forbidden, durationSeconds, exactRoute)
            }
        } finally {
            cancellationHandle?.dispose()
        }
    } catch (e: Exception) {
        // V222 : propager aussi l’annulation du calcul complet vers une station
        // afin qu’un écran quitté ou une recherche remplacée s’arrête proprement.
        if (e is kotlinx.coroutines.CancellationException) throw e
        null
    }
}

// ETAPE 67 : les validations des maillons de recharge utilisent désormais le même
// moteur Valhalla LOCAL et le même pack régional que le trajet principal. Les versions
// précédentes lançaient jusqu'à 16 appels Internet en parallèle avec un timeout de 2,2 s :
// cela pouvait classer à tort une borne comme « Valhalla aller/sortie » simplement parce
// que le serveur public n'avait pas répondu assez vite. Le calcul local évite ce faux rejet
// et conserve la validation locale zéro motorway de calculateRouteJson ; trunk reste un point de contrôle, pas une interdiction automatique.
private suspend fun calculateIndependentLocalVspRouteCheck(
    router: LocalValhallaRouter,
    start: GeoPoint,
    end: GeoPoint
): IndependentVspRouteCheck? = withContext(Dispatchers.IO) {
    currentCoroutineContext().ensureActive()
    val result = router.calculateRouteJson(
        startLatitude = start.latitude,
        startLongitude = start.longitude,
        endLatitude = end.latitude,
        endLongitude = end.longitude
    )
    result.fold(
        onSuccess = { json ->
            val trip = json.optJSONObject("trip") ?: return@fold null
            val summary = trip.optJSONObject("summary") ?: return@fold null
            val km = summary.optDouble("length", Double.NaN)
            if (!km.isFinite() || km <= 0.0) return@fold null
            val seconds = summary.optDouble("time", 0.0)
            IndependentVspRouteCheck(
                distanceMeters = km * 1000.0,
                forbiddenRoadDetected = false,
                durationSeconds = seconds,
                route = null
            )
        },
        onFailure = { null }
    )
}

private suspend fun calculateIndependentVspRoadDistanceMeters(
    start: GeoPoint,
    end: GeoPoint
): Double? {
    val check = calculateIndependentVspRouteCheck(start, end) ?: return null
    return if (check.forbiddenRoadDetected) null else check.distanceMeters
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun MapSearchScreen(
    vehicle: VehicleType,
    energyType: EnergyType,
    onBack: () -> Unit
) {

    val context =
        androidx.compose.ui.platform.LocalContext.current

    val keyboardController = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
    val focusManager = androidx.compose.ui.platform.LocalFocusManager.current

    val scope = rememberCoroutineScope()

    // Diagnostic temporaire : permet de prouver qu'un calcul est effectué par
    // le moteur Valhalla embarqué, sans passer par le serveur public.
    val localValhallaRouter = remember(context) { LocalValhallaRouter(context) }
    var localValhallaDiagnostic by remember { mutableStateOf<String?>(null) }
    var localValhallaTestRunning by remember { mutableStateOf(false) }
    var localRerouteTestRunning by remember { mutableStateOf(false) }
    var comparisonRunning by remember { mutableStateOf(false) }
    var comparisonResult by remember { mutableStateOf<String?>(null) }
    var comparisonPreview by remember { mutableStateOf<List<LocalValhallaRouter.ProfilePreview>?>(null) }
    var comparisonDialogVisible by remember { mutableStateOf(false) }
    var lastRouteEngine by remember { mutableStateOf("Aucun trajet calculé dans cette session") }
    // ETAPE 133 : rendre immédiatement visible si le trajet survivra à une perte de réseau.
    var lastRouteOfflineReady by rememberSaveable { mutableStateOf<Boolean?>(null) }
    var acceptedRouteValidation by remember { mutableStateOf<String?>(null) }
    var acceptedHighSpeedAudit by remember { mutableStateOf<List<String>>(emptyList()) }
    // Étape 78 : détails des bretelles réellement empruntées par le candidat local retenu.
    var acceptedRampAudit by remember { mutableStateOf<List<String>>(emptyList()) }
    DisposableEffect(localValhallaRouter) {
        onDispose { localValhallaRouter.close() }
    }

    // V189 : conserver un seul client Valhalla pendant toute la session de la carte.
    // Les nouveaux itinéraires et recalculs réutilisent ainsi DNS, sockets et pool HTTP,
    // au lieu de reconstruire un client à chaque appel de calculateRoute().
    val routeHttpClient = remember {
        OkHttpClient.Builder()
            .connectTimeout(12, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
            .writeTimeout(12, java.util.concurrent.TimeUnit.SECONDS)
            // V214 : borner aussi la durée totale d’un appel Valhalla. Les timeouts
            // connexion/lecture/écriture ne couvrent pas forcément toute la vie de
            // la requête ; ce garde-fou évite qu’un calcul reste bloqué trop longtemps.
            .callTimeout(25, java.util.concurrent.TimeUnit.SECONDS)
            .build()
    }

    // ETAPE 122 : la destination persistée n'est utilisée que si l'état mémoire de
    // rotation n'en contient pas déjà une. Le tracé, lui, sera recalculé depuis le GPS réel.
    val storedActiveTrip = remember { loadStoredActiveTrip(context) }
    val restoredStoredDestination = if (RotationRetainedState.destination == null) {
        storedActiveTrip?.destination
    } else null
    var query by remember {
        mutableStateOf(
            RotationRetainedState.query.ifBlank { restoredStoredDestination?.label.orEmpty() }
        )
    }
    val historyContext = androidx.compose.ui.platform.LocalContext.current
    var searchHistory by remember { mutableStateOf(loadSearchHistory(historyContext)) }
    var searchFieldActive by remember { mutableStateOf(false) }
    var homeFavorite by remember { mutableStateOf(loadFavorite(historyContext, FAVORITE_HOME)) }
    var workFavorite by remember { mutableStateOf(loadFavorite(historyContext, FAVORITE_WORK)) }
    var starFavorite by remember { mutableStateOf(loadFavorite(historyContext, FAVORITE_STAR)) }
    var showFavoriteDialog by remember { mutableStateOf<String?>(null) }
    var manageFavoriteKey by remember { mutableStateOf<String?>(null) }
    var fuelType by remember { mutableStateOf(FuelType.DIESEL) }
    // V111 : l'utilisateur peut garder l'ordre par proximité ou comparer les prix
    // du carburant réellement compatible avec sa VSP.
    var fuelSortByPrice by remember { mutableStateOf(false) }
    var chargingProfile by remember { mutableStateOf(loadChargingConnectors(historyContext)) }
    var chargingProfileConfirmed by remember { mutableStateOf(isChargingProfileConfirmed(historyContext)) }
    var showChargingProfileDialog by remember { mutableStateOf(false) }
    var batteryMaxRangeKm by remember { mutableStateOf(loadBatteryMaxRange(historyContext)) }
    var batteryLevelPercent by remember { mutableStateOf(loadBatteryLevel(historyContext)) }
    var showBatteryProfileDialog by remember { mutableStateOf(false) }
    // V41 : saisie du niveau de batterie réellement atteint après une recharge.
    var rechargeBatteryStopIndex by remember { mutableStateOf<Int?>(null) }
    var rechargeBatteryPercent by remember { mutableStateOf<Int?>(null) }
    // V47 : borne réellement indisponible pendant le trajet + batterie restante saisie par le conducteur.
    var unavailableChargeStop by remember { mutableStateOf<PlannedChargeStop?>(null) }
    var unavailableBatteryPercent by remember { mutableStateOf<Int?>(null) }


    var destination by remember {
        mutableStateOf(RotationRetainedState.destination ?: restoredStoredDestination)
    }

    var searching by remember {
        mutableStateOf(false)
    }

    var addressSuggestions by remember { mutableStateOf<List<Destination>>(emptyList()) }
    var destinationConfirmed by rememberSaveable {
        mutableStateOf(
            (RotationRetainedState.destinationConfirmed && RotationRetainedState.destination != null) ||
                restoredStoredDestination != null
        )
    }
    var confirmedDestinationLabel by rememberSaveable {
        mutableStateOf(
            RotationRetainedState.confirmedDestinationLabel.ifBlank {
                when {
                    RotationRetainedState.destinationConfirmed -> RotationRetainedState.destination?.label.orEmpty()
                    restoredStoredDestination != null -> restoredStoredDestination.label
                    else -> ""
                }
            }
        )
    }
    var suggestionsLoading by remember { mutableStateOf(false) }
    var suggestionSelectionInProgress by remember { mutableStateOf(false) }

    var error by remember {
        mutableStateOf<String?>(null)
    }
    // V140 : un échec réseau pendant un recalcul ne doit pas détruire le trajet actif.
    // Ce message est affiché uniquement pendant la navigation et disparaît dès qu'un
    // nouveau trajet a réellement été obtenu.
    var navigationNetworkWarning by remember { mutableStateOf<String?>(null) }
    // V158 : sérialise les recalculs automatiques. Si plusieurs positions GPS demandent
    // un recalcul pendant qu'une requête est déjà en cours, seule la position la plus
    // récente est conservée et sera réévaluée après la fin du calcul courant.
    var pendingNavigationRerouteStart by remember { mutableStateOf<GeoPoint?>(null) }
    // V159 : après un échec réseau, attendre avant de relancer Valhalla. La dernière
    // position demandée reste mémorisée afin d'éviter une boucle de requêtes.
    var navigationRerouteRetryNotBefore by remember { mutableStateOf(0L) }

    var locationGranted by remember {
        mutableStateOf(false)
    }

    var currentLocation by remember {
        mutableStateOf<Location?>(RotationRetainedState.lastLocation?.let { Location(it) })
    }

    var nearbyPois by remember { mutableStateOf<List<VspPoi>>(emptyList()) }
    var poisLoading by remember { mutableStateOf(false) }
    var selectedPoiCategory by remember { mutableStateOf<String?>(null) }
    var fuelDataSource by remember { mutableStateOf("OSM secours") }
    // V114 : évite de retélécharger le flux DGCCRF à chaque ouverture de la liste.
    // Les prix sont rafraîchis au plus toutes les 10 minutes pendant la session.
    var fuelOfficialLoadedAt by remember { mutableStateOf(0L) }
    var selectedPoiForConfirm by remember { mutableStateOf<Pair<VspPoi, Double>?>(null) }
    var inaccessiblePoiKeys by remember { mutableStateOf<Set<String>>(emptySet()) }
    // V66 : vraie distance/temps routiers VSP jusqu’aux stations validées par Valhalla.
    var fuelRoadMetrics by remember { mutableStateOf<Map<String, Pair<Double, Double>>>(emptyMap()) }
    // V105 : cache du tracé EXACT validé pour chaque station affichée.
    var fuelValidatedRoutes by remember { mutableStateOf<Map<String, RouteOption>>(emptyMap()) }
    var poiRouteLoading by remember { mutableStateOf(false) }
    // V452 : états partagés entre les Activity successives. Si Android recrée l'écran
    // pendant une planification, la nouvelle UI se rattache au calcul déjà en cours.
    var routeChargeSearchLoading by RotationRetainedState.routeChargeSearchLoading
    var routeChargeSuggestion by RotationRetainedState.routeChargeSuggestion
    var routeChargePlan by RotationRetainedState.routeChargePlan
    // V440 : pendant un trajet électrique planifié, les bornes sont des étapes
    // intermédiaires. On conserve séparément la vraie destination finale.
    var chargePlanFinalDestination by RotationRetainedState.chargePlanFinalDestination
    var navigatingToChargeStep by RotationRetainedState.navigatingToChargeStep
    // V40 : distance Valhalla réellement validée entre la dernière recharge et la destination.
    var routeChargeFinalLegMeters by RotationRetainedState.routeChargeFinalLegMeters
    var routeChargeSearchMessage by RotationRetainedState.routeChargeSearchMessage
    val poiScope = rememberCoroutineScope()

    val startPoint = currentLocation?.let {
        GeoPoint(it.latitude, it.longitude)
    }

    LaunchedEffect(startPoint != null) {
        val center = startPoint ?: return@LaunchedEffect
        poisLoading = true
        if (error == "Recherche des points à proximité…") error = null

        nearbyPois = kotlinx.coroutines.withTimeoutOrNull(12000L) {
            loadNearbyVspPois(center)
        } ?: emptyList()

        poisLoading = false
        if (error == "Recherche des points à proximité…") error = null
    }
    var routeOptions by remember {
        mutableStateOf(RotationRetainedState.routeOptions)
    }

    var selectedRouteIndex by remember {
        mutableStateOf(RotationRetainedState.selectedRouteIndex.coerceIn(0, kotlin.math.max(0, RotationRetainedState.routeOptions.lastIndex)))
    }

    var navigationStarted by remember {
        mutableStateOf(RotationRetainedState.navigationStarted && RotationRetainedState.routeOptions.isNotEmpty())
    }

    // ETAPE 129 : pendant une navigation réelle ou une navigation d’essai, le téléphone
    // ne doit pas éteindre l’écran au milieu du guidage. On applique le verrou uniquement
    // tant que navigationStarted est vrai et on restaure l’état précédent en quittant le GPS.
    // Cette protection est purement visuelle : aucun impact sur Valhalla ou le guidage.
    val navigationHostView = androidx.compose.ui.platform.LocalView.current
    DisposableEffect(navigationStarted, navigationHostView) {
        val previousKeepScreenOn = navigationHostView.keepScreenOn
        if (navigationStarted) navigationHostView.keepScreenOn = true
        onDispose {
            if (navigationStarted) navigationHostView.keepScreenOn = previousKeepScreenOn
        }
    }

    // V383 : recopier l’état de navigation en mémoire avant/pendant une rotation.
    SideEffect {
        RotationRetainedState.query = query
        RotationRetainedState.destination = destination
        RotationRetainedState.destinationConfirmed = destinationConfirmed
        RotationRetainedState.confirmedDestinationLabel = confirmedDestinationLabel
        RotationRetainedState.routeOptions = routeOptions
        RotationRetainedState.selectedRouteIndex = selectedRouteIndex
        RotationRetainedState.navigationStarted = navigationStarted
        currentLocation?.let { RotationRetainedState.lastLocation = Location(it) }
    }

    // Lorsqu'un départ est demandé avant que l'itinéraire soit calculé,
    // on démarre automatiquement la navigation dès que le calcul réussit.
    var startAfterRouteCalculation by remember { mutableStateOf(false) }
    // ETAPE 122 : après destruction du processus, la destination est restaurée mais pas
    // l'ancien tracé. Dès qu'un nouveau fix GPS est disponible, on recalcule une fois.
    var storedTripResumePending by remember {
        mutableStateOf(storedActiveTrip != null && RotationRetainedState.routeOptions.isEmpty())
    }
    // ETAPE 127 : une arrivée finale réellement confirmée par NavigationScreen
    // invalide immédiatement la reprise persistée, puis ferme le guidage après
    // un court délai. Le conducteur voit ainsi l'état « Vous êtes arrivé » avant
    // de revenir automatiquement à l'écran d'itinéraire.
    var finalArrivalAutoFinishToken by remember { mutableStateOf(0L) }

    LaunchedEffect(finalArrivalAutoFinishToken) {
        val token = finalArrivalAutoFinishToken
        if (token <= 0L) return@LaunchedEffect
        kotlinx.coroutines.delay(12_000L)
        if (finalArrivalAutoFinishToken == token && navigationStarted) {
            navigationStarted = false
            clearStoredActiveTrip(context)
        }
    }

    val routePoints =
        (routeOptions.getOrNull(selectedRouteIndex) ?: routeOptions.firstOrNull())?.points ?: emptyList()
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions(),
        onResult = { permissions: Map<String, Boolean> ->
            locationGranted =
                permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                        permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        }
    )

    val locationManager = context.getSystemService(
        android.content.Context.LOCATION_SERVICE
    ) as android.location.LocationManager
    LaunchedEffect(Unit) {

        locationGranted =
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED

        if (!locationGranted) {

            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
        if (locationGranted) {
            try {
                currentLocation =
                    locationManager.getLastKnownLocation(
                        android.location.LocationManager.GPS_PROVIDER
                    )
                        ?: locationManager.getLastKnownLocation(
                            android.location.LocationManager.NETWORK_PROVIDER
                        )
            } catch (e: SecurityException) {
                currentLocation = null
            }
        }
    }
    suspend fun routeIsVspCompatible(points: List<GeoPoint>): Boolean =
        withContext(Dispatchers.IO) {
            if (points.isEmpty()) return@withContext false

            val maxSamples = 50
            val step = kotlin.math.max(1, points.size / maxSamples)
            val sampled = points.filterIndexed { index, _ -> index % step == 0 }
                .take(maxSamples)

            val clauses = sampled.joinToString("\n") { p ->
                """
                way(around:6,${p.latitude},${p.longitude})["highway"~"^(motorway|motorway_link)$"];
                way(around:6,${p.latitude},${p.longitude})["motorroad"="yes"];
                """.trimIndent()
            }

            val query = "[out:json][timeout:20];($clauses);out ids;"
            val requestBody = okhttp3.FormBody.Builder()
                .add("data", query)
                .build()

            val request = Request.Builder()
                .url("https://overpass-api.de/api/interpreter")
                .post(requestBody)
                .header("User-Agent", "VSP-GPS/1.0")
                .build()

            try {
                OkHttpClient().newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@withContext false
                    val body = response.body?.string() ?: return@withContext false
                    val json = JSONObject(body)
                    json.optJSONArray("elements")?.length() == 0
                }
            } catch (_: Exception) {
                false
            }
        }

    // V59 : seconde barrière de sécurité. On remappe le tracé calculé sur Valhalla
    // et on inspecte les arêtes réellement empruntées. Contrairement à un contrôle
    // "à proximité", une autoroute simplement voisine du trajet ne provoque pas de faux positif.
    // V216 : suivre aussi la requête de validation fine trace_attributes. Jusqu'ici,
    // activeRouteCall ne couvrait que /route : un nouveau calcul pouvait donc laisser
    // cette seconde requête Valhalla continuer jusqu'au timeout.
    val activeRouteCall = remember { java.util.concurrent.atomic.AtomicReference<okhttp3.Call?>(null) }

    suspend fun firstForbiddenValhallaEdgePoint(points: List<GeoPoint>): GeoPoint? =
        withContext(Dispatchers.IO) {
            if (points.size < 2) return@withContext null

            // Limiter la taille de la requête tout en conservant la géométrie du trajet.
            val maxShapePoints = 180
            val step = kotlin.math.max(1, points.size / maxShapePoints)
            val sampled = points.filterIndexed { index, _ -> index % step == 0 }.toMutableList()
            if (sampled.lastOrNull() != points.last()) sampled.add(points.last())

            val payload = JSONObject().apply {
                put("shape", org.json.JSONArray().apply {
                    sampled.forEach { p ->
                        put(JSONObject().apply {
                            put("lat", p.latitude)
                            put("lon", p.longitude)
                        })
                    }
                })
                put("costing", "auto")
                put("shape_match", "map_snap")
                put("filters", JSONObject().apply {
                    put("action", "include")
                    put("attributes", org.json.JSONArray().apply {
                        put("edge.road_class")
                        put("edge.use")
                        put("edge.names")
                        put("edge.begin_shape_index")
                        put("edge.end_shape_index")
                    })
                })
            }

            val request = Request.Builder()
                .url("https://valhalla1.openstreetmap.de/trace_attributes")
                .post(okhttp3.RequestBody.create(null, payload.toString()))
                .header("Content-Type", "application/json")
                .header("X-Client-Id", "fr.vspgps.app")
                .header("User-Agent", "VSP-GPS-Android/1.0")
                .build()

            try {
                // V213 : réutiliser le client HTTP Valhalla mémorisé pour la validation
                // fine des arêtes, au lieu de recréer un OkHttpClient à chaque itinéraire.
                // On profite ainsi du même pool de connexions, des mêmes DNS et des mêmes
                // délais réseau que le calcul principal, ce qui réduit le coût du contrôle VSP.
                val call = routeHttpClient.newCall(request)
                // V216 : rendre la validation VSP annulable exactement comme /route.
                if (!activeRouteCall.compareAndSet(null, call)) {
                    call.cancel()
                    return@withContext null
                }
                try {
                    call.execute().use { response ->
                        if (!response.isSuccessful) return@withContext null
                        val body = response.body?.string() ?: return@withContext null
                        val edges = JSONObject(body).optJSONArray("edges") ?: return@withContext null
                        for (i in 0 until edges.length()) {
                            val edge = edges.optJSONObject(i) ?: continue
                            val roadClass = edge.optString("road_class", "").lowercase(Locale.ROOT)
                            val names = edge.optJSONArray("names")
                            val namesText = if (names != null) {
                                (0 until names.length()).joinToString(" ") { names.optString(it) }
                            } else ""
                            val motorwayNumber = Regex("""(^|[\s/,(;-])a\s*\d{1,3}($|[\s/),;-])""", RegexOption.IGNORE_CASE)
                                .containsMatchIn(namesText)
                            if (roadClass == "motorway" || motorwayNumber) {
                                val sampledIndex = edge.optInt("begin_shape_index", -1)
                                if (sampledIndex in sampled.indices) return@withContext sampled[sampledIndex]
                                return@withContext sampled.getOrNull(sampled.size / 2)
                            }
                        }
                        null
                    }
                } finally {
                    activeRouteCall.compareAndSet(call, null)
                }
            } catch (e: Exception) {
                // V217 : l'annulation de la validation fine n'est pas une panne du service.
                // La propager immédiatement évite qu'un ancien calcul poursuive son traitement
                // après avoir été remplacé ou après la fermeture de l'écran.
                if (e is kotlinx.coroutines.CancellationException) throw e
                // Le contrôle primaire par instructions reste actif si ce service secondaire
                // est momentanément indisponible : ne jamais bloquer une route locale par proximité.
                null
            }
        }

    suspend fun decodePolyline6(encoded: String): List<GeoPoint> {
        val points = mutableListOf<GeoPoint>()
        var index = 0
        var latitude = 0L
        var longitude = 0L

        fun nextValue(): Long {
            var result = 0L
            var shift = 0
            var b: Int
            do {
                // V257 : une géométrie Valhalla tronquée ne doit jamais provoquer un
                // accès hors limites pendant le décodage. La réponse est rejetée proprement
                // et le mécanisme d’erreur/recalcul existant prend alors le relais.
                if (index >= encoded.length) {
                    throw IllegalArgumentException("Polyline6 tronquée")
                }
                b = encoded[index++].code - 63
                // V259 : refuser aussi une valeur varint anormalement longue.
                // Cela évite les décalages de bits incohérents si une polyline reçue
                // est corrompue tout en restant techniquement non tronquée.
                if (shift >= 60) {
                    throw IllegalArgumentException("Polyline6 invalide")
                }
                result = result or ((b and 0x1f).toLong() shl shift)
                shift += 5
            } while (b >= 0x20)

            return if ((result and 1L) != 0L) -(result shr 1) - 1L else result shr 1
        }

        while (index < encoded.length) {
            // V249 : le décodage d’une longue géométrie reste annulable. Un recalcul
            // ou la fermeture de l’écran n’attend plus la fin complète de la polyline.
            if (points.size % 128 == 0) currentCoroutineContext().ensureActive()
            latitude += nextValue()
            longitude += nextValue()
            points.add(
                GeoPoint(
                    latitude / 1_000_000.0,
                    longitude / 1_000_000.0
                )
            )
        }
        return points
    }

    // V190 : numéroter les calculs pour qu’une ancienne réponse réseau ne puisse jamais
    // écraser un itinéraire plus récent si l’utilisateur change rapidement de destination
    // ou si un recalcul GPS démarre pendant qu’une requête précédente est encore en cours.
    var routeCalculationGeneration by remember { mutableIntStateOf(0) }
    // V295 : conserver aussi le Job du calcul complet. Annuler uniquement l'appel OkHttp
    // ne stoppait pas forcément immédiatement l'ancien traitement (décodage, validation
    // VSP, temporisations de retry). Un nouveau calcul annule maintenant toute la coroutine.
    var activeRouteJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            // V295 : aucune requête ni coroutine d'itinéraire ne doit survivre à la
            // fermeture de l'écran de recherche/navigation.
            activeRouteCall.getAndSet(null)?.cancel()
            activeRouteJob?.cancel()
            activeRouteJob = null
        }
    }

    fun calculateRoute(
        start: GeoPoint,
        end: GeoPoint,
        preserveExistingRoute: Boolean = false
    ) {
        // ETAPE 123 : pendant un recalcul réel, Valhalla recevait seulement latitude/longitude.
        // Sur une route bidirectionnelle il pouvait alors accrocher le départ dans le sens
        // opposé, proposer de revenir au rond-point déjà dépassé puis déclencher un nouveau
        // recalcul quelques secondes plus tard. On capture ici le cap GPS uniquement si le
        // fix est frais, précis et réellement en mouvement. Les calculs initiaux à l'arrêt
        // restent strictement inchangés.
        val routeStartLocationSnapshot = currentLocation?.let { Location(it) }
        val rerouteHeadingDegrees = if (preserveExistingRoute) {
            routeStartLocationSnapshot?.let { loc ->
                val ageMs = if (loc.elapsedRealtimeNanos > 0L) {
                    ((android.os.SystemClock.elapsedRealtimeNanos() - loc.elapsedRealtimeNanos) / 1_000_000L)
                        .coerceAtLeast(0L)
                } else Long.MAX_VALUE
                val accuracy = if (loc.hasAccuracy()) loc.accuracy.toDouble() else Double.POSITIVE_INFINITY
                val speedKmh = if (loc.hasSpeed()) loc.speed * 3.6f else 0f
                val sameStart = distanceMetersBetween(start, GeoPoint(loc.latitude, loc.longitude)) <= 90.0
                if (
                    ageMs <= 8_000L &&
                    accuracy <= 35.0 &&
                    speedKmh >= 5.0f &&
                    loc.hasBearing() &&
                    sameStart
                ) loc.bearing.toDouble() else null
            }
        } else null

        routeCalculationGeneration += 1
        val calculationGeneration = routeCalculationGeneration
        // V210 : libérer immédiatement la connexion et les ressources du calcul précédent.
        activeRouteCall.getAndSet(null)?.cancel()
        // V295 : annuler également toute la coroutine précédente. Cela empêche un ancien
        // calcul déjà sorti de call.execute() de poursuivre son décodage/sa validation
        // pendant que le nouveau trajet démarre.
        activeRouteJob?.cancel()
        // V271 : verrouiller le calcul AVANT de lancer la coroutine. Sinon deux demandes
        // de recalcul reçues dans la même frame pouvaient toutes deux voir
        // poiRouteLoading == false et démarrer deux calculs successifs.
        poiRouteLoading = true
        activeRouteJob = scope.launch {
            error = null
            // V56 : dès qu’un nouveau calcul commence, l’ancien itinéraire ne doit jamais
            // rester visible. Cela évite d’afficher l’ancien trajet (ex. Reims) après une
            // recherche différente (ex. Lille) refusée par le contrôle VSP.
            if (!preserveExistingRoute) {
                routeOptions = emptyList()
                selectedRouteIndex = 0
                navigationStarted = false
            }

            // V59 : recherche automatique + validation des arêtes réellement empruntées.
            // Une route M/D/N n'est jamais refusée à cause de son seul préfixe : seules les
            // interdictions explicites (autoroute Axx, voie express/rapide, accès réglementé)
            // déclenchent une exclusion. En cas de passage interdit, plusieurs points du
            // tronçon sont exclus puis Valhalla recalcule sans intervention de l'utilisateur.
            val excludedLocations = mutableListOf<GeoPoint>()
            var acceptedRoute: RouteOption? = null
            var lastFailureWasForbidden = false
            var lastFailureWasWrongDirection = false
            var lastRouteFailureDetail: String? = null
            // V187 : les 8 passages servent uniquement à contourner progressivement
            // un tronçon interdit aux VSP. Si le serveur reste indisponible après les
            // 3 essais réseau internes, ne pas recommencer jusqu’à 8 fois la même requête.
            var terminalNetworkFailure = false

            repeat(8) { attempt ->
            // V197 : dès qu’un calcul plus récent a pris la main, arrêter celui-ci avant
            // de préparer ou d’envoyer une nouvelle requête Valhalla. V190 protégeait déjà
            // l’affichage final ; ce contrôle évite aussi le travail réseau devenu inutile.
            if (calculationGeneration != routeCalculationGeneration) return@launch
            if (acceptedRoute != null || terminalNetworkFailure) return@repeat

            // V204 : le motif d'échec doit décrire la tentative courante, pas rester
            // bloqué sur un ancien tronçon interdit. Sans ce reset, une tentative réseau
            // échouée après un premier détour VSP pouvait encore être présentée comme
            // un problème de route interdite et supprimer inutilement le délai de retry.
            lastFailureWasForbidden = false
            lastFailureWasWrongDirection = false

            val payload = JSONObject().apply {
                put(
                    "locations",
                    org.json.JSONArray().apply {
                        put(JSONObject().apply {
                            put("lat", start.latitude)
                            put("lon", start.longitude)
                            // ETAPE 123 : lors d'un recalcul en mouvement, contraindre le
                            // rattachement au sens réellement suivi par la VSP. Sans cap,
                            // Valhalla pouvait repartir vers le rond-point situé derrière.
                            if (rerouteHeadingDegrees != null) {
                                put("heading", rerouteHeadingDegrees)
                                put("heading_tolerance", 45)
                                put("radius", 70)
                            } else {
                                // V463 : tolérer un GPS légèrement décalé de la chaussée.
                                put("radius", 120)
                            }
                        })
                        put(JSONObject().apply {
                            put("lat", end.latitude)
                            put("lon", end.longitude)
                            // V463 : le point géocodé peut être au centre d'une parcelle/plage.
                            put("radius", 120)
                        })
                    }
                )
                if (excludedLocations.isNotEmpty()) {
                    put("exclude_locations", org.json.JSONArray().apply {
                        excludedLocations.forEach { point ->
                            put(JSONObject().apply {
                                put("lat", point.latitude)
                                put("lon", point.longitude)
                            })
                        }
                    })
                }
                put("costing", "auto")
                put(
                    "costing_options",
                    JSONObject().apply {
                        put(
                            "auto",
                            JSONObject().apply {
                                // Profil de calcul adapté à une VSP limitée à 45 km/h.
                                // use_highways=0 pénalise fortement les grands axes.
                                put("use_highways", 0.0)
                                put("use_tolls", 0.0)
                                put("use_ferry", 0.0)
                                put("top_speed", 45)
                                put("fixed_speed", 45)
                                put("ignore_access", false)
                                put("ignore_restrictions", false)
                                put("ignore_closures", false)
                            }
                        )
                    }
                )
                put("directions_options", JSONObject().apply {
                    put("language", "fr-FR")
                    put("units", "kilometers")
                    // ETAPE 49 : ne jamais laisser le moteur omettre les sorties de rond-point.
                    put("roundabout_exits", true)
                })
            }

            val requestBody = okhttp3.RequestBody.create(
                null,
                payload.toString()
            )

            // V464 : ne plus dépendre d'un seul nom d'hôte. Le serveur public
            // FOSSGIS est documenté avec valhalla1.openstreetmap.de pour l'API,
            // tandis que la spécification OpenAPI publie aussi valhalla.openstreetmap.de
            // comme serveur. Si le premier hôte est injoignable (DNS/TLS/connexion),
            // la tentative suivante bascule donc réellement sur l'autre hôte.
            val routeEndpoints = listOf(
                "https://valhalla1.openstreetmap.de/route",
                "https://valhalla.openstreetmap.de/route",
                "https://valhalla1.openstreetmap.de/route"
            )

            try {
                // V118 : une panne réseau ou un 429/5xx du serveur public ne doit plus
                // faire échouer immédiatement une destination parfaitement routable.
                // On réessaie la même requête jusqu'à 3 fois avec une courte temporisation.
                // Étape 7 : le calcul principal tente d'abord Valhalla embarqué.
                // En cas d'échec local, le chemin réseau historique reste disponible
                // comme secours pendant la phase de validation.
                var localRouteFailure: String? = null
                var responseText: String? = if (excludedLocations.isEmpty()) {
                    withContext(Dispatchers.IO) {
                        localValhallaRouter.calculateRouteJson(
                            startLatitude = start.latitude,
                            startLongitude = start.longitude,
                            endLatitude = end.latitude,
                            endLongitude = end.longitude,
                            // ETAPE 124 : le moteur local est prioritaire. Le cap de recalcul
                            // doit donc lui être transmis, pas uniquement au secours Internet.
                            startHeadingDegrees = rerouteHeadingDegrees,
                            startRadiusMeters = if (rerouteHeadingDegrees != null) 70 else 120
                        ).fold(
                            onSuccess = { it.toString() },
                            onFailure = {
                                localRouteFailure = it.message ?: it.javaClass.simpleName
                                null
                            }
                        )
                    }
                } else null
                val usedLocalRoute = responseText != null
                // Étape 27 : un rejet de sécurité local n'est PAS une panne technique.
                // Ne jamais le contourner silencieusement par le serveur Internet :
                // cela réintroduirait précisément le trajet motorway que le verrou VSP
                // vient de refuser. Les pannes techniques ordinaires gardent le secours.
                val localSafetyRejection = localRouteFailure?.startsWith("VSP_REJECT_MOTORWAY:") == true ||
                    localRouteFailure?.startsWith("VSP_VALIDATION_IMPOSSIBLE:") == true
                if (localSafetyRejection) {
                    lastRouteEngine = "Trajet VSP refusé par le contrôle local : ${localRouteFailure}"
                    lastRouteFailureDetail = localRouteFailure
                    throw IllegalStateException(localRouteFailure ?: "Trajet VSP refusé")
                }
                if (!usedLocalRoute && calculationGeneration == routeCalculationGeneration) {
                    lastRouteEngine = "Valhalla LOCAL en échec : ${localRouteFailure ?: "réponse non exploitable"} — secours Internet"
                }
                var requestFailure: String? = null
                // V195 : distinguer les erreurs HTTP permanentes des pannes temporaires.
                // Un 4xx (hors 408/429) vient de la requête elle-même : la renvoyer 3 fois
                // à l'identique ne peut pas la réparer et ne fait qu'allonger l'attente.
                var permanentHttpFailure = false
                // V199 : si Valhalla répond 429 avec Retry-After (en secondes), respecter
                // l'attente demandée au lieu de relancer trop tôt le serveur public.
                // La valeur est plafonnée à 5 s pour ne pas bloquer longtemps le guidage.
                var serverRetryAfterMillis: Long? = null
                // V189 : routeHttpClient est maintenant mémorisé au niveau de l'écran.
                // Le pool réseau reste donc disponible entre deux calculs/recalculs successifs.
                val endpointFailures = mutableListOf<String>()
                for (networkTry in 0 until 3) {
                    if (responseText != null) break
                    val endpoint = routeEndpoints[networkTry]
                    val endpointHost = java.net.URI(endpoint).host ?: endpoint
                    val request = Request.Builder()
                        .url(endpoint)
                        .post(requestBody)
                        .header("Content-Type", "application/json")
                        .header("X-Client-Id", "fr.vspgps.app")
                        .header("User-Agent", "VSP-GPS-Android/1.0")
                        .build()
                    // V197 : ne pas lancer un retry si cette destination a déjà été remplacée.
                    if (calculationGeneration != routeCalculationGeneration) return@launch
                    try {
                        responseText = withContext(Dispatchers.IO) {
                            val call = routeHttpClient.newCall(request)
                            // V212 : enregistrer l'appel de façon atomique. Un ancien calcul qui
                            // arrive ici en retard ne doit jamais écraser la référence de la nouvelle
                            // requête, sinon celle-ci ne pourrait plus être annulée correctement.
                            if (!activeRouteCall.compareAndSet(null, call)) {
                                call.cancel()
                                if (calculationGeneration != routeCalculationGeneration) {
                                    throw kotlinx.coroutines.CancellationException("Calcul d'itinéraire remplacé")
                                }
                                throw IllegalStateException("Une requête d'itinéraire est déjà active")
                            }
                            // Un nouveau calcul a pu démarrer entre le contrôle du retry et
                            // la création de l'appel HTTP : dans ce cas, ne pas l'envoyer.
                            if (calculationGeneration != routeCalculationGeneration) {
                                activeRouteCall.compareAndSet(call, null)
                                call.cancel()
                                throw kotlinx.coroutines.CancellationException("Calcul d'itinéraire remplacé")
                            }
                            try {
                                call.execute().use { response ->
                                    if (!response.isSuccessful) {
                                        val code = response.code
                                        permanentHttpFailure = code in 400..499 && code != 408 && code != 429
                                        serverRetryAfterMillis = if (code == 429 || code == 503) {
                                            // V209 : Retry-After peut aussi accompagner un HTTP 503
                                            // (service temporairement indisponible), pas seulement 429.
                                            // Respecter l'attente du serveur évite des retries trop rapides.
                                            // V200 : Retry-After peut être envoyé soit comme un nombre
                                            // de secondes, soit comme une date HTTP.
                                            response.header("Retry-After")
                                                ?.trim()
                                                ?.let { retryAfter ->
                                                    retryAfter.toLongOrNull()
                                                        ?.times(1000L)
                                                        ?: runCatching {
                                                            val parser = java.text.SimpleDateFormat(
                                                                "EEE, dd MMM yyyy HH:mm:ss zzz",
                                                                java.util.Locale.US
                                                            ).apply { isLenient = false }
                                                            (parser.parse(retryAfter)?.time
                                                                ?: System.currentTimeMillis()) - System.currentTimeMillis()
                                                        }.getOrNull()
                                                }
                                                ?.coerceIn(500L, 5000L)
                                        } else null
                                        throw IllegalStateException("Valhalla HTTP $code")
                                    }
                                    response.body?.string()
                                        ?: throw IllegalStateException("Réponse Valhalla vide")
                                }
                            } finally {
                                activeRouteCall.compareAndSet(call, null)
                            }
                        }
                        requestFailure = null
                        break
                    } catch (e: Exception) {
                        // V196 : une annulation de coroutine n'est pas une panne réseau.
                        // Si l'écran ou le calcul courant est abandonné, on laisse l'annulation
                        // remonter immédiatement au lieu de lancer d'autres retries Valhalla.
                        if (e is kotlinx.coroutines.CancellationException) throw e
                        // V210 : si l'appel vient d'être annulé parce qu'un calcul plus récent
                        // a démarré, sortir sans le comptabiliser comme une panne réseau.
                        if (calculationGeneration != routeCalculationGeneration) return@launch
                        requestFailure = e.message ?: e.javaClass.simpleName
                        endpointFailures += "$endpointHost : $requestFailure"
                        // V464 : le diagnostic indique maintenant quel hôte a échoué.
                        lastRouteFailureDetail = endpointFailures.joinToString(" | ")
                        if (permanentHttpFailure) {
                            break
                        }
                        if (networkTry < 2) {
                            val retryDelayMillis = serverRetryAfterMillis
                                ?: if (networkTry == 0) 1300L else 2600L
                            serverRetryAfterMillis = null
                            kotlinx.coroutines.delay(retryDelayMillis)
                            if (calculationGeneration != routeCalculationGeneration) return@launch
                        }
                    }
                }
                if (responseText == null) {
                    terminalNetworkFailure = true
                    val detailedFailure = endpointFailures.joinToString(" | ")
                        .ifBlank { requestFailure ?: "Serveur Valhalla indisponible" }
                    throw IllegalStateException(detailedFailure)
                }

                // V198 : une réponse Valhalla peut arriver juste après qu'un nouveau calcul
                // a pris la main. Ne pas perdre du temps à décoder la géométrie ni à lancer
                // la validation des arêtes d'un itinéraire qui ne sera de toute façon plus affiché.
                if (calculationGeneration != routeCalculationGeneration) return@launch

                // Étape 8 : indiquer la provenance réelle de chaque réponse.
                // Le succès du bouton de test seul ne prouve pas que le trajet
                // principal a utilisé le moteur local.
                val routeWasLocal = usedLocalRoute
                val json = JSONObject(responseText!!)
                // Étape 29 : lire la certification technique attachée par le moteur local
                // au candidat finalement accepté. Elle ne vaut pas certification juridique.
                acceptedRouteValidation = if (routeWasLocal) {
                    json.optJSONObject("_vsp_validation")?.let { v ->
                        val ramps = v.optJSONArray("ramp_edges")
                        acceptedRampAudit = (0 until (ramps?.length() ?: 0)).mapNotNull { idx ->
                            ramps?.optJSONObject(idx)?.let { edge ->
                                val speed = if (edge.has("speed")) "${edge.optDouble("speed").toInt()} km/h" else "?"
                                val limit = if (edge.has("speed_limit")) "${edge.optDouble("speed_limit").toInt()} km/h" else "?"
                                val length = if (edge.has("length_km")) String.format(java.util.Locale.FRANCE, "%.3f km", edge.optDouble("length_km")) else "?"
                                "${edge.optInt("index", idx + 1)}. ${edge.optString("name", "voie non nommée")} • classe=${edge.optString("road_class", "inconnu")} • usage=${edge.optString("use", "inconnu")} • vitesse=$speed • limite=$limit • longueur=$length"
                            }
                        }
                        val hs = v.optJSONArray("high_speed_edges")
                        acceptedHighSpeedAudit = (0 until (hs?.length() ?: 0)).mapNotNull { idx ->
                            hs?.optJSONObject(idx)?.let { edge ->
                                val speed = if (edge.has("speed")) "${edge.optDouble("speed").toInt()} km/h" else "?"
                                val limit = if (edge.has("speed_limit")) "${edge.optDouble("speed_limit").toInt()} km/h" else "?"
                                val length = if (edge.has("length_km")) String.format(java.util.Locale.FRANCE, "%.3f km", edge.optDouble("length_km")) else "?"
                                "${edge.optInt("index", idx + 1)}. ${edge.optString("name", "voie non nommée")} • classe=${edge.optString("road_class", "inconnu")} • usage=${edge.optString("use", "inconnu")} • vitesse=$speed • limite=$limit • longueur=$length"
                            }
                        }
                        "Contrôle du trajet retenu : motorway=${v.optInt("motorway", -1)} • trunk=${v.optInt("trunk", -1)} • bretelles=${v.optInt("ramps", -1)} • >70 km/h=${v.optInt("high_speed", -1)} • ${v.optInt("checked_edges", 0)} arêtes contrôlées • tentative ${v.optInt("attempt", 1)}"
                    }
                } else {
                    acceptedRampAudit = emptyList()
                    acceptedHighSpeedAudit = emptyList()
                    null
                }
                // V256 : le parsing JSON peut lui-même prendre un peu de temps. Si un
                // nouveau calcul a pris la main pendant cette étape, ne pas poursuivre
                // l’extraction ni le décodage d’une réponse désormais obsolète.
                if (calculationGeneration != routeCalculationGeneration) return@launch
                val trip = json.getJSONObject("trip")
                val summary = trip.getJSONObject("summary")
                // Étape 12 : Valhalla local utilise encore le costing auto.
                // Sa durée peut supposer une vitesse supérieure à celle d'une VSP.
                // Corriger UNIQUEMENT la borne inférieure du temps annoncé :
                // 45 km/h maximum, sans prétendre que le parcours est autorisé.
                // Les arrêts, ralentissements et restrictions peuvent augmenter la durée.
                if (routeWasLocal) {
                    val kmForVsp = summary.optDouble("length", Double.NaN)
                    val nativeSeconds = summary.optDouble("time", Double.NaN)
                    if (kmForVsp.isFinite() && kmForVsp >= 0.0 &&
                        nativeSeconds.isFinite() && nativeSeconds >= 0.0) {
                        val minimumSecondsAt45 = kmForVsp / 45.0 * 3600.0
                        summary.put("time", maxOf(nativeSeconds, minimumSecondsAt45))
                    }
                }
                val legs = trip.getJSONArray("legs")
                if (legs.length() == 0) throw IllegalStateException("Itinéraire sans tronçon")
                if (calculationGeneration == routeCalculationGeneration) {
                    lastRouteOfflineReady = routeWasLocal
                    lastRouteEngine = if (routeWasLocal) {
                        "Source du trajet : Valhalla LOCAL • durée plancher à 45 km/h • itinéraire non certifié VSP"
                    } else {
                        "Source du trajet : serveur INTERNET / secours • échec local : ${localRouteFailure ?: "non précisé"}"
                    }
                }

                val allPoints = mutableListOf<GeoPoint>()
                val allManeuvers = mutableListOf<RouteManeuver>()

                for (i in 0 until legs.length()) {
                    // V247 : une nouvelle demande d’itinéraire peut remplacer celle-ci pendant
                    // le décodage d’un trajet multi-segments. Arrêter avant de poursuivre le parsing.
                    if (calculationGeneration != routeCalculationGeneration) return@launch
                    val leg = legs.getJSONObject(i)
                    val shape = leg.getString("shape")
                    val decoded = decodePolyline6(shape)
                    // V250 : un nouveau calcul peut prendre la main pendant le décodage d’une
                    // longue polyline sans annuler immédiatement cette coroutine. Ne pas poursuivre
                    // avec les manœuvres ni publier les points d’un itinéraire devenu obsolète.
                    if (calculationGeneration != routeCalculationGeneration) return@launch
                    val shapeOffset = if (allPoints.isEmpty()) 0 else allPoints.size - 1

                    val maneuversJson = leg.optJSONArray("maneuvers")
                    if (maneuversJson != null) {
                        for (m in 0 until maneuversJson.length()) {
                            // V247 : ne pas continuer à construire les étapes d’un ancien trajet
                            // si un nouveau calcul a déjà pris la main pendant cette boucle.
                            if (m % 12 == 0 && calculationGeneration != routeCalculationGeneration) return@launch
                            val maneuver = maneuversJson.getJSONObject(m)
                            val streetNamesArray = maneuver.optJSONArray("street_names")
                            val streetNames = if (streetNamesArray != null) {
                                // V248 : construire les noms de rues sans collection intermédiaire et
                                // vérifier régulièrement qu’un calcul plus récent n’a pas pris la main.
                                // V434 : Valhalla peut renvoyer deux fois de suite le même nom
                                // de voie (par exemple une référence et un libellé identiques). Ne pas
                                // afficher ni prononcer « D58 / D58 ». On déduplique uniquement les
                                // doublons consécutifs afin de conserver les vrais noms alternatifs.
                                buildString {
                                    var lastStreetName: String? = null
                                    for (nameIndex in 0 until streetNamesArray.length()) {
                                        if (nameIndex % 8 == 0 && calculationGeneration != routeCalculationGeneration) {
                                            return@launch
                                        }
                                        val name = streetNamesArray.optString(nameIndex).trim()
                                        if (name.isNotBlank() && !name.equals(lastStreetName, ignoreCase = true)) {
                                            if (isNotEmpty()) append(" / ")
                                            append(name)
                                            lastStreetName = name
                                        }
                                    }
                                }
                            } else ""

                            allManeuvers.add(
                                RouteManeuver(
                                    type = maneuver.optInt("type", 0),
                                    instruction = maneuver.optString(
                                        "instruction",
                                        maneuver.optString("verbal_pre_transition_instruction", "")
                                    ),
                                    streetNames = streetNames,
                                    beginShapeIndex = shapeOffset + maneuver.optInt("begin_shape_index", 0),
                                    endShapeIndex = shapeOffset + maneuver.optInt("end_shape_index", 0),
                                    // ETAPE 105 : source unique consommée par l'UI. Sur un trajet local,
                                    // LocalValhallaRouter a déjà remplacé le compteur Odin par la
                                    // topologie V105 ; sur un secours Internet, la valeur Odin reste utilisée.
                                    roundaboutExitCount = maneuver.optInt("roundabout_exit_count", 0)
                                )
                            )
                        }
                    }

                    // V251 : couvrir aussi les petites listes de manœuvres (< 12) et une
                    // nouvelle demande arrivée juste après la dernière manœuvre. Ne pas recopier
                    // la géométrie d’un itinéraire qui n’est déjà plus le calcul actif.
                    if (calculationGeneration != routeCalculationGeneration) return@launch

                    if (allPoints.isNotEmpty() && decoded.isNotEmpty()) {
                        // V252 : éviter decoded.drop(1), qui recréait une liste complète pour
                        // chaque segment. Ajouter directement la vue restante réduit les allocations
                        // sur les longs trajets sans modifier la géométrie ni les index de manœuvres.
                        if (decoded.size > 1) allPoints.addAll(decoded.subList(1, decoded.size))
                    } else {
                        allPoints.addAll(decoded)
                    }
                }

                // V254 : couvrir aussi une annulation arrivée juste après le dernier segment.
                // Ne pas calculer les métriques ni construire un candidat devenu obsolète.
                if (calculationGeneration != routeCalculationGeneration) return@launch

                // Le calcul Valhalla est configuré pour fortement éviter les grands axes.
                // L'ancien contrôle Overpass par proximité provoquait des faux positifs
                // lorsqu'une route locale longeait ou croisait une autoroute (ex. A26 à Aix-Noulette).
                // Il ne bloque donc plus le départ : la validation stricte devra être faite
                // par un profil VSP côté moteur de routage, au niveau des arêtes réellement empruntées.
                val distanceKm = summary.optDouble("length", 0.0)
                val durationSeconds = summary.optDouble("time", 0.0)

                // V417 : sécuriser les index de manœuvres reçus du serveur avant qu'ils
                // soient utilisés par le guidage. Une réponse partielle ou incohérente ne doit
                // jamais produire une étape située hors du tracé, ni un endShapeIndex placé
                // avant son beginShapeIndex. Les réponses normales restent inchangées.
                val safeManeuvers = if (allPoints.isEmpty()) {
                    emptyList()
                } else {
                    allManeuvers.mapNotNull { maneuver ->
                        if (maneuver.beginShapeIndex !in allPoints.indices) {
                            null
                        } else {
                            // V418 : un numéro de sortie n’a de sens que pour une vraie
                            // manœuvre de rond-point Valhalla. Certains moteurs/proxys peuvent
                            // laisser une ancienne valeur roundabout_exit_count sur une autre
                            // manœuvre ; la neutraliser ici empêche cette donnée parasite de
                            // réapparaître plus tard dans l’affichage ou la voix. On borne aussi
                            // les valeurs manifestement aberrantes sans toucher aux sorties normales.
                            // V430 : réutiliser la classification Valhalla centralisée ici aussi.
                            // Cela supprime la dernière table locale 26/27 et évite de recréer un
                            // Set pendant la sécurisation de chaque manœuvre d’un itinéraire.
                            val safeRoundaboutExitCount = if (isValhallaRoundabout(maneuver.type)) {
                                maneuver.roundaboutExitCount.coerceIn(0, 12)
                            } else {
                                0
                            }
                            maneuver.copy(
                                endShapeIndex = maneuver.endShapeIndex
                                    .coerceAtLeast(maneuver.beginShapeIndex)
                                    .coerceAtMost(allPoints.lastIndex),
                                roundaboutExitCount = safeRoundaboutExitCount
                            )
                        }
                    }
                }

                val candidateRoute = RouteOption(
                        points = allPoints,
                        distanceMeters = distanceKm * 1000.0,
                        durationSeconds = durationSeconds,
                        // Étape 13 : ne jamais déclarer « validé VSP » un trajet
                        // local calculé avec CostingModel.auto. Le filtrage des
                        // seules instructions ne vérifie pas les arêtes OSM.
                        vspValidated = !routeWasLocal,
                        maneuvers = safeManeuvers
                    )

                // V198 : la vérification fine des arêtes peut elle-même utiliser le réseau.
                // Si ce calcul a été remplacé pendant le décodage, l'arrêter avant ce contrôle.
                if (calculationGeneration != routeCalculationGeneration) return@launch

                val forbiddenByInstruction = routeContainsForbiddenVspRoad(candidateRoute)
                // Étape 11 : un trajet calculé localement ne doit pas être rejeté par le
                // contrôle trace_attributes du serveur public. Ce contrôle réseau pouvait
                // remapper le tracé sur une autoroute voisine, ajouter une exclusion puis
                // forcer les tentatives suivantes à basculer sur Internet.
                // Pour une réponse locale, on conserve ici le contrôle explicite des
                // instructions. Le contrôle fin des arêtes sera porté localement dans une
                // étape dédiée avant de certifier le profil VSP.
                val forbiddenEdgePoint = if (!forbiddenByInstruction && !routeWasLocal) {
                    firstForbiddenValhallaEdgePoint(candidateRoute.points)
                } else null

                if (forbiddenByInstruction || forbiddenEdgePoint != null) {
                    lastFailureWasForbidden = true
                    val forbidden = candidateRoute.maneuvers.firstOrNull(::maneuverLooksForbiddenVsp)
                    val idx = forbidden?.beginShapeIndex?.coerceIn(0, candidateRoute.points.lastIndex)
                    if (attempt < 7) {
                        if (idx != null) {
                            // Exclure une petite zone du tronçon fautif plutôt qu'un point unique.
                            val endIdx = forbidden.endShapeIndex.coerceIn(idx, candidateRoute.points.lastIndex)
                            val midIdx = ((idx + endIdx) / 2).coerceIn(0, candidateRoute.points.lastIndex)
                            listOf(idx, midIdx, endIdx).distinct().forEach { badIndex ->
                                val badPoint = candidateRoute.points[badIndex]
                                if (excludedLocations.none { distanceMetersBetween(it, badPoint) < 80.0 }) {
                                    excludedLocations += badPoint
                                }
                            }
                        } else if (forbiddenEdgePoint != null &&
                            excludedLocations.none { distanceMetersBetween(it, forbiddenEdgePoint) < 80.0 }) {
                            excludedLocations += forbiddenEdgePoint
                        }
                        return@repeat
                    }
                } else {
                    // ETAPE 123 : sécurité supplémentaire pour le recalcul en mouvement.
                    // Si malgré le cap envoyé au moteur la polyline repart de plus de 70°
                    // dans le sens opposé, ne jamais publier ce trajet au conducteur.
                    val wrongWayReroute = rerouteHeadingDegrees?.let { gpsHeading ->
                        routeDepartureBearingDegrees(candidateRoute.points)?.let { routeHeading ->
                            headingDifferenceDegrees(gpsHeading, routeHeading) > 70.0
                        } ?: false
                    } ?: false

                    if (wrongWayReroute) {
                        lastFailureWasWrongDirection = true
                        lastRouteFailureDetail = "Recalcul rejeté : départ proposé à plus de 70° du déplacement GPS."
                        // La même requête ne doit pas être répétée huit fois : le trajet
                        // précédent reste affiché et la logique de recalcul réessaiera
                        // depuis un fix GPS plus récent quelques secondes plus tard.
                        terminalNetworkFailure = true
                        return@repeat
                    }

                    acceptedRoute = candidateRoute
                    return@repeat
                }

            } catch (e: Exception) {
                // V196 : ne jamais transformer une annulation du calcul en erreur d'itinéraire.
                if (e is kotlinx.coroutines.CancellationException) throw e
                // V215 : un calcul peut devenir obsolète pendant le décodage ou la validation
                // de la réponse. Dans ce cas, son exception ne doit plus modifier le diagnostic
                // partagé ni déclencher l'attente de la boucle externe du nouveau calcul.
                if (calculationGeneration != routeCalculationGeneration) return@launch
                // V118 : conserver la cause réelle. Après une erreur réseau, attendre un peu
                // avant la tentative suivante au lieu de marteler immédiatement Valhalla.
                lastRouteFailureDetail = e.message ?: e.javaClass.simpleName
                // V206 : si les 3 essais réseau internes ont déjà échoué, V187 a
                // déclaré l'échec terminal pour ce calcul. Ne pas ajouter encore 500 ms
                // d'attente dans la boucle externe puisqu'aucune nouvelle tentative ne
                // sera lancée : l'erreur peut ainsi être affichée plus rapidement.
                if (attempt < 7 && !lastFailureWasForbidden && !terminalNetworkFailure) {
                    kotlinx.coroutines.delay(500L)
                }
                if (attempt == 7) {
                    acceptedRoute = null
                }
            }
            if (acceptedRoute != null) return@repeat
            }

            // V190 : si un calcul plus récent a démarré entre-temps, cette réponse est
            // devenue obsolète. On l’ignore sans toucher à la carte ni aux messages d’état.
            if (calculationGeneration != routeCalculationGeneration) return@launch

            val finalRoute = acceptedRoute
            if (finalRoute != null) {
                routeOptions = listOf(finalRoute)
                selectedRouteIndex = 0
                // V457 : publier le trajet immédiatement pour qu’une rotation au même instant
                // ne restaure jamais un ancien état sans route/autonomie.
                RotationRetainedState.routeOptions = listOf(finalRoute)
                RotationRetainedState.selectedRouteIndex = 0
                error = null
                navigationNetworkWarning = null
                navigationRerouteRetryNotBefore = 0L
                poiRouteLoading = false
                if (startAfterRouteCalculation) {
                    startAfterRouteCalculation = false
                    navigationStarted = true
                }
                return@launch
            }

            if (preserveExistingRoute && routeOptions.isNotEmpty()) {
                // V140 : pendant la navigation, conserver le dernier tracé utilisable.
                // Le conducteur garde la carte et les instructions déjà chargées ; un
                // nouveau recalcul sera retenté automatiquement depuis NavigationScreen.
                navigationNetworkWarning = when {
                    lastFailureWasWrongDirection ->
                        "Recalcul rejeté car il repartait en arrière. Nouvelle tentative depuis votre position actuelle…"
                    lastFailureWasForbidden ->
                        "Recalcul VSP indisponible : itinéraire actuel conservé."
                    else ->
                        "Connexion ou serveur indisponible : itinéraire actuel conservé. Nouvelle tentative automatique…"
                }
                // V159 : conserver la position la plus récente et imposer une pause avant
                // toute nouvelle tentative. Le trajet affiché reste inchangé.
                pendingNavigationRerouteStart = currentLocation?.let {
                    GeoPoint(it.latitude, it.longitude)
                } ?: start
                // V296 : utiliser la même horloge monotone que le reste du cooldown de
                // recalcul. System.currentTimeMillis() pouvait rendre l'attente trop longue
                // ou immédiatement expirée si l'heure du téléphone changeait.
                navigationRerouteRetryNotBefore = android.os.SystemClock.elapsedRealtime() +
                    if (lastFailureWasWrongDirection) 1_500L else 8_000L
                poiRouteLoading = false
                return@launch
            }

            routeOptions = emptyList()
            selectedRouteIndex = 0
            startAfterRouteCalculation = false
            navigationStarted = false
            error = if (lastFailureWasForbidden)
                "Aucun itinéraire VSP sûr n'a pu être trouvé automatiquement vers cette destination."
            else {
                val detail = lastRouteFailureDetail.orEmpty()
                when {
                    detail.contains("HTTP 429", ignoreCase = true) ->
                        "Le serveur d'itinéraires est momentanément très sollicité. Nouvelle tentative automatique effectuée ; réessayez dans quelques instants."
                    // V208 : distinguer aussi les refus HTTP permanents (4xx hors 408/429).
                    // Ils ne doivent pas être présentés comme une simple absence d’itinéraire :
                    // la requête a bien atteint le serveur mais celui-ci l’a refusée.
                    Regex("HTTP 4(?!08|29)\\d{2}", RegexOption.IGNORE_CASE).containsMatchIn(detail) ->
                        "Le serveur d'itinéraires VSP a refusé cette demande. Vérifiez la destination puis réessayez."
                    // V207 : HTTP 408 et plusieurs erreurs réseau Android courantes sont
                    // des indisponibilités temporaires, pas une absence d’itinéraire VSP.
                    // Afficher le bon diagnostic après les tentatives automatiques.
                    detail.contains("HTTP 408", ignoreCase = true) ||
                        detail.contains("HTTP 5", ignoreCase = true) ||
                        detail.contains("timeout", ignoreCase = true) ||
                        detail.contains("timed out", ignoreCase = true) ||
                        detail.contains("Unable to resolve", ignoreCase = true) ||
                        detail.contains("Failed to connect", ignoreCase = true) ||
                        detail.contains("Connection reset", ignoreCase = true) ||
                        detail.contains("unexpected end", ignoreCase = true) ||
                        detail.contains("SocketException", ignoreCase = true) ->
                        "Le serveur d'itinéraires VSP est momentanément indisponible. Plusieurs tentatives automatiques ont été effectuées." +
                            detail.takeIf { it.isNotBlank() }?.let { "\nDiagnostic : ${it.take(90)}" }.orEmpty()
                    else ->
                        if (detail.startsWith("VSP_REJECT_MOTORWAY:")) "Itinéraire refusé : présence de voie motorway incompatible VSP. Les tentatives de détour local n’ont pas encore trouvé de trajet à 0 motorway." else "Aucun itinéraire n'a été renvoyé par le moteur VSP pour le moment. Réessayez dans quelques instants."
                }
            }
            poiRouteLoading = false
        }
    }

    LaunchedEffect(query) {
        // V443 : après sélection d’une destination, une rotation recrée l’Activity.
        // La destination et la requête sont restaurées par RotationRetainedState ;
        // ne pas relancer l’autocomplétion tant que l’utilisateur n’a pas modifié le texte.
        // V460 : verrou absolu. Une destination déjà validée interdit tout nouvel appel
        // d’autocomplétion après recréation/rotation, indépendamment du format du libellé.
        // V461 : la présence d'une Destination sélectionnée est le verrou principal.
        // Elle survit déjà à la rotation via RotationRetainedState. Tant qu'elle existe,
        // aucune recherche d'autocomplétion ne doit pouvoir repartir.
        if (destination != null || RotationRetainedState.destination != null ||
            destinationConfirmed || RotationRetainedState.destinationConfirmed) {
            addressSuggestions = emptyList()
            suggestionsLoading = false
            return@LaunchedEffect
        }

        val selectedDestination = destination
        val queryStillMatchesConfirmedDestination = confirmedDestinationLabel.isNotBlank() && query.trim() == confirmedDestinationLabel.trim()
        val queryMatchesSelectedDestination = selectedDestination != null && query.trim() == selectedDestination.label.trim()
        if ((destinationConfirmed || queryStillMatchesConfirmedDestination || queryMatchesSelectedDestination) && selectedDestination != null) {
            // V459 : la Destination elle-même est la source de vérité. Même si un booléen
            // Compose est recréé pendant la rotation, un libellé identique à la destination
            // choisie ne doit jamais déclencher ni afficher l'autocomplétion.
            destinationConfirmed = true
            confirmedDestinationLabel = selectedDestination.label
            RotationRetainedState.destinationConfirmed = true
            RotationRetainedState.confirmedDestinationLabel = selectedDestination.label
            // V457 : après validation, aucune rotation/recomposition ne relance l’autocomplétion.
            // Seule une modification volontaire du champ remet destinationConfirmed à false.
            addressSuggestions = emptyList()
            suggestionsLoading = false
            return@LaunchedEffect
        }

        if (suggestionSelectionInProgress) {
            suggestionSelectionInProgress = false
            addressSuggestions = emptyList()
            return@LaunchedEffect
        }

        val typed = query.trim()
        if (typed.length < 2 || searching) {
            addressSuggestions = emptyList()
            return@LaunchedEffect
        }

        // Petit debounce : évite un appel à chaque frappe tout en restant réactif.
        kotlinx.coroutines.delay(220L)
        if (typed != query.trim()) return@LaunchedEffect

        suggestionsLoading = true

        addressSuggestions = withContext(Dispatchers.IO) {
            // ETAPE 113 : recherche par CATEGORIE, distincte de la recherche d'adresse.
            // Exemples : "friterie", "friterie lievin", "pharmacie lens", "garage noeux-les-mines".
            // Si une commune est écrite après la catégorie, GeoPF fournit son code INSEE et
            // Overpass limite alors réellement les POI à cette commune. Sans commune, le
            // centre de recherche est la position GPS et les résultats sont triés du plus proche
            // au plus éloigné.
            fun normalizeCategorySearch(value: String): String = java.text.Normalizer.normalize(
                value.lowercase(Locale.FRANCE)
                    .replace("œ", "oe")
                    .replace("æ", "ae"),
                java.text.Normalizer.Form.NFD
            ).replace(Regex("\\p{M}+"), "")

            val categoryTokens = normalizeCategorySearch(typed)
                .split(Regex("[^\\p{L}\\p{N}]+"))
                .filter { it.isNotBlank() }

            // Pair(catégorie interne, nombre de mots consommés dans la requête).
            val categoryMatch: Pair<String, Int>? = when {
                categoryTokens.take(3) == listOf("bureau", "de", "poste") -> "post_office" to 3
                categoryTokens.take(2) == listOf("station", "service") -> "fuel" to 2
                categoryTokens.take(2) == listOf("station", "essence") -> "fuel" to 2
                categoryTokens.take(2) == listOf("station", "carburant") -> "fuel" to 2
                categoryTokens.take(2) == listOf("pompe", "essence") -> "fuel" to 2
                categoryTokens.take(2) == listOf("borne", "recharge") -> "charge" to 2
                categoryTokens.take(2) == listOf("borne", "electrique") -> "charge" to 2
                categoryTokens.take(2) == listOf("station", "recharge") -> "charge" to 2
                categoryTokens.take(2) == listOf("fast", "food") -> "fast_food" to 2
                categoryTokens.take(2) == listOf("centre", "commercial") -> "mall" to 2
                categoryTokens.take(2) == listOf("lavage", "auto") -> "car_wash" to 2
                categoryTokens.take(2) == listOf("station", "lavage") -> "car_wash" to 2
                categoryTokens.take(2) == listOf("controle", "technique") -> "vehicle_inspection" to 2
                categoryTokens.take(2) == listOf("centre", "auto") -> "car_repair" to 2
                categoryTokens.take(2) == listOf("gare", "routiere") -> "bus_station" to 2
                categoryTokens.take(2) == listOf("gare", "sncf") -> "train_station" to 2
                categoryTokens.firstOrNull().orEmpty() in setOf("friterie", "friteries", "frite", "frites") -> "friterie" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("pharmacie", "pharmacies") -> "pharmacy" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("boulangerie", "boulangeries") -> "bakery" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("garage", "garages") -> "car_repair" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("restaurant", "restaurants") -> "restaurant" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("pizzeria", "pizzerias", "pizza", "pizzas") -> "pizzeria" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("kebab", "kebabs", "doner") -> "kebab" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("supermarche", "supermarches", "hypermarche", "hypermarches") -> "supermarket" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("cafe", "cafes") -> "cafe" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("bar", "bars", "pub", "pubs") -> "bar" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("hotel", "hotels") -> "hotel" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("parking", "parkings") -> "parking" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("coiffeur", "coiffeurs", "coiffeuse", "coiffeuses") -> "hairdresser" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("tabac", "tabacs") -> "tobacco" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("banque", "banques") -> "bank" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("distributeur", "distributeurs", "dab") -> "atm" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("medecin", "medecins", "docteur", "docteurs") -> "doctor" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("dentiste", "dentistes") -> "dentist" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("veterinaire", "veterinaires") -> "veterinary" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("cinema", "cinemas") -> "cinema" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("opticien", "opticiens", "optique") -> "optician" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("laboratoire", "laboratoires", "labo", "labos") -> "laboratory" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("fleuriste", "fleuristes", "fleurs") -> "florist" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("boucherie", "boucheries", "boucher") -> "butcher" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("epicerie", "epiceries", "supérette", "superette") -> "convenience" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("bricolage", "quincaillerie") -> "diy" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("mairie", "mairies") -> "townhall" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("police", "gendarmerie", "gendarmeries") -> "police" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("pompiers", "pompier", "caserne") -> "fire_station" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("ecole", "ecoles", "college", "colleges", "lycee", "lycees") -> "school" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("creche", "creches") -> "kindergarten" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("gare", "gares", "train") -> "train_station" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("hopital", "hopitaux", "clinique", "cliniques") -> "hospital" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("poste") -> "post_office" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("recharge", "chargeur", "chargeurs", "bornes") -> "charge" to 1
                categoryTokens.firstOrNull().orEmpty() in setOf("station", "stations") -> "fuel" to 1
                else -> null
            }

            fun categoryDisplayName(key: String): String = when (key) {
                "friterie" -> "Friterie"
                "pharmacy" -> "Pharmacie"
                "bakery" -> "Boulangerie"
                "car_repair" -> "Garage"
                "fuel" -> "Station-service"
                "charge" -> "Borne de recharge"
                "restaurant" -> "Restaurant"
                "fast_food" -> "Restauration rapide"
                "pizzeria" -> "Pizzeria"
                "kebab" -> "Kebab"
                "supermarket" -> "Supermarché"
                "cafe" -> "Café"
                "bar" -> "Bar"
                "hotel" -> "Hôtel"
                "parking" -> "Parking"
                "hairdresser" -> "Coiffeur"
                "tobacco" -> "Tabac"
                "bank" -> "Banque"
                "atm" -> "Distributeur"
                "doctor" -> "Médecin"
                "dentist" -> "Dentiste"
                "veterinary" -> "Vétérinaire"
                "cinema" -> "Cinéma"
                "optician" -> "Opticien"
                "laboratory" -> "Laboratoire"
                "florist" -> "Fleuriste"
                "butcher" -> "Boucherie"
                "convenience" -> "Épicerie"
                "diy" -> "Bricolage / quincaillerie"
                "car_wash" -> "Lavage auto"
                "vehicle_inspection" -> "Contrôle technique"
                "townhall" -> "Mairie"
                "police" -> "Police / gendarmerie"
                "fire_station" -> "Pompiers"
                "school" -> "École / établissement scolaire"
                "kindergarten" -> "Crèche"
                "train_station" -> "Gare"
                "bus_station" -> "Gare routière"
                "hospital" -> "Hôpital / clinique"
                "post_office" -> "Bureau de poste"
                "mall" -> "Centre commercial"
                else -> "Lieu"
            }

            // Renvoie centre, nom officiel de commune, code INSEE. Une requête telle que
            // "Pharmacie de l'Atrium" n'active donc PAS le mode catégorie si "de l atrium"
            // n'est pas reconnu comme commune : elle continue par la recherche de nom classique.
            fun resolveMunicipality(text: String, client: OkHttpClient): Triple<GeoPoint, String, String>? {
                if (text.isBlank()) return null
                return try {
                    val encodedPlace = java.net.URLEncoder.encode(text, "UTF-8")
                    val url = "https://data.geopf.fr/geocodage/search/?q=$encodedPlace&limit=6&autocomplete=0&type=municipality"
                    val request = Request.Builder().url(url).header("User-Agent", "VSP-GPS/1.0").build()
                    client.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) return@use null
                        val features = JSONObject(response.body?.string().orEmpty()).optJSONArray("features") ?: return@use null
                        for (i in 0 until features.length()) {
                            val f = features.optJSONObject(i) ?: continue
                            val props = f.optJSONObject("properties") ?: JSONObject()
                            val type = props.optString("type").lowercase(Locale.FRANCE)
                            if (type !in setOf("municipality", "locality", "city")) continue
                            val coords = f.optJSONObject("geometry")?.optJSONArray("coordinates") ?: continue
                            if (coords.length() < 2) continue
                            val lon = coords.optDouble(0, Double.NaN)
                            val lat = coords.optDouble(1, Double.NaN)
                            if (!lat.isFinite() || !lon.isFinite()) continue
                            val cityName = props.optString("city").ifBlank { props.optString("name") }.ifBlank { text }
                            val cityCode = props.optString("citycode").trim()
                            return@use Triple(GeoPoint(lat, lon), cityName, cityCode)
                        }
                        null
                    }
                } catch (_: Exception) {
                    null
                }
            }

            fun overpassFilters(key: String, base: String): String = when (key) {
                "friterie" -> """
                    nwr["amenity"="fast_food"]["name"~"friterie|frituur|baraque.*frite|frite",i]($base);
                    nwr["amenity"="fast_food"]["cuisine"~"fries|french_fries|chips|friture",i]($base);
                    nwr["name"~"friterie|frituur|baraque.*frite",i]($base);
                """.trimIndent()
                "pharmacy" -> "nwr[\"amenity\"=\"pharmacy\"]($base);"
                "bakery" -> "nwr[\"shop\"=\"bakery\"]($base);"
                "car_repair" -> "nwr[\"shop\"=\"car_repair\"]($base);"
                "fuel" -> "nwr[\"amenity\"=\"fuel\"]($base);"
                "charge" -> "nwr[\"amenity\"=\"charging_station\"]($base);"
                "restaurant" -> "nwr[\"amenity\"=\"restaurant\"]($base);"
                "fast_food" -> "nwr[\"amenity\"=\"fast_food\"]($base);"
                "pizzeria" -> """
                    nwr["amenity"~"restaurant|fast_food"]["cuisine"~"pizza",i]($base);
                    nwr["name"~"pizzeria|pizza",i]($base);
                """.trimIndent()
                "kebab" -> """
                    nwr["amenity"~"restaurant|fast_food"]["cuisine"~"kebab|doner",i]($base);
                    nwr["name"~"kebab|doner",i]($base);
                """.trimIndent()
                "supermarket" -> "nwr[\"shop\"~\"supermarket|department_store\"]($base);"
                "cafe" -> "nwr[\"amenity\"=\"cafe\"]($base);"
                "bar" -> "nwr[\"amenity\"~\"bar|pub\"]($base);"
                "hotel" -> "nwr[\"tourism\"=\"hotel\"]($base);"
                "parking" -> "nwr[\"amenity\"=\"parking\"]($base);"
                "hairdresser" -> "nwr[\"shop\"=\"hairdresser\"]($base);"
                "tobacco" -> "nwr[\"shop\"=\"tobacco\"]($base);"
                "bank" -> "nwr[\"amenity\"=\"bank\"]($base);"
                "atm" -> "nwr[\"amenity\"=\"atm\"]($base);"
                "doctor" -> "nwr[\"amenity\"=\"doctors\"]($base); nwr[\"healthcare\"=\"doctor\"]($base);"
                "dentist" -> "nwr[\"amenity\"=\"dentist\"]($base);"
                "veterinary" -> "nwr[\"amenity\"=\"veterinary\"]($base);"
                "cinema" -> "nwr[\"amenity\"=\"cinema\"]($base);"
                "optician" -> "nwr[\"shop\"=\"optician\"]($base);"
                "laboratory" -> "nwr[\"healthcare\"=\"laboratory\"]($base); nwr[\"amenity\"=\"laboratory\"]($base);"
                "florist" -> "nwr[\"shop\"=\"florist\"]($base);"
                "butcher" -> "nwr[\"shop\"=\"butcher\"]($base);"
                "convenience" -> "nwr[\"shop\"~\"convenience|general\"]($base);"
                "diy" -> "nwr[\"shop\"~\"doityourself|hardware\"]($base);"
                "car_wash" -> "nwr[\"amenity\"=\"car_wash\"]($base);"
                "vehicle_inspection" -> "nwr[\"amenity\"=\"vehicle_inspection\"]($base);"
                "townhall" -> "nwr[\"amenity\"=\"townhall\"]($base);"
                "police" -> "nwr[\"amenity\"=\"police\"]($base);"
                "fire_station" -> "nwr[\"amenity\"=\"fire_station\"]($base);"
                "school" -> "nwr[\"amenity\"~\"school|college\"]($base);"
                "kindergarten" -> "nwr[\"amenity\"=\"kindergarten\"]($base);"
                "train_station" -> "nwr[\"railway\"=\"station\"]($base);"
                "bus_station" -> "nwr[\"amenity\"=\"bus_station\"]($base);"
                "hospital" -> "nwr[\"amenity\"~\"hospital|clinic\"]($base); nwr[\"healthcare\"~\"hospital|clinic\"]($base);"
                "post_office" -> "nwr[\"amenity\"=\"post_office\"]($base);"
                "mall" -> "nwr[\"shop\"~\"mall|shopping_centre\"]($base);"
                else -> ""
            }

            suspend fun categorySuggestions(client: OkHttpClient): List<Destination>? {
                val (categoryKey, consumed) = categoryMatch ?: return null
                // ETAPE 114 : accepter les formulations naturelles « friterie à Liévin »,
                // « pharmacie près de Lens », « garage dans Arras » comme la forme courte.
                val locationWords114 = setOf("a", "au", "aux", "de", "du", "des", "dans", "pres", "proche", "vers")
                val placeTokens114 = categoryTokens.drop(consumed).dropWhile { it in locationWords114 }
                val placeText = placeTokens114.joinToString(" ").trim()
                val municipality = if (placeText.isNotBlank()) resolveMunicipality(placeText, client) else null

                // Si du texte suit la catégorie mais n'est pas une commune, il s'agit probablement
                // d'un NOM de commerce (ex. "Pharmacie de l'Atrium") : laisser Photon/GeoPF le traiter.
                if (placeText.isNotBlank() && municipality == null) return null

                val gpsCenter = currentLocation?.let { GeoPoint(it.latitude, it.longitude) }
                val searchCenter = municipality?.first ?: gpsCenter ?: return null
                val cityName = municipality?.second.orEmpty()
                val cityCode = municipality?.third.orEmpty()
                val sortOrigin = gpsCenter ?: searchCenter

                // ETAPE 118 : si aucune ville n'est saisie, déterminer la commune du GPS pour
                // compléter la recherche avec l'Annuaire des Entreprises. C'est essentiel pour
                // les commerces dont l'enseigne ne contient pas la catégorie (ex. une friterie
                // enregistrée comme restauration traditionnelle). On ne limite PAS Overpass à
                // cette commune : elle sert seulement de recherche complémentaire prioritaire.
                fun resolveGpsMunicipality(center: GeoPoint): Triple<GeoPoint, String, String>? {
                    return try {
                        @Suppress("DEPRECATION")
                        val address = Geocoder(context, Locale.FRANCE)
                            .getFromLocation(center.latitude, center.longitude, 1)
                            ?.firstOrNull()
                        val place = listOfNotNull(address?.locality, address?.subLocality)
                            .firstOrNull { !it.isNullOrBlank() }
                            ?.trim()
                            .orEmpty()
                        if (place.isBlank()) null else resolveMunicipality(place, client)
                    } catch (_: Exception) {
                        null
                    }
                }
                val gpsMunicipality = if (municipality == null && gpsCenter != null &&
                    categoryKey in SIRENE_LOCAL_CATEGORIES_1207) {
                    resolveGpsMunicipality(gpsCenter)
                } else null

                // ETAPE 116 : la relation administrative OSM n'a pas toujours le tag ref:INSEE.
                // On accepte donc aussi le nom officiel + admin_level 8/9. Cela évite qu'une
                // recherche comme « friterie Liévin » soit vide alors que des POI existent.
                val escapedCityName = cityName.replace("\\", "\\\\").replace("\"", "\\\"")
                val areaPrefix = if (cityCode.isNotBlank() || cityName.isNotBlank()) buildString {
                    append("(")
                    if (cityCode.isNotBlank()) append("area[\"boundary\"=\"administrative\"][\"ref:INSEE\"=\"").append(cityCode).append("\"];")
                    if (cityName.isNotBlank()) append("area[\"boundary\"=\"administrative\"][\"name\"=\"").append(escapedCityName).append("\"][\"admin_level\"~\"8|9\"];")
                    append(")->.searchArea;")
                } else ""
                val base = if (municipality != null) "area.searchArea"
                    else "around:15000,${searchCenter.latitude},${searchCenter.longitude}"
                val filters = overpassFilters(categoryKey, base)
                if (filters.isBlank()) return null

                val queryOverpass = """
                    [out:json][timeout:15];
                    $areaPrefix
                    (
                    $filters
                    );
                    out center tags;
                """.trimIndent()

                val endpoints = listOf(
                    "https://overpass-api.de/api/interpreter",
                    "https://overpass.private.coffee/api/interpreter",
                    "https://maps.mail.ru/osm/tools/overpass/api/interpreter"
                )

                var body: String? = null
                for (endpoint in endpoints) {
                    try {
                        val request = Request.Builder()
                            .url(endpoint)
                            .post(okhttp3.FormBody.Builder().add("data", queryOverpass).build())
                            .header("User-Agent", "VSP-GPS/1.0")
                            .build()
                        val overpassClient = client.newBuilder()
                            .connectTimeout(6, java.util.concurrent.TimeUnit.SECONDS)
                            .readTimeout(16, java.util.concurrent.TimeUnit.SECONDS)
                            .callTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
                            .build()
                        overpassClient.newCall(request).execute().use { response ->
                            if (response.isSuccessful) {
                                body = response.body?.string()
                            }
                        }
                        if (!body.isNullOrBlank()) break
                    } catch (_: Exception) { }
                }
                // ETAPE 114 : Overpass reste prioritaire mais n'est plus un point de panne unique.
                // S'il est indisponible ou pauvre en résultats, Photon/OSM complète ensuite
                // uniquement avec de vrais POI de la catégorie demandée.
                val json = body?.let { runCatching { JSONObject(it) }.getOrNull() }
                val elements = json?.optJSONArray("elements")
                val out = mutableListOf<Destination>()
                val display = categoryDisplayName(categoryKey)

                for (i in 0 until (elements?.length() ?: 0)) {
                    val obj = elements?.optJSONObject(i) ?: continue
                    val tags = obj.optJSONObject("tags") ?: JSONObject()
                    val lat: Double
                    val lon: Double
                    val center = obj.optJSONObject("center")
                    if (center != null) {
                        lat = center.optDouble("lat", Double.NaN)
                        lon = center.optDouble("lon", Double.NaN)
                    } else {
                        lat = obj.optDouble("lat", Double.NaN)
                        lon = obj.optDouble("lon", Double.NaN)
                    }
                    if (!lat.isFinite() || !lon.isFinite()) continue
                    val point = GeoPoint(lat, lon)

                    val name = tags.optString("name").trim()
                        .ifBlank { tags.optString("brand").trim() }
                        .ifBlank { tags.optString("operator").trim() }
                        .ifBlank { display }
                    val street = listOf(tags.optString("addr:housenumber"), tags.optString("addr:street"))
                        .filter { it.isNotBlank() }.joinToString(" ").trim()
                    val resultCity = tags.optString("addr:city").trim().ifBlank { cityName }
                    val locality = listOf(tags.optString("addr:postcode"), resultCity)
                        .filter { it.isNotBlank() }.distinct().joinToString(" ").trim()
                    val label = listOf(name, street, locality)
                        .filter { it.isNotBlank() }.distinct().joinToString(", ")
                    val distance = distanceMetersBetween(sortOrigin, point)
                    out += Destination(label, point, distance)
                }

                // Secours Photon : V119 interroge plusieurs formulations et le fait même
                // quand SIRENE a déjà renvoyé quelques résultats. Sinon une liste de 5 commerces
                // lointains pouvait empêcher Photon de faire remonter un commerce réellement proche.
                fun photonMatchesCategory(properties: JSONObject): Boolean {
                    val osmKey = properties.optString("osm_key").lowercase(Locale.FRANCE)
                    val osmValue = properties.optString("osm_value").lowercase(Locale.FRANCE)
                    val normalizedName = normalizeCategorySearch(properties.optString("name"))
                    return when (categoryKey) {
                        "friterie" -> osmKey == "amenity" && osmValue == "fast_food" &&
                            ("frit" in normalizedName || "friterie" in normalizedName || "frituur" in normalizedName)
                        "pharmacy" -> osmKey == "amenity" && osmValue == "pharmacy"
                        "bakery" -> osmKey == "shop" && osmValue == "bakery"
                        "car_repair" -> osmKey == "shop" && osmValue == "car_repair"
                        "fuel" -> osmKey == "amenity" && osmValue == "fuel"
                        "charge" -> osmKey == "amenity" && osmValue == "charging_station"
                        "restaurant" -> osmKey == "amenity" && osmValue == "restaurant"
                        "fast_food" -> osmKey == "amenity" && osmValue == "fast_food"
                        "pizzeria" -> osmKey == "amenity" && osmValue in setOf("restaurant", "fast_food") &&
                            ("pizza" in normalizedName || "pizz" in normalizedName)
                        "kebab" -> osmKey == "amenity" && osmValue in setOf("restaurant", "fast_food") &&
                            ("kebab" in normalizedName || "doner" in normalizedName)
                        "supermarket" -> osmKey == "shop" && osmValue in setOf("supermarket", "department_store")
                        "cafe" -> osmKey == "amenity" && osmValue == "cafe"
                        "bar" -> osmKey == "amenity" && osmValue in setOf("bar", "pub")
                        "hotel" -> osmKey == "tourism" && osmValue == "hotel"
                        "parking" -> osmKey == "amenity" && osmValue == "parking"
                        "hairdresser" -> osmKey == "shop" && osmValue == "hairdresser"
                        "tobacco" -> osmKey == "shop" && osmValue == "tobacco"
                        "bank" -> osmKey == "amenity" && osmValue == "bank"
                        "atm" -> osmKey == "amenity" && osmValue == "atm"
                        "doctor" -> (osmKey == "amenity" && osmValue == "doctors") || (osmKey == "healthcare" && osmValue == "doctor")
                        "dentist" -> osmKey == "amenity" && osmValue == "dentist"
                        "veterinary" -> osmKey == "amenity" && osmValue == "veterinary"
                        "cinema" -> osmKey == "amenity" && osmValue == "cinema"
                        "optician" -> osmKey == "shop" && osmValue == "optician"
                        "laboratory" -> (osmKey == "healthcare" || osmKey == "amenity") && osmValue == "laboratory"
                        "florist" -> osmKey == "shop" && osmValue == "florist"
                        "butcher" -> osmKey == "shop" && osmValue == "butcher"
                        "convenience" -> osmKey == "shop" && osmValue in setOf("convenience", "general")
                        "diy" -> osmKey == "shop" && osmValue in setOf("doityourself", "hardware")
                        "car_wash" -> osmKey == "amenity" && osmValue == "car_wash"
                        "vehicle_inspection" -> osmKey == "amenity" && osmValue == "vehicle_inspection"
                        "townhall" -> osmKey == "amenity" && osmValue == "townhall"
                        "police" -> osmKey == "amenity" && osmValue == "police"
                        "fire_station" -> osmKey == "amenity" && osmValue == "fire_station"
                        "school" -> osmKey == "amenity" && osmValue in setOf("school", "college")
                        "kindergarten" -> osmKey == "amenity" && osmValue == "kindergarten"
                        "train_station" -> osmKey == "railway" && osmValue == "station"
                        "bus_station" -> osmKey == "amenity" && osmValue == "bus_station"
                        "hospital" -> (osmKey == "amenity" || osmKey == "healthcare") && osmValue in setOf("hospital", "clinic")
                        "post_office" -> osmKey == "amenity" && osmValue == "post_office"
                        "mall" -> osmKey == "shop" && osmValue in setOf("mall", "shopping_centre", "department_store")
                        else -> false
                    }
                }

                val photonTerms = when (categoryKey) {
                    "pizzeria" -> listOf("pizzeria", "pizza")
                    "friterie" -> listOf("friterie", "frite")
                    "pharmacy" -> listOf("pharmacie")
                    "bakery" -> listOf("boulangerie")
                    "car_repair" -> listOf("garage automobile", "garage")
                    else -> listOf(display)
                }
                if (categoryKey in setOf("pizzeria", "friterie", "pharmacy", "bakery", "car_repair") || out.size < 8) {
                    for (term in photonTerms.distinct().take(2)) {
                        try {
                            val fallbackTerms = listOf(term, cityName.ifBlank { placeText })
                                .filter { it.isNotBlank() }
                                .joinToString(" ")
                            val encodedFallback = java.net.URLEncoder.encode(fallbackTerms, "UTF-8")
                            val photonUrl = "https://photon.komoot.io/api/?q=$encodedFallback&limit=40&lang=fr&countrycode=FR&dedupe=0" +
                                "&lat=${searchCenter.latitude}&lon=${searchCenter.longitude}&zoom=12&location_bias_scale=0.85"
                            val photonRequest = Request.Builder().url(photonUrl).header("User-Agent", "VSP-GPS/1.0").build()
                            client.newCall(photonRequest).execute().use { response ->
                                if (response.isSuccessful) {
                                    val features = JSONObject(response.body?.string().orEmpty()).optJSONArray("features")
                                    for (i in 0 until (features?.length() ?: 0)) {
                                        val feature = features?.optJSONObject(i) ?: continue
                                        val properties = feature.optJSONObject("properties") ?: JSONObject()
                                        if (!photonMatchesCategory(properties)) continue
                                        val coords = feature.optJSONObject("geometry")?.optJSONArray("coordinates") ?: continue
                                        if (coords.length() < 2) continue
                                        val lon = coords.optDouble(0, Double.NaN)
                                        val lat = coords.optDouble(1, Double.NaN)
                                        if (!lat.isFinite() || !lon.isFinite()) continue
                                        val point = GeoPoint(lat, lon)
                                        val fromRequestedCenter = distanceMetersBetween(searchCenter, point)
                                        val maxCenterDistance = if (municipality != null) 20_000.0 else 30_000.0
                                        if (fromRequestedCenter > maxCenterDistance) continue

                                        val name = properties.optString("name").trim().ifBlank { display }
                                        val street = listOf(properties.optString("housenumber"), properties.optString("street"))
                                            .filter { it.isNotBlank() }.joinToString(" ").trim()
                                        val photonCity = properties.optString("city").trim()
                                        if (municipality != null && photonCity.isNotBlank() && cityName.isNotBlank() &&
                                            normalizeCategorySearch(photonCity) != normalizeCategorySearch(cityName)) continue
                                        val resultCity = photonCity.ifBlank { cityName }
                                        val locality = listOf(properties.optString("postcode"), resultCity)
                                            .filter { it.isNotBlank() }.distinct().joinToString(" ").trim()
                                        val label = listOf(name, street, locality)
                                            .filter { it.isNotBlank() }.distinct().joinToString(", ")
                                        out += Destination(label, point, distanceMetersBetween(sortOrigin, point))
                                    }
                                }
                            }
                        } catch (_: Exception) { }
                    }
                }

                // ETAPE 119 : source complémentaire sans clé API via le Geocoder Android.
                // Certains appareils savent résoudre des noms de commerces/POI locaux que les
                // données OSM ou SIRENE classent trop largement. Cette source reste facultative :
                // si le service n'est pas présent sur le téléphone, la recherche continue sans lui.
                fun addAndroidGeocoderCategoryResults() {
                    if (!Geocoder.isPresent()) return
                    val terms = when (categoryKey) {
                        "friterie" -> listOf("friterie", "frites")
                        "pizzeria" -> listOf("pizzeria", "pizza")
                        "pharmacy" -> listOf("pharmacie")
                        "bakery" -> listOf("boulangerie")
                        "car_repair" -> listOf("garage automobile", "garage")
                        else -> emptyList()
                    }
                    if (terms.isEmpty()) return
                    try {
                        val radiusKm = if (municipality != null) 12.0 else 15.0
                        val dLat = radiusKm / 111.0
                        val cosLat = kotlin.math.cos(Math.toRadians(searchCenter.latitude)).coerceAtLeast(0.2)
                        val dLon = radiusKm / (111.0 * cosLat)
                        @Suppress("DEPRECATION")
                        val geocoder = Geocoder(context, Locale.FRANCE)
                        for (term in terms.take(2)) {
                            val q = listOf(term, cityName.takeIf { municipality != null })
                                .filterNotNull().filter { it.isNotBlank() }.joinToString(" ")
                            @Suppress("DEPRECATION")
                            val addresses = geocoder.getFromLocationName(
                                q, 20,
                                searchCenter.latitude - dLat, searchCenter.longitude - dLon,
                                searchCenter.latitude + dLat, searchCenter.longitude + dLon
                            ).orEmpty()
                            for (a in addresses) {
                                val lat = a.latitude
                                val lon = a.longitude
                                if (!lat.isFinite() || !lon.isFinite()) continue
                                val point = GeoPoint(lat, lon)
                                val distance = distanceMetersBetween(sortOrigin, point)
                                if (distanceMetersBetween(searchCenter, point) > radiusKm * 1000.0 + 1000.0) continue
                                val localityName = listOfNotNull(a.locality, a.subAdminArea)
                                    .firstOrNull { it.isNotBlank() }.orEmpty()
                                if (municipality != null && localityName.isNotBlank() && cityName.isNotBlank() &&
                                    normalizeCategorySearch(localityName) != normalizeCategorySearch(cityName)) continue

                                val line0 = runCatching { a.getAddressLine(0) }.getOrNull().orEmpty().trim()
                                val feature = a.featureName.orEmpty().trim()
                                val premises = a.premises.orEmpty().trim()
                                fun usableBusinessName(v: String): Boolean {
                                    val n = normalizeCategorySearch(v)
                                    return n.length >= 3 && !n.all(Char::isDigit) &&
                                        n !in setOf("france", normalizeCategorySearch(cityName))
                                }
                                val firstLinePart = line0.substringBefore(',').trim()
                                val name = listOf(premises, feature, firstLinePart)
                                    .firstOrNull(::usableBusinessName)
                                    ?.take(90)
                                    ?: display
                                val street = listOf(a.subThoroughfare, a.thoroughfare)
                                    .filterNotNull().map { it.trim() }.filter { it.isNotBlank() }
                                    .joinToString(" ")
                                val locality = listOf(a.postalCode.orEmpty(), a.locality.orEmpty())
                                    .filter { it.isNotBlank() }.distinct().joinToString(" ")
                                val label = listOf(name, street, locality)
                                    .filter { it.isNotBlank() }.distinct().joinToString(", ")
                                out += Destination(label, point, distance)
                            }
                        }
                    } catch (_: Exception) { }
                }

                addAndroidGeocoderCategoryResults()

                // ETAPE 116 : Annuaire fiabilisé (null nettoyés, activité établissement, recherche par commune).
                // ETAPE 115 : source française complémentaire issue de l'Annuaire des Entreprises.
                // Le but n'est pas de remplacer OSM, mais de récupérer des établissements actifs
                // absents ou mal renseignés dans OSM (cas constaté sur pharmacies/restauration).
                // L'API est ouverte, renvoie des établissements géolocalisés et permet un filtrage
                // par activité principale. On fusionne ensuite avec OSM/Photon et on retrie par
                // distance GPS réelle.
                fun sireneActivityCodes(key: String): String? = when (key) {
                    // NAF rév.2, encore exposée dans le champ activite_principale en 2026.
                    "pharmacy" -> "47.73Z"
                    "friterie" -> "56.10A,56.10C"
                    "fast_food", "kebab" -> "56.10C"
                    "pizzeria", "restaurant" -> "56.10A,56.10C"
                    "bakery" -> "10.71C,10.71D,47.24Z"
                    "car_repair" -> "45.20A,45.20B"
                    "supermarket" -> "47.11D,47.11F"
                    "hotel" -> "55.10Z"
                    "hairdresser" -> "96.02A"
                    "tobacco" -> "47.26Z"
                    "doctor" -> "86.21Z"
                    "dentist" -> "86.23Z"
                    "veterinary" -> "75.00Z"
                    "cinema" -> "59.14Z"
                    "optician" -> "47.78A"
                    "laboratory" -> "86.90B"
                    "florist" -> "47.76Z"
                    "butcher" -> "47.22Z"
                    "convenience" -> "47.11B,47.11C"
                    "diy" -> "47.52A,47.52B"
                    "vehicle_inspection" -> "71.20A"
                    else -> null
                }

                // L'API Annuaire applique activite_principale à l'UNITÉ LÉGALE, pas directement
                // à chaque établissement. Un commerce local peut donc être absent du filtre exact
                // même si son établissement a le bon APE. La V119 ajoute un second passage par
                // SECTION NAF, beaucoup plus large, puis filtre l'APE au niveau établissement.
                fun sireneSectionCodes(key: String): String? = when (key) {
                    "friterie", "pizzeria", "restaurant", "fast_food", "kebab", "hotel" -> "I"
                    "pharmacy", "car_repair", "supermarket", "tobacco" -> "G"
                    "bakery" -> "C,G"
                    "hairdresser" -> "S"
                    "doctor", "dentist", "laboratory" -> "Q"
                    "veterinary", "vehicle_inspection" -> "M"
                    "optician", "florist", "butcher", "convenience", "diy" -> "G"
                    "cinema" -> "R"
                    else -> null
                }

                fun sireneNameMatchesCategory(key: String, rawName: String): Boolean {
                    val n = normalizeCategorySearch(rawName)
                    return when (key) {
                        // Pour ces catégories, le code APE est plus large que la recherche :
                        // on exige donc un indice dans l'enseigne / nom commercial.
                        "friterie" -> listOf("frit", "baraque a frite", "baraque frite").any { it in n }
                        "pizzeria" -> "pizza" in n || "pizz" in n
                        "kebab" -> "kebab" in n || "doner" in n || "donner" in n
                        else -> true
                    }
                }

                // ETAPE 120.8 : certains APE sont volontairement larges. 47.24Z couvre
                // le commerce de détail de pain/pâtisserie/confiserie ; une chocolaterie peut
                // donc remonter à tort dans une recherche « boulangerie ». Pour cet APE ambigu,
                // on exige un indice boulanger/pâtissier dans l'enseigne ou le nom commercial.
                // Les vrais boulangers producteurs (10.71C / 10.71D) restent acceptés sans cela.
                fun sireneAmbiguousActivityMatchesName(key: String, ape: String, evidence: String): Boolean {
                    if (key != "bakery" || ape.uppercase(Locale.FRANCE) != "47.24Z") return true
                    val n = normalizeCategorySearch(evidence)
                    val bakeryRoots = listOf(
                        "boulanger", "patisser", "pain", "mie", "fournil", "brioche", "croissant"
                    )
                    return bakeryRoots.any { it in n }
                }

                // JSONObject.optString renvoie littéralement « null » lorsque la valeur JSON
                // vaut null. Centraliser le nettoyage empêche d'afficher « null, 4 RUE ... ».
                fun apiText(obj: JSONObject, key: String): String {
                    val value = obj.opt(key)
                    if (value == null || value == JSONObject.NULL) return ""
                    return value.toString().trim().takeUnless { it.equals("null", ignoreCase = true) } ?: ""
                }

                fun sireneEstablishmentMatchesActivity(key: String, est: JSONObject): Boolean {
                    val allowed = sireneActivityCodes(key)
                        ?.split(',')
                        ?.map { it.trim().uppercase(Locale.FRANCE) }
                        ?.filter { it.isNotBlank() }
                        ?.toSet()
                        .orEmpty()
                    if (allowed.isEmpty()) return true
                    val ape = apiText(est, "activite_principale").uppercase(Locale.FRANCE)
                    // Certains enregistrements anciens n'exposent pas le code au niveau établissement :
                    // on les garde, mais lorsqu'il est présent il doit appartenir à la catégorie.
                    return ape.isBlank() || ape in allowed
                }

                fun allEnseignes(est: JSONObject): List<String> {
                    val arr = est.optJSONArray("liste_enseignes") ?: return emptyList()
                    val values = mutableListOf<String>()
                    for (idx in 0 until arr.length()) {
                        val raw = arr.opt(idx)
                        if (raw == null || raw == JSONObject.NULL) continue
                        val value = raw.toString().trim()
                        if (value.isNotBlank() && !value.equals("null", ignoreCase = true)) {
                            values += splitPoiBusinessAliases1204(value)
                        }
                    }
                    return values.distinct()
                }

                fun categoryNameScore(key: String, raw: String): Int {
                    val n = normalizeCategorySearch(raw)
                    if (n.isBlank()) return 0
                    if (key == "friterie") {
                        return when {
                            "friterie" in n || "frituur" in n -> 20
                            "frit" in n -> 15
                            else -> 1
                        }
                    }
                    val roots = poiCategoryNameRoots1207(key)
                    return if (roots.isNotEmpty() && roots.any { it in n }) 20 else 1
                }

                fun friendlySireneName(key: String, est: JSONObject, company: JSONObject, display: String): Pair<String, String> {
                    val enseignes = allEnseignes(est)
                    val commercial = apiText(est, "nom_commercial")
                    val legal = apiText(company, "nom_complet").ifBlank { apiText(company, "nom_raison_sociale") }
                    val sigle = apiText(company, "sigle")
                    val commercialAliases = splitPoiBusinessAliases1204(commercial)
                    val usefulSigle = sigle.takeIf { it.isNotBlank() && categoryNameScore(key, it) > 1 }
                    val businessNames = (enseignes + commercialAliases + listOfNotNull(usefulSigle))
                        .filter { it.isNotBlank() }.distinct()
                    val evidence = (businessNames + splitPoiBusinessAliases1204(legal))
                        .filter { it.isNotBlank() }.distinct().joinToString(" ")

                    // V119 : lorsqu'un établissement possède plusieurs enseignes/alias, choisir
                    // celle qui correspond le mieux à la catégorie demandée. Ex. « BRASSERIE DE
                    // LA GRANGE / FRITERIE AIXOISE » doit être affiché « FRITERIE AIXOISE » pour
                    // une recherche friterie.
                    val bestBusinessName = businessNames.maxByOrNull { categoryNameScore(key, it) }.orEmpty()
                    val legalNorm = normalizeCategorySearch(legal)
                    val cleanedLegal = legal.replace(
                        Regex("(?i)^(?:sarl|sarlu|sas|sasu|eurl|selarl|sci|snc|sa)\\s+"),
                        ""
                    ).trim()
                    val legalLooksTechnical = legalNorm.startsWith("sarl ") || legalNorm.startsWith("sas ") ||
                        legalNorm.startsWith("sas u ") || legalNorm.startsWith("sasu ") ||
                        legalNorm.startsWith("selarl ") || legalNorm.startsWith("eurl ") ||
                        legalNorm.startsWith("sci ") || legalNorm.startsWith("snc ")
                    val roots1207 = poiCategoryNameRoots1207(key)
                    val legalLooksUsefulForCategory = when {
                        key == "friterie" -> "frit" in legalNorm
                        roots1207.isNotEmpty() -> roots1207.any { it in legalNorm }
                        else -> true
                    }
                    val chosen = bestBusinessName.ifBlank {
                        when {
                            legal.isNotBlank() && !legalLooksTechnical && legalLooksUsefulForCategory -> legal
                            cleanedLegal.isNotBlank() && cleanedLegal.length >= 3 && legalLooksUsefulForCategory -> cleanedLegal
                            else -> display
                        }
                    }
                    return chosen to evidence
                }

                fun flexibleDouble(obj: JSONObject, key: String): Double? {
                    val direct = obj.optDouble(key, Double.NaN)
                    if (direct.isFinite()) return direct
                    return obj.optString(key).trim().replace(',', '.').toDoubleOrNull()
                }


                // ETAPE 120 : l'API Annuaire documente une limite de 7 requêtes/s/IP.
                // Les recherches multi-source utilisent plusieurs passes ; ce petit garde-fou
                // maintient volontairement un débit inférieur à la limite et réduit les HTTP 429.
                var lastSireneRequestAt120 = 0L
                fun waitForSireneSlot120() {
                    val now = android.os.SystemClock.elapsedRealtime()
                    val waitMs = 185L - (now - lastSireneRequestAt120)
                    if (waitMs > 0L) Thread.sleep(waitMs)
                    lastSireneRequestAt120 = android.os.SystemClock.elapsedRealtime()
                }

                suspend fun addSireneBusinesses() {
                    val activityCodes = sireneActivityCodes(categoryKey) ?: return
                    try {
                        // ETAPE 117 : l'endpoint near_point est paginé. Une seule page de 25 unités
                        // légales était insuffisante dans les zones denses : après filtrage par nom,
                        // une recherche "pizzeria" pouvait ne garder que deux établissements lointains.
                        // On lit plusieurs pages uniquement pour les catégories qui en ont besoin.
                        // ETAPE 120 : recherche LOCAL-FIRST. /near_point n'est pas garanti trié
                        // strictement par distance ; demander directement 15-20 km pouvait donc
                        // remplir les premières pages avec des sociétés lointaines et rater une
                        // petite pizzeria à 2 km. On élargit progressivement le rayon.
                        val radiusPasses120 = when {
                            municipality != null -> listOf(4, 8, 12)
                            categoryKey in setOf("pizzeria", "friterie", "kebab", "fast_food") -> listOf(3, 6, 12, 18)
                            categoryKey in setOf("pharmacy", "bakery", "car_repair") -> listOf(4, 8, 15)
                            else -> listOf(6, 14, 20)
                        }
                        fun pagesForRadius120(radiusKm: Int): Int = when {
                            radiusKm <= 4 -> 2
                            categoryKey in setOf("pizzeria", "friterie", "kebab") -> 2
                            else -> 1
                        }
                        val sireneClient = client.newBuilder()
                            .connectTimeout(4, java.util.concurrent.TimeUnit.SECONDS)
                            .readTimeout(7, java.util.concurrent.TimeUnit.SECONDS)
                            .callTimeout(9, java.util.concurrent.TimeUnit.SECONDS)
                            .build()

                        for (radiusKm in radiusPasses120) {
                            val pageCount120 = pagesForRadius120(radiusKm)
                            for (page in 1..pageCount120) {
                            val url = buildString {
                                append("https://recherche-entreprises.api.gouv.fr/near_point")
                                append("?lat=").append(searchCenter.latitude)
                                append("&long=").append(searchCenter.longitude)
                                append("&radius=").append(radiusKm)
                                append("&activite_principale=").append(java.net.URLEncoder.encode(activityCodes, "UTF-8"))
                                append("&page=").append(page)
                                append("&per_page=25&limite_matching_etablissements=100")
                            }
                            val req = Request.Builder()
                                .url(url)
                                .header("Accept", "application/json")
                                .header("User-Agent", "VSP-GPS/1.0")
                                .build()
                            waitForSireneSlot120()
                            sireneClient.newCall(req).execute().use { response ->
                                if (!response.isSuccessful) return@use
                                val root = runCatching { JSONObject(response.body?.string().orEmpty()) }.getOrNull() ?: return@use
                                val results = root.optJSONArray("results") ?: return@use
                                if (results.length() == 0) return@use
                                for (r in 0 until results.length()) {
                                    val company = results.optJSONObject(r) ?: continue

                                    val establishments = mutableListOf<JSONObject>()
                                    company.optJSONArray("matching_etablissements")?.let { arr ->
                                        for (e in 0 until arr.length()) arr.optJSONObject(e)?.let(establishments::add)
                                    }
                                    // Le siège peut être très loin du point recherché pour une chaîne.
                                    if (establishments.isEmpty()) company.optJSONObject("siege")?.let(establishments::add)

                                    for (est in establishments) {
                                        val state = apiText(est, "etat_administratif")
                                        if (state.isNotBlank() && state != "A") continue
                                        if (!sireneEstablishmentMatchesActivity(categoryKey, est)) continue
                                        if (municipality != null) {
                                            val establishmentCityCode = apiText(est, "commune")
                                            val establishmentCityName = apiText(est, "libelle_commune")
                                            val codeMatches = cityCode.isNotBlank() && establishmentCityCode == cityCode
                                            val nameMatches = cityName.isNotBlank() && establishmentCityName.isNotBlank() &&
                                                normalizeCategorySearch(establishmentCityName) == normalizeCategorySearch(cityName)
                                            if (establishmentCityCode.isNotBlank() && cityCode.isNotBlank() && !codeMatches) continue
                                            if (establishmentCityCode.isBlank() && establishmentCityName.isNotBlank() && cityName.isNotBlank() && !nameMatches) continue
                                        }
                                        val lat = flexibleDouble(est, "latitude") ?: continue
                                        val lon = flexibleDouble(est, "longitude") ?: continue
                                        if (!lat.isFinite() || !lon.isFinite()) continue
                                        val point = GeoPoint(lat, lon)

                                        val (rawName, nameEvidence) = friendlySireneName(categoryKey, est, company, display)
                                        val establishmentApe1208 = apiText(est, "activite_principale").uppercase(Locale.FRANCE)
                                        if (!sireneAmbiguousActivityMatchesName(categoryKey, establishmentApe1208, nameEvidence)) continue
                                        if (!sireneNameMatchesCategory(categoryKey, nameEvidence)) continue

                                        val resultCity = apiText(est, "libelle_commune").ifBlank { cityName }
                                        val postal = apiText(est, "code_postal")
                                        val fullAddress = apiText(est, "geo_adresse").ifBlank { apiText(est, "adresse") }
                                        val locality = listOf(postal, resultCity).filter { it.isNotBlank() }.distinct().joinToString(" ")
                                        val addressPart = when {
                                            fullAddress.isBlank() -> ""
                                            locality.isNotBlank() && normalizeCategorySearch(fullAddress).contains(normalizeCategorySearch(locality)) -> fullAddress
                                            else -> listOf(fullAddress, locality).filter { it.isNotBlank() }.joinToString(", ")
                                        }
                                        val label = listOf(rawName, addressPart).filter { it.isNotBlank() }.distinct().joinToString(", ")
                                        out += Destination(label, point, distanceMetersBetween(sortOrigin, point))
                                    }
                                }
                            }
                            }
                            // Si assez de bons résultats sont déjà disponibles, inutile de
                            // multiplier les requêtes sur les rayons plus larges.
                            if (out.count { (it.distanceMeters ?: Double.MAX_VALUE) <= radiusKm * 1000.0 + 500.0 } >= 10) break
                        }
                    } catch (_: Exception) {
                        // Source complémentaire : une panne ne doit jamais bloquer la recherche OSM.
                    }
                }

                suspend fun addSireneBroadSectionBusinesses() {
                    val sections = sireneSectionCodes(categoryKey) ?: return
                    val activityCodes = sireneActivityCodes(categoryKey) ?: return
                    try {
                        // Passage large V119 : le filtre de section porte lui aussi sur l'unité légale,
                        // mais il évite de rater un établissement dont l'APE local est correct alors
                        // que l'APE exact de l'entreprise mère est différent.
                        val radiusKm = if (municipality != null) 10 else when (categoryKey) {
                            "pizzeria", "friterie", "kebab" -> 10
                            else -> 8
                        }
                        val maxPages = when (categoryKey) {
                            "pizzeria", "friterie", "kebab" -> 6
                            "pharmacy", "bakery", "car_repair" -> 4
                            else -> 2
                        }
                        val broadClient = client.newBuilder()
                            .connectTimeout(4, java.util.concurrent.TimeUnit.SECONDS)
                            .readTimeout(7, java.util.concurrent.TimeUnit.SECONDS)
                            .callTimeout(9, java.util.concurrent.TimeUnit.SECONDS)
                            .build()
                        for (page in 1..maxPages) {
                            val url = buildString {
                                append("https://recherche-entreprises.api.gouv.fr/near_point")
                                append("?lat=").append(searchCenter.latitude)
                                append("&long=").append(searchCenter.longitude)
                                append("&radius=").append(radiusKm)
                                append("&section_activite_principale=").append(java.net.URLEncoder.encode(sections, "UTF-8"))
                                append("&page=").append(page)
                                append("&per_page=25&limite_matching_etablissements=100")
                            }
                            val req = Request.Builder().url(url)
                                .header("Accept", "application/json")
                                .header("User-Agent", "VSP-GPS/1.0")
                                .build()
                            var resultCount = 0
                            waitForSireneSlot120()
                            broadClient.newCall(req).execute().use { response ->
                                if (!response.isSuccessful) return@use
                                val root = runCatching { JSONObject(response.body?.string().orEmpty()) }.getOrNull() ?: return@use
                                val results = root.optJSONArray("results") ?: return@use
                                resultCount = results.length()
                                for (r in 0 until results.length()) {
                                    val company = results.optJSONObject(r) ?: continue
                                    val establishments = mutableListOf<JSONObject>()
                                    company.optJSONArray("matching_etablissements")?.let { arr ->
                                        for (e in 0 until arr.length()) arr.optJSONObject(e)?.let(establishments::add)
                                    }
                                    if (establishments.isEmpty()) company.optJSONObject("siege")?.let(establishments::add)
                                    for (est in establishments) {
                                        val state = apiText(est, "etat_administratif")
                                        if (state.isNotBlank() && state != "A") continue
                                        // Ici le filtrage exact est bien appliqué à l'établissement.
                                        val ape = apiText(est, "activite_principale").uppercase(Locale.FRANCE)
                                        val allowed = activityCodes.split(',').map { it.trim().uppercase(Locale.FRANCE) }.toSet()
                                        if (ape.isNotBlank() && ape !in allowed) continue
                                        if (municipality != null) {
                                            val establishmentCityCode = apiText(est, "commune")
                                            val establishmentCityName = apiText(est, "libelle_commune")
                                            val codeMatches = cityCode.isNotBlank() && establishmentCityCode == cityCode
                                            val nameMatches = cityName.isNotBlank() && establishmentCityName.isNotBlank() &&
                                                normalizeCategorySearch(establishmentCityName) == normalizeCategorySearch(cityName)
                                            if (establishmentCityCode.isNotBlank() && cityCode.isNotBlank() && !codeMatches) continue
                                            if (establishmentCityCode.isBlank() && establishmentCityName.isNotBlank() && cityName.isNotBlank() && !nameMatches) continue
                                        }
                                        val lat = flexibleDouble(est, "latitude") ?: continue
                                        val lon = flexibleDouble(est, "longitude") ?: continue
                                        if (!lat.isFinite() || !lon.isFinite()) continue
                                        val point = GeoPoint(lat, lon)
                                        val fromCenter = distanceMetersBetween(searchCenter, point)
                                        if (fromCenter > radiusKm * 1000.0 + 750.0) continue
                                        val (rawName0, nameEvidence) = friendlySireneName(categoryKey, est, company, display)
                                        if (!sireneAmbiguousActivityMatchesName(categoryKey, ape, nameEvidence)) continue
                                        val strictNameMatch120 = sireneNameMatchesCategory(categoryKey, nameEvidence)
                                        val legalClean120 = apiText(company, "nom_complet")
                                            .ifBlank { apiText(company, "nom_raison_sociale") }
                                            .replace(Regex("(?i)^(?:sarl|sarlu|sas|sasu|eurl|selarl|sci|snc|sa)\\s+"), "")
                                            .trim()
                                        val conflictingFood120 = normalizeCategorySearch(legalClean120).let { n ->
                                            listOf("pizza", "pizz", "kebab", "sushi", "tacos", "thai", "chinois", "indien").any { it in n }
                                        }
                                        // Une friterie réelle peut être déclarée simplement en 56.10A/56.10C
                                        // et porter un nom sans le mot « frite » (ex. « Chez ... »).
                                        // On garde ces établissements uniquement dans un rayon très local,
                                        // en les signalant comme candidats au lieu de prétendre qu'ils sont certains.
                                        val legalNorm120 = normalizeCategorySearch(legalClean120)
                                        val localFriterieCandidate120 = categoryKey == "friterie" && !strictNameMatch120 &&
                                            fromCenter <= 3000.0 && legalNorm120.startsWith("chez ") && !conflictingFood120
                                        if (!strictNameMatch120 && !localFriterieCandidate120) continue
                                        val rawName = if (localFriterieCandidate120) {
                                            "$legalClean120 • restauration proche"
                                        } else rawName0
                                        val resultCity = apiText(est, "libelle_commune").ifBlank { cityName }
                                        val postal = apiText(est, "code_postal")
                                        val fullAddress = apiText(est, "geo_adresse").ifBlank { apiText(est, "adresse") }
                                        val locality = listOf(postal, resultCity).filter { it.isNotBlank() }.distinct().joinToString(" ")
                                        val addressPart = when {
                                            fullAddress.isBlank() -> ""
                                            locality.isNotBlank() && normalizeCategorySearch(fullAddress).contains(normalizeCategorySearch(locality)) -> fullAddress
                                            else -> listOf(fullAddress, locality).filter { it.isNotBlank() }.joinToString(", ")
                                        }
                                        val label = listOf(rawName, addressPart).filter { it.isNotBlank() }.distinct().joinToString(", ")
                                        out += Destination(label, point, distanceMetersBetween(sortOrigin, point))
                                    }
                                }
                            }
                            if (resultCount < 25) break
                            if (page < maxPages) Thread.sleep(170)
                        }
                    } catch (_: Exception) { }
                }

                suspend fun addSireneMunicipalityNameSearch() {
                    val targetMunicipality = municipality ?: gpsMunicipality ?: return
                    val targetCityName = targetMunicipality.second
                    val targetCityCode = targetMunicipality.third
                    if (targetCityCode.isBlank()) return
                    val terms = sireneMunicipalityNameTerms1207(categoryKey)
                    if (terms.isEmpty()) return

                    // L'endpoint /search sait filtrer les établissements par code commune. Il est
                    // complémentaire de near_point pour les commerces dont la raison sociale n'a
                    // pas exactement le même code APE que l'enseigne visible sur place.
                                        // L'endpoint /search sait filtrer les établissements par code commune. Il est
                    // complémentaire de near_point pour les commerces dont la raison sociale n'a
                    // pas exactement le même code APE que l'enseigne visible sur place.
                    val maxNameQueries1207 = when (categoryKey) {
                        "friterie", "pizzeria" -> 4
                        "fast_food", "bakery", "car_repair" -> 3
                        else -> 2
                    }
                    for (term in terms.take(maxNameQueries1207)) {
                        try {
                            val url = buildString {
                                append("https://recherche-entreprises.api.gouv.fr/search?q=")
                                append(java.net.URLEncoder.encode(term, "UTF-8"))
                                append("&code_commune=").append(java.net.URLEncoder.encode(targetCityCode, "UTF-8"))
                                append("&etat_administratif=A&page=1&per_page=25&limite_matching_etablissements=100")
                            }
                            val req = Request.Builder().url(url)
                                .header("Accept", "application/json")
                                .header("User-Agent", "VSP-GPS/1.0")
                                .build()
                            val searchClient = client.newBuilder()
                                .connectTimeout(4, java.util.concurrent.TimeUnit.SECONDS)
                                .readTimeout(7, java.util.concurrent.TimeUnit.SECONDS)
                                .callTimeout(9, java.util.concurrent.TimeUnit.SECONDS)
                                .build()
                            waitForSireneSlot120()
                            searchClient.newCall(req).execute().use { response ->
                                if (!response.isSuccessful) return@use
                                val root = runCatching { JSONObject(response.body?.string().orEmpty()) }.getOrNull() ?: return@use
                                val results = root.optJSONArray("results") ?: return@use
                                for (r in 0 until results.length()) {
                                    val company = results.optJSONObject(r) ?: continue
                                    val establishments = mutableListOf<JSONObject>()
                                    company.optJSONArray("matching_etablissements")?.let { arr ->
                                        for (e in 0 until arr.length()) arr.optJSONObject(e)?.let(establishments::add)
                                    }
                                    if (establishments.isEmpty()) company.optJSONObject("siege")?.let(establishments::add)
                                    for (est in establishments) {
                                        val state = apiText(est, "etat_administratif")
                                        if (state.isNotBlank() && state != "A") continue
                                        val establishmentCityCode = apiText(est, "commune")
                                        val establishmentCityName = apiText(est, "libelle_commune")
                                        if (establishmentCityCode.isNotBlank() && establishmentCityCode != targetCityCode) continue
                                        if (establishmentCityCode.isBlank() && establishmentCityName.isNotBlank() &&
                                            normalizeCategorySearch(establishmentCityName) != normalizeCategorySearch(targetCityName)) continue

                                        val lat = flexibleDouble(est, "latitude") ?: continue
                                        val lon = flexibleDouble(est, "longitude") ?: continue
                                        if (!lat.isFinite() || !lon.isFinite()) continue
                                        val point = GeoPoint(lat, lon)
                                        val (rawName, nameEvidence) = friendlySireneName(categoryKey, est, company, display)
                                        val establishmentApe1208 = apiText(est, "activite_principale").uppercase(Locale.FRANCE)
                                        if (!sireneAmbiguousActivityMatchesName(categoryKey, establishmentApe1208, nameEvidence)) continue
                                        // Ici la pertinence est déjà imposée par q + code_commune côté Annuaire.
                                        // + code_commune côté Annuaire des Entreprises.

                                        val resultCity = establishmentCityName.ifBlank { targetCityName }
                                        val postal = apiText(est, "code_postal")
                                        val fullAddress = apiText(est, "geo_adresse").ifBlank { apiText(est, "adresse") }
                                        val locality = listOf(postal, resultCity).filter { it.isNotBlank() }.distinct().joinToString(" ")
                                        val addressPart = when {
                                            fullAddress.isBlank() -> ""
                                            locality.isNotBlank() && normalizeCategorySearch(fullAddress).contains(normalizeCategorySearch(locality)) -> fullAddress
                                            else -> listOf(fullAddress, locality).filter { it.isNotBlank() }.joinToString(", ")
                                        }
                                        val label = listOf(rawName, addressPart).filter { it.isNotBlank() }.distinct().joinToString(", ")
                                        out += Destination(label, point, distanceMetersBetween(sortOrigin, point))
                                    }
                                }
                            }
                        } catch (_: Exception) { }
                    }
                }

                // ETAPE 120.7 : recherche catégorie + commune généralisée à toutes
                // les catégories SIRENE prises en charge.
                // ETAPE 120.6 : lorsqu'une commune est explicitement demandée, la recherche
                // textuelle (q=friterie/pizza/...) peut rater une enseigne dont le mot recherché
                // est collé ou absent de la raison sociale. On complète donc avec un balayage
                // de la commune par section NAF, puis on vérifie l'APE AU NIVEAU ÉTABLISSEMENT.
                // code_commune filtre les établissements côté API ; section_activite_principale
                // ne sert ici qu'à réduire le volume de résultats.
                suspend fun addSireneMunicipalityActivitySweep1206() {
                    val targetMunicipality = municipality ?: return
                    val targetCityName = targetMunicipality.second
                    val targetCityCode = targetMunicipality.third
                    if (targetCityCode.isBlank()) return
                    val sections = sireneSectionCodes(categoryKey) ?: return
                    val activityCodes = sireneActivityCodes(categoryKey) ?: return
                    val allowed = activityCodes.split(',')
                        .map { it.trim().uppercase(Locale.FRANCE) }
                        .filter { it.isNotBlank() }
                        .toSet()
                    if (allowed.isEmpty()) return

                    val municipalityClient = client.newBuilder()
                        .connectTimeout(4, java.util.concurrent.TimeUnit.SECONDS)
                        .readTimeout(7, java.util.concurrent.TimeUnit.SECONDS)
                        .callTimeout(9, java.util.concurrent.TimeUnit.SECONDS)
                        .build()
                    val maxPages = when (categoryKey) {
                        "restaurant", "bakery", "car_repair", "hairdresser", "doctor" -> 5
                        "friterie", "pizzeria", "kebab", "fast_food", "supermarket" -> 4
                        else -> 3
                    }

                    for (page in 1..maxPages) {
                        var resultCount = 0
                        try {
                            val url = buildString {
                                append("https://recherche-entreprises.api.gouv.fr/search?")
                                append("code_commune=").append(java.net.URLEncoder.encode(targetCityCode, "UTF-8"))
                                append("&section_activite_principale=").append(java.net.URLEncoder.encode(sections, "UTF-8"))
                                append("&etat_administratif=A")
                                append("&page=").append(page)
                                append("&per_page=25&limite_matching_etablissements=100")
                            }
                            val req = Request.Builder().url(url)
                                .header("Accept", "application/json")
                                .header("User-Agent", "VSP-GPS/1.0")
                                .build()
                            waitForSireneSlot120()
                            municipalityClient.newCall(req).execute().use { response ->
                                if (!response.isSuccessful) return@use
                                val root = runCatching { JSONObject(response.body?.string().orEmpty()) }.getOrNull() ?: return@use
                                val results = root.optJSONArray("results") ?: return@use
                                resultCount = results.length()
                                for (r in 0 until results.length()) {
                                    val company = results.optJSONObject(r) ?: continue
                                    val establishments = mutableListOf<JSONObject>()
                                    company.optJSONArray("matching_etablissements")?.let { arr ->
                                        for (e in 0 until arr.length()) arr.optJSONObject(e)?.let(establishments::add)
                                    }
                                    if (establishments.isEmpty()) company.optJSONObject("siege")?.let(establishments::add)

                                    for (est in establishments) {
                                        val state = apiText(est, "etat_administratif")
                                        if (state.isNotBlank() && state != "A") continue
                                        val establishmentCityCode = apiText(est, "commune")
                                        val establishmentCityName = apiText(est, "libelle_commune")
                                        if (establishmentCityCode.isNotBlank() && establishmentCityCode != targetCityCode) continue
                                        if (establishmentCityCode.isBlank() && establishmentCityName.isNotBlank() &&
                                            normalizeCategorySearch(establishmentCityName) != normalizeCategorySearch(targetCityName)) continue

                                        val ape = apiText(est, "activite_principale").uppercase(Locale.FRANCE)
                                        if (ape.isBlank() || ape !in allowed) continue
                                        val lat = flexibleDouble(est, "latitude") ?: continue
                                        val lon = flexibleDouble(est, "longitude") ?: continue
                                        if (!lat.isFinite() || !lon.isFinite()) continue

                                        val (rawName, nameEvidence) = friendlySireneName(categoryKey, est, company, display)
                                        if (!sireneAmbiguousActivityMatchesName(categoryKey, ape, nameEvidence)) continue
                                        // Friterie / pizzeria / kebab partagent des APE larges : le nom ou
                                        // l'enseigne doit encore fournir un indice de la catégorie.
                                        if (!sireneNameMatchesCategory(categoryKey, nameEvidence)) continue

                                        val resultCity = establishmentCityName.ifBlank { targetCityName }
                                        val postal = apiText(est, "code_postal")
                                        val fullAddress = apiText(est, "geo_adresse").ifBlank { apiText(est, "adresse") }
                                        val locality = listOf(postal, resultCity)
                                            .filter { it.isNotBlank() }.distinct().joinToString(" ")
                                        val addressPart = when {
                                            fullAddress.isBlank() -> ""
                                            locality.isNotBlank() && normalizeCategorySearch(fullAddress)
                                                .contains(normalizeCategorySearch(locality)) -> fullAddress
                                            else -> listOf(fullAddress, locality)
                                                .filter { it.isNotBlank() }.joinToString(", ")
                                        }
                                        val point = GeoPoint(lat, lon)
                                        val label = listOf(rawName, addressPart)
                                            .filter { it.isNotBlank() }.distinct().joinToString(", ")
                                        out += Destination(label, point, distanceMetersBetween(sortOrigin, point))
                                    }
                                }
                            }
                        } catch (_: Exception) { }
                        if (resultCount < 25) break
                        if (page < maxPages) Thread.sleep(170)
                    }
                }

                addSireneBusinesses()
                if (municipality != null) addSireneMunicipalityActivitySweep1206()
                // ETAPE 120 : ne lancer les passes coûteuses que si la zone proche reste pauvre.
                // Cela réduit nettement le temps de réponse et la pression sur l'API publique
                // sans sacrifier les petites enseignes locales recherchées en priorité.
                val closePoiCount120 = out.count { (it.distanceMeters ?: Double.MAX_VALUE) <= 6000.0 }
                if (closePoiCount120 < 6) addSireneBroadSectionBusinesses()
                val closePoiCountAfterBroad120 = out.count { (it.distanceMeters ?: Double.MAX_VALUE) <= 6000.0 }
                if (closePoiCountAfterBroad120 < 5 || municipality != null) addSireneMunicipalityNameSearch()

                // ETAPE 120.5 : fusion/dédoublonnage extraite dans une fonction top-level.
                // ETAPE 120.9 : une seconde passe Photon, ciblée sur l'adresse, tente ensuite
                // de remplacer uniquement les libellés encore génériques par leur enseigne OSM.
                val merged1209 = mergeCategoryDestinations1205(out, display)
                val named1209 = enrichGenericCategoryNames1209(client, merged1209, categoryKey, display, cityName)
                return mergeCategoryDestinations1205(named1209, display)
            }


            // V442 : recherche enrichie. GeoPF reste la source française principale,
            // Photon/OSM complète les lieux, plages, commerces et autres POI que la
            // recherche d'adresses stricte peut ne pas remonter.
            val results = mutableListOf<Destination>()
            val poiResults = mutableListOf<Destination>()
            val encoded = java.net.URLEncoder.encode(typed, "UTF-8")
            val client = OkHttpClient.Builder()
                .connectTimeout(3, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(5, java.util.concurrent.TimeUnit.SECONDS)
                .callTimeout(6, java.util.concurrent.TimeUnit.SECONDS)
                .build()

            // Une vraie requête de catégorie ne doit jamais retomber sur une liste de rues.
            // null = ce n'était finalement pas une catégorie (ex. nom propre commençant par "Pharmacie").
            // liste vide = catégorie valide mais aucun POI OSM trouvé.
            val categoryOnlyResults = categorySuggestions(client)
            if (categoryOnlyResults != null) return@withContext categoryOnlyResults

            fun addFeatureCollection(body: String, photon: Boolean) {
                val features = JSONObject(body).optJSONArray("features") ?: return
                for (i in 0 until features.length()) {
                    val feature = features.optJSONObject(i) ?: continue
                    val properties = feature.optJSONObject("properties") ?: JSONObject()
                    val coordinates = feature.optJSONObject("geometry")
                        ?.optJSONArray("coordinates") ?: continue
                    if (coordinates.length() < 2) continue
                    val lon = coordinates.optDouble(0, Double.NaN)
                    val lat = coordinates.optDouble(1, Double.NaN)
                    if (!lat.isFinite() || !lon.isFinite()) continue

                    val label = if (!photon) {
                        properties.optString("label").ifBlank {
                            listOf(properties.optString("name"), properties.optString("postcode"), properties.optString("city"))
                                .filter { it.isNotBlank() }.distinct().joinToString(", ")
                        }
                    } else {
                        // V47 : pour un commerce/POI, le nom doit être la première information.
                        // Avant cette correction, « Lidl » pouvait devenir seulement « Rue ..., 62290 ... ».
                        val name = properties.optString("name").trim()
                        val street = listOf(properties.optString("housenumber"), properties.optString("street"))
                            .filter { it.isNotBlank() }.joinToString(" ").trim()
                        val locality = listOf(properties.optString("postcode"), properties.optString("city"))
                            .filter { it.isNotBlank() }.joinToString(" ").trim()
                        listOf(name, street, locality, properties.optString("state"))
                            .filter { it.isNotBlank() }.distinct().joinToString(", ")
                    }
                    if (label.isNotBlank()) {
                        val point = GeoPoint(lat, lon)
                        val distanceFromGps = currentLocation?.let {
                            distanceMetersBetween(GeoPoint(it.latitude, it.longitude), point)
                        }
                        val destination = Destination(label, point, distanceFromGps)
                        if (photon) {
                            val osmKey = properties.optString("osm_key").lowercase(Locale.FRANCE)
                            val isPoi = osmKey in setOf("shop", "amenity", "tourism", "leisure", "office", "craft", "healthcare")
                            if (isPoi) poiResults += destination else results += destination
                        } else {
                            results += destination
                        }
                    }
                }
            }

            // 1) Base Adresse Nationale / GeoPF : excellente couverture des adresses françaises.
            try {
                val url = "https://data.geopf.fr/geocodage/search/?q=$encoded&limit=10&autocomplete=1"
                val request = Request.Builder().url(url).header("User-Agent", "VSP-GPS/1.0").build()
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) addFeatureCollection(response.body?.string().orEmpty(), photon = false)
                }
            } catch (_: Exception) { }

            // 2) Photon + OpenStreetMap : complète les POI et noms de lieux (ex. « Stella Plage »).
            // ETAPE 112 : recherche France entière mieux adaptée aux commerces.
            // - countrycode=FR évite les homonymes étrangers ;
            // - limit=20 laisse davantage de place aux POI ;
            // - un biais géographique doux privilégie la zone du conducteur sans écraser
            //   une ville explicitement saisie dans la requête ;
            // - si Photon ne renvoie presque aucun POI, un second appel ciblé "shop"
            //   récupère les magasins (Lidl, Carrefour, boulangeries, etc.).
            try {
                val bias = currentLocation?.let {
                    "&lat=${it.latitude}&lon=${it.longitude}&zoom=10&location_bias_scale=0.12"
                }.orEmpty()
                val photonCommon = "&limit=20&lang=fr&countrycode=FR&dedupe=0$bias"
                val url = "https://photon.komoot.io/api/?q=$encoded$photonCommon"
                val request = Request.Builder().url(url).header("User-Agent", "VSP-GPS/1.0").build()
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) addFeatureCollection(response.body?.string().orEmpty(), photon = true)
                }

                if (poiResults.size < 3) {
                    val shopUrl = "https://photon.komoot.io/api/?q=$encoded&osm_tag=shop$photonCommon"
                    val shopRequest = Request.Builder().url(shopUrl).header("User-Agent", "VSP-GPS/1.0").build()
                    client.newCall(shopRequest).execute().use { response ->
                        if (response.isSuccessful) addFeatureCollection(response.body?.string().orEmpty(), photon = true)
                    }
                }
            } catch (_: Exception) { }

            // 3) Secours Android uniquement si les deux services n'ont rien trouvé.
            if (results.isEmpty() && poiResults.isEmpty()) {
                try {
                    @Suppress("DEPRECATION")
                    Geocoder(context, Locale.FRANCE).getFromLocationName(typed, 10)
                        ?.forEach { a ->
                            val label = listOfNotNull(a.featureName, a.thoroughfare, a.postalCode, a.locality)
                                .filter { it.isNotBlank() }.distinct().joinToString(", ")
                            if (label.isNotBlank()) {
                                val point = GeoPoint(a.latitude, a.longitude)
                                val distanceFromGps = currentLocation?.let {
                                    distanceMetersBetween(GeoPoint(it.latitude, it.longitude), point)
                                }
                                results += Destination(label, point, distanceFromGps)
                            }
                        }
                } catch (_: Exception) { }
            }

            // V47 : les commerces/services OSM passent avant les simples rues quand ils existent.
            // Une recherche « Lidl Nœux-les-Mines » doit donc proposer le magasin, pas dix rues de la ville.
            // ETAPE 53 : conserver le nom du lieu recherché. Pour une requête
            // "Lidl Nœux-les-Mines", une fiche "Lidl, ..." doit passer avant une
            // simple adresse "77A, ..." située au même endroit.
            fun normalizeSearch(value: String): String = java.text.Normalizer.normalize(
                value.lowercase(Locale.FRANCE)
                    .replace("œ", "oe")
                    .replace("æ", "ae"),
                java.text.Normalizer.Form.NFD
            ).replace(Regex("\\p{M}+"), "")

            val stopWords = setOf("de", "du", "des", "la", "le", "les", "a", "au", "aux", "en", "sur", "sous")
            val queryTokens = normalizeSearch(typed)
                .split(Regex("[^\\p{L}\\p{N}]+"))
                .filter { it.length >= 2 && it !in stopWords }
                .distinct()
            val firstToken = queryTokens.firstOrNull().orEmpty()
            val poiKeys = poiResults.mapTo(mutableSetOf()) {
                "${it.label.lowercase(Locale.FRANCE)}|${String.format(Locale.US, "%.5f", it.point.latitude)}|${String.format(Locale.US, "%.5f", it.point.longitude)}"
            }

            // ETAPE 112 : le classement tient compte de TOUS les mots saisis.
            // "Lidl Nœux-les-Mines" privilégie donc un Lidl de Nœux-les-Mines,
            // plutôt qu'une rue locale ou un Lidl d'une autre commune.
            fun candidateTextScore(candidate: Destination): Int {
                val label = normalizeSearch(candidate.label)
                val matched = queryTokens.count { token -> label.contains(token) }
                val allMatched = queryTokens.isNotEmpty() && matched == queryTokens.size
                val startsWithMain = firstToken.isNotBlank() && label.startsWith(firstToken)
                val key = "${candidate.label.lowercase(Locale.FRANCE)}|${String.format(Locale.US, "%.5f", candidate.point.latitude)}|${String.format(Locale.US, "%.5f", candidate.point.longitude)}"
                return matched * 20 +
                    (if (allMatched) 50 else 0) +
                    (if (startsWithMain) 25 else 0) +
                    (if (key in poiKeys) 15 else 0)
            }

            // ETAPE 114 : la pertinence textuelle reste prioritaire. À score égal,
            // un nom générique tel que « Lidl », « pharmacie » ou « garage » présente
            // les lieux les plus proches du GPS en premier.
            (poiResults + results)
                .distinctBy { "${it.label.lowercase(Locale.FRANCE)}|${String.format(Locale.US, "%.5f", it.point.latitude)}|${String.format(Locale.US, "%.5f", it.point.longitude)}" }
                .sortedWith(
                    compareByDescending<Destination> { candidateTextScore(it) }
                        .thenBy { it.distanceMeters ?: Double.MAX_VALUE }
                )
                .take(12)
        }

        suggestionsLoading = false
        // ETAPE 118 : un ancien échec de géocodage ne doit pas rester affiché sous une
        // nouvelle liste de POI valide. Les suggestions visibles sont la source de vérité.
        if (addressSuggestions.isNotEmpty() && error?.startsWith("Adresse introuvable") == true) {
            error = null
        }
    }

    // ETAPE 54 : si l'utilisateur recherche explicitement un commerce (ex. Lidl)
    // mais qu'un géocodeur renvoie seulement son adresse, conserver le nom recherché
    // comme libellé de destination. Les coordonnées restent celles du résultat choisi.
    fun destinationLabelPreservingPoiName(typedQuery: String, resolvedLabel: String): String {
        val token = typedQuery.trim().lowercase(Locale.FRANCE)
            .split(Regex("[^\\p{L}\\p{N}]+"))
            .firstOrNull { it.length >= 3 && it.none(Char::isDigit) }
            .orEmpty()
        if (token.isBlank()) return resolvedLabel
        val resolvedLower = resolvedLabel.lowercase(Locale.FRANCE)
        if (resolvedLower.contains(token)) return resolvedLabel
        val looksLikeAddress = resolvedLabel.trim().firstOrNull()?.isDigit() == true ||
            Regex("\\b\\d{5}\\b").containsMatchIn(resolvedLabel)
        return if (looksLikeAddress) typedQuery.trim() else resolvedLabel
    }

    fun searchAddress() {

        if (query.isBlank() || searching) {
            return
        }

        // V47 : la touche Recherche du clavier utilise aussi les résultats POI enrichis.
        // Ainsi un commerce affiché dans les suggestions n'est pas reperdu dans le Geocoder Android.
        val searchToken = query.trim().lowercase(Locale.FRANCE)
            .split(Regex("[^\\p{L}\\p{N}]+"))
            .firstOrNull { it.length >= 3 && it.none(Char::isDigit) }
            .orEmpty()
        val enrichedSuggestion = addressSuggestions.firstOrNull {
            searchToken.isNotBlank() && it.label.lowercase(Locale.FRANCE).contains(searchToken)
        } ?: addressSuggestions.firstOrNull()
        if (enrichedSuggestion != null) {
            val preserved = enrichedSuggestion.copy(
                label = destinationLabelPreservingPoiName(query, enrichedSuggestion.label)
            )
            suggestionSelectionInProgress = true
            query = preserved.label
            addressSuggestions = emptyList()
            destination = preserved
            destinationConfirmed = true
            confirmedDestinationLabel = preserved.label
            RotationRetainedState.query = preserved.label
            RotationRetainedState.destination = preserved
            RotationRetainedState.destinationConfirmed = true
            RotationRetainedState.confirmedDestinationLabel = preserved.label
            saveSearchHistory(historyContext, preserved.label)
            searchHistory = loadSearchHistory(historyContext)
            keyboardController?.hide()
            focusManager.clearFocus(force = true)
            currentLocation?.let { location ->
                calculateRoute(GeoPoint(location.latitude, location.longitude), enrichedSuggestion.point)
            }
            return
        }

        keyboardController?.hide()
        focusManager.clearFocus(force = true)

        searching = true
        error = null

        scope.launch {

            val result =
                withContext(Dispatchers.IO) {

                    try {

                        @Suppress("DEPRECATION")

                        val found =
                            Geocoder(
                                context,
                                Locale.FRANCE
                            ).getFromLocationName(
                                query,
                                1
                            )

                        found
                            ?.firstOrNull()
                            ?.let {

                                Destination(
                                    label =
                                        listOfNotNull(
                                            it.featureName,
                                            it.locality,
                                            it.postalCode
                                        )
                                            .distinct()
                                            .joinToString(", ")
                                            .ifBlank {
                                                query
                                            },

                                    point =
                                        GeoPoint(
                                            it.latitude,
                                            it.longitude
                                        )
                                )
                            }

                    } catch (_: Exception) {
                        null
                    }
                }

            val preservedResult = result?.copy(
                label = destinationLabelPreservingPoiName(query, result.label)
            )
            destination = preservedResult
                if (preservedResult != null) {
                    destinationConfirmed = true
                    confirmedDestinationLabel = preservedResult.label
                    RotationRetainedState.destination = preservedResult
                    RotationRetainedState.destinationConfirmed = true
                    RotationRetainedState.confirmedDestinationLabel = preservedResult.label
                    saveSearchHistory(historyContext, preservedResult.label)
                    searchHistory = loadSearchHistory(historyContext)
                }

            if (preservedResult != null) {
                keyboardController?.hide()
                focusManager.clearFocus(force = true)
            }

            currentLocation?.let { location ->
                preservedResult?.let { dest ->
                    calculateRoute(
                        GeoPoint(location.latitude, location.longitude),
                        dest.point
                    )
                }
            }

            if (result == null) {
                error =
                    "Adresse introuvable. Essayez avec la ville et le code postal."
            }

            searching = false
        }
    }

    // ETAPE 122 : persister uniquement la destination d'une navigation réellement active.
    // Au prochain processus, le tracé sera recalculé depuis la position courante.
    LaunchedEffect(
        navigationStarted,
        destination?.label,
        destination?.point?.latitude,
        destination?.point?.longitude,
        energyType
    ) {
        val activeDestination = destination
        if (navigationStarted && activeDestination != null) {
            saveStoredActiveTrip(context, activeDestination, energyType)
        }
    }

    // Une arrivée très proche et précise invalide la reprise persistée. Cette vérification
    // reste au niveau parent afin de ne pas modifier le gros NavigationScreen validé.
    LaunchedEffect(
        navigationStarted,
        currentLocation?.elapsedRealtimeNanos,
        destination?.point?.latitude,
        destination?.point?.longitude
    ) {
        val fix = currentLocation
        val activeDestination = destination
        if (navigationStarted && fix != null && activeDestination != null &&
            fix.hasAccuracy() && fix.accuracy <= 30f
        ) {
            val distance = distanceMetersBetween(
                GeoPoint(fix.latitude, fix.longitude),
                activeDestination.point
            )
            if (distance <= 20.0) clearStoredActiveTrip(context)
        }
    }

    // Reprise après destruction du processus : attendre un fix réel, puis recalculer
    // depuis ce point. Aucun ancien tracé n'est réutilisé.
    LaunchedEffect(
        storedTripResumePending,
        currentLocation?.elapsedRealtimeNanos,
        destination?.point?.latitude,
        destination?.point?.longitude
    ) {
        if (!storedTripResumePending || poiRouteLoading || navigationStarted) return@LaunchedEffect
        val fix = currentLocation ?: return@LaunchedEffect
        val activeDestination = destination ?: return@LaunchedEffect
        storedTripResumePending = false
        startAfterRouteCalculation = true
        calculateRoute(GeoPoint(fix.latitude, fix.longitude), activeDestination.point)
    }

    // V158 : une seule requête de recalcul peut être active à la fois.
    // poiRouteLoading est déjà l'état fiable du calcul réseau. Quand il repasse à false,
    // on traite au maximum la dernière demande reçue pendant le calcul précédent.
    LaunchedEffect(
        poiRouteLoading,
        pendingNavigationRerouteStart,
        navigationStarted,
        destination,
        navigationRerouteRetryNotBefore,
        currentLocation?.elapsedRealtimeNanos,
        currentLocation?.accuracy
    ) {
        val pendingStart = pendingNavigationRerouteStart
        val currentDestination = destination
        if (!poiRouteLoading && navigationStarted && pendingStart != null && currentDestination != null) {
            val waitMs = navigationRerouteRetryNotBefore - android.os.SystemClock.elapsedRealtime()
            if (waitMs > 0L) kotlinx.coroutines.delay(waitMs)

            // V159 : avant de retenter, vérifier la position la plus récente. Si le conducteur
            // a rejoint naturellement le tracé conservé, le recalcul devenu inutile est annulé.
            val latestLocation = currentLocation

            // V166 : ne jamais retenter un recalcul depuis une position ancienne ou
            // trop imprécise. La demande reste en attente et sera réévaluée dès qu'un
            // nouveau fix Android arrivera (elapsedRealtimeNanos fait partie des clés).
            val latestFixAgeMs = latestLocation?.elapsedRealtimeNanos
                ?.takeIf { it > 0L }
                ?.let { fixNanos ->
                    ((android.os.SystemClock.elapsedRealtimeNanos() - fixNanos) / 1_000_000L)
                        .coerceAtLeast(0L)
                } ?: Long.MAX_VALUE
            val latestAccuracy = latestLocation
                ?.takeIf { it.hasAccuracy() }
                ?.accuracy
                ?.toDouble()
                ?: Double.POSITIVE_INFINITY
            val latestFixUsable = latestFixAgeMs <= 8_000L && latestAccuracy <= 65.0

            if (!latestFixUsable) {
                // Conserver pendingNavigationRerouteStart : aucun appel réseau n'est fait
                // tant qu'une position réellement exploitable n'est pas revenue.
                return@LaunchedEffect
            }

            val activeRoute = routeOptions.getOrNull(selectedRouteIndex) ?: routeOptions.firstOrNull()
            val latestPoint = GeoPoint(latestLocation!!.latitude, latestLocation.longitude)
            val backOnRoute = activeRoute != null &&
                distanceFromPoiToRouteMeters(latestPoint, activeRoute.points) <=
                kotlin.math.max(70.0, (latestAccuracy * 2.0))

            if (backOnRoute) {
                pendingNavigationRerouteStart = null
                navigationRerouteRetryNotBefore = 0L
                navigationNetworkWarning = null
            } else if (!poiRouteLoading) {
                pendingNavigationRerouteStart = null
                calculateRoute(latestPoint ?: pendingStart, currentDestination.point, preserveExistingRoute = true)
            }
        }
    }

    if (navigationStarted && destination != null && routePoints.isNotEmpty()) {
        NavigationScreen(
            vehicle = vehicle,
            destination = destination!!,
            currentLocation = currentLocation,
            route = routeOptions[selectedRouteIndex],
            networkWarning = navigationNetworkWarning,
            routeCalculationInProgress = poiRouteLoading,
            isIntermediateChargeStep = navigatingToChargeStep,
            finalTripDestination = chargePlanFinalDestination,
            futureTripDistanceMeters = if (navigatingToChargeStep) {
                routeChargePlan.drop(1).sumOf { it.roadDistanceFromPreviousMeters } +
                    (routeChargeFinalLegMeters ?: 0.0)
            } else 0.0,
            onIntermediateChargeReached = {
                // V440 : la borne atteinte est une étape. On quitte le guidage du tronçon
                // et on demande le niveau de batterie avant d'enchaîner automatiquement.
                navigationStarted = false
                if (routeChargePlan.isNotEmpty()) {
                    rechargeBatteryStopIndex = 0
                    rechargeBatteryPercent = null
                }
            },
            onFinalArrivalReached = {
                // ETAPE 127 : l'arrivée validée par le même moteur que le guidage
                // efface immédiatement la session persistée. On conserve l'écran
                // d'arrivée 12 s avant la fermeture automatique du guidage.
                clearStoredActiveTrip(context)
                storedTripResumePending = false
                finalArrivalAutoFinishToken = android.os.SystemClock.elapsedRealtime().coerceAtLeast(1L)
            },
            onBack = {
                finalArrivalAutoFinishToken = 0L
                navigationStarted = false
                clearStoredActiveTrip(context)
            },
            onReroute = { newStart ->
                // V158 : ne jamais empiler plusieurs appels Valhalla. Pendant un calcul,
                // mémoriser uniquement la position GPS la plus récente.
                if (poiRouteLoading || android.os.SystemClock.elapsedRealtime() < navigationRerouteRetryNotBefore) {
                    pendingNavigationRerouteStart = newStart
                } else {
                    pendingNavigationRerouteStart = null
                    calculateRoute(newStart, destination!!.point, preserveExistingRoute = true)
                }
            }
        )
        return
    }

    selectedPoiCategory?.let { category ->
        val center = startPoint
        val categoryTitle = when (category) {
            "fuel" -> "⛽ Stations-service"
            "charge" -> "⚡ Bornes de recharge"
            else -> "🔧 Garages"
        }

        val sortedPois = if (center == null) {
            emptyList()
        } else {
            nearbyPois
                .filter { it.category == category }
                .filterNot { vspPoiKey(it) in inaccessiblePoiKeys }
                .map { originalPoi ->
                    // V96 : correction sur l'objet EXACT utilisé par la liste finale.
                    // On ne modifie que le libellé ; coordonnées, prix et routage restent inchangés.
                    val poi = if (category == "fuel") {
                        val a = originalPoi.address.lowercase(Locale.FRANCE)
                            .replace("é","e").replace("è","e").replace("ê","e")
                            .replace("à","a").replace("â","a").replace("î","i").replace("ï","i")
                            .replace("ô","o").replace("ù","u").replace("û","u").replace("ç","c")
                        val finalVerifiedName = when {
                            a.contains("francois beaucamp") && a.contains("grenay") -> "Esso Express Grenay"
                            a.contains("62114") && a.contains("sains") && a.contains("gohelle") && a.contains("francois") && a.contains("mitter") -> "TotalEnergies Sains-en-Gohelle"
                            a.contains("francois mitterrand") && a.contains("sains") && a.contains("gohelle") -> "TotalEnergies Sains-en-Gohelle"
                            a.contains("44 route d arras") && a.contains("lens") -> "TotalEnergies Access - Relais Césarine"
                            else -> null
                        }
                        if (finalVerifiedName != null) originalPoi.copy(name = finalVerifiedName) else originalPoi
                    } else originalPoi
                    val metric = if (category == "fuel") fuelRoadMetrics[vspPoiKey(originalPoi)] else null
                    poi to (metric?.first ?: distanceMetersBetween(center, originalPoi.point))
                }
                .let { pois ->
                    if (category == "fuel") {
                        if (fuelSortByPrice) {
                            // V112 : un prix bas ne suffit pas pour recommander une station.
                            // Le classement ne propose que les stations pour lesquelles le même
                            // trajet routier VSP a été calculé ET validé par les contrôles de sécurité.
                            // Cela évite qu'une station éloignée apparaisse seulement avec une
                            // distance à vol d'oiseau, sans durée ni itinéraire VSP exploitable.
                            pois
                                .filter { (poi, _) ->
                                    val key = vspPoiKey(poi)
                                    fuelRoadMetrics[key] != null && fuelValidatedRoutes[key] != null
                                }
                                .sortedWith(
                                    compareBy<Pair<VspPoi, Double>> {
                                        preferredFuelPriceEuros(it.first.fuelPrices, fuelType) ?: Double.MAX_VALUE
                                    }.thenBy { it.second }
                                )
                        } else if (routePoints.isNotEmpty()) {
                            // V63 : localités dans l'ordre réel du trajet, puis stations
                            // dans leur ordre d'apparition sur l'itinéraire.
                            val localityOrder = pois
                                .groupBy { fuelPoiLocality(it.first).lowercase(Locale.FRANCE) }
                                .mapValues { (_, values) ->
                                    values.minOf { routeProgressMetersForPoi(it.first.point, routePoints) }
                                }
                            pois.sortedWith(compareBy<Pair<VspPoi, Double>>(
                                { localityOrder[fuelPoiLocality(it.first).lowercase(Locale.FRANCE)] ?: Double.MAX_VALUE },
                                { routeProgressMetersForPoi(it.first.point, routePoints) },
                                { it.second }
                            ))
                        } else {
                            // V65 : sans trajet actif, la priorité est la proximité réelle.
                            // La commune reste affichée sous chaque station mais ne modifie plus l'ordre.
                            pois.sortedBy { it.second }
                        }
                    } else {
                        pois.sortedBy { it.second }
                    }
                }
        }

        AlertDialog(
            onDismissRequest = { selectedPoiCategory = null },
            title = { Text(categoryTitle) },
            text = {
                androidx.compose.foundation.lazy.LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 540.dp)
                        .padding(horizontal = 8.dp)
                ) {
                    if (category == "fuel") {
                        item {
                            Column(modifier = Modifier.padding(bottom = 8.dp)) {
                                Text(
                                    "Source : $fuelDataSource",
                                    color = if (fuelDataSource.startsWith("DGCCRF")) Color(0xFF65D68A) else Color(0xFFFFC857),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(bottom = 7.dp)
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    FilterChip(
                                        selected = fuelType == FuelType.DIESEL,
                                        onClick = { fuelType = FuelType.DIESEL },
                                        label = { Text("Diesel") }
                                    )
                                    FilterChip(
                                        selected = fuelType == FuelType.ESSENCE,
                                        onClick = { fuelType = FuelType.ESSENCE },
                                        label = { Text("Essence") }
                                    )
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    FilterChip(
                                        selected = !fuelSortByPrice,
                                        onClick = { fuelSortByPrice = false },
                                        label = { Text("Proximité") }
                                    )
                                    FilterChip(
                                        selected = fuelSortByPrice,
                                        onClick = { fuelSortByPrice = true },
                                        label = { Text("Prix ↑") }
                                    )
                                }
                                if (fuelSortByPrice) {
                                    Text(
                                        if (fuelType == FuelType.DIESEL)
                                            "Tri par prix du gazole • itinéraires VSP validés"
                                        else
                                            "Tri SP95 / E10 / SP98 • itinéraires VSP validés",
                                        color = Color(0xFF9AA7B8),
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                    items(sortedPois.size) { index ->
                        val (poi, distance) = sortedPois[index]
                        val baseDistanceText = if (distance < 1000.0) {
                            "${distance.toInt()} m"
                        } else {
                            String.format(java.util.Locale.FRANCE, "%.1f km", distance / 1000.0)
                        }
                        val fuelMetric = if (category == "fuel") fuelRoadMetrics[vspPoiKey(poi)] else null
                        val distanceText = if (fuelMetric != null && fuelMetric.second > 0.0) {
                            val minutes = vspDisplayMinutes(fuelMetric.second)
                            val roadKm = String.format(java.util.Locale.FRANCE, "%.1f km", fuelMetric.first / 1000.0)
                            "$roadKm • $minutes min"
                        } else baseDistanceText

                        if (category == "fuel" && routePoints.isNotEmpty()) {
                            val locality = fuelPoiLocality(poi)
                            val previousLocality = if (index > 0) fuelPoiLocality(sortedPois[index - 1].first) else null
                            if (index == 0 || !locality.equals(previousLocality, ignoreCase = true)) {
                                Text(
                                    locality,
                                    color = Color(0xFF65D68A),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.fillMaxWidth().padding(top = if (index == 0) 0.dp else 10.dp, bottom = 2.dp)
                                )
                            }
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedPoiCategory = null
                                    if (poi.category == "charge") {
                                        poiScope.launch {
                                            val enrichedPoi = enrichChargingPoiWithIrve(poi)
                                            selectedPoiForConfirm = enrichedPoi to distance
                                        }
                                    } else {
                                        selectedPoiForConfirm = poi to distance
                                    }
                                }
                                .padding(start = 14.dp, end = 8.dp, top = 7.dp, bottom = 7.dp)
                        ) {
                            Text(
                                poi.name,
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (poi.address.isNotBlank()) {
                                Text(
                                    poi.address,
                                    color = Color(0xFFB8C2D1),
                                    fontSize = 12.sp,
                                    maxLines = 3,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Text(
                                distanceText,
                                color = Color(0xFF58A9FF),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                            if (category == "fuel" && fuelSortByPrice && poi.fuelPrices.isNotBlank()) {
                                preferredFuelPriceLabel(poi.fuelPrices, fuelType)?.let { rankedPrice ->
                                    Text(
                                        "Prix classé : $rankedPrice",
                                        color = Color(0xFFFFC857),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1
                                    )
                                }
                            }
                            if (category == "fuel" && poi.fuelPrices.isNotBlank()) {
                                Text(
                                    poi.fuelPrices,
                                    color = Color(0xFF65D68A),
                                    fontSize = 10.sp,
                                    maxLines = 4,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (category == "fuel" && poi.fuelPriceUpdate.isNotBlank()) {
                                val priceUpdateLabel = formatFuelPriceUpdate(poi.fuelPriceUpdate)
                                if (priceUpdateLabel.isNotBlank()) {
                                    Text(
                                        "Mis à jour : $priceUpdateLabel",
                                        color = Color(0xFF9AA7B8),
                                        fontSize = 9.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            if (category == "charge" && chargingProfile.isNotEmpty() && chargingPoiMatchesProfile(poi, chargingProfile)) {
                                Text(
                                    "✓ Compatible avec votre VSP",
                                    color = Color(0xFF66D98B),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedPoiCategory = null }) {
                    Text("Fermer")
                }
            }
        )
    }

    selectedPoiForConfirm?.let { (poi, distance) ->
        val distanceText = if (distance < 1000.0) {
            "${distance.toInt()} m"
        } else {
            String.format(java.util.Locale.FRANCE, "%.1f km", distance / 1000.0)
        }
        val poiTitle = when (poi.category) {
            "fuel" -> "⛽ Station-service"
            "charge" -> "⚡ Borne de recharge"
            else -> "Destination"
        }
        // V108 : pour une station-service déjà contrôlée, la fiche réutilise exactement
        // la durée du trajet VSP validé qui alimente la liste. Aucun second calcul n'est
        // effectué ici : la valeur reste donc cohérente jusqu'au démarrage de la navigation.
        val validatedFuelRoute = if (poi.category == "fuel") {
            fuelValidatedRoutes[vspPoiKey(poi)]
        } else null
        val validatedFuelMinutes = validatedFuelRoute?.let {
            vspDisplayMinutes(it.durationSeconds)
        }?.takeIf { it > 0 }

        AlertDialog(
            onDismissRequest = { selectedPoiForConfirm = null },
            title = { Text(poiTitle) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        poi.name,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    if (poi.address.isNotBlank()) {
                        Text(
                            poi.address,
                            fontSize = 14.sp,
                            color = Color(0xFFB8C2D1)
                        )
                    }
                    // V109 : la fiche station reprend aussi les tarifs officiels déjà chargés
                    // dans la liste. Aucun prix n'est calculé ni inventé si la source n'en fournit pas.
                    if (poi.category == "fuel" && poi.fuelPrices.isNotBlank()) {
                        Text(
                            "Prix : ${poi.fuelPrices}",
                            fontSize = 13.sp,
                            color = Color(0xFF65D68A)
                        )
                    }
                    if (poi.category == "fuel" && poi.fuelPriceUpdate.isNotBlank()) {
                        val priceUpdateLabel = formatFuelPriceUpdate(poi.fuelPriceUpdate)
                        if (priceUpdateLabel.isNotBlank()) {
                            Text(
                                "Dernière mise à jour DGCCRF : $priceUpdateLabel",
                                fontSize = 11.sp,
                                color = Color(0xFF9AA7B8)
                            )
                        }
                    }
                    if (poi.category == "charge" && poi.chargingPower.isNotBlank()) {
                        Text(
                            "⚡ Puissance : ${poi.chargingPower}",
                            fontSize = 14.sp,
                            color = Color(0xFFE7EAF0)
                        )
                    }
                    if (poi.category == "charge" && poi.chargingConnectors.isNotBlank()) {
                        Text(
                            "🔌 Prises : ${poi.chargingConnectors}",
                            fontSize = 14.sp,
                            color = Color(0xFFE7EAF0)
                        )
                    }
                    if (poi.category == "charge" && chargingProfile.isNotEmpty()) {
                        val compatible = chargingPoiMatchesProfile(poi, chargingProfile)
                        Text(
                            if (compatible) "✓ Compatible avec votre VSP" else if (poi.chargingConnectors.isBlank()) "Compatibilité : inconnue" else "⚠ Prise VSP non détectée",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (compatible) Color(0xFF66D98B) else Color(0xFFFFC857)
                        )
                    }
                    Text(
                        if (validatedFuelMinutes != null) {
                            "Distance : $distanceText • Temps : ${validatedFuelMinutes} min"
                        } else {
                            "Distance : $distanceText"
                        },
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF58A9FF)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val center = startPoint
                        if (center == null) {
                            error = "Position GPS indisponible pour calculer l’itinéraire."
                            selectedPoiForConfirm = null
                        } else {
                            destination = Destination(
                                label = poi.name,
                                point = poi.point
                            )
                            routeOptions = emptyList()
                            selectedRouteIndex = 0
                            selectedPoiForConfirm = null
                            val cachedFuelRoute = if (poi.category == "fuel") fuelValidatedRoutes[vspPoiKey(poi)] else null
                            if (cachedFuelRoute != null) {
                                // V105 : aucun second calcul. Le guidage reprend exactement le tracé
                                // déjà contrôlé et utilisé pour les km/min affichés dans la liste.
                                routeOptions = listOf(cachedFuelRoute)
                                selectedRouteIndex = 0
                                error = null
                                poiRouteLoading = false
                            } else {
                                error = "Calcul de l’itinéraire VSP vers ${poi.name}…"
                                calculateRoute(center, poi.point)
                            }
                        }
                    }
                ) {
                    Text("Itinéraire")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedPoiForConfirm = null }) {
                    Text("Annuler")
                }
            }
        )
    }

    // V41 : contrôle avant de repartir d'une borne. La marge de sécurité de 20 %
    // est conservée : la batterie doit couvrir le prochain tronçon + la réserve.
    rechargeBatteryStopIndex?.let { stopIndex ->
        val nextMeters = if (stopIndex + 1 < routeChargePlan.size) {
            routeChargePlan[stopIndex + 1].roadDistanceFromPreviousMeters
        } else {
            routeChargeFinalLegMeters ?: 0.0
        }
        val nextKm = nextMeters / 1000.0
        val reserveKm = batteryMaxRangeKm * 0.20
        val requiredPercent = if (batteryMaxRangeKm > 0) {
            kotlin.math.ceil(((nextKm + reserveKm) / batteryMaxRangeKm) * 100.0).toInt().coerceIn(0, 100)
        } else 100
        var afterChargeText by remember(stopIndex) { mutableStateOf("") }
        val afterCharge = afterChargeText.toIntOrNull()?.coerceIn(0, 100)
        val availableKm = if (afterCharge != null && batteryMaxRangeKm > 0) batteryMaxRangeKm * afterCharge / 100.0 else 0.0
        val enough = afterCharge != null && afterCharge >= requiredPercent
        AlertDialog(
            onDismissRequest = { rechargeBatteryStopIndex = null },
            title = { Text("🔋 Batterie après recharge") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(String.format(Locale.FRANCE, "Prochaine étape : %.1f km par la route VSP.", nextKm))
                    Text("Pour conserver la réserve de sécurité, batterie minimale conseillée : $requiredPercent %.", color = Color(0xFFB8C2D1))
                    OutlinedTextField(
                        value = afterChargeText,
                        onValueChange = { afterChargeText = it.filter(Char::isDigit).take(3) },
                        label = { Text("Batterie après recharge (%)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (afterCharge != null) {
                        Text(
                            if (enough) String.format(Locale.FRANCE, "✓ Départ possible • autonomie estimée %.0f km", availableKm)
                            else String.format(Locale.FRANCE, "⚠ Recharge insuffisante • autonomie estimée %.0f km. Poursuivez la recharge.", availableKm),
                            color = if (enough) Color(0xFF65D68A) else Color(0xFFFFC857),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = enough,
                    onClick = {
                        batteryLevelPercent = afterCharge!!
                        saveBatteryProfile(historyContext, batteryMaxRangeKm, batteryLevelPercent)
                        rechargeBatteryPercent = afterCharge
                        // V48 : une recharge validée signifie que cette borne a été atteinte.
                        // On retire donc du plan toutes les étapes déjà parcourues au lieu de
                        // repartir du point GPS initial et de reproposer les anciennes bornes.
                        val remainingStops = routeChargePlan.drop(stopIndex + 1)
                        routeChargePlan = remainingStops
                        routeChargeSuggestion = remainingStops.firstOrNull()?.let { next ->
                            next.poi to next.roadDistanceFromPreviousMeters
                        }
                        routeChargeSearchMessage = if (remainingStops.isNotEmpty()) {
                            "✓ Étape précédente validée à ${afterCharge} %. Le trajet continue depuis cette borne vers la prochaine recharge."
                        } else {
                            "✓ Étape précédente validée à ${afterCharge} %. Le trajet continue depuis cette borne vers la destination finale."
                        }

                        // V440 : après validation de la recharge, enchaîner directement
                        // vers l'étape suivante, ou vers la vraie destination finale.
                        val nextDestination = if (remainingStops.isNotEmpty()) {
                            val nextStop = remainingStops.first()
                            navigatingToChargeStep = true
                            Destination(chargingPoiDisplayName(nextStop.poi), nextStop.poi.point)
                        } else {
                            navigatingToChargeStep = false
                            chargePlanFinalDestination
                        }
                        val restartPoint = currentLocation?.let { GeoPoint(it.latitude, it.longitude) }
                        if (nextDestination != null && restartPoint != null) {
                            destination = nextDestination
                            startAfterRouteCalculation = true
                            calculateRoute(restartPoint, nextDestination.point)
                        }
                        rechargeBatteryStopIndex = null
                    }
                ) { Text("Valider et poursuivre") }
            },
            dismissButton = { TextButton(onClick = { rechargeBatteryStopIndex = null }) { Text("Annuler") } }
        )
    }

    if (showBatteryProfileDialog) {
        var maxRangeText by remember(showBatteryProfileDialog) {
            mutableStateOf(if (batteryMaxRangeKm > 0) batteryMaxRangeKm.toString() else "")
        }
        var batteryText by remember(showBatteryProfileDialog) {
            mutableStateOf(batteryLevelPercent.toString())
        }
        val maxRangeDraft = maxRangeText.toIntOrNull()
        val batteryDraft = batteryText.toIntOrNull()
        val validBatteryProfile = maxRangeDraft != null && maxRangeDraft > 0 &&
            batteryDraft != null && batteryDraft in 0..100
        val estimatedDraft = if (validBatteryProfile) {
            ((maxRangeDraft!! * batteryDraft!!) / 100.0).toInt()
        } else null

        AlertDialog(
            onDismissRequest = { showBatteryProfileDialog = false },
            title = { Text("🔋 Autonomie de votre VSP") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "Indiquez l’autonomie maximale habituelle de votre VSP, puis le niveau actuel de la batterie.",
                        color = Color(0xFFB8C2D1),
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = maxRangeText,
                        onValueChange = { value -> maxRangeText = value.filter { it.isDigit() }.take(3) },
                        label = { Text("Autonomie maximale (km)") },
                        placeholder = { Text("Ex. 75") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = batteryText,
                        onValueChange = { value -> batteryText = value.filter { it.isDigit() }.take(3) },
                        label = { Text("Batterie actuelle (%)") },
                        placeholder = { Text("Ex. 60") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    estimatedDraft?.let { estimated ->
                        Text(
                            "🔋 Autonomie estimée : $estimated km",
                            color = Color(0xFF65D68A),
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        "Estimation indicative : le relief, la température, la vitesse et le chauffage peuvent réduire l’autonomie réelle.",
                        color = Color(0xFF9CB0C4),
                        fontSize = 11.sp
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = validBatteryProfile,
                    onClick = {
                        batteryMaxRangeKm = maxRangeDraft!!
                        batteryLevelPercent = batteryDraft!!
                        saveBatteryProfile(historyContext, batteryMaxRangeKm, batteryLevelPercent)
                        showBatteryProfileDialog = false
                    }
                ) { Text("Enregistrer") }
            },
            dismissButton = {
                TextButton(onClick = { showBatteryProfileDialog = false }) { Text("Annuler") }
            }
        )
    }

    if (showChargingProfileDialog) {
        var draft by remember(showChargingProfileDialog) { mutableStateOf(chargingProfile) }
        AlertDialog(
            onDismissRequest = { showChargingProfileDialog = false },
            title = { Text("🔌 Choix de la prise") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "Sélectionnez uniquement les prises réellement compatibles avec votre voiture. Le planificateur utilisera uniquement les bornes compatibles.",
                        color = Color(0xFFB8C2D1),
                        fontSize = 13.sp
                    )
                    CHARGING_CONNECTOR_CHOICES.forEach { connector ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .combinedClickable(onClick = {
                                    draft = if (connector in draft) draft - connector else draft + connector
                                }),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = connector in draft,
                                onCheckedChange = { checked ->
                                    draft = if (checked) draft + connector else draft - connector
                                }
                            )
                            Text(connector, color = Color.White)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = draft.isNotEmpty(),
                    onClick = {
                        chargingProfile = draft
                        saveChargingConnectors(historyContext, draft)
                        chargingProfileConfirmed = true
                        showChargingProfileDialog = false
                    }
                ) { Text("Enregistrer") }
            },
            dismissButton = {
                TextButton(onClick = { showChargingProfileDialog = false }) { Text("Annuler") }
            }
        )
    }

    manageFavoriteKey?.let { favoriteKey ->
        val currentValue = when (favoriteKey) {
            FAVORITE_HOME -> homeFavorite
            FAVORITE_WORK -> workFavorite
            else -> starFavorite
        }
        val favoriteName = when (favoriteKey) {
            FAVORITE_HOME -> "Maison"
            FAVORITE_WORK -> "Travail"
            else -> "Favori"
        }

        AlertDialog(
            onDismissRequest = { manageFavoriteKey = null },
            title = { Text("Gérer $favoriteName") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Adresse enregistrée",
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF58A9FF)
                    )
                    Text(
                        currentValue.ifBlank { "Aucune adresse enregistrée" },
                        fontSize = 16.sp
                    )
                    Text(
                        "Tu peux modifier cette adresse ou supprimer ce raccourci.",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    manageFavoriteKey = null
                    showFavoriteDialog = favoriteKey
                }) { Text("✏ Modifier") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        deleteFavorite(historyContext, favoriteKey)
                        when (favoriteKey) {
                            FAVORITE_HOME -> homeFavorite = ""
                            FAVORITE_WORK -> workFavorite = ""
                            else -> starFavorite = ""
                        }
                        manageFavoriteKey = null
                    }) { Text("🗑 Supprimer") }
                    TextButton(onClick = { manageFavoriteKey = null }) {
                        Text("Fermer")
                    }
                }
            }
        )
    }

    showFavoriteDialog?.let { favoriteKey ->
        val title = when (favoriteKey) {
            FAVORITE_HOME -> "Adresse Maison"
            FAVORITE_WORK -> "Adresse Travail"
            else -> "Adresse favorite"
        }
        var favoriteText by remember(favoriteKey) {
            mutableStateOf(
                when (favoriteKey) {
                    FAVORITE_HOME -> homeFavorite
                    FAVORITE_WORK -> workFavorite
                    else -> starFavorite
                }
            )
        }

        AlertDialog(
            onDismissRequest = { showFavoriteDialog = null },
            title = { Text(title) },
            text = {
                OutlinedTextField(
                    value = favoriteText,
                    onValueChange = { favoriteText = it },
                    label = { Text("Adresse, ville ou lieu") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(
                    enabled = favoriteText.isNotBlank(),
                    onClick = {
                        saveFavorite(historyContext, favoriteKey, favoriteText)
                        when (favoriteKey) {
                            FAVORITE_HOME -> homeFavorite = favoriteText.trim()
                            FAVORITE_WORK -> workFavorite = favoriteText.trim()
                            else -> starFavorite = favoriteText.trim()
                        }
                        showFavoriteDialog = null
                    }
                ) { Text("Enregistrer") }
            },
            dismissButton = {
                TextButton(onClick = { showFavoriteDialog = null }) {
                    Text("Annuler")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF07182E))
            .statusBarsPadding()
            // V444 : l’écran de recherche complet doit rester utilisable en paysage.
            // Sur les écrans peu hauts, le contenu peut désormais défiler verticalement
            // jusqu’aux réglages, à la carte et au bouton de démarrage.
            .verticalScroll(rememberScrollState())
            .padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 12.dp)
    ) {

        // V62 : icône Home en contour, sans emoji ni texte.
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.size(44.dp)
            ) {
                Canvas(modifier = Modifier.size(30.dp)) {
                    val stroke = Stroke(width = 2.6.dp.toPx())
                    val home = Path().apply {
                        moveTo(size.width * 0.10f, size.height * 0.47f)
                        lineTo(size.width * 0.50f, size.height * 0.12f)
                        lineTo(size.width * 0.90f, size.height * 0.47f)
                        moveTo(size.width * 0.20f, size.height * 0.39f)
                        lineTo(size.width * 0.20f, size.height * 0.88f)
                        lineTo(size.width * 0.80f, size.height * 0.88f)
                        lineTo(size.width * 0.80f, size.height * 0.39f)
                        moveTo(size.width * 0.40f, size.height * 0.88f)
                        lineTo(size.width * 0.40f, size.height * 0.60f)
                        lineTo(size.width * 0.60f, size.height * 0.60f)
                        lineTo(size.width * 0.60f, size.height * 0.88f)
                    }
                    drawPath(home, color = Color(0xFFEAF2FF), style = stroke)
                }
            }
        }

        OutlinedTextField(
            value = query,

            onValueChange = { newText ->
                if (newText != query) {
                    query = newText
                    // V458 : ne déverrouiller l'autocomplétion que sur une vraie modification
                    // utilisateur du libellé validé, jamais lors d'une recréation/rotation.
                    if (destination != null && newText.trim() != destination?.label?.trim()) {
                        // V461 : une vraie frappe utilisateur signifie « modifier la destination ».
                        // On retire alors l'objet sélectionné ; c'est la seule façon (avec X)
                        // de réautoriser les suggestions.
                        destination = null
                        destinationConfirmed = false
                        confirmedDestinationLabel = ""
                        RotationRetainedState.destination = null
                        RotationRetainedState.destinationConfirmed = false
                        RotationRetainedState.confirmedDestinationLabel = ""
                    }
                }
                error = null
            },

            modifier =
                Modifier
                    .fillMaxWidth()
                    .onFocusChanged { focusState ->
                        searchFieldActive = focusState.isFocused
                    },

            singleLine = true,

            label = {
                Text("Où allez-vous ?")
            },

            placeholder = {
                Text("Adresse, ville ou lieu")
            },

            leadingIcon = {
                Text("🔎")
            },

            trailingIcon = {
                if (searching) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.dp
                    )
                } else if (query.isNotBlank()) {
                    IconButton(
                        onClick = {
                            query = ""
                            destination = null
                            destinationConfirmed = false
                            confirmedDestinationLabel = ""
                            RotationRetainedState.query = ""
                            RotationRetainedState.destination = null
                            RotationRetainedState.destinationConfirmed = false
                            RotationRetainedState.confirmedDestinationLabel = ""
                            addressSuggestions = emptyList()
                            error = null
                        }
                    ) {
                        Text(
                            text = "✕",
                            fontSize = 22.sp,
                            color = Color(0xFF58A6FF)
                        )
                    }
                }
            },

            keyboardOptions =
                KeyboardOptions(
                    imeAction = androidx.compose.ui.text.input.ImeAction.Search
                ),

            keyboardActions =
                KeyboardActions(
                    onSearch = {
                        searchAddress()
                    }
                )
        )

        if (searchFieldActive && query.isBlank() && searchHistory.isNotEmpty()) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF102A46))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 230.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 12.dp, end = 4.dp, top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Destinations récentes",
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold
                        )
                        TextButton(onClick = {
                            clearSearchHistory(historyContext)
                            searchHistory = emptyList()
                        }) {
                            Text("Effacer")
                        }
                    }

                    searchHistory.forEach { recent ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(
                                onClick = {
                                    query = recent
                                    searchFieldActive = false
                                    keyboardController?.hide()
                                    focusManager.clearFocus(force = true)
                                    searchAddress()
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    "🕘  $recent",
                                    modifier = Modifier.fillMaxWidth(),
                                    color = Color(0xFFD7E7FF),
                                    fontSize = 15.sp
                                )
                            }
                            TextButton(
                                onClick = {
                                    val updated = searchHistory.filterNot { it == recent }
                                    searchHistory = updated
                                    historyContext
                                        .getSharedPreferences(
                                            SEARCH_HISTORY_PREFS,
                                            android.content.Context.MODE_PRIVATE
                                        )
                                        .edit()
                                        .putString(SEARCH_HISTORY_KEY, updated.joinToString(SEARCH_HISTORY_SEPARATOR))
                                        .apply()
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp)
                            ) {
                                Text("✕", color = Color(0xFF58A6FF), fontSize = 18.sp)
                            }
                        }
                    }
                }
            }
        }

        if (destination == null && RotationRetainedState.destination == null &&
            !destinationConfirmed && !RotationRetainedState.destinationConfirmed &&
            suggestionsLoading && query.trim().length >= 2) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }

        if (destination == null && RotationRetainedState.destination == null &&
            !destinationConfirmed && !RotationRetainedState.destinationConfirmed &&
            addressSuggestions.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF102A46))
            ) {
                // ETAPE 114 : la liste de POI peut contenir jusqu'à 12 résultats. Elle
                // défile désormais dans son propre panneau au lieu de descendre derrière
                // le clavier sur les petits écrans.
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 390.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    addressSuggestions.forEach { suggestion ->
                        TextButton(
                            onClick = {
                                val preservedSuggestion = suggestion.copy(
                                    label = destinationLabelPreservingPoiName(query, suggestion.label)
                                )
                                suggestionSelectionInProgress = true
                                query = preservedSuggestion.label
                                addressSuggestions = emptyList()
                                destination = preservedSuggestion
                                destinationConfirmed = true
                                confirmedDestinationLabel = preservedSuggestion.label
                                // V457 : écrire immédiatement avant tout calcul réseau ; SideEffect peut arriver
                                // trop tard si Android recrée l’Activity juste après le clic.
                                RotationRetainedState.query = preservedSuggestion.label
                                RotationRetainedState.destination = preservedSuggestion
                                RotationRetainedState.destinationConfirmed = true
                                RotationRetainedState.confirmedDestinationLabel = preservedSuggestion.label
                                saveSearchHistory(historyContext, preservedSuggestion.label)
                                searchHistory = loadSearchHistory(historyContext)
                                keyboardController?.hide()
                                focusManager.clearFocus(force = true)
                                currentLocation?.let { location ->
                                    calculateRoute(
                                        GeoPoint(location.latitude, location.longitude),
                                        preservedSuggestion.point
                                    )
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val suggestionLabel = suggestion.label.trim()
                            val postcodeMatch = Regex("\\b\\d{5}\\b").find(suggestionLabel)
                            val mainAddress: String
                            val localityLine: String

                            if (postcodeMatch != null) {
                                val splitIndex = postcodeMatch.range.first
                                mainAddress = suggestionLabel
                                    .substring(0, splitIndex)
                                    .trim().trimEnd(',', '-', ' ')
                                    .ifBlank { suggestionLabel }
                                localityLine = suggestionLabel
                                    .substring(splitIndex)
                                    .trim().trimStart(',', '-', ' ')
                            } else {
                                val parts = suggestionLabel.split(",", limit = 2)
                                mainAddress = parts.firstOrNull()?.trim().orEmpty()
                                    .ifBlank { suggestionLabel }
                                localityLine = parts.getOrNull(1)?.trim().orEmpty()
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "📍",
                                    fontSize = 20.sp,
                                    modifier = Modifier.padding(end = 10.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        mainAddress,
                                        color = Color.White,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (localityLine.isNotBlank()) {
                                        Text(
                                            localityLine,
                                            color = Color(0xFFB8C7D9),
                                            fontSize = 13.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                suggestion.distanceMeters?.let { meters ->
                                    val distanceLabel = if (meters < 1000.0) {
                                        "${meters.roundToInt()} m"
                                    } else {
                                        String.format(Locale.FRANCE, "%.1f km", meters / 1000.0)
                                    }
                                    Text(
                                        distanceLabel,
                                        color = Color(0xFF58A6FF),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(start = 8.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(
            Modifier.height(8.dp)
        )

        
        Text(
            "Raccourcis",
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(top = 8.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(
                Triple("🏠 Maison", FAVORITE_HOME, homeFavorite),
                Triple("💼 Travail", FAVORITE_WORK, workFavorite),
                Triple("⭐ Favori", FAVORITE_STAR, starFavorite)
            ).forEach { (label, key, value) ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .border(
                            1.dp,
                            Color(0xFF9AA7B8),
                            RoundedCornerShape(24.dp)
                        )
                        .combinedClickable(
                            onClick = {
                                if (value.isBlank()) {
                                    showFavoriteDialog = key
                                } else {
                                    query = value
                                    searchAddress()
                                }
                            },
                            onLongClick = {
                                if (value.isBlank()) {
                                    showFavoriteDialog = key
                                } else {
                                    manageFavoriteKey = key
                                }
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        label,
                        color = Color(0xFF58A9FF),
                        fontSize = 12.sp,
                        maxLines = 1,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Text(
            "Appui simple : lancer • appui long : modifier ou supprimer.",
            color = Color.Gray,
            fontSize = 11.sp,
            modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
        )

        if (startPoint != null) {
            Text(
                "À proximité",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 6.dp)
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val nearbyCategories = if (energyType == EnergyType.ELECTRIC) {
                    emptyList()
                } else {
                    listOf("⛽ Stations" to "fuel")
                }
                nearbyCategories.forEach { (label, category) ->
                    OutlinedButton(
                        onClick = {
                            val centerForPois = startPoint
                            if (centerForPois != null) {
                                poiScope.launch {
                                    // Un seul appui : attendre le préchargement déjà lancé,
                                    // puis ouvrir automatiquement la liste demandée.
                                    if (poisLoading) {
                                        error = "Recherche des points à proximité…"
                                        while (poisLoading) {
                                            kotlinx.coroutines.delay(100L)
                                        }
                                    }

                                    // V67 : le carburant vient d'abord du flux officiel national.
                                    // Cela récupère aussi les stations de supermarchés absentes/incomplètes dans OSM.
                                    if (category == "fuel") {
                                        error = "Chargement des stations et prix officiels…"
                                        // V71 : la liste officielle est la source carburant principale et n'est
                                        // jamais fusionnée/remplacée par les stations OSM. On retente le flux
                                        // officiel afin qu'une erreur réseau ponctuelle ne fasse pas disparaître
                                        // Angres/Aix-Noulette. OSM n'est conservé qu'en secours si les 3 essais échouent.
                                        val now = System.currentTimeMillis()
                                        val cachedOfficialFuel = nearbyPois.filter { it.category == "fuel" && it.fuelPrices.isNotBlank() }
                                        val officialCacheFresh = cachedOfficialFuel.isNotEmpty() &&
                                            now - fuelOfficialLoadedAt < 10L * 60L * 1000L
                                        var officialFuel: List<VspPoi> = if (officialCacheFresh) cachedOfficialFuel else emptyList()
                                        if (!officialCacheFresh) {
                                            repeat(3) { attempt ->
                                                if (officialFuel.isEmpty()) {
                                                    officialFuel = kotlinx.coroutines.withTimeoutOrNull(16000L) {
                                                        loadOfficialFuelStations(centerForPois)
                                                    }.orEmpty()
                                                    if (officialFuel.isEmpty() && attempt < 2) kotlinx.coroutines.delay(450L)
                                                }
                                            }
                                        }
                                        if (officialFuel.isNotEmpty()) {
                                            val osmSnapshot = nearbyPois
                                            val nonFuel = osmSnapshot.filter { it.category != "fuel" }
                                            // V75 : OSM n'est qu'un enrichissement de nom/enseigne.
                                            // Aucune station officielle ne peut être supprimée si elle n'a pas de correspondance OSM.
                                            val enrichedOfficialFuel = enrichOfficialFuelBrands(officialFuel, osmSnapshot)
                                            nearbyPois = nonFuel + enrichedOfficialFuel
                                            fuelDataSource = "DGCCRF officielle + enseignes"
                                            if (!officialCacheFresh) fuelOfficialLoadedAt = now
                                        } else {
                                            fuelDataSource = "OSM secours"
                                        }
                                        // Si le service officiel est momentanément indisponible, nearbyPois garde
                                        // simplement les stations OSM préchargées : le bouton Stations reste utilisable.
                                        error = null
                                    }

                                    // V63 carburant : si un itinéraire existe, enrichir la liste
                                    // avec les stations situées le long du trajet. Aucun choix ou
                                    // recalcul supplémentaire n'est demandé au conducteur.
                                    if (false && category == "fuel" && routePoints.isNotEmpty()) {
                                        error = "Recherche des stations sur l’itinéraire…"
                                        val routeDistance = (routeOptions.getOrNull(selectedRouteIndex) ?: routeOptions.firstOrNull())?.distanceMeters
                                            ?: 0.0
                                        val alongRoute = kotlinx.coroutines.withTimeoutOrNull(18000L) {
                                            loadFuelPoisAlongRoute(routePoints, routeDistance)
                                        }.orEmpty()
                                        nearbyPois = (nearbyPois + alongRoute)
                                            .distinctBy { vspPoiKey(it) }
                                        error = null
                                    }

                                    // Si le préchargement n'a rien retourné, faire une tentative
                                    // directe sans demander un deuxième appui.
                                    if (nearbyPois.isEmpty()) {
                                        poisLoading = true
                                        error = "Recherche des points à proximité…"
                                        nearbyPois = kotlinx.coroutines.withTimeoutOrNull(12000L) {
                                            loadNearbyVspPois(centerForPois)
                                        } ?: emptyList()
                                        poisLoading = false
                                    }

                                    if (nearbyPois.any {
                                            it.category == category &&
                                                vspPoiKey(it) !in inaccessiblePoiKeys
                                        }) {
                                        if (category == "fuel") {
                                            // V114 : ouvrir immédiatement la fenêtre. Les métriques VSP arrivent
                                            // progressivement au lieu de bloquer l'utilisateur pendant 24 calculs séquentiels.
                                            selectedPoiCategory = category
                                            error = null
                                            val candidates = nearbyPois
                                                .filter { it.category == "fuel" && vspPoiKey(it) !in inaccessiblePoiKeys }
                                                .sortedBy { distanceMetersBetween(centerForPois, it.point) }
                                                .take(24)
                                            // Si la position a beaucoup changé, les anciennes distances ne sont plus valables.
                                            // Le cache de route reste utile tant que le départ est pratiquement identique.
                                            val pending = candidates.filter { poi ->
                                                val key = vspPoiKey(poi)
                                                fuelRoadMetrics[key] == null || fuelValidatedRoutes[key] == null
                                            }
                                            // Petits lots parallèles : nettement plus rapide sans marteler le serveur public Valhalla.
                                            pending.chunked(4).forEach { batch ->
                                                coroutineScope {
                                                    val results = batch.map { poi ->
                                                        async {
                                                            poi to kotlinx.coroutines.withTimeoutOrNull(7000L) {
                                                                calculateIndependentVspRouteCheck(centerForPois, poi.point)
                                                            }
                                                        }
                                                    }.awaitAll()
                                                    results.forEach { result ->
                                                        val poi = result.first
                                                        val check = result.second
                                                        val key = vspPoiKey(poi)
                                                        if (check != null && !check.forbiddenRoadDetected) {
                                                            fuelRoadMetrics = fuelRoadMetrics + (key to (check.distanceMeters to check.durationSeconds))
                                                            check.route?.let { route ->
                                                                fuelValidatedRoutes = fuelValidatedRoutes + (key to route)
                                                            }
                                                        } else if (check?.forbiddenRoadDetected == true) {
                                                            inaccessiblePoiKeys = inaccessiblePoiKeys + key
                                                        }
                                                    }
                                                }
                                            }
                                        } else {
                                            selectedPoiCategory = category
                                        }
                                        error = null
                                    } else {
                                        error = "Aucun point accessible en VSP trouvé à proximité pour cette catégorie."
                                    }
                                }
                            }
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 3.dp, vertical = 7.dp)
                    ) {
                        Text(label, fontSize = 11.sp, maxLines = 1)
                    }
                }
            }
            if (energyType == EnergyType.ELECTRIC) {
                // V441 : les trois commandes électriques tiennent sur une seule ligne
                // afin de libérer de la hauteur sur l'écran d'accueil.
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = {
                            // ETAPE 114 : un appui « Bornes de recharge » ne doit plus
                            // ouvrir une liste vide parce que le préchargement a échoué.
                            // On réutilise le cache s'il contient des bornes, sinon on fait
                            // une tentative locale immédiate avant d'ouvrir la liste.
                            val centerForCharge114 = startPoint
                            if (centerForCharge114 == null) {
                                error = "Position GPS nécessaire pour rechercher les bornes proches."
                            } else {
                                poiScope.launch {
                                    if (poisLoading) {
                                        error = "Recherche des bornes de recharge…"
                                        while (poisLoading) kotlinx.coroutines.delay(100L)
                                    }
                                    if (nearbyPois.none { it.category == "charge" }) {
                                        poisLoading = true
                                        error = "Recherche des bornes de recharge…"
                                        val refreshed114 = kotlinx.coroutines.withTimeoutOrNull(14000L) {
                                            loadNearbyVspPois(centerForCharge114)
                                        }.orEmpty()
                                        if (refreshed114.isNotEmpty()) {
                                            nearbyPois = (nearbyPois + refreshed114).distinctBy { vspPoiKey(it) }
                                        }
                                        poisLoading = false
                                    }
                                    if (nearbyPois.any { it.category == "charge" }) {
                                        selectedPoiCategory = "charge"
                                        error = null
                                    } else {
                                        error = "Aucune borne de recharge trouvée à proximité."
                                    }
                                }
                            }
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 5.dp)
                    ) {
                        Text("⚡ Bornes de recharge", fontSize = 10.sp, maxLines = 2)
                    }
                    TextButton(
                        onClick = { showChargingProfileDialog = true },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 5.dp)
                    ) {
                        Text("🔌 Choix de la prise", color = Color(0xFF58A9FF), fontSize = 10.sp, maxLines = 2)
                    }
                    TextButton(
                        onClick = { showBatteryProfileDialog = true },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 5.dp)
                    ) {
                        Text("🔋 Autonomie", color = Color(0xFF65D68A), fontSize = 10.sp, maxLines = 2)
                    }
                }
            } else {
                Text(
                    "⛽ VSP carburant • stations-service",
                    color = Color(0xFF65D68A),
                    fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 4.dp)
                )
            }

        }


Button(
            onClick = {
                searchAddress()
            },

            enabled =
                query.isNotBlank() &&
                !searching,

            modifier =
                Modifier.fillMaxWidth()
        ) {

            Text(
                "Rechercher l'adresse"
            )
        }

        error?.let {

            Text(
                text = it,
                color = Color(0xFFFFC857),
                modifier =
                    Modifier.padding(
                        vertical = 6.dp
                    )
            )
        }

        destination?.let {

            Text(
                text =
                    "Destination : ${it.label}",

                color =
                    Color(0xFF65D68A),

                modifier =
                    Modifier.padding(
                        vertical = 6.dp
                    )
            )
        }

        // V451 : sélection de route robuste après rotation/tablette. Si l'index retenu
        // n'existe plus après recréation de l'Activity, on reprend la première route au lieu
        // de masquer entièrement le bloc autonomie/recharge.
        // Vérification d'autonomie purement visuelle : elle est calculée uniquement
        // à partir d'un itinéraire déjà obtenu. Elle ne déclenche ni recherche,
        // ni recalcul, ni appel réseau.
        if (energyType == EnergyType.ELECTRIC) {
        (routeOptions.getOrNull(selectedRouteIndex) ?: routeOptions.firstOrNull())?.let { selectedRoute ->
            // V457 : ne plus masquer silencieusement tout le bloc si le profil batterie
            // n’est pas chargé. L’utilisateur voit alors immédiatement ce qu’il manque.
            if (batteryMaxRangeKm <= 0) {
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("⚠️ Autonomie à configurer", color = Color(0xFFFFC857), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Le trajet est calculé, mais aucune autonomie maximale n’est enregistrée. Configurez l’autonomie pour vérifier automatiquement les recharges.", color = Color.White, fontSize = 12.sp)
                        Button(onClick = { showBatteryProfileDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("🔋 Configurer l’autonomie") }
                    }
                }
            } else {
                val estimatedRangeKm = (batteryMaxRangeKm * batteryLevelPercent) / 100.0
                val routeKm = selectedRoute.distanceMeters / 1000.0
                val safetyReserveKm = batteryMaxRangeKm * 0.20
                // V42 : la réserve correspond à 20 % de la capacité complète, pas à 20 % du niveau actuel.
                // Exemple 75 km / 60 % => 45 km estimés - 15 km de réserve = 30 km réellement planifiables.
                val safeUsableKm = (estimatedRangeKm - safetyReserveKm).coerceAtLeast(0.0)
                val needsRecharge = routeKm > safeUsableKm

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(
                            text = if (needsRecharge) "⚠️ Recharge à prévoir" else "✓ Autonomie suffisante",
                            color = if (needsRecharge) Color(0xFFFFC857) else Color(0xFF65D68A),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = String.format(
                                Locale.FRANCE,
                                "Trajet : %.1f km • autonomie estimée : %.0f km",
                                routeKm, estimatedRangeKm
                            ),
                            color = Color.White,
                            fontSize = 12.sp
                        )
                        Text(
                            text = String.format(
                                Locale.FRANCE,
                                "Réserve de sécurité : %.0f km (20 %%) • utilisable : %.0f km",
                                safetyReserveKm, safeUsableKm
                            ),
                            color = Color(0xFF9CB0C4),
                            fontSize = 11.sp
                        )


                        if (needsRecharge) {
                            Spacer(modifier = Modifier.height(4.dp))
                            val planRecharges: (Int?) -> Unit = planRecharges@ { batteryPercentOverride ->
                                    if (!routeChargeSearchLoading) {
                                        if (!chargingProfileConfirmed || chargingProfile.isEmpty()) {
                                            routeChargeSearchMessage = "Choisissez d’abord au moins une prise réellement compatible avec votre VSP."
                                            showChargingProfileDialog = true
                                            return@planRecharges
                                        }
                                        routeChargeSearchLoading = true
                                        routeChargeSuggestion = null
                                        routeChargePlan = emptyList()
                                        routeChargeFinalLegMeters = null
                                        routeChargeSearchMessage = "Planification des recharges compatibles…"
                                        // V452 : scope de session non lié au cycle de vie de l'Activity.
                                        // Le calcul continue donc réellement pendant une rotation.
                                        RotationRetainedState.rechargePlanningScope.launch {
                                            try {
                                                val routeStart = startPoint
                                                if (routeStart == null) {
                                                    routeChargeSearchMessage = "Position de départ indisponible."
                                                } else {
                                                    val planningBatteryPercent = batteryPercentOverride ?: batteryLevelPercent
                                                    val planningEstimatedKm = batteryMaxRangeKm * planningBatteryPercent / 100.0
                                                    val initialSafeMeters = (planningEstimatedKm - safetyReserveKm).coerceAtLeast(0.0) * 1000.0
                                                    val fullSafeMeters = batteryMaxRangeKm * 0.80 * 1000.0
                                                    // V42 : le premier tronçon utilise la batterie réellement présente au départ.
                                                    // Après une recharge, le planificateur retrouve la limite sûre à 80 % de l’autonomie maximale.
                                                    val safeMeters = fullSafeMeters
                                                    val planned = mutableListOf<PlannedChargeStop>()
                                                    var previousPoint: GeoPoint = routeStart!!
                                                    var currentProgressMeters = 0.0
                                                    var failed = false
                                                    var destinationReached = false
                                                    // ETAPE 66 : diagnostic précis du PREMIER maillon de recharge.
                                                    // Il ne modifie aucune règle de sécurité : il compte seulement pourquoi
                                                    // les candidates du premier tronçon sont éliminées.
                                                    val firstLegRejects = java.util.Collections.synchronizedMap(mutableMapOf<String, Int>())
                                                    var firstLegTested = 0
                                                    fun firstLegReject(reason: String) {
                                                        synchronized(firstLegRejects) {
                                                            firstLegRejects[reason] = (firstLegRejects[reason] ?: 0) + 1
                                                        }
                                                    }

                                                    // V12 : le planificateur partage d'abord EXACTEMENT la liste déjà
                                                    // chargée par le bouton « Recharge ». Ainsi une borne connue de l'écran
                                                    // principal ne peut plus disparaître du planificateur.
                                                    val allCandidates = linkedMapOf<String, VspPoi>()
                                                    var startChargingCount = 0
                                                    var corridorChargingAdded = 0
                                                    nearbyPois.asSequence()
                                                        .filter { it.category == "charge" }
                                                        .filter { distanceFromPoiToRouteMeters(it.point, selectedRoute.points) <= 14000.0 }
                                                        .forEach { poi -> allCandidates[vspPoiKey(poi)] = poi }

                                                    // V13 : on ne suppose plus que la liste « Recharge » est déjà chargée.
                                                    // Le planificateur force d'abord le MÊME chargement local autour du départ
                                                    // et attend son résultat avant de chercher plus loin sur le trajet.
                                                    // V18 : planification rapide. On ne lance plus une recherche lourde
                                                    // autour du départ puis une recherche globale puis une recherche progressive.
                                                    // On interroge en parallèle plusieurs points utiles du trajet, avec un budget
                                                    // total court. Les bornes déjà visibles à l’écran restent prioritaires.
                                                    routeChargeSearchMessage = "Recherche rapide des bornes sur le trajet…"
                                                    val sampleDistances = linkedSetOf<Double>()
                                                    sampleDistances += 0.0
                                                    // V441 : sur les longs trajets, limiter les recherches locales génériques.
                                                    // Les zones calculées selon l'autonomie restent ajoutées juste après,
                                                    // donc on conserve les points réellement utiles tout en réduisant les appels réseau.
                                                    val localSampleStep = if (selectedRoute.distanceMeters >= 120000.0) 50000.0 else 35000.0
                                                    var sampleD = localSampleStep
                                                    while (sampleD < selectedRoute.distanceMeters) {
                                                        sampleDistances += sampleD
                                                        sampleD += localSampleStep
                                                    }
                                                    sampleDistances += selectedRoute.distanceMeters

                                                    // V20 : la source IRVE est réellement appelée ici (V19 contenait
                                                    // la fonction IRVE mais le planificateur continuait à n'appeler que
                                                    // la recherche locale). On lance IRVE + recherche locale en parallèle.
                                                    // V456 : budgets indépendants. Une source lente ne supprime jamais
                                                    // les résultats déjà obtenus par l'autre source.
                                                    val sourceResults = kotlinx.coroutines.coroutineScope {
                                                            // V30 : recherche IRVE par zones successives le long du trajet.
                                                            // Une requête englobant tout Aix-Noulette -> Reims pouvait atteindre
                                                            // la limite API de 100 résultats avant d'inclure les bornes utiles
                                                            // autour de 45-55 km. On interroge désormais de petites portions
                                                            // centrées tous les ~50 km, puis on fusionne les résultats.
                                                            val zoneCenters = linkedSetOf<Double>()
                                                            // V43 : quand le départ se fait avec une batterie partielle,
                                                            // ajouter une zone IRVE dédiée AVANT la limite du premier tronçon.
                                                            // Exemple 75 km / 60 % : 30 km sûrs -> recherche prioritaire vers 20-24 km.
                                                            if (initialSafeMeters > 0.0 && initialSafeMeters < fullSafeMeters) {
                                                                zoneCenters += (initialSafeMeters * 0.72).coerceAtMost(selectedRoute.distanceMeters)
                                                            }
                                                            var zoneD = safeMeters * (50.0 / 60.0)
                                                            while (zoneD < selectedRoute.distanceMeters) {
                                                                zoneCenters += zoneD
                                                                zoneD += safeMeters * (50.0 / 60.0)
                                                            }
                                                            zoneCenters += selectedRoute.distanceMeters

                                                            val irveDeferred = async {
                                                                kotlinx.coroutines.withTimeoutOrNull(16000L) {
                                                                zoneCenters.map { centerD ->
                                                                    async {
                                                                        val a = (centerD - 12000.0).coerceAtLeast(0.0)
                                                                        val b = centerD
                                                                        val c = (centerD + 12000.0).coerceAtMost(selectedRoute.distanceMeters)
                                                                        val miniRoute = listOfNotNull(
                                                                            routePointAtDistance(selectedRoute.points, a),
                                                                            routePointAtDistance(selectedRoute.points, b),
                                                                            routePointAtDistance(selectedRoute.points, c)
                                                                        ).distinctBy { pt ->
                                                                            String.format(java.util.Locale.US, "%.5f,%.5f", pt.latitude, pt.longitude)
                                                                        }
                                                                        if (miniRoute.size >= 2) {
                                                                            loadChargingPoisForRouteCorridor(
                                                                                context,
                                                                                miniRoute,
                                                                                (c - a).coerceAtLeast(1000.0),
                                                                                connectorProfile = chargingProfile.toSet()
                                                                            )
                                                                        } else emptyList()
                                                                    }
                                                                }.awaitAll().flatten().distinctBy { vspPoiKey(it) }
                                                                } ?: emptyList()
                                                            }
                                                            val localDeferred = async {
                                                                kotlinx.coroutines.withTimeoutOrNull(16000L) {
                                                                // OSM est également ciblé sur les mêmes zones utiles, avec quelques
                                                                // points intermédiaires pour conserver un filet de sécurité.
                                                                val targetedSamples = (sampleDistances + zoneCenters).toSortedSet()
                                                                targetedSamples.mapNotNull { sd ->
                                                                    routePointAtDistance(selectedRoute.points, sd)
                                                                }.map { center ->
                                                                    async { loadLocalChargingPoisForRoute(center) }
                                                                }.awaitAll().flatten()
                                                                } ?: emptyList()
                                                            }
                                                            irveDeferred.await() to localDeferred.await()
                                                    }
                                                    val irvePois = sourceResults.first
                                                    val fastPois = sourceResults.second
                                                    if (irvePois.isEmpty() && fastPois.isEmpty()) {
                                                        lastIrveDiagnostic = "$lastIrveDiagnostic • $lastOsmChargingDiagnostic"
                                                    }

                                                    val beforeFastMerge = allCandidates.size
                                                    (irvePois + fastPois).asSequence()
                                                        .filter { distanceFromPoiToRouteMeters(it.point, selectedRoute.points) <= 14000.0 }
                                                        .forEach { poi -> allCandidates[vspPoiKey(poi)] = poi }
                                                    corridorChargingAdded = (allCandidates.size - beforeFastMerge).coerceAtLeast(0)
                                                    startChargingCount = allCandidates.values.count {
                                                        distanceMetersBetween(routeStart, it.point) <= 14000.0
                                                    }
                                                    // V34 : interface utilisateur simplifiée. Les diagnostics IRVE restent
                                                    // disponibles dans les variables internes, mais ne ralentissent pas la lecture.
                                                    routeChargeSearchMessage = if (allCandidates.isEmpty()) {
                                                        "Recherche terminée sans borne exploitable. $lastIrveDiagnostic • $lastOsmChargingDiagnostic • IRVE=${irvePois.size} • OSM=${fastPois.size}."
                                                    } else {
                                                        "Recherche des bornes compatibles VSP…"
                                                    }

                                                    data class ChargePathState(
                                                        val point: GeoPoint,
                                                        val progressMeters: Double,
                                                        val stops: List<PlannedChargeStop>
                                                    )

                                                    var frontier = listOf(ChargePathState(routeStart, 0.0, emptyList()))
                                                    val roadDistanceCache = java.util.Collections.synchronizedMap(mutableMapOf<String, Double?>())
                                                    // V33 : mémorise aussi le contrôle de sortie des bornes afin de ne pas
                                                    // multiplier les appels Valhalla pendant le beam-search.
                                                    val chargerExitSafetyCache = java.util.Collections.synchronizedMap(mutableMapOf<String, Boolean>())

                                                    // ETAPE 70 : mémorise la meilleure chaîne complète rencontrée.
                                                    // Si une première solution contient un tronçon > 55 km après recharge,
                                                    // on poursuit le beam-search afin d'autoriser un arrêt supplémentaire
                                                    // susceptible de ramener tous les tronçons dans la zone préférée <= 55 km.
                                                    var bestCompletedState: ChargePathState? = null
                                                    var bestCompletedWorstRatio = Double.POSITIVE_INFINITY

                                                    for (depth in 1..8) {
                                                        // V31 : ne plus considérer la destination atteignable uniquement
                                                        // grâce à la progression sur le tracé principal. Depuis chaque état du
                                                        // beam-search, on valide aussi la DERNIÈRE étape par une vraie distance
                                                        // routière VSP jusqu'à la destination. Cela sécurise Recharge 2/3 -> arrivée.
                                                        // V449 : les chemins susceptibles d'atteindre directement la destination
                                                        // sont validés en parallèle. En V448, jusqu'à 10 états du beam-search
                                                        // pouvaient attendre Valhalla l'un après l'autre (1,5 s chacun), ce qui
                                                        // expliquait une grande partie des 27 s observées au premier calcul.
                                                        // ETAPE 69 : parmi les chaînes qui atteignent réellement la destination,
                                                        // ne plus prendre automatiquement celle qui a le plus progressé sur le tracé.
                                                        // On choisit d'abord celle dont le tronçon le plus tendu utilise la plus petite
                                                        // fraction de l'autonomie sûre. Une chaîne à 50-55 km doit donc battre une chaîne
                                                        // à 59,6 km lorsqu'une alternative complète existe. La limite absolue reste inchangée.
                                                        val completed: ChargePathState? = kotlinx.coroutines.coroutineScope {
                                                            frontier.map { state ->
                                                                async(kotlinx.coroutines.Dispatchers.IO) {
                                                                    val stateSafeMeters = if (state.stops.isEmpty()) initialSafeMeters else fullSafeMeters
                                                                    val remainingOnMainRoute = selectedRoute.distanceMeters - state.progressMeters
                                                                    if (remainingOnMainRoute > stateSafeMeters) return@async null
                                                                    val cacheKeyToDestination = String.format(
                                                                        java.util.Locale.US,
                                                                        "%.5f,%.5f>%.5f,%.5f",
                                                                        state.point.latitude, state.point.longitude,
                                                                        destination!!.point.latitude, destination!!.point.longitude
                                                                    )
                                                                    val roadToDestination = if (roadDistanceCache.containsKey(cacheKeyToDestination)) {
                                                                        roadDistanceCache[cacheKeyToDestination]
                                                                    } else {
                                                                        val d = kotlinx.coroutines.withTimeoutOrNull(2500L) {
                                                                            calculateIndependentLocalVspRouteCheck(
                                                                                localValhallaRouter, state.point, destination!!.point
                                                                            )?.takeUnless { it.forbiddenRoadDetected }?.distanceMeters
                                                                        }
                                                                        roadDistanceCache[cacheKeyToDestination] = d
                                                                        d
                                                                    }
                                                                    if (roadToDestination != null && roadToDestination <= stateSafeMeters) {
                                                                        val stopRatios = state.stops.mapIndexed { index, stop ->
                                                                            val limit = if (index == 0) initialSafeMeters else fullSafeMeters
                                                                            stop.roadDistanceFromPreviousMeters / limit
                                                                        }
                                                                        val finalRatio = roadToDestination / stateSafeMeters
                                                                        val worstRatio = (stopRatios + finalRatio).maxOrNull() ?: finalRatio
                                                                        // ETAPE 71 : à sécurité équivalente, départager les chaînes
                                                                        // par la distance routière totale réellement validée. Cela évite
                                                                        // de choisir une succession de détours simplement parce que le
                                                                        // dernier tronçon est légèrement plus court.
                                                                        val totalRoadMeters = state.stops.sumOf { it.roadDistanceFromPreviousMeters } + roadToDestination
                                                                        Triple(state, worstRatio, totalRoadMeters)
                                                                    } else null
                                                                }
                                                            }.awaitAll().filterNotNull()
                                                                .minWithOrNull(
                                                                    compareBy<Triple<ChargePathState, Double, Double>> { it.second }
                                                                        .thenBy { it.first.stops.size }
                                                                        .thenBy { it.third }
                                                                )?.first
                                                        }
                                                        if (completed != null) {
                                                            val completedRoadToDestination = calculateIndependentLocalVspRouteCheck(
                                                                localValhallaRouter, completed.point, destination!!.point
                                                            )?.takeUnless { it.forbiddenRoadDetected }?.distanceMeters
                                                            val completedSafeMeters = if (completed.stops.isEmpty()) initialSafeMeters else fullSafeMeters
                                                            val completedStopRatios = completed.stops.mapIndexed { index, stop ->
                                                                val limit = if (index == 0) initialSafeMeters else fullSafeMeters
                                                                stop.roadDistanceFromPreviousMeters / limit
                                                            }
                                                            val completedFinalRatio = (completedRoadToDestination ?: completedSafeMeters) / completedSafeMeters
                                                            val completedWorstRatio = (completedStopRatios + completedFinalRatio).maxOrNull() ?: completedFinalRatio

                                                            if (completedWorstRatio < bestCompletedWorstRatio ||
                                                                (kotlin.math.abs(completedWorstRatio - bestCompletedWorstRatio) < 0.0001 &&
                                                                    (bestCompletedState == null || completed.stops.size < bestCompletedState!!.stops.size))) {
                                                                bestCompletedState = completed
                                                                bestCompletedWorstRatio = completedWorstRatio
                                                            }

                                                            // Zone préférée : après recharge, aucun tronçon ne dépasse 55/60
                                                            // de l'autonomie sûre. Dès qu'une telle chaîne existe, inutile
                                                            // d'ajouter encore des arrêts. Sinon on continue pour chercher
                                                            // une chaîne à 4 (ou plus) recharges plus robuste.
                                                            if (completedWorstRatio <= (55.0 / 60.0)) {
                                                                planned.clear()
                                                                planned.addAll(completed.stops)
                                                                currentProgressMeters = completed.progressMeters
                                                                previousPoint = completed.point
                                                                destinationReached = true
                                                                break
                                                            }
                                                        }

                                                        val nextStates = mutableListOf<ChargePathState>()
                                                        // V22 : recharge de confort avant la limite de sécurité.
                                                        // Cible normale : 80 % de l'autonomie sûre (48 km pour 60 km utilisables).
                                                        // On privilégie les bornes atteignables avant 85 % (51 km). La zone
                                                        // 51-60 km n'est utilisée qu'en secours si aucune borne plus sûre n'existe.
                                                        // ETAPE 65 : le beam-search doit réellement explorer plusieurs chaînes.
                                                        // Jusqu'ici `take(1)` ne développait que le meilleur état courant : une
                                                        // borne sûre menant à une impasse pouvait donc condamner toute la recherche,
                                                        // même si les 2e/3e choix permettaient d’atteindre Reims. On développe les
                                                        // 4 meilleurs états ; la largeur finale reste bornée à 10 plus bas.
                                                        for (state in frontier.take(4)) {
                                                            val stateSafeMeters = if (state.stops.isEmpty()) initialSafeMeters else fullSafeMeters
                                                            val targetProgress = kotlin.math.min(
                                                                selectedRoute.distanceMeters,
                                                                state.progressMeters + stateSafeMeters * 0.80
                                                            )
                                                            val rankedCandidates = allCandidates.values.asSequence()
                                                                .filterNot { vspPoiKey(it) in inaccessiblePoiKeys }
                                                                .map { poi ->
                                                                    val progress = routeProgressMetersNearest(poi.point, selectedRoute.points)
                                                                    val offRoute = distanceFromPoiToRouteMeters(poi.point, selectedRoute.points)
                                                                    Triple(poi, progress, offRoute)
                                                                }
                                                                .filter { (_, progress, offRoute) ->
                                                                    val minAdvance = if (state.stops.isEmpty() && stateSafeMeters < fullSafeMeters) 1500.0 else 5000.0
                                                                    progress > state.progressMeters + minAdvance &&
                                                                    progress - state.progressMeters <= stateSafeMeters &&
                                                                    offRoute <= 22000.0
                                                                }
                                                                .filter { (poi, _, _) ->
                                                                    state.stops.none { distanceMetersBetween(it.poi.point, poi.point) < 250.0 }
                                                                }
                                                                .sortedBy { (_, progress, offRoute) ->
                                                                    kotlin.math.abs(progress - targetProgress) + offRoute * 3.0
                                                                }
                                                                .toList()

                                                            // V25 : ne plus éliminer AVANT Valhalla les bornes situées entre
                                                            // 51 et 60 km de progression. En V24, l'existence d'une borne
                                                            // géométriquement "normale" suffisait à supprimer les bornes plus
                                                            // lointaines, même si cette borne normale n'était qu'à 17,7 km par
                                                            // la route VSP. On laisse donc Valhalla mesurer un éventail plus large,
                                                            // puis le beam-search choisit la distance ROUTIÈRE la plus proche de 48 km.
                                                            // V28 : présélection équilibrée le long du tracé VSP.
                                                            // On évite à la fois les 40 calculs routiers de V26 (trop lents)
                                                            // et la sélection trop étroite de V27 qui pouvait rater les bonnes bornes.
                                                            // V39 : recherche élargie autour des maillons critiques.
                                                            // On accepte jusqu’à 22 km du corridor pour ne pas rater une borne
                                                            // légèrement décalée qui évite une étape dangereusement proche de 60 km.
                                                            // 8 candidates proches de la cible + 3 avant + 3 après = 14 max.
                                                            // La sécurité V33 reste inchangée : chaque candidate retenue est
                                                            // toujours vérifiée à l'arrivée ET à la sortie par Valhalla.
                                                            // V43 : au premier tronçon à batterie partielle, tester davantage de bornes :
                                                            // une petite autonomie laisse moins de choix et une présélection trop courte
                                                            // pouvait manquer la seule borne réellement accessible par route VSP.
                                                            val firstPartialLeg = state.stops.isEmpty() && stateSafeMeters < fullSafeMeters
                                                            val targetWindow = rankedCandidates.take(if (firstPartialLeg) 16 else 8)
                                                            val beforeTarget = rankedCandidates
                                                                .filter { (_, progress, _) -> progress <= targetProgress }
                                                                .sortedByDescending { (_, progress, _) -> progress }
                                                                .take(3)
                                                            val afterTarget = rankedCandidates
                                                                .filter { (_, progress, _) -> progress > targetProgress }
                                                                .sortedBy { (_, progress, _) -> progress }
                                                                .take(3)
                                                            val candidates = (targetWindow + beforeTarget + afterTarget)
                                                                .distinctBy { (poi, _, _) ->
                                                                    String.format(java.util.Locale.US, "%.5f,%.5f", poi.point.latitude, poi.point.longitude)
                                                                }
                                                                .take(if (firstPartialLeg) 24 else 14)

                                                            // V450 : conserve le parallélisme rapide de V449 mais restaure la largeur et les délais
                                                            // de validation fiables de V445 : 24 candidates au premier tronçon partiel,
                                                            // puis 14, avec 2,2 s pour les contrôles Valhalla. Les appels restant parallèles,
                                                            // le temps n’est plus additionné borne par borne.
                                                            // V39 : au maximum quatorze candidates par étape atteignent les contrôles
                                                            // réseau coûteux. Les caches ci-dessous évitent tout recalcul identique.
                                                            // V28 : on collecte toutes les options réellement mesurées de cette
                                                            // présélection, puis le classement final reste basé sur la distance
                                                            // ROUTIÈRE VSP réelle et non sur la seule géométrie.
                                                            // Une étape <= 55 km est considérée comme sûre/préférée.
                                                            // La zone 55-60 km ne doit servir qu'en dernier recours, et ne doit
                                                            // jamais gagner simplement parce qu'elle permet un arrêt de moins.
                                                            val measuredStates = mutableListOf<ChargePathState>()

                                                            // V448 : les validations réseau de candidates indépendantes sont lancées
                                                            // en parallèle. Avant V448, chaque borne attendait successivement
                                                            // l’aller Valhalla puis le contrôle de sortie, ce qui cumulait les délais.
                                                            // Les mêmes contrôles de sécurité sont conservés ; seul leur ordonnancement change.
                                                            val parallelMeasured = kotlinx.coroutines.coroutineScope {
                                                                candidates.map { (candidate, progress, _) ->
                                                                    async(kotlinx.coroutines.Dispatchers.IO) {
                                                                        val diagnosticFirstLeg = state.stops.isEmpty()
                                                                        if (diagnosticFirstLeg) synchronized(firstLegRejects) { firstLegTested += 1 }
                                                                        if (chargingPoiLooksExplicitlyMotorwayOnly(candidate)) {
                                                                            if (diagnosticFirstLeg) firstLegReject("aire autoroute")
                                                                            return@async null
                                                                        }
                                                                        if (distanceMetersBetween(state.point, candidate.point) > stateSafeMeters * 1.02) {
                                                                            if (diagnosticFirstLeg) firstLegReject("distance directe")
                                                                            return@async null
                                                                        }

                                                                        val enriched = if (chargingProfile.isNotEmpty() && candidate.chargingConnectors.isBlank()) {
                                                                            kotlinx.coroutines.withTimeoutOrNull(1200L) {
                                                                                enrichChargingPoiWithIrve(candidate)
                                                                            } ?: candidate
                                                                        } else candidate

                                                                        if (chargingProfile.isNotEmpty() &&
                                                                            (enriched.chargingConnectors.isBlank() ||
                                                                                !chargingPoiMatchesProfile(enriched, chargingProfile))) {
                                                                            if (diagnosticFirstLeg) firstLegReject("prise incompatible")
                                                                            return@async null
                                                                        }

                                                                        val cacheKey = String.format(
                                                                            java.util.Locale.US,
                                                                            "%.5f,%.5f>%.5f,%.5f",
                                                                            state.point.latitude, state.point.longitude,
                                                                            enriched.point.latitude, enriched.point.longitude
                                                                        )
                                                                        val roadDistance = if (roadDistanceCache.containsKey(cacheKey)) {
                                                                            roadDistanceCache[cacheKey]
                                                                        } else {
                                                                            val check = kotlinx.coroutines.withTimeoutOrNull(2200L) {
                                                                                calculateIndependentLocalVspRouteCheck(localValhallaRouter, state.point, enriched.point)
                                                                            }
                                                                            if (diagnosticFirstLeg) {
                                                                                when {
                                                                                    check == null -> firstLegReject("Valhalla LOCAL aller")
                                                                                    check.forbiddenRoadDetected -> firstLegReject("motorway aller")
                                                                                }
                                                                            }
                                                                            val d = check?.takeUnless { it.forbiddenRoadDetected }?.distanceMeters
                                                                            roadDistanceCache[cacheKey] = d
                                                                            d
                                                                        } ?: return@async null

                                                                        val exitTargetProgress = kotlin.math.min(
                                                                            selectedRoute.distanceMeters,
                                                                            progress + 5000.0
                                                                        )
                                                                        val exitTarget = routePointAtDistance(selectedRoute.points, exitTargetProgress)
                                                                            ?: destination!!.point
                                                                        val exitKey = String.format(
                                                                            java.util.Locale.US,
                                                                            "%.5f,%.5f>%.5f,%.5f",
                                                                            enriched.point.latitude, enriched.point.longitude,
                                                                            exitTarget.latitude, exitTarget.longitude
                                                                        )
                                                                        val exitSafe = chargerExitSafetyCache[exitKey] ?: run {
                                                                            val check = kotlinx.coroutines.withTimeoutOrNull(2200L) {
                                                                                calculateIndependentLocalVspRouteCheck(localValhallaRouter, enriched.point, exitTarget)
                                                                            }
                                                                            if (diagnosticFirstLeg) {
                                                                                when {
                                                                                    check == null -> firstLegReject("Valhalla LOCAL sortie")
                                                                                    check.forbiddenRoadDetected -> firstLegReject("motorway sortie")
                                                                                }
                                                                            }
                                                                            val safe = check != null && !check.forbiddenRoadDetected
                                                                            chargerExitSafetyCache[exitKey] = safe
                                                                            safe
                                                                        }
                                                                        if (!exitSafe) return@async null
                                                                        if (roadDistance > stateSafeMeters) {
                                                                            if (diagnosticFirstLeg) firstLegReject("distance routière > autonomie")
                                                                            return@async null
                                                                        }
                                                                        if (diagnosticFirstLeg) firstLegReject("VALIDÉE")

                                                                        val stop = PlannedChargeStop(enriched, roadDistance, progress / 1000.0)
                                                                        ChargePathState(enriched.point, progress, state.stops + stop)
                                                                    }
                                                                }.awaitAll().filterNotNull()
                                                            }
                                                            measuredStates += parallelMeasured

                                                            // V30 : sélection après recherche zonée. Ne plus accepter une borne beaucoup trop tôt simplement
                                                            // parce qu'elle est sûre. Pour 60 km utilisables, la fenêtre
                                                            // prioritaire est 45-55 km ROUTIERS depuis l'étape précédente.
                                                            // On élargit seulement si aucune borne de cette fenêtre n'est viable.
                                                            val comfortMaxMeters = stateSafeMeters * (55.0 / 60.0)
                                                            val preferredMinMeters = stateSafeMeters * (45.0 / 60.0)
                                                            val secondaryMinMeters = stateSafeMeters * (35.0 / 60.0)
                                                            val preferred = measuredStates.filter {
                                                                val d = it.stops.lastOrNull()?.roadDistanceFromPreviousMeters ?: Double.MAX_VALUE
                                                                d in preferredMinMeters..comfortMaxMeters
                                                            }
                                                            val secondary = measuredStates.filter {
                                                                val d = it.stops.lastOrNull()?.roadDistanceFromPreviousMeters ?: Double.MAX_VALUE
                                                                d in secondaryMinMeters..comfortMaxMeters
                                                            }
                                                            val comfortable = measuredStates.filter {
                                                                (it.stops.lastOrNull()?.roadDistanceFromPreviousMeters ?: Double.MAX_VALUE) <= comfortMaxMeters
                                                            }
                                                            // V38 : ne plus supprimer les options 55-60 km dès qu'une borne
                                                            // plus confortable existe localement. Une borne à 45-55 km peut mener
                                                            // à une impasse plus loin, alors qu'une borne proche de la limite peut
                                                            // être la seule à permettre une chaîne complète. On conserve donc les
                                                            // meilleures options confortables ET quelques solutions de secours ;
                                                            // le score du beam-search pénalise fortement ces dernières, qui ne
                                                            // gagneront que si elles sont nécessaires pour atteindre la destination.
                                                            val preferredPool = when {
                                                                preferred.isNotEmpty() -> preferred
                                                                secondary.isNotEmpty() -> secondary
                                                                comfortable.isNotEmpty() -> comfortable
                                                                else -> emptyList()
                                                            }
                                                            val fallbackNearLimit = measuredStates
                                                                .filter {
                                                                    val d = it.stops.lastOrNull()?.roadDistanceFromPreviousMeters ?: Double.MAX_VALUE
                                                                    d > comfortMaxMeters && d <= stateSafeMeters
                                                                }
                                                                .sortedBy {
                                                                    it.stops.lastOrNull()?.roadDistanceFromPreviousMeters ?: Double.MAX_VALUE
                                                                }
                                                                .take(4)
                                                            nextStates += (preferredPool + fallbackNearLimit)
                                                                .distinctBy {
                                                                    val p = it.stops.lastOrNull()?.poi?.point
                                                                    if (p != null) String.format(java.util.Locale.US, "%.5f,%.5f", p.latitude, p.longitude)
                                                                    else it.progressMeters.toString()
                                                                }
                                                        }

                                                        if (nextStates.isEmpty()) {
                                                            failed = true
                                                            break
                                                        }

                                                        // Beam search : conserve plusieurs chemins distincts au lieu d'un seul.
                                                        frontier = nextStates
                                                            .sortedWith(compareBy<ChargePathState> {
                                                                // V25 : choix final selon la distance routière VSP réelle.
                                                                // Cible 48 km ; 60 km reste la limite absolue de sécurité.
                                                                // V42 FIX : la limite dépend du tronçon évalué.
                                                                // Pour la première borne, on utilise la batterie réelle au départ ;
                                                                // après une recharge, on retrouve la limite à pleine charge.
                                                                val pathSafeMeters = if (it.stops.size <= 1) initialSafeMeters else fullSafeMeters
                                                                val d = it.stops.lastOrNull()?.roadDistanceFromPreviousMeters ?: pathSafeMeters
                                                                val comfortMax = pathSafeMeters * (55.0 / 60.0)
                                                                val preferredMin = pathSafeMeters * (45.0 / 60.0)
                                                                // Cible 50 km au centre de la fenêtre 45-55.
                                                                // Une borne trop proche reçoit une pénalité forte afin qu'un arrêt
                                                                // prématuré ne puisse pas battre une borne réellement utile.
                                                                val currentLegScore = kotlin.math.abs(d - pathSafeMeters * (50.0 / 60.0)) +
                                                                    (if (d < preferredMin) (preferredMin - d) * 4.0 else 0.0) +
                                                                    (if (d > comfortMax) pathSafeMeters * 2.0 else 0.0)
                                                                // ETAPE 69 : le score tient aussi compte du pire tronçon déjà présent
                                                                // dans toute la chaîne, pas uniquement du dernier arrêt ajouté.
                                                                val worstUsedRatio = it.stops.mapIndexed { index, stop ->
                                                                    val limit = if (index == 0) initialSafeMeters else fullSafeMeters
                                                                    stop.roadDistanceFromPreviousMeters / limit
                                                                }.maxOrNull() ?: 0.0
                                                                currentLegScore + if (worstUsedRatio > (55.0 / 60.0)) {
                                                                    pathSafeMeters * (worstUsedRatio - (55.0 / 60.0)) * 8.0
                                                                } else 0.0
                                                            }.thenByDescending { it.progressMeters })
                                                            .distinctBy { (it.progressMeters / 2500.0).toInt() }
                                                            // V45 : largeur 10 pour conserver davantage de chaînes confortables
                                                            // lorsqu’un maillon 55-60 km apparaît dans la chaîne.
                                                            .take(10)
                                                    }

                                                    // ETAPE 70 : si aucune chaîne <=55 km n'a été trouvée, on conserve
                                                    // tout de même la meilleure chaîne complète <=60 km rencontrée.
                                                    if (!destinationReached && bestCompletedState != null) {
                                                        planned.clear()
                                                        planned.addAll(bestCompletedState!!.stops)
                                                        currentProgressMeters = bestCompletedState!!.progressMeters
                                                        previousPoint = bestCompletedState!!.point
                                                        destinationReached = true
                                                    }

                                                    if (!destinationReached && !failed) {
                                                        // V31 : même contrôle routier pour le meilleur chemin restant.
                                                        val best = frontier.maxByOrNull { it.progressMeters }
                                                        if (best != null) {
                                                            val bestSafeMeters = if (best.stops.isEmpty()) initialSafeMeters else fullSafeMeters
                                                            val remainingOnMainRoute = selectedRoute.distanceMeters - best.progressMeters
                                                            if (remainingOnMainRoute <= bestSafeMeters) {
                                                                val cacheKeyToDestination = String.format(
                                                                    java.util.Locale.US,
                                                                    "%.5f,%.5f>%.5f,%.5f",
                                                                    best.point.latitude, best.point.longitude,
                                                                    destination!!.point.latitude, destination!!.point.longitude
                                                                )
                                                                val roadToDestination = if (roadDistanceCache.containsKey(cacheKeyToDestination)) {
                                                                    roadDistanceCache[cacheKeyToDestination]
                                                                } else {
                                                                    val d = kotlinx.coroutines.withTimeoutOrNull(2500L) {
                                                                        calculateIndependentLocalVspRouteCheck(
                                                                            localValhallaRouter, best.point, destination!!.point
                                                                        )?.takeUnless { it.forbiddenRoadDetected }?.distanceMeters
                                                                    }
                                                                    roadDistanceCache[cacheKeyToDestination] = d
                                                                    d
                                                                }
                                                                // V40 : même exigence ici : dernière recharge -> destination doit être
                                                                // réellement routée par Valhalla et rester sous la limite sûre.
                                                                if (roadToDestination != null && roadToDestination <= bestSafeMeters) {
                                                                    planned.clear()
                                                                    planned.addAll(best.stops)
                                                                    currentProgressMeters = best.progressMeters
                                                                    previousPoint = best.point
                                                                    destinationReached = true
                                                                }
                                                            }
                                                        }
                                                    }

                                                    if (!failed && destinationReached && planned.isNotEmpty()) {
                                                        val lastChargePoint = planned.last().poi.point
                                                        val finalKey = String.format(
                                                            java.util.Locale.US,
                                                            "%.5f,%.5f>%.5f,%.5f",
                                                            lastChargePoint.latitude, lastChargePoint.longitude,
                                                            destination!!.point.latitude, destination!!.point.longitude
                                                        )
                                                        val finalLeg = roadDistanceCache[finalKey] ?: kotlinx.coroutines.withTimeoutOrNull(2500L) {
                                                            calculateIndependentLocalVspRouteCheck(
                                                                localValhallaRouter, lastChargePoint, destination!!.point
                                                            )?.takeUnless { it.forbiddenRoadDetected }?.distanceMeters
                                                        }
                                                        // V40 : par sécurité, ne publie jamais un plan « complet » si le dernier
                                                        // tronçon n'a pas une distance routière VSP Valhalla explicite.
                                                        if (finalLeg != null && finalLeg <= fullSafeMeters) {
                                                            routeChargePlan = planned
                                                            routeChargeFinalLegMeters = finalLeg
                                                            routeChargeSuggestion = planned.first().poi to planned.first().roadDistanceFromPreviousMeters
                                                            routeChargeSearchMessage = "${planned.size} arrêt${if (planned.size > 1) "s" else ""} de recharge prévu${if (planned.size > 1) "s" else ""}. Tous les tronçons, y compris la dernière recharge jusqu’à la destination, sont validés par la route VSP."
                                                        } else {
                                                            routeChargePlan = emptyList()
                                                            routeChargeFinalLegMeters = null
                                                            routeChargeSuggestion = null
                                                            routeChargeSearchMessage = "Le dernier tronçon jusqu’à la destination n’a pas pu être validé en sécurité par la route VSP."
                                                        }
                                                    } else {
                                                        val connectorLabel = chargingProfile.joinToString(" / ")
                                                        // ETAPE 60 : diagnostic utilisateur uniquement. Aucune règle de
                                                        // navigation, de sécurité, de sélection des bornes ou de routage n'est modifiée.
                                                        val receivedCount = irvePois.size + fastPois.size
                                                        val corridorCount = allCandidates.size
                                                        val compatibleCandidates = allCandidates.values.filter { poi ->
                                                            chargingProfile.isNotEmpty() && poi.chargingConnectors.isNotBlank() &&
                                                                chargingPoiMatchesProfile(poi, chargingProfile)
                                                        }
                                                        val compatibleCount = compatibleCandidates.size
                                                        val unknownConnectorCount = allCandidates.values.count { it.chargingConnectors.isBlank() }
                                                        val reachableFirstLegCount = compatibleCandidates.count { poi ->
                                                            val progress = routeProgressMetersNearest(poi.point, selectedRoute.points)
                                                            progress > 0.0 && progress <= initialSafeMeters &&
                                                                distanceFromPoiToRouteMeters(poi.point, selectedRoute.points) <= 22000.0
                                                        }
                                                        val furthestCompatibleKm = compatibleCandidates.maxOfOrNull { poi ->
                                                            routeProgressMetersNearest(poi.point, selectedRoute.points) / 1000.0
                                                        }
                                                        val diagnosticSummary = buildString {
                                                            append("Diagnostic : reçues=").append(receivedCount)
                                                            append(" (IRVE=").append(irvePois.size).append(", OSM=").append(fastPois.size).append(")")
                                                            append(" • corridor=").append(corridorCount)
                                                            append(" • compatibles=").append(compatibleCount)
                                                            append(" • prise inconnue=").append(unknownConnectorCount)
                                                            append(" • atteignables au 1er tronçon=").append(reachableFirstLegCount)
                                                            if (furthestCompatibleKm != null) {
                                                                append(" • dernière compatible≈")
                                                                append(String.format(java.util.Locale.FRANCE, "%.1f", furthestCompatibleKm))
                                                                append(" km")
                                                            }
                                                            append(" • limite départ=")
                                                            append(String.format(java.util.Locale.FRANCE, "%.1f", initialSafeMeters / 1000.0))
                                                            append(" km • limite après recharge=")
                                                            append(String.format(java.util.Locale.FRANCE, "%.1f", fullSafeMeters / 1000.0))
                                                            append(" km.")
                                                        }
                                                        routeChargeSearchMessage = if (compatibleCandidates.isEmpty()) {
                                                            "Aucune borne compatible $connectorLabel n’a été trouvée sur ce trajet. $diagnosticSummary " +
                                                                "Sources : $lastIrveDiagnostic • $lastOsmChargingDiagnostic"
                                                        } else {
                                                            "Aucun trajet complet et sûr n’a pu être validé avec $connectorLabel et l’autonomie disponible. " +
                                                                run {
                                                                val bestProgressKm = frontier.maxOfOrNull { it.progressMeters }?.div(1000.0)
                                                                val bestStops = frontier.maxByOrNull { it.progressMeters }?.stops?.size ?: 0
                                                                val chainDiagnostic = if (bestProgressKm != null) {
                                                                    " • meilleure chaîne validée : $bestStops recharge${if (bestStops > 1) "s" else ""}, progression≈" +
                                                                        String.format(java.util.Locale.FRANCE, "%.1f", bestProgressKm) + " km."
                                                                } else " • aucune première chaîne routière complète n’a survécu aux contrôles."
                                                                val firstLegDiagnostic = if (firstLegTested > 0) {
                                                                    val ordered = listOf("VALIDÉE", "Valhalla LOCAL aller", "motorway aller", "distance routière > autonomie", "Valhalla LOCAL sortie", "motorway sortie", "aire autoroute", "distance directe", "prise incompatible")
                                                                    val details = ordered.mapNotNull { key -> firstLegRejects[key]?.takeIf { it > 0 }?.let { "$key=$it" } }.joinToString(", ")
                                                                    " • diagnostic 1er maillon : testées=$firstLegTested${if (details.isNotBlank()) ", $details" else ""}."
                                                                } else " • diagnostic 1er maillon : aucune candidate présélectionnée."
                                                                "$diagnosticSummary$chainDiagnostic$firstLegDiagnostic Une ou plusieurs bornes existent, mais aucune chaîne complète n’a passé tous les contrôles routiers VSP."
                                                            }
                                                        }
                                                    }
                                                }
                                            } catch (_: Exception) {
                                                routeChargeSearchMessage = "Planification des recharges indisponible pour le moment."
                                            } finally {
                                                routeChargeSearchLoading = false
                                            }
                                        }
                                    }
                            }
                            Button(
                                onClick = { planRecharges(null) },
                                enabled = !routeChargeSearchLoading,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (routeChargeSearchLoading) "Planification…" else if (!chargingProfileConfirmed || chargingProfile.isEmpty()) "⚙️ Configurer mes prises" else "⚡ Planifier les recharges")
                            }

                            routeChargeSearchMessage?.let { message ->
                                Text(
                                    text = message,
                                    color = Color(0xFF9CB0C4),
                                    fontSize = 11.sp
                                )
                            }

                            if (routeChargePlan.isNotEmpty()) {
                                // V437 : l’action principale reste toujours visible au-dessus de la liste
                                // des étapes. Elle ne peut donc plus disparaître dans le défilement interne.
                                val firstChargeStop = routeChargePlan.first()
                                Button(
                                    onClick = {
                                        val center = startPoint
                                        val finalDestination = destination
                                        if (center == null || finalDestination == null) {
                                            error = "Position GPS ou destination indisponible."
                                        } else {
                                            // V440 : un seul appui sur Démarrer lance le premier tronçon.
                                            // La borne devient une étape, jamais la destination finale du voyage.
                                            chargePlanFinalDestination = finalDestination
                                            navigatingToChargeStep = true
                                            destination = Destination(
                                                label = chargingPoiDisplayName(firstChargeStop.poi),
                                                point = firstChargeStop.poi.point
                                            )
                                            startAfterRouteCalculation = true
                                            calculateRoute(center, firstChargeStop.poi.point)
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("▶ Démarrer")
                                }

                                // V32: la liste des recharges peut dépasser la hauteur d'un écran mobile.
                                // Elle possède donc son propre défilement vertical sans modifier la carte GPS.
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(max = 430.dp)
                                        .verticalScroll(rememberScrollState()),
                                    verticalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    routeChargePlan.forEachIndexed { index, stop ->
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = CardDefaults.cardColors(containerColor = Color(0xFF12385A))
                                        ) {
                                            Column(modifier = Modifier.padding(10.dp)) {
                                                Text(
                                                    if (index == 0) "⚡ Prochaine recharge • ${chargingPoiDisplayName(stop.poi)}"
                                                    else "⚡ Recharge suivante ${index + 1} • ${chargingPoiDisplayName(stop.poi)}",
                                                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp
                                                )
                                                if (stop.poi.address.isNotBlank()) {
                                                    Text(stop.poi.address, color = Color(0xFFB9C9D8), fontSize = 10.sp)
                                                }
                                                if (stop.poi.chargingConnectors.isNotBlank()) {
                                                    Text("🔌 ${normalizeChargingConnectors(stop.poi.chargingConnectors)}", color = Color(0xFF65D68A), fontSize = 10.sp)
                                                }
                                                val legKm = stop.roadDistanceFromPreviousMeters / 1000.0
                                                // V45 : la première étape dépend de la batterie de départ ; après recharge,
                                                // la référence redevient l'autonomie sûre à 100 %.
                                                val legSafeKm = if (index == 0) safeUsableKm else batteryMaxRangeKm * 0.80
                                                val legStatus = when {
                                                    legKm <= legSafeKm * (52.0 / 60.0) -> "Confortable"
                                                    legKm <= legSafeKm * (57.0 / 60.0) -> "Correcte"
                                                    else -> "Prudence : proche de la limite"
                                                }
                                                Text(
                                                    String.format(Locale.FRANCE, "✓ %.1f km par la route VSP depuis l’étape précédente • %s", legKm, legStatus),
                                                    color = if (legKm > legSafeKm * (57.0 / 60.0)) Color(0xFFFFC857) else Color(0xFF9CB0C4),
                                                    fontSize = 10.sp
                                                )
                                                TextButton(
                                                    onClick = {
                                                        rechargeBatteryStopIndex = index
                                                        rechargeBatteryPercent = null
                                                    },
                                                    modifier = Modifier.align(Alignment.End)
                                                ) {
                                                    Text("🔋 Batterie après recharge")
                                                }
                                                TextButton(
                                                    onClick = {
                                                        unavailableChargeStop = stop
                                                        unavailableBatteryPercent = null
                                                    },
                                                    modifier = Modifier.align(Alignment.End)
                                                ) {
                                                    Text("⚠ Signaler borne indisponible")
                                                }
                                            }
                                        }
                                    }
                                    routeChargeFinalLegMeters?.let { finalMeters ->
                                        val finalKm = finalMeters / 1000.0
                                        val finalSafeKm = batteryMaxRangeKm * 0.80
                                        val finalStatus = when {
                                            finalKm <= finalSafeKm * (52.0 / 60.0) -> "Confortable"
                                            finalKm <= finalSafeKm * (57.0 / 60.0) -> "Correcte"
                                            else -> "Prudence : proche de la limite"
                                        }
                                        Text(
                                            "🏁 ${destination?.label ?: "Destination"}",
                                            color = Color(0xFF65D68A),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            String.format(Locale.FRANCE, "✓ %.1f km par la route VSP depuis la dernière recharge • %s", finalKm, finalStatus),
                                            color = if (finalKm > finalSafeKm * (57.0 / 60.0)) Color(0xFFFFC857) else Color(0xFF9CB0C4),
                                            fontSize = 10.sp
                                        )
                                    }
                                    unavailableChargeStop?.let { failedStop ->
                                        AlertDialog(
                                            onDismissRequest = { unavailableChargeStop = null; unavailableBatteryPercent = null },
                                            title = { Text("⚠ Signaler borne indisponible") },
                                            text = {
                                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                                    Text("${chargingPoiDisplayName(failedStop.poi)} ne sera plus proposée pour ce trajet.")
                                                    Text("Indiquez la batterie réellement restante maintenant. Le GPS cherchera automatiquement une autre borne atteignable par la route VSP.")
                                                    OutlinedTextField(
                                                        value = unavailableBatteryPercent?.toString() ?: "",
                                                        onValueChange = { value -> unavailableBatteryPercent = value.filter { it.isDigit() }.toIntOrNull()?.coerceIn(0, 100) },
                                                        label = { Text("Batterie restante (%)") },
                                                        singleLine = true,
                                                        keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                                                    )
                                                }
                                            },
                                            confirmButton = {
                                                TextButton(
                                                    enabled = unavailableBatteryPercent != null && !routeChargeSearchLoading,
                                                    onClick = {
                                                        val remaining = unavailableBatteryPercent ?: return@TextButton
                                                        inaccessiblePoiKeys = inaccessiblePoiKeys + vspPoiKey(failedStop.poi)
                                                        batteryLevelPercent = remaining
                                                        saveBatteryProfile(historyContext, batteryMaxRangeKm, remaining)
                                                        routeChargePlan = emptyList()
                                                        routeChargeFinalLegMeters = null
                                                        routeChargeSuggestion = null
                                                        routeChargeSearchMessage = "Borne exclue. Recherche automatique d’une solution avec $remaining % de batterie…"
                                                        unavailableChargeStop = null
                                                        unavailableBatteryPercent = null
                                                        planRecharges(remaining)
                                                    }
                                                ) { Text("Exclure et recalculer") }
                                            },
                                            dismissButton = {
                                                TextButton(onClick = { unavailableChargeStop = null; unavailableBatteryPercent = null }) { Text("Annuler") }
                                            }
                                        )
                                    }

                                    Text(
                                        "Après chaque recharge, indiquez le nouveau niveau de batterie pour poursuivre vers l’étape suivante.",
                                        color = Color(0xFF9CB0C4),
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        }

        if (routeOptions.size > 1) {
            Text(
                text = "Itinéraires proposés",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                routeOptions.take(3).forEachIndexed { index, option ->
                    val km = option.distanceMeters / 1000.0
                    val minutes = vspDisplayMinutes(option.durationSeconds)

                    if (index == selectedRouteIndex) {
                        Button(
                            onClick = { selectedRouteIndex = index },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(String.format(Locale.FRANCE, "✓ VSP\n%.1f km • %d min", km, minutes))
                        }
                    } else {
                        OutlinedButton(
                            onClick = { selectedRouteIndex = index },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(String.format(Locale.FRANCE, "✓ VSP\n%.1f km • %d min", km, minutes))
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {

            AndroidView(
                modifier =
                    Modifier.fillMaxSize(),

                factory = { ctx ->

                    MapView(ctx).apply {

                        setMultiTouchControls(true)

                        controller.setZoom(
                            13.0
                        )

                        controller.setCenter(
                            GeoPoint(
                                50.425,
                                2.710
                            )
                        )
                    }
                },

                update = { map ->

                    // Points utiles VSP issus d'OpenStreetMap autour de la position.
                    

                    destination?.let { d ->

                        map.overlays.removeAll {
                            it is Marker || it is Polyline
                        }

                        currentLocation?.let { location ->
                            val startMarker = Marker(map).apply {
                                position = GeoPoint(location.latitude, location.longitude)
                                title = "Ma position"
                                icon = ContextCompat.getDrawable(map.context, android.R.drawable.presence_online)
                                setAnchor(
                                    Marker.ANCHOR_CENTER,
                                    Marker.ANCHOR_CENTER
                                )
                            }
                            map.overlays.add(startMarker)
                        }

                        val marker =
                            Marker(map).apply {

                                position =
                                    d.point

                                title =
                                    d.label

                                setAnchor(
                                    Marker.ANCHOR_CENTER,
                                    Marker.ANCHOR_BOTTOM
                                )
                            }

                        if (routePoints.isNotEmpty()) {
                            val routeLine = Polyline().apply {
                                setPoints(routePoints)
                                outlinePaint.strokeWidth = 10f
                                outlinePaint.color = android.graphics.Color.BLUE
                            }

                            map.overlays.add(routeLine)
                            map.invalidate()
                        }
                        map.overlays.add(
                            marker
                        )

                        if (routePoints.isNotEmpty()) {
                            // Ne pas utiliser MapView.zoomToBoundingBox ici : sur certains Xiaomi,
                            // osmdroid peut rester bloqué plusieurs secondes dans Projection.toPixels.
                            // On calcule donc directement un centre et un niveau de zoom simples.
                            var minLat = Double.POSITIVE_INFINITY
                            var maxLat = Double.NEGATIVE_INFINITY
                            var minLon = Double.POSITIVE_INFINITY
                            var maxLon = Double.NEGATIVE_INFINITY

                            routePoints.forEach { point ->
                                minLat = kotlin.math.min(minLat, point.latitude)
                                maxLat = kotlin.math.max(maxLat, point.latitude)
                                minLon = kotlin.math.min(minLon, point.longitude)
                                maxLon = kotlin.math.max(maxLon, point.longitude)
                            }

                            val center = GeoPoint(
                                (minLat + maxLat) / 2.0,
                                (minLon + maxLon) / 2.0
                            )
                            val latSpan = kotlin.math.max(maxLat - minLat, 0.0001)
                            val lonSpan = kotlin.math.max(maxLon - minLon, 0.0001)
                            val log2 = kotlin.math.ln(2.0)
                            val zoomLon = kotlin.math.ln((360.0 * 0.72) / lonSpan) / log2
                            val zoomLat = kotlin.math.ln((180.0 * 0.50) / latSpan) / log2
                            val safeZoom = kotlin.math.min(zoomLon, zoomLat).coerceIn(4.0, 17.0)

                            map.controller.setCenter(center)
                            map.controller.setZoom(safeZoom)
                        } else {
                            map.controller.setCenter(d.point)
                            map.controller.setZoom(16.0)
                        }

                        map.invalidate()
                    }
                }
            )
        }

        Spacer(
            Modifier.height(8.dp)
        )

        if (poiRouteLoading) {
            Text(
                text = "Calcul de l’itinéraire VSP en cours…",
                color = Color(0xFFFFC857),
                fontSize = 14.sp,
                modifier = Modifier.padding(vertical = 6.dp)
            )
        }

        if (destination != null) {
            Button(
                onClick = {
                    // V439 : en électrique, aucune prise n'est supposée compatible par défaut.
                    // Le départ est bloqué tant que l'utilisateur n'en a pas validé au moins une.
                    if (energyType == EnergyType.ELECTRIC && (!chargingProfileConfirmed || chargingProfile.isEmpty())) {
                        error = "⚠ Choisissez au moins une prise compatible avec votre VSP avant de démarrer."
                        showChargingProfileDialog = true
                        return@Button
                    }
                    if (routeOptions.isNotEmpty()) {
                        navigationStarted = true
                    } else if (!poiRouteLoading) {
                        val dest = destination ?: return@Button
                        startAfterRouteCalculation = true

                        fun launchRouteFrom(location: Location?) {
                            if (location == null) {
                                startAfterRouteCalculation = false
                                error = "Position GPS indisponible. Activez la localisation puis réessayez."
                                return
                            }
                            currentLocation = location
                            calculateRoute(
                                GeoPoint(location.latitude, location.longitude),
                                dest.point
                            )
                        }

                        // Demande ponctuelle de position uniquement au moment du départ.
                        // Aucun nouveau suivi GPS permanent n'est ajouté à l'écran de recherche.
                        val fineGranted = ContextCompat.checkSelfPermission(
                            context, Manifest.permission.ACCESS_FINE_LOCATION
                        ) == PackageManager.PERMISSION_GRANTED
                        val coarseGranted = ContextCompat.checkSelfPermission(
                            context, Manifest.permission.ACCESS_COARSE_LOCATION
                        ) == PackageManager.PERMISSION_GRANTED

                        if (!fineGranted && !coarseGranted) {
                            startAfterRouteCalculation = false
                            error = "Autorisation GPS nécessaire pour démarrer."
                            permissionLauncher.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                )
                            )
                        } else {
                            try {
                                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                                    locationManager.getCurrentLocation(
                                        android.location.LocationManager.GPS_PROVIDER,
                                        null,
                                        context.mainExecutor
                                    ) { location ->
                                        if (location != null) {
                                            launchRouteFrom(location)
                                        } else {
                                            try {
                                                launchRouteFrom(
                                                    locationManager.getLastKnownLocation(
                                                        android.location.LocationManager.NETWORK_PROVIDER
                                                    )
                                                )
                                            } catch (_: SecurityException) {
                                                launchRouteFrom(null)
                                            }
                                        }
                                    }
                                } else {
                                    launchRouteFrom(
                                        currentLocation
                                            ?: locationManager.getLastKnownLocation(
                                                android.location.LocationManager.GPS_PROVIDER
                                            )
                                            ?: locationManager.getLastKnownLocation(
                                                android.location.LocationManager.NETWORK_PROVIDER
                                            )
                                    )
                                }
                            } catch (_: Exception) {
                                startAfterRouteCalculation = false
                                error = "Position GPS indisponible. Réessayez dans quelques instants."
                            }
                        }
                    }
                },
                enabled = !poiRouteLoading && (
                    energyType == EnergyType.FUEL ||
                    ((routeOptions.getOrNull(selectedRouteIndex) ?: routeOptions.firstOrNull())?.let { r ->
                        val estimated = (batteryMaxRangeKm * batteryLevelPercent) / 100.0
                        val safeNow = (estimated - batteryMaxRangeKm * 0.20).coerceAtLeast(0.0)
                        val rechargeNeeded = (r.distanceMeters / 1000.0) > safeNow
                        !rechargeNeeded || routeChargePlan.isNotEmpty()
                    } ?: false)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(18.dp)
            ) {
                Text(
                    text = if (poiRouteLoading) "Calcul de l’itinéraire…" else "▶  Démarrer",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(Modifier.height(8.dp))
        }

        Text(
            text =
                if (locationGranted)
                    "Moteur VSP en validation"
                else
                    "Autorisation GPS nécessaire",

            color =
                if (locationGranted)
                    Color(0xFF65D68A)
                else
                    Color(0xFFFFC857)
        )

        Text(
            text = "Moteur Valhalla local • profil 45 km/h • autoroutes contrôlées sur les arêtes réellement empruntées. Les autres restrictions restent soumises aux données cartographiques et à la signalisation réelle.",

            color =
                Color(0xFF9CB0C4),

            fontSize =
                12.sp
        )

        MapPackControls(
            router = localValhallaRouter,
            externallyBusy = localValhallaTestRunning,
            startLocation = currentLocation,
            destination = destination,
            onDiagnostic = { localValhallaDiagnostic = it }
        )

        // Diagnostic volontairement visible : le test utilise deux coordonnées
        // fixes couvertes par l'archive régionale. La recherche
        // d'adresse n'intervient donc pas dans ce test.
        OutlinedButton(
            onClick = {
                if (!localValhallaTestRunning) {
                    localValhallaTestRunning = true
                    localValhallaDiagnostic = "Test Valhalla local en cours…"
                    scope.launch {
                        val result = withContext(Dispatchers.IO) {
                            localValhallaRouter.calculateTestRoute(
                                startLatitude = 50.425,
                                startLongitude = 2.710,
                                endLatitude = 50.429,
                                endLongitude = 2.831
                            )
                        }
                        localValhallaDiagnostic = when (result) {
                            is LocalValhallaRouter.LocalRouteResult.Success ->
                                "✓ Valhalla local OK — trajet calculé hors serveur public\n" +
                                    localValhallaRouter.describeRouteResponse(result.response) + "\n" +
                                    localValhallaRouter.validateResponseForGps(result.response).fold(
                                        onSuccess = { "✓ $it" },
                                        onFailure = { "✗ conversion GPS : ${it.message ?: it.javaClass.simpleName}" }
                                    )
                            is LocalValhallaRouter.LocalRouteResult.Failed ->
                                "✗ Valhalla local : ${result.message}"
                        }
                        localValhallaTestRunning = false
                    }
                }
            },
            enabled = !localValhallaTestRunning,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (localValhallaTestRunning) "Test en cours…" else "Tester Valhalla local")
        }

        // ETAPE 124 : test du recalcul utilisable à l'arrêt. Il travaille sur des
        // coordonnées de test couvertes par le pack local et n'altère jamais le trajet affiché.
        OutlinedButton(
            onClick = {
                if (!localRerouteTestRunning) {
                    localRerouteTestRunning = true
                    localValhallaDiagnostic = "Test recalcul directionnel local en cours…"
                    scope.launch {
                        val result = withContext(Dispatchers.IO) {
                            localValhallaRouter.runDirectionalRerouteSelfTest()
                        }
                        localValhallaDiagnostic = result.fold(
                            onSuccess = { it },
                            onFailure = { "✗ Recalcul directionnel local : ${it.message ?: it.javaClass.simpleName}" }
                        )
                        localRerouteTestRunning = false
                    }
                }
            },
            enabled = !localRerouteTestRunning && !localValhallaTestRunning && !comparisonRunning,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (localRerouteTestRunning) "Test recalcul en cours…" else "🧪 Tester le recalcul à l'arrêt")
        }

        OutlinedButton(
            onClick = {
                if (!comparisonRunning) {
                    comparisonRunning = true
                    comparisonResult = "Comparaison locale en cours…"
                    scope.launch {
                        comparisonResult = withContext(Dispatchers.IO) {
                            localValhallaRouter.compareProfiles(
                                startLatitude = 50.425,
                                startLongitude = 2.710,
                                endLatitude = 50.429,
                                endLongitude = 2.831
                            )
                        }
                        comparisonRunning = false
                    }
                }
            },
            enabled = !comparisonRunning && !localValhallaTestRunning,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (comparisonRunning) "Comparaison en cours…" else "Comparer auto / scooter (local)")
        }
        comparisonResult?.let { result ->
            Text(result, color = Color(0xFF9CB0C4), fontSize = 12.sp)
        }
        OutlinedButton(
            onClick = {
                if (!comparisonRunning) {
                    comparisonRunning = true
                    comparisonResult = "Chargement des deux tracés…"
                    scope.launch {
                        val preview = withContext(Dispatchers.IO) {
                            localValhallaRouter.previewProfiles(50.425, 2.710, 50.429, 2.831)
                        }
                        preview.fold(
                            onSuccess = { comparisonPreview = it; comparisonDialogVisible = true; comparisonResult = "Tracés disponibles : auto et scooter" },
                            onFailure = { comparisonResult = "Comparaison des tracés impossible : ${it.message ?: it.javaClass.simpleName}" }
                        )
                        comparisonRunning = false
                    }
                }
            },
            enabled = !comparisonRunning && !localValhallaTestRunning,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Voir les deux tracés sur la carte") }
        if (comparisonDialogVisible) {
            comparisonPreview?.let { previews ->
                ProfileComparisonDialog(previews = previews, onDismiss = { comparisonDialogVisible = false })
            }
        }


        Text(
            text = lastRouteEngine,
            color = Color(0xFFFFC857),
            fontSize = 12.sp
        )
        lastRouteOfflineReady?.let { offlineReady ->
            Text(
                text = if (offlineReady) {
                    "✓ Trajet disponible hors ligne avec le pack actuel"
                } else {
                    "⚠ Ce trajet dépend d’Internet : le pack local ne couvre pas complètement cette destination"
                },
                color = if (offlineReady) Color(0xFF65D68A) else Color(0xFFFFA726),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
        acceptedRouteValidation?.let { validation ->
            // Étape 31 : le diagnostic détaillé reste exécuté en arrière-plan, mais
            // l'écran principal revient à une information utile au conducteur.
            val selectedRoute = routeOptions.getOrNull(selectedRouteIndex) ?: routeOptions.firstOrNull()
            // Étape 77 : audit transparent du candidat réellement retenu.
            // Une voie trunk ou une limitation élevée n'est PAS assimilée à une
            // interdiction VSP ; seule la présence de motorway bloque ici le trajet.
            Text(
                text = "✓ Audit VSP local : 0 arête motorway détectée",
                color = Color(0xFF65D68A),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = validation,
                color = Color(0xFFB0BEC5),
                fontSize = 10.sp
            )
            if (acceptedRampAudit.isNotEmpty()) {
                Text(
                    text = "Audit des bretelles (${acceptedRampAudit.size})",
                    color = Color(0xFFFFC857),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                acceptedRampAudit.forEach { ramp ->
                    Text(
                        text = "↪ $ramp",
                        color = Color(0xFFB0BEC5),
                        fontSize = 9.sp
                    )
                }
                Text(
                    text = "ℹ Une bretelle n'est pas automatiquement interdite à une VSP. Son classement réel est affiché ci-dessus ; motorway reste bloqué.",
                    color = Color(0xFFFFC857),
                    fontSize = 9.sp
                )
            }
            if (acceptedHighSpeedAudit.isNotEmpty()) {
                Text(
                    text = "ℹ ${acceptedHighSpeedAudit.size} arête(s) > 70 km/h observée(s) : information seulement, pas une interdiction VSP automatique.",
                    color = Color(0xFFFFC857),
                    fontSize = 10.sp
                )
            }
            Text(
                text = "Contrôle local trace_attributes du trajet retenu • trunk/bretelle/vitesse élevée = points d'audit, pas interdictions automatiques • itinéraire non certifié réglementairement.",
                color = Color(0xFF9CB0C4),
                fontSize = 10.sp
            )
            if (selectedRoute != null && selectedRoute.maneuvers.isNotEmpty()) {
                Text(
                    text = "Aperçu du guidage",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                selectedRoute.maneuvers.take(3).forEachIndexed { index, maneuver ->
                    val road = maneuver.streetNames.trim()
                    val label = maneuver.instruction.trim().ifBlank {
                        if (road.isNotBlank()) road else "Continuer sur l’itinéraire"
                    }
                    Text(
                        text = "${index + 1}. $label",
                        color = Color(0xFFB0BEC5),
                        fontSize = 10.sp
                    )
                }
            }
        }
        Text(
            text = "Sécurité : un calcul local en mode auto ne garantit pas encore l'exclusion de toutes les voies interdites aux VSP. Ne pas suivre un trajet contraire à la signalisation.",
            color = Color(0xFFFFC857),
            fontSize = 11.sp
        )
        localValhallaDiagnostic?.let { diagnostic ->
            Text(
                text = diagnostic,
                color = if (diagnostic.startsWith("✓")) Color(0xFF65D68A) else Color(0xFFFFC857),
                fontSize = 12.sp
            )
        }
    }
}


data class ManeuverGuidance(
    val arrow: String,
    val title: String,
    val distanceText: String,
    val distanceMeters: Double? = null,
    // ETAPE 86 : indication purement visuelle pour la caméra. Elle permet de
    // distinguer l'approche / l'intérieur d'un rond-point sans déduire cet état
    // du texte affiché. Le guidage et la voix restent la source de vérité.
    val cameraRoundaboutPhase: String? = null,
    // ETAPE 87 : numéro de sortie exposé uniquement à l’interface visuelle.
    // La voix et le calcul de guidage restent inchangés.
    val visualRoundaboutExitLabel: String? = null,
    // ETAPE 88 : aperçu purement visuel de la manœuvre suivante quand elle arrive
    // rapidement. Il ne déclenche aucune annonce vocale et ne modifie pas la
    // progression séquentielle des manœuvres.
    val nextVisualArrow: String? = null,
    val nextVisualText: String? = null,
    val spokenTitle: String = title,
    // V134 : identifiant stable de la manœuvre. Deux instructions vocales identiques
    // sur un même trajet restent ainsi deux étapes distinctes pour la synthèse vocale.
    val voiceKey: String = spokenTitle
)



// V422 : classification Valhalla centralisée. Les écrans, la voix et la feuille
// de route doivent tous utiliser ces mêmes fonctions afin qu'une future évolution
// ne puisse plus réintroduire des correspondances droite/gauche ou rond-point
// différentes selon l'endroit de l'application.
// V423 : ces tests sont exécutés très souvent pendant le guidage. On évite de
// recréer des Set temporaires à chaque rafraîchissement GPS/Compose : même table
// Valhalla que V422, mais sous forme de when sans allocation.
// ETAPE 107 : ne pas confondre un vrai virage avec une consigne latérale.
// Dans l'enum Valhalla :
//   9/10/11 = slight/right/sharp right, 14/15/16 = sharp/left/slight left.
// Les types 18/19 (ramp), 20/21 (exit), 23/24 (stay) et 37/38 (merge)
// ne doivent PAS être reformulés en « Tournez ... » : on conserve leur instruction Odin.
private fun isValhallaRightTurn(type: Int): Boolean = when (type) {
    9, 10, 11 -> true
    else -> false
}

private fun isValhallaLeftTurn(type: Int): Boolean = when (type) {
    14, 15, 16 -> true
    else -> false
}

private fun isValhallaRightLateral(type: Int): Boolean = when (type) {
    18, 20, 23, 37 -> true
    else -> false
}

private fun isValhallaLeftLateral(type: Int): Boolean = when (type) {
    19, 21, 24, 38 -> true
    else -> false
}

private fun isValhallaUTurn(type: Int): Boolean = type == 12 || type == 13

private fun isValhallaRoundabout(type: Int): Boolean = type == 26 || type == 27

// V425 : types de départ Valhalla centralisés sans allocation temporaire.
// Ce test est utilisé à chaque rafraîchissement du guidage.
// V429 : Valhalla possède trois variantes de départ : Start (1), StartRight (2)
// et StartLeft (3). Le type 3 manquait ici et pouvait être pris à tort pour la
// première vraie manœuvre d'un itinéraire démarrant vers la gauche.
private fun isValhallaStart(type: Int): Boolean = type == 1 || type == 2 || type == 3

// V426 : même principe pour les trois types d’arrivée Valhalla. La règle n’est
// plus dupliquée dans le rendu de la flèche : toute évolution du guidage pourra
// réutiliser ce test unique sans risquer une divergence entre les écrans.
private fun isValhallaArrival(type: Int): Boolean = type == 4 || type == 5 || type == 6

private fun maneuverArrow(type: Int): String {
    // V422 : l'icône dépend uniquement de la classification centralisée du type.
    // V428 : suppression des anciens paramètres exitCount/instruction. Ils n'étaient
    // plus utilisés depuis la sécurisation des ronds-points ; les retirer de la
    // signature garantit qu'aucun texte ni numéro de sortie ne pourra redevenir
    // une source implicite pour choisir l'icône.
    // V424 : comme pour les virages en V423, ne plus construire de Set temporaire
    // pour reconnaître les trois types d'arrivée à chaque rafraîchissement.
    return when {
        isValhallaArrival(type) -> "🏁"
        isValhallaRightTurn(type) -> "↱"
        isValhallaLeftTurn(type) -> "↰"
        isValhallaRightLateral(type) -> "↗"
        isValhallaLeftLateral(type) -> "↖"
        isValhallaUTurn(type) -> "↩"
        isValhallaRoundabout(type) -> "↺"
        else -> "↑"
    }
}

// V431 : libellés de sortie de rond-point centralisés. L’affichage reste compact
// tandis que la voix utilise des ordinaux français explicites jusqu’à la 12e sortie,
// afin d’éviter les prononciations variables de formes comme « 7e » par Android TTS.
private fun roundaboutExitVisualLabel(exit: Int): String = when {
    exit <= 0 -> ""
    exit == 1 -> "1re"
    else -> "${exit}e"
}

// V436 : garde-fou défensif. Une sortie absente/invalide ne doit jamais produire
// un libellé comme « 0e » si cette fonction est réutilisée ailleurs plus tard.
private fun roundaboutExitSpokenLabel(exit: Int): String = when (exit) {
    1 -> "première"
    2 -> "deuxième"
    3 -> "troisième"
    4 -> "quatrième"
    5 -> "cinquième"
    6 -> "sixième"
    7 -> "septième"
    8 -> "huitième"
    9 -> "neuvième"
    10 -> "dixième"
    11 -> "onzième"
    12 -> "douzième"
    else -> if (exit > 0) "${exit}e" else ""
}

// V441 / étape 41 : privilégier le vrai nom de voie dans le guidage conducteur.
// Valhalla renvoie parfois « Rue ... / D58e2 ». Quand un nom lisible existe, la
// référence administrative est inutile à l'écran et à la voix. Si la voie n'a
// QUE son numéro (D51, N17...), on le conserve afin de ne pas perdre l'information.
private fun simplifiedGuidanceRoadName(raw: String): String {
    val parts = raw.split("/").map { it.trim() }.filter { it.isNotBlank() }
    if (parts.isEmpty()) return raw.trim()
    val refRegex = Regex("^(?:[ADN]|D\\s*|N\\s*)\\s*\\d+[A-Za-z0-9-]*$", RegexOption.IGNORE_CASE)
    val named = parts.firstOrNull { !refRegex.matches(it.replace(" ", "")) }
    return (named ?: parts.first()).trim()
}

// ETAPE 108/109 : l'écran de navigation affiche déjà la voie séparément sous la
// consigne principale. On retire donc de la version VISUELLE les compléments
// redondants tels que « pour rester D 917 », « pour prendre la bretelle »,
// « sur Rue ... » ou « dans ... ».
// La consigne vocale Odin n'est jamais modifiée par cette fonction.
private fun compactVisualInstruction(raw: String): String {
    var text = raw.substringBefore(". ").trim().trimEnd('.')
    val separators = listOf(" pour rester ", " pour prendre ", " sur ", " dans ")
    for (separator in separators) {
        val index = text.indexOf(separator, ignoreCase = true)
        if (index >= 0) text = text.substring(0, index).trim()
    }
    return text.ifBlank { "Continuez" }
}

private fun maneuverDistanceMeters(points: List<GeoPoint>, from: Int, to: Int): Double {
    if (points.size < 2) return 0.0
    val a = from.coerceIn(0, points.lastIndex)
    val b = to.coerceIn(a, points.lastIndex)
    var d = 0.0
    for (i in a until b) d += points[i].distanceToAsDouble(points[i + 1])
    return d
}

private fun formatRoadmapDistance(meters: Double): String = when {
    meters < 1.0 -> ""
    meters < 1000.0 -> "${meters.toInt()} m"
    else -> String.format(java.util.Locale.FRANCE, "%.1f km", meters / 1000.0)
}


// V106 : une durée Valhalla est affichée de façon identique partout.
// On arrondit à la minute supérieure pour ne jamais annoncer moins que la durée calculée.
private fun vspDisplayMinutes(durationSeconds: Double): Int =
    if (durationSeconds <= 0.0) 0
    else kotlin.math.max(1, kotlin.math.ceil(durationSeconds / 60.0).toInt())

private fun formatEtaFromMinutes(minutes: Int): String {
    val targetMillis = System.currentTimeMillis() + minutes.coerceAtLeast(0) * 60_000L
    return java.text.SimpleDateFormat("HH:mm", java.util.Locale.FRANCE)
        .format(java.util.Date(targetMillis))
}

private fun formatGpsDistance(meters: Double): String =
    if (meters < 1000.0) "${meters.toInt()} m"
    else String.format(java.util.Locale.FRANCE, "%.1f km", meters / 1000.0)

@Composable
fun NavigationScreen(
    vehicle: VehicleType,
    destination: Destination,
    currentLocation: Location?,
    route: RouteOption,
    networkWarning: String?,
    routeCalculationInProgress: Boolean,
    isIntermediateChargeStep: Boolean = false,
    finalTripDestination: Destination? = null,
    futureTripDistanceMeters: Double = 0.0,
    onIntermediateChargeReached: () -> Unit = {},
    onFinalArrivalReached: () -> Unit = {},
    onBack: () -> Unit,
    onReroute: (GeoPoint) -> Unit
) {
    var liveLocation by remember { mutableStateOf(currentLocation) }
    // ETAPE 33 : simulateur de conduite local. Il injecte des positions fictives
    // uniquement dans cet écran de navigation et ne modifie jamais le GPS Android.
    var simulationActive by remember { mutableStateOf(false) }
    var simulationMeters by remember { mutableStateOf(0.0) }
    // ETAPE 36 : accélérateur du mode test uniquement. Le GPS réel reste inchangé.
    var simulationMultiplier by remember { mutableStateOf(1) }
    // ETAPE 39 : marche arrière de test à ×2. Elle ne concerne que le simulateur.
    // La position sur le trajet est conservée et les annonces sont suspendues pendant le recul.
    var simulationRewinding by remember { mutableStateOf(false) }
    // ETAPE 56 : pause du mode test. La progression reste exactement au même mètre.
    var simulationPaused by remember { mutableStateOf(false) }
    // V301 : confirmation des grands sauts GPS. V300 rejetait correctement un point
    // isolé aberrant, mais une vraie reprise GPS loin du dernier fix pouvait être
    // bloquée plusieurs secondes. Deux fixes successifs cohérents dans la nouvelle
    // zone suffisent maintenant à confirmer que le déplacement est réel.
    var jumpCandidateLocation by remember { mutableStateOf<Location?>(null) }
    var jumpCandidateCount by remember { mutableStateOf(0) }
    var liveBearing by remember { mutableStateOf(0f) }
    var offRoute by remember { mutableStateOf(false) }
    var showRoadmap by remember { mutableStateOf(false) }
    var offRouteSince by remember { mutableStateOf<Long?>(null) }
    // V292 : le cooldown de recalcul utilise l’horloge monotone Android. Un changement
    // d’heure système (réseau, utilisateur, changement de fuseau) ne peut ainsi plus
    // prolonger ou supprimer artificiellement la protection de 20 secondes.
    var lastRerouteAt by remember { mutableStateOf(0L) }
    // V265 : conserver un état visuel de recalcul jusqu’à réception effective
    // du nouveau tracé. Sans cela, le bandeau « Recalcul automatique… » pouvait
    // disparaître dès que offRoute était remis à zéro alors que le calcul réseau
    // était encore en cours.
    var rerouteInProgress by remember { mutableStateOf(false) }
    // V276 : verrou atomique local au lancement d’un recalcul. Les états Compose sont
    // publiés de façon asynchrone ; deux effets déclenchés dans la même frame pouvaient
    // donc tous deux lire rerouteInProgress=false avant sa mise à jour. Ce verrou ferme
    // cette fenêtre de course et garantit une seule demande de recalcul à la fois.
    val rerouteLaunchGate = remember { java.util.concurrent.atomic.AtomicBoolean(false) }
    var mapAutoFollow by remember { mutableStateOf(true) }
    var lastManualMapTouchAt by remember { mutableStateOf(0L) }
    // V293 : tous les délais internes de navigation (reprise auto de carte, preuve de
    // mouvement, GPS marginal et confirmation hors-route) utilisent désormais l’horloge
    // monotone Android. Un changement d’heure du téléphone ne peut plus les prolonger
    // ou les écourter pendant un trajet.

    // V154 : identifiant du tracé actuellement affiché. NavigationScreen reste la
    // même composition après un recalcul ; cette clé permet de réarmer proprement
    // les états transitoires qui appartenaient à l'ancien trajet.
    val routeRevisionKey = remember(route) {
        val first = route.points.firstOrNull()
        val last = route.points.lastOrNull()
        listOf(
            route.points.size.toString(),
            route.distanceMeters.toLong().toString(),
            first?.latitude?.toString().orEmpty(),
            first?.longitude?.toString().orEmpty(),
            last?.latitude?.toString().orEmpty(),
            last?.longitude?.toString().orEmpty()
        ).joinToString(":")
    }
    // ETAPE 52 CORRIGEE : routeRevisionKey doit être déclaré avant son utilisation.
    // La progression canonique de simulation est ainsi réinitialisée uniquement
    // lorsqu'un nouveau tracé est réellement chargé.
    var simulationRouteSegment by remember(routeRevisionKey) { mutableStateOf(0) }
    // V125 : après une consultation manuelle de la carte, le suivi reprend tout seul
    // après 8 secondes. Pendant un recalcul il est réactivé immédiatement.
    LaunchedEffect(mapAutoFollow, lastManualMapTouchAt) {
        if (!mapAutoFollow && lastManualMapTouchAt > 0L) {
            kotlinx.coroutines.delay(8_000L)
            if (android.os.SystemClock.elapsedRealtime() - lastManualMapTouchAt >= 7_500L) {
                mapAutoFollow = true
            }
        }
    }

    // V166 : les nouvelles tentatives après un échec réseau sont pilotées au niveau
    // de MapSearchScreen, qui connaît l'état du calcul et conserve une seule demande
    // en attente. On ne lance plus ici une seconde boucle de recalcul indépendante :
    // cela évite les doublons et surtout l'utilisation d'un ancien fix GPS.

    // V124 : compteur de vitesse permanent intégré à la carte, dans l’esprit Waze.
    // La vitesse vient du GPS Android (Location.speed), plus fiable qu’un accéléromètre seul.
    val rawSpeedKmh = liveLocation?.takeIf { it.hasSpeed() }?.speed?.times(3.6f) ?: 0f
    val speedKmh = if (rawSpeedKmh < 1.5f) 0 else kotlin.math.round(rawSpeedKmh).toInt()
    // V289 : à très faible allure, Location.speed peut brièvement retomber à 0 entre
    // deux fixes (rond-point, sortie de parking, circulation lente). On garde pendant
    // 3 secondes la preuve d'un mouvement réel >= 2 km/h. Cela évite que la détection
    // hors itinéraire s'éteigne au milieu d'une manœuvre sans réactiver les recalculs
    // dus à une dérive GPS lorsque la VSP est réellement immobile depuis plusieurs secondes.
    var lastRealMovementAt by remember { mutableStateOf(0L) }
    if (rawSpeedKmh >= 2.0f) {
        lastRealMovementAt = android.os.SystemClock.elapsedRealtime()
    }
    val movementRecentlyConfirmed =
        rawSpeedKmh >= 2.0f ||
        (lastRealMovementAt > 0L && android.os.SystemClock.elapsedRealtime() - lastRealMovementAt <= 3_000L)

    // V121 : le bouton Retour système Android (triangle / geste Retour) ne ferme plus
    // l'application pendant la navigation. Il utilise la même sortie que le bouton
    // « Itinéraire » et revient donc à l'écran d'accueil GPS.
    BackHandler(enabled = true) {
        onBack()
    }

    // V120 : après démarrage ou perte de précision GPS, le guidage reste suspendu
    // jusqu'à confirmation de la route réellement suivie.
    var gpsNavigationReady by remember { mutableStateOf(false) }
    var recoverySegmentIndex by remember { mutableStateOf<Int?>(null) }
    var recoverySegmentMatches by remember { mutableStateOf(0) }
    // V147 : hystérésis de qualité GPS. Une dégradation progressive ne doit pas
    // couper brutalement le guidage ni provoquer un faux recalcul.
    var gpsSignalUsable by remember { mutableStateOf(false) }
    var marginalGpsSince by remember { mutableStateOf<Long?>(null) }

    // V164/V165 : un ancien fix ne doit jamais rester considéré comme fiable si Android
    // cesse momentanément de fournir des positions. V165 utilise l'horloge monotone
    // d'Android et tient compte de l'âge réel d'un éventuel lastKnownLocation au démarrage :
    // une ancienne position précise n'est donc plus considérée comme "fraîche" pendant 8 s.
    fun locationAgeMillis(location: Location?): Long {
        if (location == null) return Long.MAX_VALUE
        val fixElapsedNanos = location.elapsedRealtimeNanos
        if (fixElapsedNanos <= 0L) return Long.MAX_VALUE
        return ((android.os.SystemClock.elapsedRealtimeNanos() - fixElapsedNanos) / 1_000_000L)
            .coerceAtLeast(0L)
    }

    val initialFixAgeMs = remember(currentLocation) { locationAgeMillis(currentLocation) }
    var lastGpsFixAtElapsed by remember {
        mutableStateOf(
            if (initialFixAgeMs <= 8_000L)
                android.os.SystemClock.elapsedRealtime() - initialFixAgeMs
            else 0L
        )
    }
    // V281 : Android peut suspendre les callbacks GPS bien plus de 30 s lorsque le véhicule
    // est réellement immobile. Un fix précis dont la dernière vitesse confirme l'arrêt
    // reste donc exploitable jusqu'à 2 min. En déplacement, la limite stricte de 8 s
    // reste inchangée afin de ne jamais guider longtemps sur une ancienne position.
    fun gpsFreshnessLimitMs(location: Location?): Long {
        // V412 : 1,5 m/s (~5,4 km/h) était trop élevé pour déclarer la VSP immobile :
        // dans un bouchon ou une manoeuvre très lente, un ancien fix aurait pu rester
        // accepté jusqu'à 2 minutes. La tolérance longue est désormais réservée à une
        // immobilité quasi certaine (< 0,5 m/s, soit ~1,8 km/h).
        // Sans vitesse Android, on conserve toujours la limite stricte de 8 s.
        val stationary = location?.let { it.hasSpeed() && it.speed < 0.5f } ?: false
        return if (stationary) 120_000L else 8_000L
    }
    var gpsFixFresh by remember {
        mutableStateOf(initialFixAgeMs <= gpsFreshnessLimitMs(currentLocation))
    }

    // V278 : NavigationScreen peut recevoir une position récente du niveau parent alors
    // que son propre LocationListener n'a pas encore rappelé onLocationChanged (cas
    // fréquent à l'arrêt avec l'ancien minDistance=2 m). Dans ce cas la carte pouvait
    // afficher "GPS précis ±3 m" tandis que gpsFixFresh expirait et affichait
    // "Signal GPS insuffisant". Toute position parent réellement fraîche réarme donc
    // maintenant la navigation immédiatement.
    LaunchedEffect(
        currentLocation?.latitude,
        currentLocation?.longitude,
        currentLocation?.elapsedRealtimeNanos
    ) {
        if (simulationActive) return@LaunchedEffect
        val parentFix = currentLocation ?: return@LaunchedEffect
        val parentFixAgeMs = locationAgeMillis(parentFix)
        if (parentFixAgeMs <= gpsFreshnessLimitMs(parentFix)) {
            liveLocation = parentFix
            lastGpsFixAtElapsed = android.os.SystemClock.elapsedRealtime() - parentFixAgeMs
            gpsFixFresh = true
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(2_000L)
            val freshnessLimitMs = gpsFreshnessLimitMs(liveLocation)
            gpsFixFresh = lastGpsFixAtElapsed > 0L &&
                android.os.SystemClock.elapsedRealtime() - lastGpsFixAtElapsed <= freshnessLimitMs
        }
    }

    // V156 : progression suivie sur la polyline. Elle empêche un fix GPS proche
    // d'une portion parallèle située beaucoup plus loin dans le trajet de faire
    // sauter prématurément une ou plusieurs instructions.
    var trackedRouteSegment by remember { mutableStateOf<Int?>(null) }
    // V160 : dernier fix ayant réellement fait progresser le suivi. Il sert à
    // comparer le déplacement physique avec un éventuel grand saut sur la polyline.
    var lastTrackedLocation by remember { mutableStateOf<Location?>(null) }

    // V154 : dès que le recalcul fournit un nouveau tracé, supprimer les états
    // hors-itinéraire de l'ancienne route et réévaluer immédiatement le fix GPS
    // courant sur la nouvelle route. On conserve lastRerouteAt pour le cooldown.
    // V268 : terminer l’indicateur de recalcul dès que la requête réseau se termine,
    // même si Valhalla renvoie avec succès exactement le même tracé. Dans ce cas,
    // routeRevisionKey ne change pas et networkWarning reste null : V267 pouvait donc
    // laisser « Recalcul en cours… » affiché indéfiniment malgré une requête terminée.
    // L'effet ne dépend volontairement pas de rerouteInProgress : le passage local à
    // true juste avant onReroute ne doit pas être effacé avant que le parent publie
    // routeCalculationInProgress = true.
    LaunchedEffect(routeCalculationInProgress, networkWarning) {
        if (!routeCalculationInProgress) {
            rerouteInProgress = false
            rerouteLaunchGate.set(false)
        }
    }

    // V290 : le lancement local d'un recalcul doit être rapidement confirmé par l'état
    // réseau du parent. Si l'appel n'est finalement pas pris en charge (cycle de vie,
    // callback interrompu, départ refusé), ne pas conserver pendant 45 s un faux état
    // « Recalcul en cours… » ni bloquer rerouteLaunchGate. Huit secondes laissent une
    // marge confortable au parent pour publier routeCalculationInProgress = true.
    LaunchedEffect(rerouteInProgress, routeCalculationInProgress) {
        if (rerouteInProgress && !routeCalculationInProgress) {
            kotlinx.coroutines.delay(8_000L)
            if (rerouteInProgress && !routeCalculationInProgress) {
                rerouteInProgress = false
                rerouteLaunchGate.set(false)
                offRouteSince = null
            }
        }
    }

    LaunchedEffect(routeRevisionKey) {
        // V266 : la réception d’un nouveau tracé termine explicitement l’état de
        // recalcul. V265 affichait correctement « Recalcul en cours… », mais cet
        // état pouvait rester actif après réception de la nouvelle route.
        rerouteInProgress = false
        rerouteLaunchGate.set(false)
        offRoute = false
        offRouteSince = null
        mapAutoFollow = true
        gpsNavigationReady = false
        recoverySegmentIndex = null
        recoverySegmentMatches = 0
        trackedRouteSegment = null
        lastTrackedLocation = null
    }

    // V160 : suivre la progression réelle sans permettre qu'un fix GPS proche
    // d'une rue parallèle ou d'une branche de carrefour fasse franchir artificiellement
    // plusieurs manœuvres. La progression autorisée est liée au déplacement réellement
    // observé depuis le dernier fix accepté, avec une marge adaptée à la précision GPS.
    LaunchedEffect(liveLocation?.latitude, liveLocation?.longitude, gpsFixFresh, routeRevisionKey) {
        val location = liveLocation ?: return@LaunchedEffect
        if (route.points.size < 2) return@LaunchedEffect

        // V162 : un fix momentanément imprécis ne doit jamais déplacer la progression
        // validée sur la polyline. On conserve donc la dernière progression fiable
        // pendant une courte perte de qualité GPS et on la reprend au prochain bon fix.
        // Cela évite aussi qu'une rue parallèle soit choisie pendant la dégradation.
        val trackingAccuracy = location.takeIf { it.hasAccuracy() }?.accuracy?.toDouble()
            ?: Double.POSITIVE_INFINITY
        // V167 : la progression sur le tracé exige désormais un fix à la fois précis
        // ET récent. Une ancienne position conservée par Android ne peut donc plus
        // faire avancer une étape, modifier l'ETA ou sélectionner une route parallèle
        // avant l'arrivée d'un nouveau fix réellement reçu par l'application.
        if (!gpsFixFresh || trackingAccuracy > 65.0) return@LaunchedEffect

        val lat0 = Math.toRadians(location.latitude)
        val earthRadius = 6_371_000.0

        fun segmentDistance(index: Int): Double {
            val a = route.points[index]
            val b = route.points[index + 1]
            val ax = earthRadius * Math.toRadians(a.longitude - location.longitude) * kotlin.math.cos(lat0)
            val ay = earthRadius * Math.toRadians(a.latitude - location.latitude)
            val bx = earthRadius * Math.toRadians(b.longitude - location.longitude) * kotlin.math.cos(lat0)
            val by = earthRadius * Math.toRadians(b.latitude - location.latitude)
            val vx = bx - ax
            val vy = by - ay
            val len2 = vx * vx + vy * vy
            val t = if (len2 <= 0.0001) 0.0 else ((-ax * vx - ay * vy) / len2).coerceIn(0.0, 1.0)
            val x = ax + t * vx
            val y = ay + t * vy
            return kotlin.math.sqrt(x * x + y * y)
        }

        fun routeDistanceBetweenSegments(from: Int, to: Int): Double {
            if (to <= from) return 0.0
            val result = FloatArray(1)
            var total = 0.0
            for (i in from until to.coerceAtMost(route.points.lastIndex)) {
                val a = route.points[i]
                val b = route.points[i + 1]
                Location.distanceBetween(a.latitude, a.longitude, b.latitude, b.longitude, result)
                total += result[0]
            }
            return total
        }

        val previous = trackedRouteSegment
        val start = if (previous == null) 0 else (previous - 8).coerceAtLeast(0)
        // V183 : la zone du premier recalage n'est plus définie par un nombre fixe
        // de points de polyline. La densité des points varie énormément selon les routes :
        // 250 points pouvaient représenter quelques centaines de mètres ou plusieurs km.
        // On utilise maintenant les 5 premiers kilomètres réels du nouveau tracé.
        // Un léger coût de progression départage aussi les portions qui repassent près
        // du départ : à distance GPS comparable, la portion la plus tôt sur le trajet gagne.
        val firstFixProgressMeters = mutableMapOf<Int, Double>()
        val endExclusive = if (previous == null) {
            val distanceResult = FloatArray(1)
            var cumulativeMeters = 0.0
            var end = 1
            while (end < route.points.lastIndex && cumulativeMeters < 5_000.0) {
                val a = route.points[end - 1]
                val b = route.points[end]
                Location.distanceBetween(a.latitude, a.longitude, b.latitude, b.longitude, distanceResult)
                cumulativeMeters += distanceResult[0]
                firstFixProgressMeters[end - 1] = cumulativeMeters
                end++
            }
            end.coerceAtMost(route.points.lastIndex)
        } else {
            // V184 : même principe pendant le guidage : la fenêtre de recherche vers
            // l'avant est exprimée en distance réelle et non plus en 120 points de polyline.
            // Cela garde un comportement stable sur une route très détaillée comme sur une
            // route peu découpée, sans autoriser un saut vers une portion lointaine du trajet.
            val distanceResult = FloatArray(1)
            var cumulativeForwardMeters = 0.0
            var end = (previous + 1).coerceAtMost(route.points.lastIndex)
            while (end < route.points.lastIndex && cumulativeForwardMeters < 3_000.0) {
                val a = route.points[end - 1]
                val b = route.points[end]
                Location.distanceBetween(a.latitude, a.longitude, b.latitude, b.longitude, distanceResult)
                cumulativeForwardMeters += distanceResult[0]
                end++
            }
            end.coerceAtMost(route.points.lastIndex)
        }

        var bestIndex = start
        var bestDistance = Double.POSITIVE_INFINITY
        var bestScore = Double.POSITIVE_INFINITY
        for (i in start until endExclusive) {
            val d = segmentDistance(i)
            val score = if (previous == null) {
                val progressMeters = firstFixProgressMeters[i] ?: 0.0
                d + progressMeters * 0.015
            } else d
            // V287 : sur deux portions du tracé qui se croisent ou restent parallèles,
            // quelques mètres d'écart GPS ne doivent pas suffire à faire sauter le suivi
            // vers une portion beaucoup plus avancée. Pendant le guidage, on conserve le
            // premier candidat tant que le suivant n'est pas réellement meilleur (4 m).
            val meaningfullyBetter = if (previous == null) {
                score < bestScore
            } else {
                d < bestDistance - 4.0
            }
            if (meaningfullyBetter) {
                bestScore = score
                bestDistance = d
                bestIndex = i
            }
        }

        // ETAPE 45 : la marche arrière du simulateur est la seule situation où la
        // progression validée a le droit de reculer. Cela permet de revenir avant un
        // rond-point terminé puis de le rejouer ; le GPS réel reste strictement monotone.
        if (simulationActive && simulationRewinding) {
            trackedRouteSegment = bestIndex
            lastTrackedLocation = Location(location)
            return@LaunchedEffect
        }

        if (previous == null) {
            // Premier fix (ou nouveau tracé) : recaler librement la navigation.
            trackedRouteSegment = bestIndex
            lastTrackedLocation = Location(location)
        } else if (bestIndex <= previous + 2) {
            // V161 : la progression validée ne recule plus. Un fix GPS légèrement en
            // arrière peut arriver à un carrefour ou entre deux rues parallèles ; revenir
            // de quelques segments pouvait alors faire réapparaître une instruction déjà
            // franchie. Un nouveau tracé remet toujours ce verrou à zéro via routeRevisionKey.
            trackedRouteSegment = kotlin.math.max(previous, bestIndex)
            lastTrackedLocation = Location(location)
        } else {
            val lastAccepted = lastTrackedLocation
            val physicalMoveMeters = if (lastAccepted != null)
                lastAccepted.distanceTo(location).toDouble() else 0.0
            val accuracyMargin = if (location.hasAccuracy())
                location.accuracy.toDouble().coerceIn(5.0, 65.0) else 35.0
            // V288 : un saut GPS ponctuel ne doit pas agrandir lui-même la fenêtre de
            // progression. Avant cette version, un faux déplacement de 800 m pouvait
            // autoriser plusieurs kilomètres d'avance sur la polyline puisque
            // physicalMoveMeters était multiplié par trois. On borne maintenant le
            // déplacement crédible avec le temps réellement écoulé entre les deux fixes.
            // 20 m/s (~72 km/h) laisse une marge très supérieure aux 45 km/h d'une VSP,
            // sans laisser un téléport GPS sélectionner une portion lointaine du trajet.
            val elapsedSinceAcceptedSeconds = if (
                lastAccepted != null &&
                lastAccepted.elapsedRealtimeNanos > 0L &&
                location.elapsedRealtimeNanos > lastAccepted.elapsedRealtimeNanos
            ) {
                (location.elapsedRealtimeNanos - lastAccepted.elapsedRealtimeNanos) / 1_000_000_000.0
            } else 1.0
            val plausibleMoveMeters = (elapsedSinceAcceptedSeconds.coerceIn(0.5, 10.0) * 20.0) + accuracyMargin
            val boundedPhysicalMoveMeters = physicalMoveMeters.coerceAtMost(plausibleMoveMeters)
            // À 45 km/h, deux fixes peuvent être espacés de plusieurs dizaines de mètres.
            // La marge de 70 m laisse passer un vrai virage tout en refusant un bond de
            // plusieurs centaines de mètres vers une portion parallèle du trajet.
            val allowedForwardMeters = kotlin.math.max(120.0, boundedPhysicalMoveMeters * 3.0 + accuracyMargin * 2.0 + 70.0)
            val requestedForwardMeters = routeDistanceBetweenSegments(previous, bestIndex)

            if (requestedForwardMeters <= allowedForwardMeters) {
                trackedRouteSegment = bestIndex
                lastTrackedLocation = Location(location)
            } else {
                // V191 : chercher le meilleur segment atteignable sans recalculer toute
                // la distance depuis `previous` à chaque point. L'ancienne boucle rappelait
                // routeDistanceBetweenSegments(previous, i) pour chaque candidat et pouvait
                // devenir coûteuse sur les polylines très détaillées. On cumule désormais
                // chaque segment une seule fois jusqu'à la limite physiquement atteignable.
                // V263 : ce bloc n’est exécuté que lorsqu’une progression précédente
                // existe. On verrouille explicitement ce contrat en Int non nullable :
                // aucune comparaison ou indexation de segment ne dépend plus d’un Int?.
                val previousIndex: Int = requireNotNull(previous)
                var safeIndex: Int = previousIndex
                val lastSegmentIndex = (route.points.lastIndex - 1).coerceAtLeast(0)
                var safeDistance = segmentDistance(previousIndex.coerceIn(0, lastSegmentIndex))
                val safeDistanceResult = FloatArray(1)
                var cumulativeSafeMeters = 0.0
                // V264 : ne jamais laisser la fenêtre de recalage dépasser les segments
                // réellement présents dans la polyline, même après un changement de route.
                val safeEndExclusive = endExclusive.coerceAtMost(route.points.size)
                for (i in (previousIndex + 1).coerceAtLeast(1) until safeEndExclusive) {
                    val a = route.points[i - 1]
                    val b = route.points[i]
                    Location.distanceBetween(a.latitude, a.longitude, b.latitude, b.longitude, safeDistanceResult)
                    cumulativeSafeMeters += safeDistanceResult[0]
                    if (cumulativeSafeMeters > allowedForwardMeters) break
                    val d = segmentDistance(i)
                    if (d < safeDistance) {
                        safeDistance = d
                        safeIndex = i
                    }
                }
                trackedRouteSegment = safeIndex
                // V263 : previousIndex et safeIndex restent des Int stricts pendant
                // toute la recherche de recalage, y compris dans la comparaison finale.
                // Ne pas mémoriser le fix comme progression confirmée s'il ressemble à
                // un saut parallèle : le prochain bon fix pourra recoller naturellement.
                if (safeIndex > previousIndex) lastTrackedLocation = Location(location)
            }
        }
    }

    // V157 : distance restante projetée sur le segment de route le plus proche.
    // Contrairement à la recherche du simple sommet de polyline le plus proche,
    // cette méthode évite les bonds de distance/ETA entre deux points du tracé et
    // reste cohérente immédiatement après un recalcul d'itinéraire.
    fun remainingDistanceMeters(location: Location?): Double {
        if (location == null || route.points.isEmpty()) return route.distanceMeters
        if (route.points.size == 1) {
            val result = FloatArray(1)
            Location.distanceBetween(
                location.latitude, location.longitude,
                route.points[0].latitude, route.points[0].longitude, result
            )
            return result[0].toDouble()
        }

        val lat0 = Math.toRadians(location.latitude)
        val earthRadius = 6_371_000.0
        fun localXY(point: GeoPoint): Pair<Double, Double> {
            val dLat = Math.toRadians(point.latitude - location.latitude)
            val dLon = Math.toRadians(point.longitude - location.longitude)
            return Pair(
                earthRadius * dLon * kotlin.math.cos(lat0),
                earthRadius * dLat
            )
        }

        // V186 : la fenêtre utilisée pour calculer distance restante / ETA suit désormais
        // la même logique physique que le suivi GPS V184. Les anciens +120 points dépendaient
        // trop de la densité de la polyline et pouvaient couvrir une distance très différente
        // selon la route. On cherche jusqu'à environ 3 km devant la progression validée.
        val progressAnchor = trackedRouteSegment
        val searchStart = progressAnchor?.let { (it - 2).coerceAtLeast(0) } ?: 0
        val searchEndExclusive = progressAnchor?.let { anchor ->
            val distanceResult = FloatArray(1)
            var cumulativeForwardMeters = 0.0
            var end = (anchor + 1).coerceAtMost(route.points.lastIndex)
            while (end < route.points.lastIndex && cumulativeForwardMeters < 3_000.0) {
                val a = route.points[end - 1]
                val b = route.points[end]
                Location.distanceBetween(a.latitude, a.longitude, b.latitude, b.longitude, distanceResult)
                cumulativeForwardMeters += distanceResult[0]
                end++
            }
            end.coerceAtMost(route.points.lastIndex)
        } ?: route.points.lastIndex

        var bestSegment = searchStart
        var bestT = 0.0
        var bestDistance = Double.POSITIVE_INFINITY
        for (i in searchStart until searchEndExclusive) {
            val (ax, ay) = localXY(route.points[i])
            val (bx, by) = localXY(route.points[i + 1])
            val vx = bx - ax
            val vy = by - ay
            val length2 = vx * vx + vy * vy
            val t = if (length2 > 0.0) {
                ((-ax * vx - ay * vy) / length2).coerceIn(0.0, 1.0)
            } else 0.0
            val px = ax + t * vx
            val py = ay + t * vy
            val d = kotlin.math.sqrt(px * px + py * py)
            if (d < bestDistance) {
                bestDistance = d
                bestSegment = i
                bestT = t
            }
        }

        val result = FloatArray(1)
        val a = route.points[bestSegment]
        val b = route.points[bestSegment + 1]
        Location.distanceBetween(a.latitude, a.longitude, b.latitude, b.longitude, result)
        var remaining = result[0].toDouble() * (1.0 - bestT)
        for (i in (bestSegment + 1) until route.points.lastIndex) {
            val p1 = route.points[i]
            val p2 = route.points[i + 1]
            Location.distanceBetween(p1.latitude, p1.longitude, p2.latitude, p2.longitude, result)
            remaining += result[0]
        }
        return remaining.coerceAtLeast(0.0)
    }

    val routeRemainingMeters = remainingDistanceMeters(liveLocation)

    // ETAPE 128 : le point d'un POI géocodé peut être situé au centre d'un bâtiment
    // ou d'une parcelle (mairie, magasin, hôpital...). Pour l'arrivée, on ne doit pas
    // demander au conducteur d'atteindre ce point non routier : le dernier point de la
    // géométrie Valhalla est l'emplacement réellement accroché au réseau carrossable.
    // Le point brut de destination reste uniquement un secours si la route est vide.
    val routedArrivalPoint = route.points.lastOrNull() ?: destination.point
    val distanceToDestinationMeters = liveLocation?.let { location ->
        val result = FloatArray(1)
        Location.distanceBetween(
            location.latitude, location.longitude,
            routedArrivalPoint.latitude, routedArrivalPoint.longitude,
            result
        )
        result[0].toDouble()
    } ?: Double.POSITIVE_INFINITY

    // Valhalla distingue l'arrivée générique (4), à droite (5) et à gauche (6).
    // On n'annonce donc jamais un côté si le moteur ne nous l'a pas explicitement fourni.
    val destinationSide = route.maneuvers.lastOrNull()?.type?.let { type ->
        when (type) {
            5 -> "droite"
            6 -> "gauche"
            else -> null
        }
    }
    // V162 : l'arrivée est verrouillée une fois confirmée par un fix suffisamment
    // précis. Un petit rebond GPS après l'arrivée ne doit plus réactiver une ancienne
    // consigne, un recalcul ou faire remonter distance/ETA.
    var arrivalReached by remember(routeRevisionKey) { mutableStateOf(false) }
    val arrivalAccuracy = liveLocation?.takeIf { it.hasAccuracy() }?.accuracy?.toDouble()
        ?: Double.POSITIVE_INFINITY
    // V168 : l’arrivée exige désormais un fix récent en plus d’une bonne précision.
    // Une ancienne position Android proche de la destination ne peut donc plus verrouiller
    // l’arrivée au démarrage ou après une interruption temporaire des mises à jour GPS.
    // V171 : être géographiquement proche de l'adresse ne suffit pas si l'itinéraire
    // repasse près de la destination avant sa fin (boucle, rues parallèles, accès à sens
    // unique). On exige aussi que la progression validée soit réellement dans la fin
    // du tracé. Cela évite une fausse arrivée alors qu'il reste encore une portion à suivre.
    val arrivalProgressNearEnd = routeRemainingMeters <= 120.0 ||
        (trackedRouteSegment?.let { it >= (route.points.lastIndex - 4).coerceAtLeast(0) } == true)
    val arrivalCandidate = gpsFixFresh &&
        arrivalProgressNearEnd &&
        distanceToDestinationMeters <= 45.0 &&
        arrivalAccuracy <= 65.0

    // V170 : une seule mesure GPS aberrante ne suffit plus à verrouiller l'arrivée.
    // Très près de la destination (<= 20 m), l'arrivée reste immédiate. Entre 20 et
    // 45 m, deux fixes frais consécutifs sont nécessaires. Cela conserve une arrivée
    // réactive tout en évitant un faux "Vous êtes arrivé" provoqué par un saut GPS.
    var arrivalCandidateMatches by remember(routeRevisionKey) { mutableStateOf(0) }
    // V172 : les deux confirmations d'arrivée doivent provenir de deux fixes réellement
    // distincts dans le temps. Deux mises à jour Compose quasi simultanées autour du même
    // fix ne peuvent donc plus valider l'arrivée à elles seules. À moins de 20 m, on garde
    // l'arrivée immédiate afin de ne pas rendre le guidage artificiellement lent.
    var lastArrivalCandidateFixTime by remember(routeRevisionKey) { mutableStateOf(0L) }
    // V174 : mémoriser le précédent candidat d'arrivée permet de vérifier que les deux
    // confirmations restent physiquement cohérentes. Deux fixes distincts mais séparés
    // par un grand saut GPS ne doivent jamais suffire à déclencher l'arrivée.
    var lastArrivalCandidateLat by remember(routeRevisionKey) { mutableStateOf<Double?>(null) }
    var lastArrivalCandidateLon by remember(routeRevisionKey) { mutableStateOf<Double?>(null) }
    LaunchedEffect(
        liveLocation?.latitude,
        liveLocation?.longitude,
        liveLocation?.time,
        gpsFixFresh,
        routeRevisionKey
    ) {
        if (arrivalReached) return@LaunchedEffect
        if (!arrivalCandidate) {
            arrivalCandidateMatches = 0
            lastArrivalCandidateFixTime = 0L
            lastArrivalCandidateLat = null
            lastArrivalCandidateLon = null
            return@LaunchedEffect
        }

        // V173 : même à moins de 20 m, l'arrivée n'est plus validée sur un seul fix.
        // Deux relevés GPS distincts sont toujours exigés. Très près de la destination,
        // le délai minimal reste court (300 ms) pour conserver une arrivée réactive ;
        // entre 20 et 45 m, on demande 700 ms afin de mieux filtrer un saut GPS isolé.
        val fixTime = liveLocation?.time ?: System.currentTimeMillis()
        val minArrivalConfirmationDelayMs = if (distanceToDestinationMeters <= 20.0) 300L else 700L
        if (lastArrivalCandidateFixTime == 0L) {
            arrivalCandidateMatches = 1
            lastArrivalCandidateFixTime = fixTime
            lastArrivalCandidateLat = liveLocation?.latitude
            lastArrivalCandidateLon = liveLocation?.longitude
        } else if (fixTime > lastArrivalCandidateFixTime &&
            fixTime - lastArrivalCandidateFixTime >= minArrivalConfirmationDelayMs
        ) {
            val previousLat = lastArrivalCandidateLat
            val previousLon = lastArrivalCandidateLon
            val currentLat = liveLocation?.latitude
            val currentLon = liveLocation?.longitude
            val candidateJumpMeters = if (previousLat != null && previousLon != null &&
                currentLat != null && currentLon != null
            ) {
                val result = FloatArray(1)
                Location.distanceBetween(previousLat, previousLon, currentLat, currentLon, result)
                result[0].toDouble()
            } else {
                Double.POSITIVE_INFINITY
            }

            // À 45 km/h, 700 ms représentent moins de 9 m. Une séparation > 30 m entre
            // deux candidats successifs est donc traitée comme un saut GPS et redémarre
            // la confirmation au lieu de valider une fausse arrivée.
            if (candidateJumpMeters <= 30.0) {
                arrivalCandidateMatches += 1
                if (arrivalCandidateMatches >= 2) arrivalReached = true
            } else {
                arrivalCandidateMatches = 1
            }
            lastArrivalCandidateFixTime = fixTime
            lastArrivalCandidateLat = currentLat
            lastArrivalCandidateLon = currentLon
        }
    }
    val arrivalConfirmed = arrivalReached
    var intermediateChargeHandled by remember(routeRevisionKey) { mutableStateOf(false) }
    LaunchedEffect(arrivalConfirmed, isIntermediateChargeStep, routeRevisionKey) {
        if (arrivalConfirmed && isIntermediateChargeStep && !intermediateChargeHandled) {
            intermediateChargeHandled = true
            onIntermediateChargeReached()
        } else if (arrivalConfirmed && !isIntermediateChargeStep) {
            // ETAPE 127 : LaunchedEffect ne se relance qu'au changement de l'état
            // d'arrivée / du tracé. On peut donc remonter l'arrivée finale sans ajouter
            // un nouvel état remember dans ce très gros composable de navigation.
            onFinalArrivalReached()
        }
    }

    // V157 : une arrivée confirmée force les trois indicateurs à leur état final.
    // Sinon distance, durée restante et heure d'arrivée reposent toutes sur la même
    // progression du NOUVEAU tracé, ce qui évite de conserver une ancienne estimation
    // après un recalcul.
    val currentLegRemainingMeters = if (arrivalConfirmed) 0.0 else routeRemainingMeters
    // V445 : une borne de recharge reste une étape technique. Les indicateurs principaux
    // (distance, temps restant et heure d'arrivée) continuent de représenter le voyage
    // complet jusqu'à la destination choisie par l'utilisateur.
    val remainingMeters = currentLegRemainingMeters +
        if (isIntermediateChargeStep) futureTripDistanceMeters.coerceAtLeast(0.0) else 0.0
    val distanceKm = remainingMeters / 1000.0
    val currentLegSeconds = if (arrivalConfirmed) {
        0.0
    } else if (route.distanceMeters > 0.0) {
        route.durationSeconds *
            (currentLegRemainingMeters / route.distanceMeters).coerceIn(0.0, 1.0)
    } else 0.0
    // Les futurs tronçons ont déjà été validés par le profil VSP. Tant qu'ils ne sont
    // pas encore actifs, on estime leur durée à la vitesse cible VSP de 45 km/h.
    val futureTripSeconds = if (isIntermediateChargeStep) {
        futureTripDistanceMeters.coerceAtLeast(0.0) / 12.5
    } else 0.0
    val minutes = vspDisplayMinutes(currentLegSeconds + futureTripSeconds)
    val displayedTripDestination = if (isIntermediateChargeStep) {
        finalTripDestination ?: destination
    } else destination

    // Cherche le prochain changement de direction significatif sur le tracé.
    fun nextTurnGuidance(location: Location?): ManeuverGuidance {
        if (location == null || route.points.isEmpty()) {
            return ManeuverGuidance("↑", "Continuez tout droit", "")
        }

        val result = FloatArray(1)

        // V122 : on se repère sur le SEGMENT réellement occupé, et non plus seulement
        // sur le sommet de polyline le plus proche. Cela évite qu'une manœuvre située
        // juste derrière le véhicule reste considérée comme la « prochaine ».
        val lat0 = Math.toRadians(location.latitude)
        val earthRadius = 6_371_000.0
        fun localXY(point: GeoPoint): Pair<Double, Double> {
            val dLat = Math.toRadians(point.latitude - location.latitude)
            val dLon = Math.toRadians(point.longitude - location.longitude)
            return Pair(
                earthRadius * dLon * kotlin.math.cos(lat0),
                earthRadius * dLat
            )
        }

        var nearestSegmentIndex = 0
        var nearestSegmentT = 0.0
        var nearestDistance = Double.POSITIVE_INFINITY

        if (route.points.size >= 2) {
            for (i in 0 until route.points.lastIndex) {
                val (ax, ay) = localXY(route.points[i])
                val (bx, by) = localXY(route.points[i + 1])
                val vx = bx - ax
                val vy = by - ay
                val lengthSquared = vx * vx + vy * vy
                val t = if (lengthSquared <= 0.0001) 0.0 else
                    ((-ax * vx - ay * vy) / lengthSquared).coerceIn(0.0, 1.0)
                val closestX = ax + t * vx
                val closestY = ay + t * vy
                val distance = kotlin.math.sqrt(closestX * closestX + closestY * closestY)
                if (distance < nearestDistance) {
                    nearestDistance = distance
                    nearestSegmentIndex = i
                    nearestSegmentT = t
                }
            }
        }

        fun distanceAlongRoute(toIndex: Int): Double {
            if (route.points.size < 2 || toIndex <= nearestSegmentIndex) return 0.0

            // Distance restante sur le segment où se trouve actuellement le véhicule.
            val a = route.points[nearestSegmentIndex]
            val b = route.points[nearestSegmentIndex + 1]
            Location.distanceBetween(a.latitude, a.longitude, b.latitude, b.longitude, result)
            var total = result[0] * (1.0 - nearestSegmentT)

            for (i in (nearestSegmentIndex + 1) until kotlin.math.min(toIndex, route.points.lastIndex)) {
                val p1 = route.points[i]
                val p2 = route.points[i + 1]
                Location.distanceBetween(
                    p1.latitude, p1.longitude,
                    p2.latitude, p2.longitude,
                    result
                )
                total += result[0]
            }
            return total
        }

        // ETAPE 52 : distance géométrique entre deux indices du tracé.
        // Sert à détecter les manœuvres très rapprochées (notamment deux ronds-points
        // séparés de moins de 100 m) sans dépendre de la position courante.
        fun distanceBetweenRouteIndices(fromIndex: Int, toIndex: Int): Double {
            if (route.points.size < 2 || toIndex <= fromIndex) return 0.0
            var total = 0.0
            val start = fromIndex.coerceIn(0, route.points.lastIndex)
            val end = toIndex.coerceIn(0, route.points.lastIndex)
            for (i in start until end) {
                if (i >= route.points.lastIndex) break
                val p1 = route.points[i]
                val p2 = route.points[i + 1]
                Location.distanceBetween(p1.latitude, p1.longitude, p2.latitude, p2.longitude, result)
                total += result[0]
            }
            return total
        }

        fun distanceLabel(meters: Double): String = when {
            // À moins de 30 m, on garde uniquement la consigne et la rue :
            // pas de texte « MAINTENANT » avant l’instruction.
            meters < 30 -> ""
            // ETAPE 38 : ne jamais afficher prématurément « 100 m » ou « 50 m ».
            // Au-dessus de 100 m on arrondit vers le palier supérieur : ainsi 149..101 m
            // restent affichés à 150 m et « 100 m » apparaît seulement lorsque la
            // distance réelle atteint effectivement le seuil vocal de 100 m.
            meters <= 100 -> "${(kotlin.math.ceil(meters / 10.0) * 10.0).toInt().coerceAtLeast(30)} m"
            meters < 1000 -> "${(kotlin.math.ceil(meters / 50.0) * 50.0).toInt()} m"
            else -> String.format(Locale.FRANCE, "%.1f km", meters / 1000.0)
        }

        // V156 : pour choisir la prochaine manœuvre, utiliser la progression suivie
        // lorsqu'elle est disponible. Le segment géométriquement le plus proche reste
        // utile pour calculer la distance précise, mais ne peut plus à lui seul faire
        // sauter vers une portion parallèle beaucoup plus loin dans le trajet.
        // ETAPE 51 : la simulation connaît exactement le segment qu'elle parcourt.
        // Utiliser ce segment comme source de vérité évite qu'un rond-point visible
        // soit ignoré parce que le map-matching a sélectionné une branche voisine ou
        // une portion plus avancée du même trajet. En GPS réel, on conserve le suivi
        // sécurisé trackedRouteSegment puis le segment géométrique en dernier recours.
        val guidanceSegmentIndex = if (simulationActive) {
            simulationRouteSegment.coerceIn(0, (route.points.lastIndex - 1).coerceAtLeast(0))
        } else {
            trackedRouteSegment ?: nearestSegmentIndex
        }

        // V160 : une arrivée réellement confirmée est prioritaire sur une éventuelle
        // dernière manœuvre Valhalla encore présente. Cela évite de conserver une
        // consigne de virage alors que la destination est déjà atteinte.
        if (arrivalConfirmed) {
            val arrivalTitle = if (isIntermediateChargeStep) {
                "Étape recharge atteinte"
            } else {
                destinationSide?.let { "Destination à $it" } ?: "Vous êtes arrivé"
            }
            val arrivalVoice = if (isIntermediateChargeStep) {
                "Étape recharge atteinte."
            } else {
                destinationSide?.let {
                    "Vous êtes arrivé à destination. Votre destination se trouve sur votre $it."
                } ?: "Vous êtes arrivé à destination."
            }
            return ManeuverGuidance(
                arrow = if (isIntermediateChargeStep) "⚡" else "🏁",
                title = arrivalTitle,
                distanceText = destination.label,
                distanceMeters = 0.0,
                spokenTitle = arrivalVoice,
                voiceKey = "arrival:${destination.label}:${destinationSide ?: "unknown"}"
            )
        }

        // V185 : distinguer explicitement la manœuvre en cours de la prochaine.
        // Une manœuvre reste active pendant toute sa plage begin/end (utile notamment
        // dans les ronds-points), puis on passe uniquement à la suivante. Cela remplace
        // la tolérance fixe de 2 segments, trop dépendante du découpage de la polyline,
        // tout en empêchant le retour vers une consigne déjà dépassée.
        // V302 : ne conserver une manœuvre déjà commencée comme consigne active que
        // pour les ronds-points. Pour un virage classique, garder la manœuvre jusqu'à
        // endShapeIndex pouvait laisser « Tournez... » affiché après que le virage était
        // déjà effectué. Une fois beginShapeIndex franchi, on prépare donc la suivante.
        // V303 : V302 passait à la consigne suivante dès que le segment suivi atteignait
        // exactement beginShapeIndex. Avec le recalage GPS, cela pouvait arriver juste
        // AVANT le virage et afficher prématurément l'étape suivante. Pour un virage
        // classique, conserver la consigne sur une très courte fenêtre (au maximum un
        // segment après beginShapeIndex), puis basculer. Les ronds-points gardent leur
        // plage complète begin/end afin de suivre correctement l'entrée et la sortie.
        // ETAPE 45 : un rond-point doit devenir définitivement "passé" dès que le
        // véhicule a franchi son point de sortie. Les endShapeIndex Valhalla peuvent
        // continuer loin sur la rue suivante : ils ne sont donc pas utilisés pour
        // maintenir artificiellement le rond-point actif après sa sortie.
        // ETAPE 54 : deux ronds-points successifs peuvent être représentés par des
        // manœuvres Valhalla contiguës. Il ne faut surtout pas les fusionner en un seul
        // groupe : sinon la sortie du premier marque aussi le second comme terminé.
        // Un groupe commence sur kRoundaboutEnter (26) et s'arrête AVANT le prochain
        // kRoundaboutEnter. kRoundaboutExit (27) appartient uniquement à ce groupe.
        fun roundaboutGroupBounds(index: Int): IntRange? {
            if (index !in route.maneuvers.indices || !isValhallaRoundabout(route.maneuvers[index].type)) return null
            var first = index
            if (route.maneuvers[index].type == 27) {
                var i = index - 1
                while (i >= 0 && isValhallaRoundabout(route.maneuvers[i].type)) {
                    if (route.maneuvers[i].type == 26) { first = i; break }
                    i--
                }
            }
            var last = first
            var j = first + 1
            while (j < route.maneuvers.size) {
                val type = route.maneuvers[j].type
                if (!isValhallaRoundabout(type) || type == 26) break
                last = j
                if (type == 27) break
                j++
            }
            return first..last
        }

        fun roundaboutExitIndexFor(maneuver: RouteManeuver): Int? {
            val index = route.maneuvers.indexOf(maneuver)
            val bounds = roundaboutGroupBounds(index) ?: return null
            return bounds.asSequence()
                .map { route.maneuvers[it] }
                .firstOrNull { it.type == 27 }
                ?.beginShapeIndex
                ?: route.maneuvers[bounds.last].endShapeIndex
        }

        fun hasPassedShapeIndex(shapeIndex: Int): Boolean {
            // nearestSegmentT permet de distinguer "j'arrive sur le segment de sortie"
            // de "j'ai réellement commencé à rouler dessus". En simulation il est
            // particulièrement précis ; avec le GPS réel, trackedRouteSegment garde le
            // verrou anti-saut sur les routes parallèles.
            if (guidanceSegmentIndex > shapeIndex) return true
            return guidanceSegmentIndex == shapeIndex &&
                nearestSegmentIndex == shapeIndex && nearestSegmentT >= 0.12
        }

        fun roundaboutAlreadyCompleted(maneuver: RouteManeuver): Boolean {
            val exitIndex = roundaboutExitIndexFor(maneuver) ?: return false
            return hasPassedShapeIndex(exitIndex)
        }

        // ETAPE 48 : progression STRICTEMENT séquentielle des manœuvres.
        // Les étapes 45/46 avaient sécurisé la fin d'un rond-point, mais la recherche
        // globale par plage begin/end pouvait ensuite sélectionner une manœuvre beaucoup
        // plus loin lorsque des plages Valhalla se chevauchaient. Résultat : plusieurs
        // ronds-points intermédiaires pouvaient être ignorés.
        //
        // On choisit maintenant la manœuvre active la PLUS AVANCÉE réellement commencée,
        // puis, à défaut, la PREMIÈRE manœuvre future dans l'ordre du trajet. Aucun saut
        // vers une étape ultérieure n'est donc possible simplement parce que son end index
        // englobe la position courante.
        val indexedManeuvers = route.maneuvers.withIndex()

        fun maneuverCanGuide(m: RouteManeuver): Boolean =
            !isValhallaStart(m.type) &&
                (!isValhallaArrival(m.type) || routeRemainingMeters <= 120.0) &&
                m.beginShapeIndex in route.points.indices &&
                !(isValhallaRoundabout(m.type) && roundaboutAlreadyCompleted(m))

        // ETAPE 53 : ne plus chercher la manœuvre "la plus avancée" parmi toutes
        // les plages qui chevauchent la position. Les endShapeIndex Valhalla peuvent
        // recouvrir plusieurs étapes et cette stratégie sautait alors des ronds-points.
        // On parcourt désormais la liste Valhalla DANS SON ORDRE et on prend la
        // première manœuvre qui n'est pas réellement terminée.
        fun maneuverCompletionIndex(m: RouteManeuver): Int {
            return if (isValhallaRoundabout(m.type)) {
                roundaboutExitIndexFor(m) ?: m.endShapeIndex
            } else {
                // Pour un virage classique, un segment après begin suffit à considérer
                // l'action effectuée ; on n'utilise jamais un endShapeIndex très lointain.
                kotlin.math.min(m.endShapeIndex, m.beginShapeIndex + 1)
            }
        }

        // ETAPE 102 : verrou séquentiel des ronds-points rapprochés.
        // Quand deux ronds-points ne sont séparés que de quelques mètres, une manœuvre
        // générique située entre les deux (ou des plages Valhalla qui se chevauchent)
        // ne doit jamais permettre au guidage de sélectionner le second avant d'avoir
        // réellement franchi la sortie du premier.
        //
        // On cherche donc d'abord le PREMIER groupe de rond-point non terminé dans
        // l'ordre Valhalla. S'il a déjà commencé, ou si son entrée est la prochaine
        // action réelle devant le véhicule, il devient prioritaire. Le groupe suivant
        // ne pourra prendre la main qu'après hasPassedShapeIndex(sortieDuPremier).
        val firstPendingRoundaboutIndexed = indexedManeuvers
            .asSequence()
            .filter { isValhallaRoundabout(it.value.type) }
            .filter { maneuverCanGuide(it.value) }
            .firstOrNull { indexed ->
                val exit = roundaboutExitIndexFor(indexed.value)
                    ?: maneuverCompletionIndex(indexed.value)
                !hasPassedShapeIndex(exit)
            }

        val normalUpcomingIndexed = indexedManeuvers
            .asSequence()
            .filter { maneuverCanGuide(it.value) }
            .firstOrNull { indexed ->
                val m = indexed.value
                val completion = maneuverCompletionIndex(m)
                // Future manœuvre, ou manœuvre actuellement en cours.
                guidanceSegmentIndex < m.beginShapeIndex || !hasPassedShapeIndex(completion)
            }

        val upcomingIndexed = firstPendingRoundaboutIndexed?.let { roundaboutIndexed ->
            val normal = normalUpcomingIndexed
            // Le rond-point est prioritaire seulement s'il est déjà commencé ou s'il
            // n'existe aucune autre vraie manœuvre avant son entrée. Cela conserve le
            // guidage normal sur les virages qui précèdent réellement le rond-point.
            val roundaboutBegin = roundaboutGroupBounds(roundaboutIndexed.index)?.first
                ?.let { route.maneuvers[it].beginShapeIndex }
                ?: roundaboutIndexed.value.beginShapeIndex
            val normalBegin = normal?.value?.beginShapeIndex ?: Int.MAX_VALUE
            if (guidanceSegmentIndex >= roundaboutBegin || roundaboutBegin <= normalBegin) {
                roundaboutIndexed
            } else normal
        } ?: normalUpcomingIndexed

        val upcoming = upcomingIndexed?.value

        if (upcoming != null) {

            // V416 : le type Valhalla est la source de vérité pour le sens de la
            // manœuvre. L'ancienne table droite/gauche était inversée (les types 9-11
            // sont des virages à droite, 14-16 des virages à gauche). De plus, un
            // roundabout_exit_count isolé ne suffit plus à inventer un rond-point :
            // seuls kRoundaboutEnter/kRoundaboutExit (26/27) l'autorisent.
            val isRoundabout = isValhallaRoundabout(upcoming.type)

            // V443 / étape 43 : un rond-point est traité comme une séquence complète.
            // On ne se contente plus de la manœuvre voisine : on regroupe toutes les
            // manœuvres Valhalla de rond-point contiguës, puis on récupère la première
            // vraie voie APRÈS le rond-point pour le nom de sortie. Cela évite de
            // réutiliser le nom d'un rond-point précédent.
            val upcomingIndex = route.maneuvers.indexOf(upcoming)
            val roundaboutGroup = if (isRoundabout && upcomingIndex >= 0) {
                roundaboutGroupBounds(upcomingIndex)
                    ?.map { route.maneuvers[it] }
                    .orEmpty()
            } else emptyList()

            // ETAPE 44 : pour un rond-point Valhalla, le point de sortie fiable est
            // le DEBUT de kRoundaboutExit (type 27), pas son endShapeIndex. Ce dernier
            // peut s'étendre sur la voie suivante et produisait le faux « 5,0 km ».
            val roundaboutEntryShapeIndex = roundaboutGroup
                .firstOrNull { it.type == 26 }?.beginShapeIndex
                ?: roundaboutGroup.minOfOrNull { it.beginShapeIndex }
                ?: upcoming.beginShapeIndex
            val roundaboutExitManeuver = roundaboutGroup.firstOrNull { it.type == 27 }
            val roundaboutExitShapeIndex = roundaboutExitManeuver?.beginShapeIndex
                ?: roundaboutGroup.maxOfOrNull { it.endShapeIndex }
                ?: upcoming.endShapeIndex
            val afterRoundaboutManeuver = if (roundaboutGroup.isNotEmpty()) {
                val lastIndex = route.maneuvers.indexOf(roundaboutGroup.last())
                route.maneuvers.drop(lastIndex + 1).firstOrNull { !isValhallaRoundabout(it.type) }
            } else null

            // ETAPE 52 : préparer aussi le rond-point suivant lorsqu'il arrive presque
            // immédiatement après celui en cours. On parcourt la liste Valhalla dans
            // l'ordre et on ne combine que le PREMIER prochain groupe de rond-point.
            val closeNextRoundabout = if (roundaboutGroup.isNotEmpty()) {
                val lastIndex = route.maneuvers.indexOf(roundaboutGroup.last())
                val nextRoundaboutIndex = ((lastIndex + 1) until route.maneuvers.size)
                    .firstOrNull { isValhallaRoundabout(route.maneuvers[it].type) }
                nextRoundaboutIndex?.let { nextIndex ->
                    val next = route.maneuvers[nextIndex]
                    val gapMeters = distanceBetweenRouteIndices(roundaboutExitShapeIndex, next.beginShapeIndex)
                    if (gapMeters in 0.0..120.0) {
                        var j = nextIndex
                        val group = mutableListOf<RouteManeuver>()
                        while (j < route.maneuvers.size && isValhallaRoundabout(route.maneuvers[j].type)) {
                            group += route.maneuvers[j]
                            j++
                        }
                        val exits = group.firstOrNull { it.type == 27 }
                            ?.roundaboutExitCount?.takeIf { it > 0 }
                            ?: group.firstOrNull { it.type == 26 }
                                ?.roundaboutExitCount?.takeIf { it > 0 }
                            ?: next.roundaboutExitCount.coerceAtLeast(0)
                        Pair(gapMeters, exits)
                    } else null
                }
            } else null

            val insideRoundabout = isRoundabout &&
                guidanceSegmentIndex >= roundaboutEntryShapeIndex &&
                guidanceSegmentIndex <= roundaboutExitShapeIndex

            // Trois phases : approche (jusqu'à l'entrée), circulation dans l'anneau,
            // puis sortie imminente. Le nom de rue n'apparaît que dans cette dernière
            // phase, quand il devient réellement utile.
            val metersToEntry = distanceAlongRoute(roundaboutEntryShapeIndex)
            val metersToExit = distanceAlongRoute(roundaboutExitShapeIndex)
            // ETAPE 44 : annoncer la sortie suffisamment tôt pour que la phrase TTS
            // soit utile, mais uniquement une fois réellement engagé dans l'anneau.
            val exitNow = insideRoundabout && metersToExit <= 35.0
            val meters = when {
                !isRoundabout -> distanceAlongRoute(upcoming.beginShapeIndex)
                !insideRoundabout -> metersToEntry
                else -> metersToExit
            }

            // ETAPE 55 : le compteur porté par kRoundaboutExit (type 27) est prioritaire.
            // Prendre le premier compteur non nul du groupe pouvait utiliser celui de
            // kRoundaboutEnter (type 26) et annoncer « 2e sortie » alors que la sortie
            // réellement empruntée était la 1re. On ne fait surtout pas un -1 global :
            // chaque rond-point conserve le numéro fourni pour SA manœuvre de sortie.
            val resolvedRoundaboutExitCount = if (isRoundabout) {
                roundaboutExitManeuver?.roundaboutExitCount?.takeIf { it > 0 }
                    ?: roundaboutGroup.firstOrNull { it.type == 26 }
                        ?.roundaboutExitCount?.takeIf { it > 0 }
                    ?: upcoming.roundaboutExitCount.coerceAtLeast(0)
            } else 0

            // ETAPE 106 : aucune seconde correction dans l'UI.
            // `roundaboutExitCount` contient déjà le résultat topologique V105 quand le trajet
            // vient du moteur local. Affichage, voix et tests consomment exactement cette valeur.
            val roundaboutExitCountUncertain = false
            val effectiveRoundaboutExitCount = resolvedRoundaboutExitCount

            val effectiveRoundaboutRoad = simplifiedGuidanceRoadName(
                if (isRoundabout) {
                    // La manœuvre de sortie porte généralement la vraie voie empruntée.
                    // Elle est prioritaire sur la manœuvre suivante, qui peut commencer
                    // beaucoup plus loin et décrire une autre rue.
                    roundaboutExitManeuver?.streetNames?.takeIf { it.isNotBlank() }
                        ?: afterRoundaboutManeuver?.streetNames?.takeIf { it.isNotBlank() }
                        ?: ""
                } else upcoming.streetNames
            )

            // V419 : une seule source de vérité pour l’icône de manœuvre.
            // L’écran de guidage réutilise désormais exactement la même table Valhalla
            // que les autres affichages, ce qui empêche une future divergence droite/gauche
            // entre deux parties de l’interface.
            val arrow = maneuverArrow(upcoming.type)

            val fullInstruction = upcoming.instruction.ifBlank { "Continuez" }

            // ETAPE 107 : uniquement les VRAIS virages 9/10/11 et 14/15/16 sont
            // reformulés en « Tournez ... ». Les rampes, sorties, « stay » et fusions
            // gardent le texte Odin afin de ne plus transformer « Gardez la route »
            // en faux virage gauche/droite.
            // V420 : pour les virages directionnels, le type Valhalla reste la source
            // de vérité jusque dans le TEXTE et la voix. Ainsi, même si le libellé
            // renvoyé par le serveur est ambigu, traduit différemment ou contradictoire,
            // l'application ne peut plus afficher une flèche à droite tout en disant
            // « gauche » (ou inversement). La rue reste ajoutée séparément.
            val canonicalDirectionTitle = when {
                isValhallaRightTurn(upcoming.type) -> "Tournez à droite"
                isValhallaLeftTurn(upcoming.type) -> "Tournez à gauche"
                isValhallaUTurn(upcoming.type) -> "Faites demi-tour"
                else -> null
            }
            val canonicalDirectionSpoken = canonicalDirectionTitle?.let { direction ->
                val road = simplifiedGuidanceRoadName(upcoming.streetNames)
                if (road.isNotBlank()) "$direction $road" else direction
            }

            // Affichage court façon GPS : la consigne principale et la voie sont séparées.
            // La synthèse vocale conserve, elle, l'instruction Valhalla complète.
            val visualTitle = when {
                // V442 / étape 42 : le numéro de sortie est annoncé AVANT le rond-point.
                // Une fois engagé, l'action utile n'est plus de recompter les sorties mais
                // d'identifier clairement la sortie à prendre maintenant.
                isRoundabout && exitNow -> "Prenez la sortie"
                isRoundabout && roundaboutExitCountUncertain && insideRoundabout -> "Continuez tout droit"
                isRoundabout && roundaboutExitCountUncertain -> "Au rond-point, continuez tout droit"
                isRoundabout && insideRoundabout && effectiveRoundaboutExitCount > 0 ->
                    "Prenez la ${roundaboutExitVisualLabel(effectiveRoundaboutExitCount)} sortie"
                isRoundabout && effectiveRoundaboutExitCount > 0 ->
                    "Au rond-point, prenez la ${roundaboutExitVisualLabel(effectiveRoundaboutExitCount)} sortie"
                isRoundabout -> "Au rond-point"
                canonicalDirectionTitle != null -> canonicalDirectionTitle
                else -> compactVisualInstruction(fullInstruction)
            }

            // Pour les ronds-points, on construit nous-mêmes l'annonce vocale afin
            // que le numéro de sortie soit toujours clairement prononcé.
            val spokenInstruction = when {
                // V442 / étape 42 : deux phases vocales distinctes.
                // Approche : annoncer le numéro de sortie dès le seuil de 100 m.
                // Dans le rond-point : annoncer la sortie et son nom, sans répéter le numéro.
                isRoundabout && exitNow -> {
                    val road = effectiveRoundaboutRoad.trim()
                    if (road.isNotBlank()) "Prenez la sortie, $road" else "Prenez la sortie"
                }
                isRoundabout && roundaboutExitCountUncertain && insideRoundabout -> "Continuez tout droit"
                isRoundabout && roundaboutExitCountUncertain -> "Au rond-point, continuez tout droit"
                isRoundabout && insideRoundabout && effectiveRoundaboutExitCount > 0 -> {
                    val spokenExitLabel = roundaboutExitSpokenLabel(effectiveRoundaboutExitCount)
                    "Prenez la $spokenExitLabel sortie"
                }
                isRoundabout && effectiveRoundaboutExitCount > 0 -> {
                    val spokenExitLabel = roundaboutExitSpokenLabel(effectiveRoundaboutExitCount)
                    val base = "Au rond-point, prenez la $spokenExitLabel sortie"
                    // ETAPE 52 : si un second rond-point suit à <= 120 m, l'annoncer
                    // dès la préparation du premier. À la sortie du premier, la progression
                    // séquentielle de l'étape 51 basculera immédiatement sur le second,
                    // qui conservera ensuite ses propres phases entrée/sortie.
                    val nextExitCount = closeNextRoundabout?.second ?: 0
                    if (!insideRoundabout && nextExitCount > 0) {
                        val nextLabel = roundaboutExitSpokenLabel(nextExitCount)
                        "$base. Puis, au rond-point suivant, prenez la $nextLabel sortie"
                    } else base
                }
                isRoundabout -> "Au rond-point"
                canonicalDirectionSpoken != null -> canonicalDirectionSpoken
                else -> fullInstruction
            }

            val distanceText = distanceLabel(meters)
            val roadText = when {
                isRoundabout && exitNow && effectiveRoundaboutRoad.isNotBlank() && distanceText.isNotBlank() ->
                    "$distanceText • $effectiveRoundaboutRoad"
                isRoundabout && exitNow && effectiveRoundaboutRoad.isNotBlank() -> effectiveRoundaboutRoad
                isRoundabout -> distanceText
                effectiveRoundaboutRoad.isNotBlank() && distanceText.isNotBlank() ->
                    "$distanceText • $effectiveRoundaboutRoad"
                effectiveRoundaboutRoad.isNotBlank() -> effectiveRoundaboutRoad
                else -> distanceText
            }

            // ETAPE 88 : préparer une indication « Ensuite » lorsque la prochaine
            // vraie action arrive à moins de 250 m. Pour un rond-point, on saute toutes
            // les manœuvres internes du groupe afin de ne jamais afficher sa propre
            // sortie comme une nouvelle étape. Cette information reste 100 % visuelle.
            val currentLogicalLastIndex = if (isRoundabout && roundaboutGroup.isNotEmpty()) {
                route.maneuvers.indexOf(roundaboutGroup.last())
            } else upcomingIndex
            val nextVisualManeuver = route.maneuvers
                .drop((currentLogicalLastIndex + 1).coerceAtLeast(0))
                .firstOrNull { candidate ->
                    !isValhallaStart(candidate.type) &&
                        !isValhallaArrival(candidate.type) &&
                        candidate.beginShapeIndex in route.points.indices
                }
            val nextVisualGapMeters = nextVisualManeuver?.let { candidate ->
                val fromIndex = if (isRoundabout) roundaboutExitShapeIndex else upcoming.beginShapeIndex
                distanceBetweenRouteIndices(fromIndex, candidate.beginShapeIndex)
            }
            val nextVisualText88 = if (nextVisualManeuver != null &&
                nextVisualGapMeters != null && nextVisualGapMeters in 0.0..250.0) {
                val nextRoad = simplifiedGuidanceRoadName(nextVisualManeuver.streetNames)
                val nextAction = when {
                    isValhallaRoundabout(nextVisualManeuver.type) -> {
                        val count = nextVisualManeuver.roundaboutExitCount.coerceAtLeast(0)
                        if (count > 0) "rond-point, ${roundaboutExitVisualLabel(count)} sortie" else "rond-point"
                    }
                    isValhallaRightTurn(nextVisualManeuver.type) -> "tournez à droite"
                    isValhallaLeftTurn(nextVisualManeuver.type) -> "tournez à gauche"
                    isValhallaUTurn(nextVisualManeuver.type) -> "faites demi-tour"
                    else -> compactVisualInstruction(nextVisualManeuver.instruction)
                        .lowercase()
                }
                buildString {
                    append("Ensuite : ")
                    append(nextAction)
                    if (nextRoad.isNotBlank() && !isValhallaRoundabout(nextVisualManeuver.type)) append(" • $nextRoad")
                    // ETAPE 110 : espace insécable entre la valeur et l’unité afin
                    // d’éviter un « m » isolé sur la ligne suivante dans l’encart Ensuite.
                    val nextDistanceLabel110 = distanceLabel(nextVisualGapMeters)
                        .replace(" ", "\u00A0")
                    append(" • $nextDistanceLabel110")
                }
            } else null

            return ManeuverGuidance(
                arrow = arrow,
                title = visualTitle,
                distanceText = roadText,
                distanceMeters = meters,
                cameraRoundaboutPhase = if (isRoundabout) {
                    when {
                        exitNow -> "exit"
                        insideRoundabout -> "inside"
                        else -> "approach"
                    }
                } else null,
                visualRoundaboutExitLabel = if (isRoundabout && effectiveRoundaboutExitCount > 0) {
                    roundaboutExitVisualLabel(effectiveRoundaboutExitCount)
                } else null,
                nextVisualArrow = nextVisualManeuver?.takeIf { nextVisualText88 != null }?.let { maneuverArrow(it.type) },
                nextVisualText = nextVisualText88,
                spokenTitle = spokenInstruction,
                voiceKey = "${upcoming.beginShapeIndex}:${upcoming.endShapeIndex}:${upcoming.type}:$effectiveRoundaboutExitCount:${when { exitNow -> "exit-now"; insideRoundabout -> "inside"; else -> "approach" }}"
            )
        }

        return ManeuverGuidance("↑", "Continuez", "vers ${destination.label}")
    }

    // V120 : retourne le segment de tracé le plus proche et sa distance au GPS.
    // Cette information sert uniquement à sécuriser la reprise après un signal faible.
    fun nearestRouteSegment(location: Location?): Pair<Int, Double>? {
        if (location == null || route.points.size < 2) return null
        val lat0 = Math.toRadians(location.latitude)
        val earthRadius = 6_371_000.0
        fun localXY(point: GeoPoint): Pair<Double, Double> {
            val dLat = Math.toRadians(point.latitude - location.latitude)
            val dLon = Math.toRadians(point.longitude - location.longitude)
            return Pair(
                earthRadius * dLon * kotlin.math.cos(lat0),
                earthRadius * dLat
            )
        }

        var bestIndex = -1
        var bestDistance = Double.POSITIVE_INFINITY
        for (i in 0 until route.points.lastIndex) {
            val (ax, ay) = localXY(route.points[i])
            val (bx, by) = localXY(route.points[i + 1])
            val vx = bx - ax
            val vy = by - ay
            val lengthSquared = vx * vx + vy * vy
            val t = if (lengthSquared <= 0.0001) 0.0 else
                ((-ax * vx - ay * vy) / lengthSquared).coerceIn(0.0, 1.0)
            val closestX = ax + t * vx
            val closestY = ay + t * vy
            val distance = kotlin.math.sqrt(closestX * closestX + closestY * closestY)
            if (distance < bestDistance) {
                bestDistance = distance
                bestIndex = i
            }
        }
        return if (bestIndex >= 0) bestIndex to bestDistance else null
    }

    // V107 : mesure la distance jusqu'au SEGMENT de route le plus proche.
    // L'ancienne version comparait uniquement la position aux sommets de la polyline :
    // sur une longue portion droite, un conducteur pourtant sur la route pouvait donc
    // être déclaré à tort "hors itinéraire" entre deux sommets.
    fun distanceFromRouteMeters(location: Location?): Double {
        if (location == null || route.points.isEmpty()) return 0.0
        if (route.points.size == 1) {
            return distanceMetersBetween(
                GeoPoint(location.latitude, location.longitude),
                route.points.first()
            )
        }

        val lat0 = Math.toRadians(location.latitude)
        val earthRadius = 6_371_000.0
        fun localXY(point: GeoPoint): Pair<Double, Double> {
            val dLat = Math.toRadians(point.latitude - location.latitude)
            val dLon = Math.toRadians(point.longitude - location.longitude)
            return Pair(
                earthRadius * dLon * kotlin.math.cos(lat0),
                earthRadius * dLat
            )
        }

        var nearest = Double.POSITIVE_INFINITY
        for (i in 0 until route.points.lastIndex) {
            val (ax, ay) = localXY(route.points[i])
            val (bx, by) = localXY(route.points[i + 1])
            val vx = bx - ax
            val vy = by - ay
            val lengthSquared = vx * vx + vy * vy
            val t = if (lengthSquared <= 0.0001) 0.0 else
                ((-ax * vx - ay * vy) / lengthSquared).coerceIn(0.0, 1.0)
            val closestX = ax + t * vx
            val closestY = ay + t * vy
            val distance = kotlin.math.sqrt(closestX * closestX + closestY * closestY)
            if (distance < nearest) nearest = distance
        }
        return nearest
    }

    val distanceFromRoute = distanceFromRouteMeters(liveLocation)

    val gpsAccuracyMeters = liveLocation
        ?.takeIf { it.hasAccuracy() }
        ?.accuracy
        ?.toDouble()
        ?: Double.POSITIVE_INFINITY

    // V147/V163 : trois zones d'hystérésis évitent l'effet yo-yo autour d'un seuil unique.
    // V163 conserve volontairement les seuils validés : on fiabilise les consommateurs
    // (écran/voix/progression) sans rallonger la reprise GPS corrigée en V153.
    // <= 65 m : le fix reste exploitable ; > 75 m : suspension immédiate.
    // Entre 65 et 75 m, on conserve le guidage pendant 10 s si le GPS était déjà
    // bon, ce qui absorbe les pointes momentanées fréquentes en ville.
    LaunchedEffect(gpsAccuracyMeters) {
        when {
            gpsAccuracyMeters <= 65.0 -> {
                marginalGpsSince = null
                gpsSignalUsable = true
            }
            gpsAccuracyMeters > 75.0 -> {
                marginalGpsSince = null
                gpsSignalUsable = false
            }
            gpsSignalUsable -> {
                if (marginalGpsSince == null) marginalGpsSince = android.os.SystemClock.elapsedRealtime()
                val startedAt = marginalGpsSince ?: android.os.SystemClock.elapsedRealtime()
                kotlinx.coroutines.delay(10_000L)
                if (gpsAccuracyMeters > 65.0 && android.os.SystemClock.elapsedRealtime() - startedAt >= 9_500L) {
                    gpsSignalUsable = false
                }
            }
            else -> gpsSignalUsable = false
        }
    }

    // V410 : un ancien fix précis ne doit pas rester fiable indéfiniment à l'arrêt.
    // V282 autorisait stationaryPreciseFix sans limite d'âge : après une vraie perte
    // de satellites, l'application pouvait donc conserver « GPS précis » et continuer
    // à considérer la position comme exploitable. On garde la tolérance de 2 minutes
    // prévue pour un véhicule immobile, puis le fix est réellement déclaré perdu.
    val stationaryFixAgeMs = if (lastGpsFixAtElapsed > 0L) {
        (android.os.SystemClock.elapsedRealtime() - lastGpsFixAtElapsed).coerceAtLeast(0L)
    } else Long.MAX_VALUE
    // V413 : ne jamais déduire l'immobilité d'une vitesse absente. speedKmh vaut 0
    // aussi quand Android ne fournit pas Location.speed ; cela contournait la règle V411
    // et pouvait conserver un ancien fix précis pendant 2 minutes. La tolérance longue
    // exige maintenant une vitesse GPS réellement présente et < 0,5 m/s.
    val stationaryPreciseFix = liveLocation?.let { location ->
        location.hasSpeed() &&
            location.speed < 0.5f &&
            gpsAccuracyMeters <= 35.0 &&
            stationaryFixAgeMs <= 120_000L
    } ?: false
    val gpsFixReliable = gpsSignalUsable && (gpsFixFresh || stationaryPreciseFix)
    val routeRecoveryToleranceMeters = when {
        gpsAccuracyMeters <= 15.0 -> 35.0
        gpsAccuracyMeters <= 35.0 -> 55.0
        gpsAccuracyMeters <= 65.0 -> 85.0
        else -> 100.0
    }

    // V146 : récupération automatique après une vraie perte de précision GPS.
    // Dès qu'un fix exploitable revient, la cohérence avec le tracé est réévaluée.
    // V153 : inclure l'état de fiabilité GPS dans les clés de l'effet.
    // Sans cette clé, quand gpsSignalUsable repassait de false à true sur le même fix,
    // cet effet pouvait ne jamais être relancé et laisser le guidage en stabilisation.
    LaunchedEffect(
        liveLocation?.latitude,
        liveLocation?.longitude,
        liveLocation?.accuracy,
        gpsFixReliable,
        routeRevisionKey
    ) {
        if (!gpsFixReliable) {
            gpsNavigationReady = false
            recoverySegmentIndex = null
            recoverySegmentMatches = 0
            offRouteSince = null
        } else if (!gpsNavigationReady) {
            val nearest = nearestRouteSegment(liveLocation)
            if (nearest == null || nearest.second > routeRecoveryToleranceMeters) {
                recoverySegmentIndex = null
                recoverySegmentMatches = 0
            } else {
                val segment = nearest.first
                // V148 : reprise plus rapide après stabilisation sans perdre la
                // protection V147 contre les faux recalculs. Un fix <= 25 m cohérent
                // avec le tracé reprend immédiatement. Entre 25 et 35 m, deux fixes
                // cohérents suffisent ; au-delà, on garde trois confirmations.
                if (gpsAccuracyMeters <= 25.0) {
                    recoverySegmentIndex = segment
                    recoverySegmentMatches = 3
                    gpsNavigationReady = true
                    offRouteSince = null
                } else {
                    if (segment == recoverySegmentIndex) {
                        recoverySegmentMatches += 1
                    } else {
                        recoverySegmentIndex = segment
                        recoverySegmentMatches = 1
                    }
                    val requiredRecoveryMatches = if (gpsAccuracyMeters <= 35.0) 2 else 3
                    if (recoverySegmentMatches >= requiredRecoveryMatches) {
                        gpsNavigationReady = true
                        offRouteSince = null
                    }
                }
            }
        }
    }

    // V152 : sortie de stabilisation rapide avec un GPS précis.
    // Il ne doit exister aucune zone morte entre « assez près pour reprendre » et
    // « assez loin pour recalculer ». Avec <= 15 m de précision, si la position
    // n'est pas dans la tolérance de reprise (35 m), l'écart est confirmé très
    // brièvement puis le trajet est recalculé. Entre 15 et 25 m, on garde une
    // confirmation un peu plus longue pour absorber un saut GPS ponctuel.
    val recoveryNearestRoute = nearestRouteSegment(liveLocation)
    val recoveryRerouteThresholdMeters = routeRecoveryToleranceMeters
    val recoveryOffRouteCandidate = !gpsNavigationReady &&
        gpsFixReliable &&
        gpsAccuracyMeters <= 25.0 &&
        !arrivalConfirmed &&
        distanceToDestinationMeters > 80.0 &&
        recoveryNearestRoute != null &&
        recoveryNearestRoute.second > recoveryRerouteThresholdMeters
    val latestRecoveryLocation by rememberUpdatedState(liveLocation)

    // V298 : l’effet de récupération doit lui aussi être lié à la révision du tracé.
    // Si un nouveau trajet est reçu pendant son délai de confirmation ou son cooldown,
    // Compose annule cette ancienne coroutine au lieu de recalculer depuis l’ancien tracé.
    LaunchedEffect(recoveryOffRouteCandidate, gpsAccuracyMeters <= 15.0, routeRevisionKey) {
        if (!recoveryOffRouteCandidate) return@LaunchedEffect

        val recoveryConfirmationDelay = if (gpsAccuracyMeters <= 15.0) 700L else 1_500L
        kotlinx.coroutines.delay(recoveryConfirmationDelay)
        val confirmedLocation = latestRecoveryLocation ?: return@LaunchedEffect
        val confirmedAccuracy = confirmedLocation
            .takeIf { it.hasAccuracy() }
            ?.accuracy
            ?.toDouble()
            ?: Double.POSITIVE_INFINITY
        val confirmedDistanceFromRoute = distanceFromRouteMeters(confirmedLocation)

        if (
            !gpsNavigationReady &&
            gpsSignalUsable &&
            confirmedAccuracy <= 25.0 &&
            confirmedDistanceFromRoute > when {
                confirmedAccuracy <= 15.0 -> 35.0
                confirmedAccuracy <= 35.0 -> 55.0
                else -> 85.0
            } &&
            !arrivalConfirmed &&
            distanceToDestinationMeters > 80.0
        ) {
            val cooldownRemaining = (20_000L - (android.os.SystemClock.elapsedRealtime() - lastRerouteAt))
                .coerceAtLeast(0L)
            if (cooldownRemaining > 0L) {
                kotlinx.coroutines.delay(cooldownRemaining)
            }

            val finalLocation = latestRecoveryLocation ?: return@LaunchedEffect
            val finalAccuracy = finalLocation
                .takeIf { it.hasAccuracy() }
                ?.accuracy
                ?.toDouble()
                ?: Double.POSITIVE_INFINITY
            val finalDistance = distanceFromRouteMeters(finalLocation)

            if (
                // V270 : ne jamais lancer un second recalcul GPS pendant qu’un calcul
                // d’itinéraire est déjà actif. Cela évite deux requêtes concurrentes si
                // plusieurs changements d’état GPS arrivent presque au même instant.
                !routeCalculationInProgress &&
                !rerouteInProgress &&
                !gpsNavigationReady &&
                // V273 : un recalcul de récupération ne doit jamais partir d’un ancien
                // fix resté en mémoire après une perte momentanée du GPS. V272 vérifiait
                // la précision, mais pas explicitement la fraîcheur du dernier fix ici.
                gpsFixFresh &&
                gpsSignalUsable &&
                locationAgeMillis(finalLocation) <= 8_000L &&
                finalAccuracy <= 25.0 &&
                finalDistance > when {
                    finalAccuracy <= 15.0 -> 35.0
                    finalAccuracy <= 35.0 -> 55.0
                    else -> 85.0
                } &&
                !arrivalConfirmed &&
                rerouteLaunchGate.compareAndSet(false, true)
            ) {
                lastRerouteAt = android.os.SystemClock.elapsedRealtime()
                offRouteSince = null
                // V269 : ce chemin de récupération GPS déclenche lui aussi un vrai
                // recalcul réseau. Il doit donc activer le même état visuel que le
                // recalcul hors-itinéraire normal, sinon le conducteur pouvait croire
                // que l'application ne réagissait pas pendant le calcul du nouveau tracé.
                rerouteInProgress = true
                mapAutoFollow = true
                onReroute(GeoPoint(finalLocation.latitude, finalLocation.longitude))
            }
        }
    }

    // V147 : la marge hors itinéraire augmente avec l'incertitude GPS. Ainsi un
    // écart apparent causé par un fix à ±40/60 m ne déclenche pas un recalcul.
    // V175 : à très faible vitesse (arrêt, feu, embouteillage), la dérive GPS latérale
    // est proportionnellement plus importante que le déplacement réel. On élargit donc
    // légèrement la tolérance hors itinéraire sous 5 km/h afin d'éviter un recalcul
    // parasite vers une rue parallèle, sans modifier la sensibilité normale en roulant.
    fun offRouteThresholdFor(location: Location?, accuracyMeters: Double): Double {
        val base = when {
            accuracyMeters <= 15.0 -> 60.0
            accuracyMeters <= 35.0 -> 80.0
            accuracyMeters <= 65.0 -> 120.0
            else -> 140.0
        }
        val currentSpeedKmh = location
            ?.takeIf { it.hasSpeed() }
            ?.speed
            ?.times(3.6f)
            ?.toDouble()
            ?: 0.0
        return if (currentSpeedKmh < 5.0) base + 20.0 else base
    }

    val offRouteThresholdMeters = offRouteThresholdFor(liveLocation, gpsAccuracyMeters)
    // V138 : à proximité immédiate de l'adresse, une petite imprécision de carte/GPS
    // ne doit jamais déclencher un nouveau calcul au moment où l'on arrive.
    // V283 : le recalcul hors itinéraire « normal » ne doit pas se déclencher sur
    // une dérive GPS alors que la VSP est complètement immobile. Les cas où la
    // navigation démarre réellement loin du tracé restent pris en charge par la
    // logique recoveryOffRouteCandidate ci-dessus. Dès que le véhicule roule à
    // nouveau (>= 3 km/h), la détection hors itinéraire redevient immédiatement active.
    // V285 : une VSP peut commencer à s'écarter du tracé à très basse vitesse
    // (sortie de parking, rond-point, circulation lente). Le seuil passe à 2 km/h :
    // assez bas pour détecter plus tôt un vrai départ hors itinéraire, tout en gardant
    // l'immobilité réelle à 0 km/h protégée contre les dérives GPS.
    // V289 : utiliser la preuve de mouvement temporisée plutôt que la vitesse arrondie
    // instantanée, qui peut osciller entre 0 et 2 km/h d'un fix GPS à l'autre.
    val movingForOffRouteDetection = movementRecentlyConfirmed
    offRoute = gpsNavigationReady &&
        movingForOffRouteDetection &&
        !arrivalConfirmed &&
        distanceToDestinationMeters > 80.0 &&
        distanceFromRoute > offRouteThresholdMeters

    // V149 : le délai hors itinéraire reste de 5 s, mais la décision finale utilise
    // désormais la DERNIÈRE position GPS reçue. Cela évite de recalculer depuis le point
    // qui avait déclenché le délai alors que le véhicule a continué à avancer entre-temps.
    // On recontrôle aussi la qualité GPS et la distance au tracé juste avant le recalcul :
    // une pointe d'imprécision ne peut donc pas, à elle seule, lancer un nouveau trajet.
    val latestLocationForReroute by rememberUpdatedState(liveLocation)
    val latestGpsReliableForReroute by rememberUpdatedState(gpsFixReliable)
    val latestNavigationReadyForReroute by rememberUpdatedState(gpsNavigationReady)
    val latestArrivalConfirmedForReroute by rememberUpdatedState(arrivalConfirmed)
    // V275 : les délais de confirmation/cooldown peuvent durer jusqu'à plusieurs
    // secondes. Lire les valeurs les plus récentes au moment de la décision évite
    // qu'une coroutine lancée avec un ancien état déclenche un second recalcul alors
    // qu'un calcul réseau a démarré entre-temps.
    val latestRouteCalculationInProgressForReroute by rememberUpdatedState(routeCalculationInProgress)
    val latestRerouteInProgressForReroute by rememberUpdatedState(rerouteInProgress)
    val latestGpsSignalUsableForReroute by rememberUpdatedState(gpsSignalUsable)
    val latestDistanceToDestinationForReroute by rememberUpdatedState(distanceToDestinationMeters)
    val latestMovementConfirmedForReroute by rememberUpdatedState(movementRecentlyConfirmed)

    // V294 : l'identité du tracé fait désormais partie de la clé de cet effet.
    // Si un nouveau trajet arrive pendant les délais de confirmation/cooldown,
    // Compose annule immédiatement l'ancienne coroutine : elle ne peut donc plus
    // déclencher un recalcul basé sur l'itinéraire précédent.
    LaunchedEffect(offRoute, gpsNavigationReady, routeRevisionKey) {
        if (!offRoute || !gpsNavigationReady) {
            offRouteSince = null
            return@LaunchedEffect
        }

        offRouteSince = android.os.SystemClock.elapsedRealtime()

        // V176 : un écart très net avec un GPS précis n'attend plus systématiquement
        // 5 secondes avant d'être recontrôlé. Cela rend le recalcul plus réactif après
        // une vraie mauvaise direction, tout en conservant 5 s pour les écarts limites
        // ou une précision GPS moyenne afin de ne pas multiplier les faux recalculs.
        val initialAccuracy = liveLocation
            ?.takeIf { it.hasAccuracy() }
            ?.accuracy
            ?.toDouble()
            ?: Double.POSITIVE_INFINITY
        val strongOffRoute = initialAccuracy <= 15.0 &&
            distanceFromRoute > offRouteThresholdMeters + 35.0
        val offRouteConfirmationDelayMs = if (strongOffRoute) 2_500L else 5_000L
        kotlinx.coroutines.delay(offRouteConfirmationDelayMs)

        val latestLocation = latestLocationForReroute
        if (
            latestLocation != null &&
            latestGpsReliableForReroute &&
            latestNavigationReadyForReroute &&
            !latestArrivalConfirmedForReroute
        ) {
            val latestAccuracy = latestLocation
                .takeIf { it.hasAccuracy() }
                ?.accuracy
                ?.toDouble()
                ?: Double.POSITIVE_INFINITY
            val latestDistanceFromRoute = distanceFromRouteMeters(latestLocation)
            val latestOffRouteThreshold = offRouteThresholdFor(latestLocation, latestAccuracy)

            if (latestAccuracy <= 65.0 && latestDistanceFromRoute > latestOffRouteThreshold) {
                // V150 : si un recalcul vient juste d'avoir lieu, on ne perd plus la
                // demande hors itinéraire pendant le cooldown de 20 s. On attend seulement
                // le temps restant puis on contrôle ENCORE la toute dernière position GPS.
                // Avant V150, un écart apparu pendant le cooldown pouvait rester bloqué sans
                // nouveau recalcul tant que l'état offRoute ne changeait pas.
                val cooldownRemaining = (20_000L - (android.os.SystemClock.elapsedRealtime() - lastRerouteAt))
                    .coerceAtLeast(0L)
                if (cooldownRemaining > 0L) {
                    kotlinx.coroutines.delay(cooldownRemaining)
                }

                val finalLocation = latestLocationForReroute
                if (
                    finalLocation != null &&
                    latestGpsReliableForReroute &&
                    latestNavigationReadyForReroute &&
                    !latestArrivalConfirmedForReroute
                ) {
                    val finalAccuracy = finalLocation
                        .takeIf { it.hasAccuracy() }
                        ?.accuracy
                        ?.toDouble()
                        ?: Double.POSITIVE_INFINITY
                    val finalDistanceFromRoute = distanceFromRouteMeters(finalLocation)
                    val finalThreshold = offRouteThresholdFor(finalLocation, finalAccuracy)
                    // V284 : revalider aussi le mouvement juste avant le recalcul.
                    // Si la VSP s'est arrêtée pendant le délai de confirmation/cooldown,
                    // une dérive GPS résiduelle ne doit pas déclencher un nouveau trajet.
                    val finalSpeedKmh = finalLocation
                        .takeIf { it.hasSpeed() }
                        ?.speed
                        ?.times(3.6f)
                        ?.toDouble()
                        ?: 0.0

                    if (
                        !latestRouteCalculationInProgressForReroute &&
                        !latestRerouteInProgressForReroute &&
                        // V274/V275 : après le délai et le cooldown, revalider aussi les
                        // conditions de sécurité qui ont pu changer entre-temps. Cela
                        // évite un recalcul tardif si le véhicule est finalement arrivé,
                        // si le GPS n'est plus exploitable ou si l'on est désormais à
                        // moins de 80 m de la destination.
                        !latestArrivalConfirmedForReroute &&
                        latestDistanceToDestinationForReroute > 80.0 &&
                        latestGpsSignalUsableForReroute &&
                        locationAgeMillis(finalLocation) <= 8_000L &&
                        finalAccuracy <= 65.0 &&
                        // V285 : même seuil que la détection initiale afin qu'un
                        // recalcul valide à faible allure ne soit pas annulé au dernier contrôle.
                        // V289 : ne pas annuler un vrai recalcul uniquement parce que
                        // Location.speed est retombé momentanément à 0 entre deux fixes.
                        (finalSpeedKmh >= 2.0 || latestMovementConfirmedForReroute) &&
                        finalDistanceFromRoute > finalThreshold &&
                        rerouteLaunchGate.compareAndSet(false, true)
                    ) {
                        // V276 : le verrou atomique ci-dessus complète les états Compose :
                        // même deux effets arrivant dans la même frame ne peuvent plus
                        // lancer deux appels onReroute concurrents.
                        // V270 : un seul recalcul réseau à la fois, même si un nouveau fix
                        // GPS est reçu exactement pendant le basculement de l’état parent.
                        lastRerouteAt = android.os.SystemClock.elapsedRealtime()
                        offRouteSince = null
                        rerouteInProgress = true
                        mapAutoFollow = true
                        onReroute(GeoPoint(finalLocation.latitude, finalLocation.longitude))
                    } else {
                        offRouteSince = null
                    }
                }
            } else {
                // Le point s'est rapproché du tracé ou la précision s'est dégradée :
                // on annule ce recalcul et on laisse la logique GPS reprendre la main.
                offRouteSince = null
            }
        }
    }

    // V398 : pendant une perte GPS brève, conserver à l'écran la dernière consigne
    // de conduite réellement valide au lieu de remplacer immédiatement tout le bandeau
    // par « Signal GPS insuffisant ». Le badge GPS indique déjà clairement la perte du
    // signal. Cela évite au conducteur de perdre sa prochaine manoeuvre dans un tunnel,
    // sous un pont ou pendant une coupure momentanée du récepteur. La voix reste, elle,
    // protégée plus bas par gpsFixReliable et ne répète donc pas une ancienne consigne.
    var lastStableManeuver by remember(routeRevisionKey) {
        mutableStateOf<ManeuverGuidance?>(null)
    }

    val liveStableManeuver = if (
        gpsFixReliable &&
        gpsNavigationReady &&
        !rerouteInProgress &&
        !offRoute
    ) {
        nextTurnGuidance(liveLocation)
    } else null

    LaunchedEffect(
        liveStableManeuver?.voiceKey,
        liveStableManeuver?.distanceText,
        routeRevisionKey
    ) {
        if (liveStableManeuver != null) {
            lastStableManeuver = liveStableManeuver
        }
    }

    // V147 : le guidage ne saute plus dès qu'une précision moyenne se dégrade un peu.
    // L'hystérésis ci-dessus décide quand le signal est réellement insuffisant.
    val maneuver = when {
        !gpsFixReliable -> lastStableManeuver?.copy(
            distanceText = "GPS temporairement indisponible"
        ) ?: ManeuverGuidance(
            "⌖",
            "Signal GPS insuffisant",
            "Recherche de votre position…"
        )
        !gpsNavigationReady -> ManeuverGuidance(
            "⌖",
            "GPS en stabilisation",
            "Confirmation de la route…"
        )
        rerouteInProgress -> ManeuverGuidance("↻", "Nouvel itinéraire", "Recalcul en cours…")
        offRoute -> ManeuverGuidance("↻", "Hors itinéraire", "Recalcul automatique…")
        else -> liveStableManeuver ?: nextTurnGuidance(liveLocation)
    }

    val context = LocalContext.current
    var ttsReady by remember { mutableStateOf(false) }
    val voicePrefs = remember {
        context.getSharedPreferences("vsp_voice_settings", android.content.Context.MODE_PRIVATE)
    }
    var voiceEnabled by remember {
        mutableStateOf(voicePrefs.getBoolean("voice_enabled", true))
    }
    var lastSpokenInstruction by remember { mutableStateOf("") }
    var lastSpokenInstructionElapsed by remember { mutableLongStateOf(0L) }

    // V415 : une seule source de vérité pour la disponibilité de la répétition vocale.
    // Le portrait et le paysage utilisent exactement les mêmes conditions, ce qui évite
    // qu'un bouton paraisse actif alors que l'action est refusée (GPS, TTS ou consigne absente).
    val manualReplayAvailable =
        voiceEnabled && ttsReady && gpsNavigationReady && gpsFixReliable && maneuver.spokenTitle.isNotBlank()

    val textToSpeech = remember {
        TextToSpeech(context) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
        }
    }

    LaunchedEffect(ttsReady) {
        if (ttsReady) {
            val languageResult = textToSpeech.setLanguage(Locale.FRANCE)
            if (languageResult == TextToSpeech.LANG_MISSING_DATA ||
                languageResult == TextToSpeech.LANG_NOT_SUPPORTED
            ) {
                voiceEnabled = false
            } else {
                textToSpeech.setSpeechRate(0.95f)
            }
        }
    }

    DisposableEffect(textToSpeech) {
        onDispose {
            textToSpeech.stop()
            textToSpeech.shutdown()
        }
    }

    var voiceManeuverKey by remember { mutableStateOf("") }
    var spokenVoiceThresholds by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var previousVoiceDistanceMeters by remember { mutableStateOf<Double?>(null) }
    // V337 : candidat temporaire pour confirmer un gros bond vocal avant de l'accepter.
    var pendingVoiceJumpDistanceMeters by remember { mutableStateOf<Double?>(null) }
    // V345 : horodater le candidat de gros bond GPS pour éviter qu'un ancien point
    // suspect soit confirmé plusieurs secondes plus tard après une perte momentanée du signal.
    var pendingVoiceJumpElapsed by remember { mutableLongStateOf(0L) }
    // V363 : compter réellement les fixes cohérents d'un gros bond lorsque la
    // précision reste moyenne (25..35 m). V362 remplaçait le candidat à chaque
    // relevé mais ne mémorisait pas combien de confirmations avaient déjà été vues.
    var pendingVoiceJumpConfirmations by remember { mutableIntStateOf(0) }
    // V310 : éviter que deux annonces vocales se remplacent presque instantanément
    // lors d’un saut GPS ou de manœuvres très rapprochées.
    var lastVoiceAnnouncementElapsed by remember { mutableLongStateOf(0L) }
    // V308 : mémoriser la plage de vitesse vocale pour éviter que les seuils
    // changent sans cesse lorsque la vitesse oscille autour de 20 ou 35 km/h.
    var voiceSpeedBand by remember { mutableIntStateOf(0) }
    // V372 : hystérésis dédiée à la précision vocale. Sans mémoire, une précision
    // oscillant autour de ±45 m pouvait suspendre/réactiver la voix à chaque fix.
    // On suspend au-delà de ±48 m et on ne reprend qu'à ±40 m ou mieux.
    var voiceAccuracyWeak by remember { mutableStateOf(false) }
    // V378 : mémoriser depuis combien de temps la précision vocale est dégradée.
    // Après une longue période sans distance fiable, on ne doit pas comparer le retour
    // du GPS à une ancienne distance et annoncer un palier devenu obsolète.
    var voiceAccuracyWeakSinceElapsed by remember { mutableLongStateOf(0L) }

    // V155 : un recalcul change routeRevisionKey alors que NavigationScreen reste affiché.
    // Couper immédiatement une éventuelle annonce de l'ancien tracé et remettre à zéro
    // la mémoire vocale. La première consigne du nouveau trajet sera ensuite annoncée
    // par la logique normale dès que le GPS est de nouveau prêt.
    LaunchedEffect(routeRevisionKey, ttsReady) {
        if (ttsReady) {
            textToSpeech.stop()
        }
        voiceManeuverKey = ""
        spokenVoiceThresholds = emptySet()
        previousVoiceDistanceMeters = null
        pendingVoiceJumpDistanceMeters = null
            pendingVoiceJumpElapsed = 0L
        pendingVoiceJumpConfirmations = 0
        // V312 : un nouveau tracé ne doit pas hériter du délai anti-chevauchement
        // de l'ancienne route. Sans ce reset, la première annonce du trajet recalculé
        // pouvait être retardée jusqu'à 2,5 s alors qu'elle est déjà pertinente.
        lastVoiceAnnouncementElapsed = 0L
        lastSpokenInstruction = ""
    }

    // V162 : si la qualité GPS suspend le guidage, couper immédiatement une annonce
    // devenue potentiellement obsolète. La voix repartira uniquement avec la manœuvre
    // réellement active lorsque la navigation GPS sera de nouveau prête.
    LaunchedEffect(gpsFixReliable, gpsNavigationReady, ttsReady) {
        if (ttsReady && (!gpsFixReliable || !gpsNavigationReady)) {
            textToSpeech.stop()
            voiceManeuverKey = ""
            spokenVoiceThresholds = emptySet()
            // V193 : une interruption GPS invalide aussi la distance vocale précédente.
            // Sans ce reset, la reprise pouvait comparer la nouvelle position à une
            // mesure ancienne et détecter à tort un franchissement de seuil.
            previousVoiceDistanceMeters = null
            pendingVoiceJumpDistanceMeters = null
            pendingVoiceJumpElapsed = 0L
            pendingVoiceJumpConfirmations = 0
            lastVoiceAnnouncementElapsed = 0L
            lastSpokenInstruction = ""
            lastSpokenInstructionElapsed = 0L
            // V374 : une perte complète de fiabilité GPS termine aussi l'ancien état
            // d'hystérésis de précision vocale. Sans ce reset, après une coupure GPS,
            // la voix pouvait rester artificiellement suspendue tant que la précision
            // n'était pas revenue à <= 40 m, même si le nouveau fix était déjà exploitable
            // (par exemple ±42 m). La reprise réévalue maintenant proprement le nouveau fix.
            voiceAccuracyWeak = false
            voiceAccuracyWeakSinceElapsed = 0L
        }
    }

    // V203 : couper immédiatement une annonce en cours si l'utilisateur désactive
    // le guidage vocal. Auparavant, voiceEnabled empêchait seulement les nouvelles
    // annonces : une phrase déjà lancée pouvait continuer jusqu'à la fin.
    LaunchedEffect(voiceEnabled, ttsReady) {
        if (ttsReady && !voiceEnabled) {
            textToSpeech.stop()
            // V205 : pendant que la voix est coupée, les distances ne sont plus suivies
            // par l'effet vocal. Invalider la dernière distance évite qu'à la réactivation
            // l'app interprète tout le trajet parcouru en mode muet comme un grand saut GPS
            // et annonce immédiatement un seuil déjà franchi. Les seuils déjà prononcés
            // restent mémorisés : seule la référence de franchissement est réinitialisée.
            previousVoiceDistanceMeters = null
            pendingVoiceJumpDistanceMeters = null
            pendingVoiceJumpElapsed = 0L
            pendingVoiceJumpConfirmations = 0
            // V325 : annuler aussi le délai anti-chevauchement quand la voix est coupée.
            // Si l'utilisateur coupe puis réactive rapidement le guidage vocal, une ancienne
            // annonce ne doit pas retarder de 2,5 s la première consigne utile après réactivation.
            lastVoiceAnnouncementElapsed = 0L
        }
    }

    // V163 : la voix suit désormais explicitement le même état de qualité GPS que
    // l'écran. Un changement de précision qui suspend le fix ne peut donc pas laisser
    // partir une consigne calculée juste avant la suspension. Dès que le fix redevient
    // fiable et que la route est confirmée, la consigne active est de nouveau éligible.
    LaunchedEffect(
        maneuver.title,
        // V314 : inclure l'identité réelle de la manœuvre dans les clés de l'effet vocal.
        // Deux virages successifs peuvent avoir le même texte et momentanément la même
        // distance ; sans voiceKey, Compose pouvait alors conserver l'ancien effet et ne
        // pas réarmer immédiatement les seuils vocaux de la nouvelle manœuvre.
        maneuver.voiceKey,
        maneuver.distanceMeters,
        voiceEnabled,
        ttsReady,
        gpsFixReliable,
        gpsNavigationReady,
        routeRevisionKey,
        speedKmh,
        movementRecentlyConfirmed,
        // V370 : relancer aussi la décision vocale lorsque la précision change.
        gpsAccuracyMeters,
        simulationRewinding
    ) {
        if (!voiceEnabled || !ttsReady || maneuver.title.isBlank() || !gpsFixReliable || !gpsNavigationReady || (simulationActive && simulationRewinding)) return@LaunchedEffect

        val meters = maneuver.distanceMeters ?: return@LaunchedEffect
        // V322 : protéger le guidage vocal contre une distance de manœuvre invalide.
        // Un recalcul interrompu ou une géométrie momentanément incohérente ne doit
        // jamais injecter NaN/Infinity (ou une distance négative) dans les fenêtres
        // vocales et dans previousVoiceDistanceMeters. On attend simplement la
        // prochaine position/route valide avant de reprendre les annonces.
        if (!meters.isFinite() || meters < 0.0) {
            // V365 : une distance invalide interrompt aussi toute confirmation de gros
            // bond GPS en cours. Sans ce reset, un candidat mémorisé juste avant une
            // géométrie/recalcul momentanément invalide pouvait survivre puis être
            // confirmé par le premier relevé valide suivant, alors que les deux mesures
            // n'appartenaient plus forcément au même état de guidage.
            pendingVoiceJumpDistanceMeters = null
            pendingVoiceJumpElapsed = 0L
            pendingVoiceJumpConfirmations = 0
            return@LaunchedEffect
        }
        // V134 : ne plus utiliser uniquement le texte parlé comme identifiant.
        // Deux ronds-points successifs peuvent avoir exactement la même annonce
        // (par exemple « prenez la 2e sortie »). Chaque vraie manœuvre possède
        // désormais sa propre clé, ce qui réarme correctement les seuils vocaux.
        // V154 : un nouveau tracé doit réarmer la voix même si sa première
        // manœuvre possède les mêmes indices/type que celle de l'ancien tracé.
        val key = "$routeRevisionKey:${maneuver.voiceKey}"

        val isNewVoiceManeuver = key != voiceManeuverKey
        if (isNewVoiceManeuver) {
            // Une nouvelle manœuvre remplace immédiatement l'ancienne annonce :
            // aucune consigne précédente ne doit continuer après le changement d'étape.
            textToSpeech.stop()
            voiceManeuverKey = key
            spokenVoiceThresholds = emptySet()
            // V309 : réinitialiser aussi la plage de vitesse à chaque nouvelle manœuvre.
            // Sans cela, une étape terminée à 35-45 km/h pouvait laisser la plage haute
            // active pendant une mise à jour après un fort ralentissement et déclencher
            // une annonce lointaine inutile pour la nouvelle étape.
            voiceSpeedBand = when {
                speedKmh >= 35 -> 2
                speedKmh >= 20 -> 1
                else -> 0
            }
            // V193 : chaque manœuvre démarre avec sa propre référence de distance.
            // La dernière distance de l'étape précédente ne doit jamais servir au
            // détecteur de franchissement ajouté en V192.
            previousVoiceDistanceMeters = null
            pendingVoiceJumpDistanceMeters = null
            pendingVoiceJumpElapsed = 0L
            pendingVoiceJumpConfirmations = 0
            // V352 : une nouvelle manœuvre a déjà interrompu l’ancienne annonce via
            // textToSpeech.stop(). Ne pas conserver le délai anti-chevauchement de
            // l’étape précédente : sinon une nouvelle consigne apparaissant vers
            // 200/300 m pouvait être bloquée quelques secondes, sortir de sa fenêtre
            // vocale et ne jamais être annoncée. Chaque vraie nouvelle manœuvre repart
            // donc avec son propre délai vocal, sans affecter la protection entre deux
            // annonces appartenant à la même étape.
            lastVoiceAnnouncementElapsed = 0L
            // ETAPE 49 : conserver la dernière phrase réellement prononcée pendant le
            // changement de manœuvre. Elle sert à bloquer un doublon immédiat (souvent
            // « Continuez… » juste après une sortie) sans empêcher une vraie consigne
            // identique plusieurs secondes plus tard.
        }

        // V179 : ne jamais annoncer une distance supérieure de façon trompeuse
        // lorsque la navigation démarre déjà à l'intérieur d'un seuil. Par exemple,
        // à 300 m d'un virage on attend désormais le seuil 200 m au lieu de dire
        // « Dans 500 mètres ». Les fenêtres gardent une marge pour les sauts GPS.
        // V182 : ajout d'un rappel intermédiaire à 50 m. Sur les petites rues et
        // intersections rapprochées, le saut 100 m -> consigne immédiate pouvait
        // être trop brutal. La fenêtre 40-65 m absorbe les petits sauts GPS.
        // V192 : si deux positions GPS successives sautent entièrement une fenêtre
        // vocale (ex. 230 m -> 140 m), ne plus perdre l'annonce correspondante.
        // On détecte le franchissement réel d'un seuil et, dans ce cas, on annonce
        // une distance arrondie proche de la position actuelle plutôt qu'une distance
        // devenue supérieure à la réalité. Les fenêtres V179/V182 restent prioritaires.
        var previousMeters = previousVoiceDistanceMeters
        // V306 : adapter les annonces lointaines à la vitesse réelle de la VSP.
        // À faible allure, annoncer 500 m trop tôt surcharge le guidage ; à 35-45 km/h,
        // l'annonce à 500 m laisse au contraire davantage de temps pour anticiper.
        // V307 : à vitesse élevée, conserver aussi le palier intermédiaire de 300 m.
        // V306 annonçait 500 m puis sautait directement à 200 m, ce qui créait un long
        // silence alors que la VSP parcourait cette distance rapidement. La séquence
        // devient donc 500/300/200/100/50 m à partir de 35 km/h.
        // V308 : hystérésis sur les changements de plage. Sans elle, une vitesse
        // oscillant autour de 20 ou 35 km/h pouvait activer/désactiver plusieurs fois
        // les annonces lointaines. On entre dans une plage à 20/35 km/h, mais on n'en
        // ressort qu'en dessous de 17/32 km/h.
        // V350 : si la VSP ralentit brutalement depuis la plage haute jusqu'à une
        // vitesse très faible (par exemple 40 -> 0 km/h à un feu), ne pas rester
        // artificiellement une mise à jour entière dans la plage intermédiaire.
        // V349/V308 pouvaient alors conserver momentanément les seuils 300/200/100 m
        // alors que le véhicule était déjà quasiment arrêté. La descente 2 -> 0 est
        // maintenant directe sous 17 km/h, tout en gardant l'hystérésis 32/35 km/h.
        voiceSpeedBand = when (voiceSpeedBand) {
            2 -> when {
                speedKmh < 17 -> 0
                speedKmh < 32 -> 1
                else -> 2
            }
            1 -> when {
                speedKmh >= 35 -> 2
                speedKmh < 17 -> 0
                else -> 1
            }
            else -> when {
                speedKmh >= 35 -> 2
                speedKmh >= 20 -> 1
                else -> 0
            }
        }
        // V329 : à 35-45 km/h, le rappel « 50 mètres » arrivait trop près de la
        // consigne finale déclenchée à 40 m. À 45 km/h, ces 10 m représentent moins
        // d'une seconde : le TTS pouvait commencer « Dans 50 mètres… » puis être
        // immédiatement coupé par la consigne finale. En plage haute, on garde donc
        // 500/300/200/100 m puis la consigne directe à 40 m. Les plages plus lentes
        // conservent le rappel 50 m, où l'écart temporel reste réellement utile.
        // V330 : supprimer aussi le rappel 50 m dans la plage intermédiaire.
        // Avec une consigne finale à 37 m, il ne restait que 13 m entre les deux
        // annonces : vers 30-35 km/h, le TTS pouvait encore être coupé presque
        // immédiatement. Le rappel 50 m est désormais réservé à la faible vitesse,
        // où l'écart jusqu'à la consigne finale à 35 m laisse réellement le temps
        // d'entendre les deux annonces.
        // ETAPE 35 : les alertes rapprochées commencent uniquement à 100 m,
        // conformément au choix utilisateur. Plus d'annonce spéciale à 500/300/200 m.
        // La séquence devient 100 m -> 50 m -> consigne immédiate, quelle que soit
        // la plage de vitesse. La distance normale reste affichée au-delà de 100 m.
        // ETAPE 39 : suppression du rappel vocal à 50 m à la demande utilisateur.
        // Séquence : 100 m -> consigne immédiate (« maintenant »).
        val activeVoiceThresholds = listOf(100)
        // V316 : ne pas déclencher une nouvelle annonce de distance lorsque la
        // distance au virage vient d'augmenter fortement. Un recalage GPS peut par
        // exemple faire passer momentanément 230 m -> 305 m et provoquer à tort
        // « Dans 300 mètres » alors que la VSP s'approchait déjà du virage. Une
        // tolérance de 20 m conserve les petites oscillations normales du GPS.
        // La consigne immédiate (<= 35 m) reste toujours prioritaire.
        val distanceProgressionReliable = previousMeters == null || meters <= previousMeters + 20.0
        // V318 : à la vitesse maximale d'une VSP, attendre 35 m pour la consigne finale
        // laisse très peu de temps avant l'intersection. Avancer légèrement le seuil
        // immédiat à 40 m dans la plage de vitesse haute.
        // V320 : utiliser la plage de vitesse stabilisée de V308 plutôt que la vitesse
        // instantanée. Ainsi, une oscillation GPS autour de 35 km/h ne fait plus alterner
        // le seuil final entre 35 et 40 m d'une position à l'autre.
        // V323 : rendre aussi le dernier rappel progressif dans la plage intermédiaire.
        // Entre 20 et ~35 km/h, 35 m pouvait être un peu court alors que 40 m est
        // surtout utile proche de la vitesse maximale d’une VSP. On utilise donc
        // 35 / 37 / 40 m selon la plage stabilisée, sans dépendre de la vitesse
        // instantanée afin de conserver l’hystérésis introduite en V320.
        val immediateVoiceDistanceMeters = when (voiceSpeedBand) {
            2 -> 40.0
            1 -> 37.0
            else -> 35.0
        }
        // V367 : en mouvement aussi, tenir compte d'une précision GPS dégradée avant
        // d'annoncer la consigne finale. Avec un fix à ±30/35 m, utiliser directement
        // une zone « tournez maintenant » de 35-40 m peut annoncer le virage trop tôt.
        // On réduit donc progressivement cette zone au-delà de ±15 m de précision,
        // avec une correction plafonnée à 12 m pour ne jamais rendre la consigne
        // excessivement tardive. Avec un bon GPS (<= 15 m), le comportement reste
        // strictement identique aux versions précédentes.
        val immediateAccuracyPenaltyMeters =
            ((gpsAccuracyMeters - 15.0).coerceAtLeast(0.0) * 0.5).coerceAtMost(12.0)
        val effectiveImmediateVoiceDistanceMeters =
            (immediateVoiceDistanceMeters - immediateAccuracyPenaltyMeters).coerceAtLeast(23.0)
        // V321 : resserrer le bas des fenêtres vocales. Lorsqu'une navigation démarrait
        // directement à 410/430 m d'un virage, l'ancienne fenêtre 400..520 pouvait dire
        // « Dans 500 mètres », donc annoncer une distance sensiblement supérieure à la
        // distance réelle. On conserve une petite tolérance GPS sous chaque palier, mais
        // on attend désormais le palier suivant si l'on démarre nettement en dessous.
        // V334 : éviter une fausse consigne immédiate après un saut GPS brutal vers
        // l'avant. Si la distance passe en une seule mise à jour de plus de 150 m à
        // la zone "tournez maintenant", attendre une seconde position cohérente avant
        // de parler. Au relevé suivant, previousVoiceDistanceMeters est déjà proche du
        // virage et la consigne immédiate est alors autorisée normalement. Cela ajoute
        // au maximum un relevé de délai tout en évitant un faux virage sur un point GPS
        // aberrant isolé.
        // V369 : utiliser ici aussi la zone immédiate réellement autorisée après
        // correction de précision (V367). Avec un fix dégradé, comparer encore au
        // seuil brut 35/37/40 m pouvait classer comme « saut vers tournez maintenant »
        // une position qui n'était en réalité pas encore admissible pour la consigne
        // finale. Toutes les protections de saut parlent désormais du même seuil.
        var suspiciousImmediateJump = previousMeters != null &&
            previousMeters > 150.0 &&
            meters <= effectiveImmediateVoiceDistanceMeters
        // V336 : étendre la protection V334 aux gros bonds GPS vers l'avant qui
        // n'atterrissent pas forcément dans la zone immédiate. Un saut isolé comme
        // 520 m -> 85 m pouvait encore être interprété comme le franchissement de
        // plusieurs seuils et provoquer une annonce vocale alors que la position
        // n'était pas encore confirmée. Au-delà de 250 m gagnés en un seul relevé,
        // on mémorise la nouvelle distance mais on attend le relevé suivant avant
        // toute annonce. Si la position est réelle, le guidage reprend aussitôt ;
        // si c'était un point aberrant, aucune fausse consigne n'est prononcée.
        // V346 : si le candidat V345 a expiré, l'abandonner sans perdre ce relevé.
        // L'ancienne version quittait immédiatement l'effet : après une coupure GPS,
        // il fallait donc encore attendre un relevé supplémentaire avant même de
        // pouvoir commencer à confirmer la nouvelle position. Le relevé courant peut
        // maintenant devenir lui-même un nouveau candidat s'il constitue toujours un
        // gros bond par rapport à la dernière distance réellement fiable.
        // V377 : ne jamais confirmer un gros bond GPS avec un fix qui se trouve déjà
        // dans la zone de précision où le guidage vocal est (ou doit rester) suspendu.
        // V376 réinitialisait bien le candidat lors du passage en précision faible, mais
        // cette remise à zéro arrivait plus bas dans l'effet, APRES la logique de
        // confirmation du bond. Un fix > 48 m pouvait donc exceptionnellement confirmer
        // l'ancien candidat avant d'être déclaré inutilisable. De même, pendant
        // l'hystérésis V372 (voix encore suspendue entre 40 et 48 m), on ne doit pas
        // valider de nouvelle zone. On invalide le candidat avant toute confirmation.
        val jumpFixAccuracyTooWeak = voiceAccuracyWeak || gpsAccuracyMeters > 48.0
        if (jumpFixAccuracyTooWeak && pendingVoiceJumpDistanceMeters != null) {
            pendingVoiceJumpDistanceMeters = null
            pendingVoiceJumpElapsed = 0L
            pendingVoiceJumpConfirmations = 0
        }
        val pendingJumpRaw = if (jumpFixAccuracyTooWeak) null else pendingVoiceJumpDistanceMeters
        val voiceJumpNowElapsed = android.os.SystemClock.elapsedRealtime()
        val pendingJumpExpired = pendingJumpRaw != null &&
            (pendingVoiceJumpElapsed <= 0L || voiceJumpNowElapsed - pendingVoiceJumpElapsed > 5000L)
        if (pendingJumpExpired) {
            pendingVoiceJumpDistanceMeters = null
            pendingVoiceJumpElapsed = 0L
            pendingVoiceJumpConfirmations = 0
            // V366 : après expiration d'un candidat de gros bond, repartir du dernier
            // état vocal réellement validé. Le relevé courant peut toujours ouvrir
            // une nouvelle confirmation juste en dessous, mais il ne doit pas hériter
            // d'un drapeau de saut immédiat calculé à partir du candidat expiré. Cela
            // évite de bloquer inutilement une vraie consigne proche après une coupure
            // GPS, tout en conservant la protection contre un nouveau bond isolé.
            suspiciousImmediateJump = false
        }
        val pendingJump = if (pendingJumpExpired) null else pendingJumpRaw
        if (pendingJump != null) {
            // V337 : le second relevé doit rester proche du premier bond suspect.
            // S'il confirme la nouvelle zone (écart <= 80 m), on accepte le bond ;
            // sinon on l'abandonne sans avoir pollué la dernière distance fiable.
            // V340 : resserrer la confirmation d'un gros bond GPS. Une tolérance
            // fixe de 80 m pouvait valider deux points encore très dispersés. La
            // seconde mesure doit maintenant rester dans une zone beaucoup plus
            // proche du premier point suspect : 35 m à basse/moyenne vitesse et
            // 50 m à vitesse élevée, afin de conserver assez de marge entre deux
            // relevés lorsque la VSP roule réellement à 35-45 km/h.
            // V347 : utiliser la plage de vitesse stabilisée pour la tolérance de
            // confirmation, comme pour les seuils vocaux. Avec la vitesse instantanée,
            // une oscillation autour de 35 km/h pouvait faire varier la tolérance de
            // 35 à 50 m entre les deux relevés et accepter/refuser le même bond GPS
            // selon une variation minime de vitesse. La bande haute bénéficie de 50 m,
            // les bandes basse/intermédiaire restent à 35 m.
            val jumpConfirmationToleranceMeters = if (voiceSpeedBand == 2) 50.0 else 35.0
            // V348 : tenir compte du déplacement réel entre les deux relevés qui
            // confirment un gros bond. À 45 km/h, quelques secondes sans nouvelle
            // position peuvent faire diminuer normalement la distance de plus de
            // 50 m : le test V347 rejetait alors une nouvelle zone pourtant cohérente.
            // On garde une marge stricte vers l'arrière, mais on autorise vers l'avant
            // la distance que la VSP a pu parcourir depuis le premier point suspect.
            val jumpConfirmationElapsedSeconds = if (pendingVoiceJumpElapsed > 0L) {
                ((voiceJumpNowElapsed - pendingVoiceJumpElapsed).coerceAtLeast(0L) / 1000.0)
            } else {
                0.0
            }
            // V349 : ne pas dépendre uniquement de la vitesse du second fix pour
            // confirmer un déplacement réel. Android peut fournir momentanément
            // 0 km/h (ou une vitesse très basse) sur ce fix alors que la VSP a bien
            // avancé depuis le premier point suspect. On conserve donc la vitesse
            // instantanée lorsqu'elle est exploitable, avec un plancher cohérent avec
            // la bande de vitesse stabilisée. Cela évite de rejeter à tort une reprise
            // GPS réelle juste parce que le second relevé a perdu l'information vitesse.
            val confirmationSpeedFloorKmh = when (voiceSpeedBand) {
                2 -> 35.0
                1 -> 20.0
                else -> 0.0
            }
            // V382 : speedKmh est un Int. Le convertir explicitement en Double avant
            // coerceIn/max évite l’erreur de surcharge Kotlin apparue en V381.
            val confirmationSpeedKmh = kotlin.math.max(
                speedKmh.toDouble().coerceIn(0.0, 45.0),
                confirmationSpeedFloorKmh
            )
            val expectedForwardTravelMeters =
                (confirmationSpeedKmh / 3.6 * jumpConfirmationElapsedSeconds)
                    .coerceAtMost(65.0)
            val jumpDistanceDelta = pendingJump - meters
            val jumpSpatiallyConsistent = jumpDistanceDelta >= -jumpConfirmationToleranceMeters &&
                jumpDistanceDelta <= jumpConfirmationToleranceMeters + expectedForwardTravelMeters
            // V361 : un gros déplacement ne doit pas être validé uniquement parce que
            // deux positions sont proches l'une de l'autre si le second fix reste très
            // imprécis. Un GPS à ±50/60 m peut produire deux points cohérents entre eux
            // mais tous deux décalés sur une rue parallèle. Exiger <= 35 m pour confirmer
            // la nouvelle zone. Si la géométrie est cohérente mais la précision encore
            // insuffisante, conserver le candidat (jusqu'à l'expiration V345) et attendre
            // un prochain fix plus précis au lieu de rejeter immédiatement le déplacement.
            // V362 : distinguer une confirmation GPS vraiment précise d'une
            // confirmation seulement acceptable. Entre 25 et 35 m de précision,
            // deux fixes proches peuvent encore appartenir à une rue parallèle.
            // Dans cette zone intermédiaire, demander un troisième fix cohérent :
            // le point courant devient le nouveau candidat sans modifier la dernière
            // distance vocale validée. A <= 25 m, deux fixes cohérents suffisent.
            val jumpAccuracyStrong = gpsAccuracyMeters <= 25.0
            val jumpAccuracyUsable = gpsAccuracyMeters <= 35.0
            // V363 : V362 annonçait qu'un troisième fix était demandé entre 25 et
            // 35 m, mais le code ne comptait pas les confirmations : chaque point
            // remplaçait simplement le candidat et pouvait prolonger l'attente sans fin.
            // Le premier gros bond vaut 1 fix ; chaque nouveau fix spatialement cohérent
            // et <= 35 m incrémente le compteur. Deux fixes suffisent si le second est
            // très précis (<= 25 m), sinon trois fixes cohérents valident la nouvelle zone.
            val coherentConfirmationCount = if (jumpSpatiallyConsistent && jumpAccuracyUsable) {
                (pendingVoiceJumpConfirmations.coerceAtLeast(1) + 1)
            } else {
                pendingVoiceJumpConfirmations
            }
            val jumpConfirmed = jumpSpatiallyConsistent &&
                (jumpAccuracyStrong || (jumpAccuracyUsable && coherentConfirmationCount >= 3))
            if (jumpSpatiallyConsistent && jumpAccuracyUsable && !jumpConfirmed) {
                pendingVoiceJumpDistanceMeters = meters
                // V364 : conserver l'horodatage du PREMIER point suspect pendant
                // toute la séquence de confirmation. V363 le remettait à zéro à
                // chaque fix intermédiaire : avec des positions moyennement précises,
                // le candidat pouvait ainsi rester vivant indéfiniment et finir par
                // valider une zone qui n'était plus liée au bond GPS initial.
                // La fenêtre V345 de 5 s couvre maintenant toute la confirmation.
                pendingVoiceJumpConfirmations = coherentConfirmationCount
                return@LaunchedEffect
            }
            if (jumpConfirmed) {
                pendingVoiceJumpDistanceMeters = null
                pendingVoiceJumpElapsed = 0L
                pendingVoiceJumpConfirmations = 0
                previousVoiceDistanceMeters = meters
                // V342 : une fois le gros bond confirmé, utiliser immédiatement la
                // position confirmée comme nouvelle référence dans CE cycle. V341
                // attendait encore un relevé supplémentaire avant toute annonce : si
                // le bond réel amenait la VSP directement à proximité du virage, la
                // consigne finale pouvait donc arriver trop tard. En remplaçant aussi
                // previousMeters par la distance confirmée, aucun ancien seuil franchi
                // n'est rejoué, mais la consigne immédiate (35/37/40 m) peut être
                // prononcée sans attendre une troisième position GPS.
                previousMeters = meters
                // V344 : le bond vient d'être confirmé par un second relevé cohérent.
                // Ne conserver surtout pas le drapeau suspiciousImmediateJump calculé
                // avant cette confirmation : il bloquerait encore la consigne finale
                // dans windowThreshold et annulerait le bénéfice de V342. Une position
                // désormais confirmée à proximité du virage peut donc annoncer tout de
                // suite la manœuvre, sans attendre un troisième relevé GPS.
                suspiciousImmediateJump = false
            } else {
                // V343 : si le second point ne confirme pas le gros bond, ne jamais
                // promouvoir cette seconde mesure comme nouvelle distance fiable.
                // V338 remplaçait previousVoiceDistanceMeters par `meters` : deux
                // points aberrants différents pouvaient donc déplacer silencieusement
                // la référence vocale. On conserve maintenant la dernière distance
                // réellement validée, on abandonne seulement le candidat et on attend
                // le prochain relevé GPS avant toute nouvelle annonce.
                pendingVoiceJumpDistanceMeters = null
                pendingVoiceJumpElapsed = 0L
                pendingVoiceJumpConfirmations = 0
                previousVoiceDistanceMeters = previousMeters
                return@LaunchedEffect
            }
        }
        val suspiciousLargeForwardJump = pendingJump == null && previousMeters != null &&
            previousMeters > 150.0 &&
            previousMeters - meters > 250.0
        if (suspiciousLargeForwardJump) {
            pendingVoiceJumpDistanceMeters = meters
            pendingVoiceJumpElapsed = android.os.SystemClock.elapsedRealtime()
            pendingVoiceJumpConfirmations = 1
            return@LaunchedEffect
        }
        // V351 : une petite hausse de distance (recalage GPS de quelques mètres) ne
        // doit pas faire entrer artificiellement la VSP dans une fenêtre vocale et
        // déclencher une annonce qu'elle vient en réalité de dépasser. On tolère
        // jusqu'à 5 m de bruit GPS pour les fenêtres normales ; la consigne immédiate
        // reste prioritaire et le démarrage d'une nouvelle manœuvre reste autorisé.
        val voiceDistanceApproaching = previousMeters == null || meters <= previousMeters + 5.0
        val windowThreshold = when {
            suspiciousImmediateJump -> null
            meters <= effectiveImmediateVoiceDistanceMeters -> 0
            !distanceProgressionReliable -> null
            !voiceDistanceApproaching -> null
            // V326 : resserrer encore le bord inférieur des fenêtres. Au démarrage
            // d'un guidage, annoncer « 500 m » à 470 m ou « 300 m » à 285 m restait
            // inutilement supérieur à la distance réelle. Les franchissements entre
            // deux positions restent couverts par crossedThresholds juste en dessous.
            // ETAPE 38 : l'écran et la voix franchissent exactement les mêmes seuils.
            // Ne plus préparer la voix au-dessus du seuil (ancienne fenêtre 98..110 m
            // pour 100 m et 49..65 m pour 50 m), car l'affichage pouvait alors montrer
            // le palier avant que le TTS ne parte. Une nouvelle manœuvre déjà entrée
            // dans le palier reste annoncée grâce à cette fenêtre située sous le seuil.
            100 in activeVoiceThresholds && meters in 90.0..100.0 -> 100
            200 in activeVoiceThresholds && meters in 196.0..220.0 -> 200
            300 in activeVoiceThresholds && meters in 294.0..330.0 -> 300
            500 in activeVoiceThresholds && meters in 490.0..520.0 -> 500
            else -> null
        }
        // V201 : un saut GPS peut franchir plusieurs seuils en une seule mise à jour.
        // On conserve la liste complète des seuils réellement franchis et, si aucune
        // fenêtre normale ne s'applique, on choisit le seuil franchi le plus proche.
        // V331 : considérer aussi comme franchi un seuil lorsque la mesure GPS
        // précédente tombait exactement dessus (ex. 100,0 m -> 94 m). Avec le test
        // strict `previousMeters > threshold`, cette situation pouvait sortir de la
        // fenêtre normale au relevé suivant et faire perdre complètement l'annonce.
        // Le >= rend le franchissement robuste sans créer de double annonce, puisque
        // spokenVoiceThresholds continue de verrouiller chaque palier déjà prononcé.
        val crossedThresholds = if (previousMeters != null && meters < previousMeters) {
            activeVoiceThresholds.filter { thresholdMeters ->
                thresholdMeters !in spokenVoiceThresholds &&
                    previousMeters > thresholdMeters.toDouble() &&
                    meters <= thresholdMeters.toDouble()
            }
        } else {
            emptyList()
        }
        val crossedThreshold = crossedThresholds.lastOrNull()
        // V335 : si un saut GPS franchit plusieurs paliers d'un coup, ne pas annoncer
        // une distance devenue trop éloignée de la position réelle. Exemple : 520 m ->
        // 85 m franchit 500/300/200/100 ; choisir le plus petit palier franchi (100 m),
        // donc celui qui reste le plus proche de la distance actuelle. `lastOrNull()`
        // dépendait de l'ordre décroissant de activeVoiceThresholds et retenait 500 m.
        val nearestCrossedThreshold = crossedThresholds.minOrNull()
        var threshold = windowThreshold ?: nearestCrossedThreshold
        // V355 : à l'arrêt, protéger aussi la consigne immédiate contre une dérive GPS
        // importante. V353 bloquait les paliers 200/100/50 m mais laissait toujours
        // passer le seuil final : un glissement ponctuel de 60-80 m vers moins de 35 m
        // pouvait donc encore faire dire « tournez » alors que la VSP n'avait pas bougé.
        // On autorise la consigne finale à l'arrêt seulement si la dernière distance
        // fiable était déjà proche du virage (marge de 25 m), ou s'il s'agit de la
        // première consigne d'une nouvelle manœuvre. Un arrêt réel juste avant
        // l'intersection reste donc guidé, sans transformer une dérive GPS en faux virage.
        // V356 : à l'arrêt, tenir aussi compte de la précision réelle du fix GPS.
        // Avec une précision médiocre (par ex. ±40/50 m), une position peut sembler
        // entrer artificiellement dans la zone « tournez maintenant » même si la
        // distance précédente était relativement proche. On n'autorise donc cette
        // consigne à l'arrêt que si le fix reste au moins moyen (<= 35 m), sauf si
        // la distance fiable précédente était déjà dans la zone immédiate elle-même.
        // V357 : resserrer encore la fiabilité de la consigne immédiate à l'arrêt.
        // Une précision annoncée à ±30/35 m reste trop proche de la zone finale
        // (35/37/40 m) pour distinguer sûrement « avant le carrefour » de « au carrefour ».
        // Si la distance précédente n'était pas déjà dans la zone immédiate, exiger
        // désormais un fix <= 25 m avant d'autoriser « tournez maintenant » à l'arrêt.
        // V358 : rendre la précision exigée proportionnelle à la zone immédiate.
        // Un seuil fixe de 25 m restait relativement large face à une zone finale de
        // seulement 35 à 40 m. À l'arrêt, si la position précédente n'était pas déjà
        // dans cette zone, on exige maintenant une précision représentant au maximum
        // 60 % de la distance de consigne immédiate (21 / 22,2 / 24 m selon la bande).
        // Cela réduit encore le risque qu'un fix imprécis place artificiellement la
        // VSP sur le carrefour, tout en conservant la consigne si elle était déjà proche.
        // V368 : aligner aussi la protection à l'arrêt sur la zone immédiate réellement
        // utilisable après correction de précision (V367). Avec un GPS dégradé, V367
        // pouvait réduire par exemple 40 m à 28 m, alors que la logique stationnaire
        // continuait encore à considérer 40 m comme « déjà dans la zone ». On utilise
        // désormais effectiveImmediateVoiceDistanceMeters partout dans ce contrôle afin
        // qu'une ancienne position à 35-40 m ne contourne pas la pénalité de précision.
        val stationaryImmediateMaxAccuracyMeters =
            (effectiveImmediateVoiceDistanceMeters * 0.60).coerceAtMost(25.0)
        // V359 : protéger aussi la toute première consigne immédiate d'une manœuvre.
        // Jusqu'ici, previousMeters == null suffisait à considérer la position fiable :
        // au démarrage d'un trajet, un premier fix très imprécis pouvait donc annoncer
        // un virage immédiat alors que la VSP était encore à l'arrêt. Sans historique,
        // on exige désormais la même précision adaptative que pour une entrée récente
        // dans la zone du carrefour. Une position déjà confirmée dans la zone immédiate
        // reste prioritaire, afin de ne pas retarder une vraie consigne au feu ou au stop.
        val stationaryImmediateReliable = if (previousMeters == null) {
            gpsAccuracyMeters <= stationaryImmediateMaxAccuracyMeters
        } else {
            previousMeters <= effectiveImmediateVoiceDistanceMeters ||
                (gpsAccuracyMeters <= stationaryImmediateMaxAccuracyMeters &&
                    previousMeters <= effectiveImmediateVoiceDistanceMeters + 25.0)
        }
        // V360 : appliquer cette protection aussi à la toute première consigne de la
        // manœuvre. V359 calculait bien stationaryImmediateReliable pour previousMeters == null,
        // mais la condition ci-dessous exemptait encore isNewVoiceManeuver : le premier fix
        // imprécis pouvait donc malgré tout laisser passer le seuil immédiat. À l'arrêt, toute
        // consigne « tournez maintenant », nouvelle manœuvre comprise, doit désormais satisfaire
        // le contrôle de précision adaptatif.
        if (!movementRecentlyConfirmed && threshold == 0 && !stationaryImmediateReliable) {
            threshold = null
        }
        // V353 : pendant un arrêt réel, une petite dérive GPS peut faire diminuer la
        // distance de quelques mètres et traverser artificiellement un palier vocal.
        // Ne pas annoncer 200/100/50 m tant qu'aucun mouvement récent n'est confirmé.
        // La consigne immédiate reste autorisée, tout comme la première annonce d'une
        // nouvelle manœuvre (utile lorsque l'itinéraire démarre alors que la VSP est
        // encore stationnée). Dès que le véhicule repart, movementRecentlyConfirmed
        // relance cet effet et les annonces normales reprennent avec la distance réelle.
        if (!movementRecentlyConfirmed && !isNewVoiceManeuver && threshold != 0) {
            threshold = null
        }
        // V317 : lorsqu'une hausse de distance est rejetée comme recalage GPS, ne pas
        // l'enregistrer comme nouvelle référence. Sinon, après 230 -> 305 m (rejeté),
        // le retour normal à 230 m ressemblait au franchissement du seuil 300 m et
        // pouvait déclencher exactement l'annonce tardive que V316 cherchait à éviter.
        // On conserve donc la dernière distance fiable jusqu'à ce que la progression
        // redevienne cohérente.
        // V354 : lorsqu'une dérive GPS est ignorée pendant un arrêt (V353), ne pas
        // mémoriser malgré tout cette fausse diminution comme nouvelle référence.
        // Sinon, une dérive 115 m -> 95 m à l'arrêt pouvait consommer implicitement
        // le franchissement des 100 m : au redémarrage, l'annonce utile n'était plus
        // détectée. On fige donc la référence de distance pendant l'arrêt pour une
        // manœuvre déjà active ; elle se remet à jour dès qu'un mouvement est confirmé.
        // V370 : avec une précision GPS très dégradée (> ±45 m), ne pas prononcer
        // une distance de virage qui pourrait être trompeuse. On fige aussi la référence
        // de distance : dès que la précision redevient correcte, le franchissement utile
        // peut encore être détecté au lieu d'avoir été consommé silencieusement.
        // LaunchedEffect dépend maintenant de gpsAccuracyMeters, donc la reprise est
        // immédiate dès qu'un meilleur fix arrive.
        // V372 : appliquer une hystérésis autour de la limite de précision vocale.
        // Cela évite le pompage ON/OFF lorsque l'accuracy alterne par exemple entre
        // 44 et 46 m. Une fois suspendue, la voix attend un vrai retour à <= 40 m.
        // V375 : si la précision se dégrade pendant qu'une phrase est déjà en cours,
        // couper cette annonce immédiatement. V370/V372 empêchaient bien le départ de
        // nouvelles annonces, mais une phrase lancée juste avant le passage au-dessus
        // de ±48 m pouvait continuer alors que sa distance n'était plus assez fiable.
        // On ne coupe qu'au moment exact de l'entrée dans l'état faible afin de ne pas
        // appeler stop() à chaque nouveau fix tant que la précision reste dégradée.
        val voiceAccuracyWasWeak = voiceAccuracyWeak
        val voiceAccuracyNowElapsed = android.os.SystemClock.elapsedRealtime()
        // V379 : ne pas suspendre inutilement les annonces lointaines lorsque la
        // précision GPS est seulement moyenne. À plus de 250 m de la manœuvre, une
        // précision jusqu'à ±60 m reste suffisante pour préparer le conducteur ; près
        // du virage, on conserve la limite stricte de ±48 m. L'hystérésis associée
        // (52/40 m) évite toujours les bascules répétées autour des seuils.
        // V380 : supprimer la rupture brutale de tolérance exactement à 250 m.
        // Avec V379, une simple variation 251 -> 249 m pouvait faire passer la limite
        // de précision de 60 m à 48 m et couper la voix alors que la qualité GPS n'avait
        // pas changé. Entre 200 et 300 m, faire évoluer progressivement les seuils :
        // 48 -> 60 m pour la suspension et 40 -> 52 m pour la reprise. Cela conserve
        // la sécurité stricte près du virage et la tolérance utile à longue distance,
        // sans bascule artificielle au voisinage de 250 m.
        val voiceAccuracyDistanceBlend = ((meters - 200.0) / 100.0).coerceIn(0.0, 1.0)
        val voiceAccuracySuspendMeters = 48.0 + (12.0 * voiceAccuracyDistanceBlend)
        val voiceAccuracyResumeMeters = 40.0 + (12.0 * voiceAccuracyDistanceBlend)
        voiceAccuracyWeak = when {
            voiceAccuracyWeak && gpsAccuracyMeters <= voiceAccuracyResumeMeters -> false
            !voiceAccuracyWeak && gpsAccuracyMeters > voiceAccuracySuspendMeters -> true
            else -> voiceAccuracyWeak
        }
        val voiceAccuracyTooWeak = voiceAccuracyWeak
        if (!voiceAccuracyWasWeak && voiceAccuracyTooWeak) {
            voiceAccuracyWeakSinceElapsed = voiceAccuracyNowElapsed
            textToSpeech.stop()
            lastSpokenInstruction = ""
            lastSpokenInstructionElapsed = 0L
            lastVoiceAnnouncementElapsed = 0L
            // V376 : une entrée en précision GPS faible invalide aussi toute confirmation
            // de gros bond vocal en cours. La logique de bond est évaluée plus haut dans
            // cet effet ; sans ce reset, un candidat mémorisé avec un fix devenu imprécis
            // pouvait survivre à la suspension puis être confirmé au retour d'un bon GPS,
            // provoquant une annonce basée sur une ancienne anomalie de position.
            pendingVoiceJumpDistanceMeters = null
            pendingVoiceJumpElapsed = 0L
            pendingVoiceJumpConfirmations = 0
        }
        // V378 : si la voix est restée suspendue plus de 10 s, la distance mémorisée
        // avant la dégradation est trop ancienne pour détecter proprement un palier.
        // À la reprise, repartir de la distance courante évite par exemple d'annoncer
        // « 300 m » après avoir parcouru une longue portion avec un GPS imprécis.
        // La consigne immédiate reste autorisée afin de ne jamais masquer un virage proche.
        val recoveredAfterLongWeakAccuracy =
            voiceAccuracyWasWeak && !voiceAccuracyTooWeak &&
                voiceAccuracyWeakSinceElapsed > 0L &&
                voiceAccuracyNowElapsed - voiceAccuracyWeakSinceElapsed >= 10_000L
        if (voiceAccuracyTooWeak) {
            threshold = null
        } else if (recoveredAfterLongWeakAccuracy) {
            if (threshold != 0) threshold = null
            previousVoiceDistanceMeters = meters
            voiceAccuracyWeakSinceElapsed = 0L
        } else if (voiceAccuracyWasWeak && !voiceAccuracyTooWeak) {
            voiceAccuracyWeakSinceElapsed = 0L
        }
        val keepVoiceDistanceReferenceFrozen =
            (!movementRecentlyConfirmed && !isNewVoiceManeuver) || voiceAccuracyTooWeak
        if (!keepVoiceDistanceReferenceFrozen && (distanceProgressionReliable || previousMeters == null)) {
            previousVoiceDistanceMeters = meters
        }

        if (threshold != null && threshold !in spokenVoiceThresholds) {
            // V310 : laisser une annonce se terminer avant d’en lancer une autre.
            // V311 : exception pour la consigne immédiate (<= 35 m). Une annonce de
            // préparation encore en cours ne doit jamais retarder le « tournez maintenant »
            // quand la VSP arrive réellement sur l'intersection. L'espacement de 2,5 s
            // reste appliqué uniquement aux annonces de distance (500/300/200/100/50 m).
            val voiceNowElapsed = android.os.SystemClock.elapsedRealtime()
            val isImmediateInstruction = threshold == 0
            // V313 : une nouvelle manœuvre déjà proche (100 m ou moins) est prioritaire.
            // Le délai anti-chevauchement de 2,5 s protège toujours les annonces ordinaires,
            // mais il ne doit pas faire rater la préparation d'un second virage très rapproché.
            // La consigne immédiate reste, comme en V311, toujours prioritaire.
            val urgentNewManeuver = isNewVoiceManeuver && meters <= 110.0
            // V327 : le rappel à 50 m devient lui aussi prioritaire. À 45 km/h,
            // 2,5 secondes représentent plus de 30 m : si l'annonce à 100 m vient
            // d'être prononcée tardivement après un saut GPS, appliquer encore le
            // délai anti-chevauchement pouvait repousser le rappel 50 m presque
            // jusqu'au virage. On autorise donc ce dernier rappel sans temporisation,
            // tout en conservant la protection pour les annonces 500/300/200/100 m.
            val finalDistanceReminder = threshold == 50
            // V328 : adapter aussi l'anti-chevauchement à la vitesse. À 35-45 km/h,
            // attendre systématiquement 2,5 s entre deux annonces peut représenter
            // plus de 30 m parcourus et retarder inutilement une préparation utile.
            // On conserve 2,5 s à faible allure, 2,2 s en plage intermédiaire et
            // 1,8 s en plage haute. Les rappels 50 m et immédiats restent prioritaires.
            val minimumVoiceGapMs = when (voiceSpeedBand) {
                2 -> 1800L
                1 -> 2200L
                else -> 2500L
            }
            if (!isImmediateInstruction && !finalDistanceReminder && !urgentNewManeuver &&
                lastVoiceAnnouncementElapsed > 0L &&
                voiceNowElapsed - lastVoiceAnnouncementElapsed < minimumVoiceGapMs
            ) {
                previousVoiceDistanceMeters = previousMeters
                return@LaunchedEffect
            }
            val crossedOutsideWindow = windowThreshold == null && nearestCrossedThreshold == threshold
            val spokenInstruction = if (crossedOutsideWindow && threshold != 0) {
                // V332 : lors d’un franchissement de seuil provoqué par un saut entre
                // deux relevés GPS, annoncer la distance arrondie la PLUS PROCHE plutôt
                // que systématiquement l’arrondi inférieur. Exemple : à 148 m après
                // avoir franchi 200 m, dire « environ 150 mètres » est plus fidèle que
                // « environ 100 mètres ». Sous 100 m on conserve un pas de 10 m ; au-delà,
                // un pas de 50 m garde une annonce simple et naturelle à l’oreille.
                // V333 : conserver l'arrondi le plus proche seulement s'il ne
                // surestime pas la distance de plus de 10 m. Exemple : 148 m ->
                // « environ 150 m », mais 126 m -> « environ 100 m » plutôt que
                // « environ 150 m ». Le guidage reste naturel sans donner
                // l'impression que le virage est plus loin qu'il ne l'est réellement.
                val roundingStep = if (meters < 100.0) 10.0 else 50.0
                val nearestRounded = (kotlin.math.round(meters / roundingStep) * roundingStep).toInt()
                val lowerRounded = (kotlin.math.floor(meters / roundingStep) * roundingStep).toInt()
                val roundedCurrentMeters = if (nearestRounded.toDouble() - meters <= 10.0) {
                    nearestRounded
                } else {
                    lowerRounded
                }.coerceAtLeast(if (meters < 100.0) 10 else 50)
                "Dans environ $roundedCurrentMeters mètres, ${maneuver.spokenTitle}"
            } else when (threshold) {
                500 -> "Dans 500 mètres, ${maneuver.spokenTitle}"
                300 -> "Dans 300 mètres, ${maneuver.spokenTitle}"
                200 -> "Dans 200 mètres, ${maneuver.spokenTitle}"
                100 -> "Dans 100 mètres, ${maneuver.spokenTitle}"
                50 -> "Dans 50 mètres, ${maneuver.spokenTitle}"
                // Au dernier seuil, annoncer directement la consigne sans dire « Maintenant ».
                else -> maneuver.spokenTitle
            }

            // ETAPE 49 : anti-doublon entre deux manœuvres successives. Un changement
            // de clé peut produire deux fois la même phrase à quelques instants d'intervalle
            // (notamment après la sortie d'un rond-point). Ne pas la répéter pendant 8 s.
            // Le numéro de sortie / nom de rue faisant partie du texte, deux vraies consignes
            // différentes ne sont pas fusionnées.
            val normalizedSpokenInstruction = spokenInstruction.trim().lowercase(Locale.ROOT)
                .replace(Regex("\\s+"), " ")
            val normalizedLastSpokenInstruction = lastSpokenInstruction.trim().lowercase(Locale.ROOT)
                .replace(Regex("\\s+"), " ")
            if (normalizedSpokenInstruction.isNotBlank() &&
                normalizedSpokenInstruction == normalizedLastSpokenInstruction &&
                lastSpokenInstructionElapsed > 0L &&
                voiceNowElapsed - lastSpokenInstructionElapsed < 8_000L) {
                spokenVoiceThresholds = spokenVoiceThresholds + threshold
                previousVoiceDistanceMeters = meters
                return@LaunchedEffect
            }

            // V202 : ne considérer une annonce comme réellement passée que si Android
            // accepte la demande TTS. Si speak() échoue, on conserve l'ancienne distance
            // de référence afin que le seuil puisse être retenté à la prochaine mise à jour
            // au lieu de perdre définitivement une consigne importante.
            val speechResult = textToSpeech.speak(
                spokenInstruction,
                TextToSpeech.QUEUE_FLUSH,
                null,
                "vsp_guidance_${key.hashCode()}_$threshold"
            )
            if (speechResult != TextToSpeech.ERROR) {
                // V201 : une seule consigne est prononcée, mais tous les seuils réellement
                // franchis pendant le saut GPS sont mémorisés comme consommés. Cela évite
                // qu'une ancienne annonce (500/200/100/50 m) puisse ressortir plus tard.
                // V315 : une fois la consigne immédiate prononcée, considérer aussi
                // tous les paliers de distance de cette manœuvre comme consommés.
                // Sans cela, un petit recul de distance dû au GPS (par ex. 25 m -> 80 m)
                // pouvait faire annoncer ensuite « Dans 50/100 mètres » alors que le
                // virage venait déjà d'être annoncé. La prochaine vraie manœuvre réarme
                // naturellement tous les seuils via voiceManeuverKey.
                val consumedThresholds = if (threshold == 0) {
                    crossedThresholds.toSet() + activeVoiceThresholds.toSet() + 0
                } else {
                    crossedThresholds.toSet() + threshold
                }
                spokenVoiceThresholds = spokenVoiceThresholds + consumedThresholds
                lastVoiceAnnouncementElapsed = voiceNowElapsed
                lastSpokenInstruction = spokenInstruction
                lastSpokenInstructionElapsed = voiceNowElapsed
            } else {
                previousVoiceDistanceMeters = previousMeters
            }
        }
    }

    // Feuille de route : Valhalla peut parfois fournir deux manœuvres successives
    // pour un même rond-point (entrée/sortie). Pour l'affichage uniquement, on les
    // regroupe afin d'éviter deux cartes consécutives pour le même rond-point.
    val roadmapManeuvers = remember(route.maneuvers) {
        val source = route.maneuvers
        val merged = mutableListOf<RouteManeuver>()
        var i = 0
        while (i < source.size) {
            val current = source[i]
            // V421 : la feuille de route suit la même règle stricte que le guidage :
            // seul le type Valhalla 26/27 peut identifier un rond-point. Le texte
            // traduit ("sortie", "rond-point") et roundaboutExitCount ne peuvent
            // plus transformer une intersection ordinaire en faux rond-point.
            val currentRoundabout = isValhallaRoundabout(current.type)

            if (currentRoundabout && i + 1 < source.size) {
                val next = source[i + 1]
                val nextRoundabout = isValhallaRoundabout(next.type)

                // On ne fusionne que deux manœuvres de rond-point vraiment voisines
                // dans la géométrie de l'itinéraire. Le guidage vocal reste inchangé.
                if (nextRoundabout &&
                    current.type == 26 && next.type == 27 &&
                    next.beginShapeIndex >= current.beginShapeIndex &&
                    next.beginShapeIndex - current.endShapeIndex <= 8
                ) {
                    // ETAPE 55 : pour une paire entrée(26) -> sortie(27), le numéro
                    // de la manœuvre de sortie est la référence. Cela aligne la feuille
                    // de route avec le guidage principal et évite aussi de fusionner
                    // deux entrées de ronds-points successifs.
                    val exitCount = when {
                        next.roundaboutExitCount > 0 -> next.roundaboutExitCount
                        current.roundaboutExitCount > 0 -> current.roundaboutExitCount
                        else -> 0
                    }
                    // V433 : même formateur que le guidage principal. La feuille de route
                    // ne reconstruit plus elle-même « 1re / Ne », ce qui évite qu'un futur
                    // changement de libellé diverge entre la carte et la liste des étapes.
                    val exitInstruction = if (exitCount > 0) {
                        "Prenez la ${roundaboutExitVisualLabel(exitCount)} sortie"
                    } else {
                        current.instruction
                    }
                    val road = next.streetNames.ifBlank { current.streetNames }

                    merged += current.copy(
                        instruction = exitInstruction,
                        streetNames = road,
                        endShapeIndex = kotlin.math.max(current.endShapeIndex, next.endShapeIndex),
                        roundaboutExitCount = exitCount
                    )
                    i += 2
                    continue
                }
            }

            merged += current
            i++
        }
        merged
    }

    // V432 : l'arrivée est identifiée d'abord par les types Valhalla officiels
    // (4/5/6), et non plus seulement en analysant le texte de l'instruction.
    // Le contrôle textuel reste en secours pour tolérer une réponse serveur ancienne
    // ou atypique. Cela évite qu'une arrivée formulée différemment apparaisse comme
    // une étape de conduite supplémentaire dans la feuille de route.
    val roadmapDrivingManeuvers = remember(roadmapManeuvers) {
        roadmapManeuvers.filterNot { step ->
            if (isValhallaArrival(step.type)) {
                true
            } else {
                val instruction = step.instruction.trim()
                instruction.startsWith("Votre destination est", ignoreCase = true) ||
                    instruction.contains("arrivé à votre destination", ignoreCase = true) ||
                    instruction.contains("arrive at your destination", ignoreCase = true)
            }
        }
    }

    if (showRoadmap) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showRoadmap = false },
            title = {
                Column {
                    Text("Étapes de l’itinéraire")
                    Text(
                        "${
                            if (route.distanceMeters < 1000.0)
                                "${route.distanceMeters.toInt()} m"
                            else
                                String.format(java.util.Locale.FRANCE, "%.1f km", route.distanceMeters / 1000.0)
                        } • ${
                            vspDisplayMinutes(route.durationSeconds)
                        } min • ${roadmapDrivingManeuvers.size + 1} étapes",
                        fontSize = 14.sp,
                        color = Color.Gray
                    )
                    Text(
                        "Itinéraire calculé avec le profil VSP",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            },
            text = {
                androidx.compose.foundation.lazy.LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 560.dp)
                ) {
                    items(roadmapDrivingManeuvers.size) { index ->
                        val step = roadmapDrivingManeuvers[index]
                        val previousIndex = if (index == 0) 0
                            else roadmapDrivingManeuvers[index - 1].beginShapeIndex
                        val distanceText = formatRoadmapDistance(
                            maneuverDistanceMeters(route.points, previousIndex, step.beginShapeIndex)
                        )
                        val isRoundabout = isValhallaRoundabout(step.type)
                        val shortInstruction = when {
                            isRoundabout && step.roundaboutExitCount > 0 ->
                                "Prenez la ${roundaboutExitVisualLabel(step.roundaboutExitCount)} sortie"
                            isRoundabout -> "Au rond-point"
                            else -> step.instruction
                                .substringBefore(". ")
                                .substringBefore(" sur ", missingDelimiterValue = step.instruction.substringBefore(". "))
                                .substringBefore(" dans ")
                                .trim()
                                .trimEnd('.')
                                .ifBlank { "Continuez" }
                        }

                        androidx.compose.material3.Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp),
                            shape = RoundedCornerShape(14.dp),
                            tonalElevation = 2.dp
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(end = 12.dp)
                                ) {
                                    Text(
                                        "${index + 1}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.Gray
                                    )
                                    Text(
                                        maneuverArrow(step.type),
                                        fontSize = 34.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        shortInstruction,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (step.streetNames.isNotBlank()) {
                                        Text(
                                            step.streetNames,
                                            fontSize = 14.sp,
                                            color = Color.Gray,
                                            modifier = Modifier.padding(top = 2.dp)
                                        )
                                    }
                                }
                                if (distanceText.isNotBlank()) {
                                    Text(
                                        distanceText,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF1976D2),
                                        modifier = Modifier.padding(start = 10.dp)
                                    )
                                }
                                // V137 : écoute d'une étape depuis la feuille de route.
                                // On réutilise le libellé déjà calculé pour l'affichage afin
                                // d'éviter une seconde logique spécifique aux ronds-points.
                                androidx.compose.material3.TextButton(
                                    onClick = {
                                        if (ttsReady) {
                                            val spokenRoadmapStep = if (step.streetNames.isNotBlank()) {
                                                "$shortInstruction, ${step.streetNames}"
                                            } else {
                                                shortInstruction
                                            }
                                            textToSpeech.stop()
                                            textToSpeech.speak(
                                                spokenRoadmapStep,
                                                TextToSpeech.QUEUE_FLUSH,
                                                null,
                                                "roadmap_step_${index}"
                                            )
                                        }
                                    },
                                    enabled = ttsReady,
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                    modifier = Modifier.padding(start = 2.dp)
                                ) {
                                    Text("🔊", fontSize = 20.sp)
                                }
                            }
                        }
                    }
                    // ETAPE 50 : diagnostic brut Valhalla. Tant que le rond-point
                    // intermédiaire de Nœux-les-Mines n'est pas expliqué, on affiche
                    // volontairement les manœuvres NON fusionnées reçues du moteur.
                    // Une capture de cette section permet de savoir si le moteur fournit
                    // le rond-point (types 26/27) ou si le problème est en aval.
                    item {
                        Text(
                            "DIAGNOSTIC ÉTAPE 50 — Valhalla brut",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFC857),
                            modifier = Modifier.padding(top = 14.dp, bottom = 4.dp)
                        )
                        Text(
                            "segment suivi = ${trackedRouteSegment ?: -1} • simulation = $simulationRouteSegment • ${route.maneuvers.size} manœuvre(s)",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }
                    items(route.maneuvers.size) { rawIndex ->
                        val raw = route.maneuvers[rawIndex]
                        val rawRoundabout = isValhallaRoundabout(raw.type)
                        androidx.compose.material3.Surface(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                            shape = RoundedCornerShape(10.dp),
                            tonalElevation = 1.dp
                        ) {
                            Column(modifier = Modifier.fillMaxWidth().padding(9.dp)) {
                                Text(
                                    "RAW ${rawIndex + 1} • type=${raw.type} • shape=${raw.beginShapeIndex}→${raw.endShapeIndex}" +
                                        if (rawRoundabout) " • ROND-POINT sortie=${raw.roundaboutExitCount}" else "",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (rawRoundabout) Color(0xFFFFC857) else Color.White
                                )
                                Text(
                                    raw.instruction.ifBlank { "(instruction vide)" },
                                    fontSize = 11.sp,
                                    color = Color.LightGray
                                )
                                if (raw.streetNames.isNotBlank()) {
                                    Text(raw.streetNames, fontSize = 10.sp, color = Color.Gray)
                                }
                            }
                        }
                    }

                    item {
                        androidx.compose.material3.Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp, bottom = 2.dp),
                            shape = RoundedCornerShape(14.dp),
                            tonalElevation = 2.dp
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(end = 12.dp)
                                ) {
                                    Text(
                                        "${roadmapDrivingManeuvers.size + 1}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.Gray
                                    )
                                    Text(if (isIntermediateChargeStep) "⚡" else "🏁", fontSize = 30.sp)
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        if (isIntermediateChargeStep) "Étape recharge" else "Arrivée",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(destination.label, fontSize = 14.sp, color = Color.Gray)
                                }
                                // V139 : permet de tester l'annonce d'arrivée directement
                                // depuis la feuille de route, sans devoir se déplacer.
                                androidx.compose.material3.TextButton(
                                    onClick = {
                                        if (ttsReady) {
                                            val arrivalRoadmapVoice = if (isIntermediateChargeStep) {
                                                "Étape recharge atteinte."
                                            } else {
                                                destinationSide?.let { side ->
                                                    "Vous êtes arrivé à destination. Votre destination se trouve sur votre $side."
                                                } ?: "Vous êtes arrivé à destination."
                                            }
                                            textToSpeech.stop()
                                            textToSpeech.speak(
                                                arrivalRoadmapVoice,
                                                TextToSpeech.QUEUE_FLUSH,
                                                null,
                                                "roadmap_arrival"
                                            )
                                        }
                                    },
                                    enabled = ttsReady,
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                    modifier = Modifier.padding(start = 2.dp)
                                ) {
                                    Text("🔊", fontSize = 20.sp)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showRoadmap = false }) { Text("Fermer") }
            }
        )
    }

DisposableEffect(Unit) {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (simulationActive) return
                // V169 : Android peut exceptionnellement livrer un fix mis en cache au
                // moment de l'abonnement. On vérifie donc son âge monotone avant de le
                // laisser piloter la navigation. Un fix vieux de plus de 8 s est ignoré.
                val callbackFixAgeMs = locationAgeMillis(location)
                if (callbackFixAgeMs > gpsFreshnessLimitMs(location)) {
                    gpsFixFresh = false
                    return
                }

                // V394 : un callback GPS réellement récent prouve que le récepteur GPS
                // fonctionne, même si le point est ensuite écarté par le filtre anti-saut.
                // Auparavant, un point précis pouvait être rejeté avant le réarmement de
                // lastGpsFixAtElapsed : le badge affichait alors « GPS précis ±3 m » tandis
                // que le bandeau restait bloqué sur « Signal GPS insuffisant ».
                // On réarme uniquement la fraîcheur ici ; liveLocation n'est toujours
                // modifiée qu'après validation complète du point, donc aucun saut de carte.
                lastGpsFixAtElapsed = android.os.SystemClock.elapsedRealtime() - callbackFixAgeMs
                gpsFixFresh = true

                // V300 : filtrer les "téléportations" GPS isolées avant qu'elles ne
                // déplacent la voiture, la progression ou le recalcul. Même avec une bonne
                // accuracy déclarée, Android peut exceptionnellement livrer un point aberrant.
                // On ne filtre que les sauts très rapides (< 5 s) et manifestement impossibles
                // pour une VSP ; après une vraie perte/reprise GPS, le nouveau fix reste accepté.
                val previousFix = liveLocation
                if (previousFix != null &&
                    previousFix.elapsedRealtimeNanos > 0L &&
                    location.elapsedRealtimeNanos > previousFix.elapsedRealtimeNanos
                ) {
                    val deltaSeconds =
                        (location.elapsedRealtimeNanos - previousFix.elapsedRealtimeNanos) / 1_000_000_000.0
                    if (deltaSeconds in 0.05..5.0) {
                        val jumpResult = FloatArray(1)
                        Location.distanceBetween(
                            previousFix.latitude,
                            previousFix.longitude,
                            location.latitude,
                            location.longitude,
                            jumpResult
                        )
                        val jumpMeters = jumpResult[0].toDouble()
                        // 120 m de marge fixe + 35 m/s (~126 km/h) : seuil volontairement
                        // très permissif pour ne jamais rejeter un déplacement VSP réel.
                        val plausibleJumpMeters = 120.0 + 35.0 * deltaSeconds
                        if (jumpMeters > plausibleJumpMeters) {
                            val candidate = jumpCandidateLocation
                            val candidateDistance = if (candidate != null) {
                                val candidateResult = FloatArray(1)
                                Location.distanceBetween(
                                    candidate.latitude,
                                    candidate.longitude,
                                    location.latitude,
                                    location.longitude,
                                    candidateResult
                                )
                                candidateResult[0].toDouble()
                            } else Double.POSITIVE_INFINITY

                            // V301 : un seul grand saut reste rejeté. Si le fix suivant
                            // confirme la même nouvelle zone (rayon tenant compte de
                            // l'accuracy), on accepte immédiatement la reprise GPS réelle.
                            val confirmationRadius = kotlin.math.max(45.0,
                                (if (location.hasAccuracy()) location.accuracy.toDouble() else 25.0) * 1.5)
                            if (candidate != null && candidateDistance <= confirmationRadius) {
                                jumpCandidateCount += 1
                                if (jumpCandidateCount < 2) return
                            } else {
                                jumpCandidateLocation = Location(location)
                                jumpCandidateCount = 1
                                return
                            }
                        } else {
                            jumpCandidateLocation = null
                            jumpCandidateCount = 0
                        }
                    }
                }

                liveLocation = location
                jumpCandidateLocation = null
                jumpCandidateCount = 0
                // V164/V169 : chaque position réellement récente réarme immédiatement le
                // contrôle de fraîcheur. Sans nouveau fix pendant 8 s, le guidage
                // se suspend au lieu de continuer sur une ancienne position.
                lastGpsFixAtElapsed = android.os.SystemClock.elapsedRealtime() - callbackFixAgeMs
                gpsFixFresh = true

                // Ne change l'orientation que lorsque le véhicule se déplace réellement.
                // Cela évite que la carte tourne dans tous les sens à l'arrêt ou à très basse vitesse.
                if (location.hasBearing() && location.hasSpeed() && location.speed >= 1.5f) {
                    // Lisse les changements de cap pour éviter les rotations brusques de la carte.
                    val targetBearing = location.bearing
                    var delta = (targetBearing - liveBearing + 540f) % 360f - 180f
                    if (kotlin.math.abs(delta) < 2f) delta = 0f
                    liveBearing = (liveBearing + delta * 0.28f + 360f) % 360f
                }
            }
        }

        val fineGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (fineGranted || coarseGranted) {
            try {
                // V280 : GPS satellite uniquement pour la navigation. V279 écoutait
                // aussi NETWORK_PROVIDER, ce qui pouvait remplacer un fix GPS à ±3 m
                // par une position réseau à ±100 m. À l'arrêt, la fraîcheur est désormais
                // gérée par une tolérance temporelle adaptée au lieu de dégrader la source.
                locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    1000L,
                    0f,
                    listener
                )
            } catch (_: Exception) {
            }
        }

        onDispose {
            try {
                locationManager.removeUpdates(listener)
            } catch (_: Exception) {
            }
            // V261 : NavigationScreen ne possède pas l'AtomicReference activeRouteCall
            // de MapSearchScreen. L'ancien accès hors portée empêchait la compilation.
            // Les calculs de l'écran précédent restent annulés par leur propre cycle de vie.
        }
    }

    // ETAPE 34 : simulation + cap dynamique de la flèche de navigation.
    // Le cap est calculé sur le segment réellement parcouru afin que la pointe
    // tourne dans chaque virage, y compris lorsque le GPS réel n'est pas utilisé.
    // ETAPE 39 : pendant la marche arrière, aucune consigne vocale n'est jouée.
    // Quand on repart en avant, on réarme les seuils de la manœuvre courante afin de
    // pouvoir réécouter le passage revu (100 m puis consigne immédiate).
    LaunchedEffect(simulationRewinding, simulationPaused, ttsReady) {
        if (simulationRewinding || simulationPaused) {
            if (ttsReady) textToSpeech.stop()
        } else if (simulationActive) {
            spokenVoiceThresholds = emptySet()
            previousVoiceDistanceMeters = null
            pendingVoiceJumpDistanceMeters = null
            pendingVoiceJumpElapsed = 0L
            pendingVoiceJumpConfirmations = 0
            lastVoiceAnnouncementElapsed = 0L
        }
    }

    // ETAPE 33 : avance fictive le long de la polyline à 30 km/h.
    // Le même moteur de progression que le vrai GPS reçoit ces points, ce qui permet
    // de tester à domicile les changements de manoeuvre, distances et ETA.
    LaunchedEffect(simulationActive, simulationPaused, routeRevisionKey) {
        if (!simulationActive || simulationPaused || route.points.size < 2) return@LaunchedEffect
        // ETAPE 37 : ne jamais remettre la progression à zéro lors d'un simple
        // changement de multiplicateur. Le LaunchedEffect ne dépend plus du multiplicateur :
        // il lit sa valeur courante à chaque tick.
        gpsNavigationReady = true
        gpsFixFresh = true
        val segmentLengths = route.points.zipWithNext { a, b -> a.distanceToAsDouble(b) }
        val total = segmentLengths.sum().coerceAtLeast(1.0)
        val cumulativeMeters131 = DoubleArray(route.points.size)
        for (i131 in 1 until route.points.size) {
            cumulativeMeters131[i131] = cumulativeMeters131[i131 - 1] + segmentLengths[i131 - 1]
        }
        val speedMps = 30.0 / 3.6
        while (simulationActive && (simulationRewinding || simulationMeters < total)) {
            var remaining = simulationMeters
            var seg = 0
            while (seg < segmentLengths.size - 1 && remaining > segmentLengths[seg]) {
                remaining -= segmentLengths[seg]
                seg++
            }
            // ETAPE 51 : publier le segment exact AVANT de produire le fix simulé.
            // Le guidage, les ronds-points et la marche arrière partagent ainsi une
            // seule progression ordonnée, sans ambiguïté géométrique.
            simulationRouteSegment = seg
            val a = route.points[seg]
            val b = route.points[(seg + 1).coerceAtMost(route.points.lastIndex)]
            val len = segmentLengths.getOrElse(seg) { 1.0 }.coerceAtLeast(0.1)
            val t = (remaining / len).coerceIn(0.0, 1.0)
            val segmentBearing = a.bearingTo(b).toFloat()
            val loc = Location("VSP_SIMULATION").apply {
                latitude = a.latitude + (b.latitude - a.latitude) * t
                longitude = a.longitude + (b.longitude - a.longitude) * t
                accuracy = 3f
                speed = speedMps.toFloat()
                bearing = segmentBearing
                elapsedRealtimeNanos = android.os.SystemClock.elapsedRealtimeNanos()
                time = System.currentTimeMillis()
            }
            // Même lissage que le GPS réel, mais alimenté par la géométrie du tracé.
            var bearingDelta = (segmentBearing - liveBearing + 540f) % 360f - 180f
            if (kotlin.math.abs(bearingDelta) < 1f) bearingDelta = 0f
            liveBearing = (liveBearing + bearingDelta * 0.42f + 360f) % 360f
            liveLocation = loc
            lastGpsFixAtElapsed = android.os.SystemClock.elapsedRealtime()
            gpsFixFresh = true
            // Le véhicule virtuel conserve une vitesse GPS de 30 km/h pour tester les mêmes
            // règles de guidage qu’une VSP. Seul le temps de parcours du test est accéléré.
            // ETAPE 131 : le mode ×16 reste très rapide sur les longues portions,
            // mais ralentit automatiquement à l'approche d'une vraie manœuvre afin
            // de ne pas sauter un rond-point, un virage, une bretelle ou l'arrivée.
            // Le multiplicateur choisi par l'utilisateur reste ×16 : seul le pas
            // EFFECTIF du simulateur est réduit temporairement puis remonte tout seul.
            val effectiveSimulationMultiplier = if (!simulationRewinding && simulationMultiplier >= 16) {
                val nextAttentionDistance131 = route.maneuvers.asSequence()
                    .filter { m131 ->
                        m131.beginShapeIndex in route.points.indices &&
                            !isValhallaStart(m131.type) &&
                            (isValhallaArrival(m131.type) ||
                                isValhallaRoundabout(m131.type) ||
                                isValhallaRightTurn(m131.type) ||
                                isValhallaLeftTurn(m131.type) ||
                                isValhallaRightLateral(m131.type) ||
                                isValhallaLeftLateral(m131.type) ||
                                isValhallaUTurn(m131.type))
                    }
                    .map { m131 -> cumulativeMeters131[m131.beginShapeIndex] - simulationMeters }
                    .filter { it >= -2.0 }
                    .minOrNull()
                when {
                    nextAttentionDistance131 == null -> 16
                    nextAttentionDistance131 <= 120.0 -> 1
                    nextAttentionDistance131 <= 250.0 -> 2
                    nextAttentionDistance131 <= 500.0 -> 4
                    nextAttentionDistance131 <= 1000.0 -> 8
                    else -> 16
                }
            } else {
                simulationMultiplier
            }
            val simulationStepMeters = if (simulationRewinding) {
                -speedMps * 0.5 * 2.0
            } else {
                speedMps * 0.5 * effectiveSimulationMultiplier
            }
            simulationMeters = (simulationMeters + simulationStepMeters).coerceIn(0.0, total)
            kotlinx.coroutines.delay(500L)
        }
        if (simulationActive) {
            val end = route.points.last()
            liveLocation = Location("VSP_SIMULATION").apply {
                latitude = end.latitude; longitude = end.longitude; accuracy = 3f; speed = 0f
                elapsedRealtimeNanos = android.os.SystemClock.elapsedRealtimeNanos(); time = System.currentTimeMillis()
            }
            simulationActive = false
        }
    }

    // V384 : vraie disposition de navigation en paysage. V383 conservait bien
    // l’itinéraire lors de la rotation, mais les cartes d’informations gardaient
    // leurs dimensions portrait et écrasaient la carte en une bande très fine.
    val navigationLandscape = androidx.compose.ui.platform.LocalConfiguration.current.orientation ==
        android.content.res.Configuration.ORIENTATION_LANDSCAPE

    // ETAPE 89 : banc d’essai sur le VRAI tracé Valhalla actuellement chargé.
    // Les boutons ne fabriquent aucune manœuvre : ils repèrent des situations réellement
    // présentes dans route.maneuvers puis placent le simulateur ~220 m avant la zone.
    // Cela permet d’enchaîner plusieurs vidéos courtes sans rechercher manuellement les routes.
    var showRealGpsTests89 by remember { mutableStateOf(false) }
    // ETAPE 93 : progression d'un lot de tests sans rechercher manuellement chaque cas.
    var currentRealGpsTestIndex93 by remember(routeRevisionKey) { mutableStateOf(-1) }
    val cumulativeRouteMeters89 = remember(routeRevisionKey) {
        val cumulative = MutableList(route.points.size) { 0.0 }
        for (i in 1 until route.points.size) {
            cumulative[i] = cumulative[i - 1] + route.points[i - 1].distanceToAsDouble(route.points[i])
        }
        cumulative
    }
    data class RealGpsTest89(val label: String, val shapeIndex: Int, val detail: String)
    // ETAPE 89 CORRECTIF : formateur local au banc de tests.
    // distanceLabel() appartient au calcul de guidage et n'est pas visible dans ce scope Compose.
    fun testDistanceLabel89(meters: Double): String = when {
        meters < 1000.0 -> "${meters.toInt()} m"
        else -> String.format(java.util.Locale.FRANCE, "%.1f km", meters / 1000.0)
    }
    // ETAPE 103 : le banc de tests reconstruit les ronds-points à partir de
    // leurs vraies paires Valhalla kRoundaboutEnter (26) -> kRoundaboutExit (27).
    // L'ancien calcul utilisait endShapeIndex de la sortie, qui peut s'étendre très
    // loin sur la route suivante et produire un faux « écart réel 12 m » alors que
    // le rond-point suivant est encore à plusieurs centaines de mètres.
    data class RoundaboutTestGroup103(
        val enterManeuverIndex: Int,
        val exitManeuverIndex: Int,
        val entryShapeIndex: Int,
        val exitShapeIndex: Int,
        val exitCount: Int
    )

    val realGpsTests89 = remember(routeRevisionKey) {
        val tests = mutableListOf<RealGpsTest89>()
        val logical = route.maneuvers.withIndex().filter { (_, m) ->
            !isValhallaStart(m.type) && !isValhallaArrival(m.type) && m.beginShapeIndex in route.points.indices
        }

        // Construire chaque rond-point UNE seule fois : entrée 26 puis première sortie 27
        // avant une éventuelle nouvelle entrée 26. entryShapeIndex et exitShapeIndex sont
        // les seuls points utilisés pour mesurer les distances entre ronds-points.
        val roundaboutGroups103 = mutableListOf<RoundaboutTestGroup103>()
        var maneuverCursor103 = 0
        while (maneuverCursor103 < route.maneuvers.size) {
            val enter = route.maneuvers[maneuverCursor103]
            if (enter.type == 26 && enter.beginShapeIndex in route.points.indices) {
                var exitManeuverIndex103 = -1
                var j103 = maneuverCursor103 + 1
                while (j103 < route.maneuvers.size) {
                    val type103 = route.maneuvers[j103].type
                    if (type103 == 26) break
                    if (type103 == 27) {
                        exitManeuverIndex103 = j103
                        break
                    }
                    j103++
                }
                if (exitManeuverIndex103 >= 0) {
                    val exit = route.maneuvers[exitManeuverIndex103]
                    if (exit.beginShapeIndex in route.points.indices) {
                        val exitCount103 = exit.roundaboutExitCount.takeIf { it > 0 }
                            ?: enter.roundaboutExitCount.takeIf { it > 0 }
                            ?: 0
                        roundaboutGroups103 += RoundaboutTestGroup103(
                            enterManeuverIndex = maneuverCursor103,
                            exitManeuverIndex = exitManeuverIndex103,
                            entryShapeIndex = enter.beginShapeIndex,
                            exitShapeIndex = exit.beginShapeIndex,
                            exitCount = exitCount103
                        )
                        maneuverCursor103 = exitManeuverIndex103 + 1
                        continue
                    }
                }
            }
            maneuverCursor103++
        }

        // PRIORITE V106 : deux vrais ronds-points successifs. Mesure STRICTE entre
        // la sortie (type 27, beginShapeIndex) du premier et l'entrée (type 26,
        // beginShapeIndex) du second. Le simulateur est ancré AVANT l'entrée du premier.
        roundaboutGroups103.zipWithNext().firstOrNull { (a, b) ->
            val ia = a.exitShapeIndex.coerceIn(0, cumulativeRouteMeters89.lastIndex)
            val ib = b.entryShapeIndex.coerceIn(0, cumulativeRouteMeters89.lastIndex)
            val gap103 = cumulativeRouteMeters89[ib] - cumulativeRouteMeters89[ia]
            gap103 in 0.0..600.0
        }?.let { (a, b) ->
            val ia = a.exitShapeIndex.coerceIn(0, cumulativeRouteMeters89.lastIndex)
            val ib = b.entryShapeIndex.coerceIn(0, cumulativeRouteMeters89.lastIndex)
            val gap103 = (cumulativeRouteMeters89[ib] - cumulativeRouteMeters89[ia]).coerceAtLeast(0.0)
            val pairLabel106 = when {
                gap103 <= 120.0 -> "Deux ronds-points très rapprochés"
                gap103 <= 300.0 -> "Deux ronds-points successifs"
                else -> "Deux ronds-points proches"
            }
            tests += RealGpsTest89(
                pairLabel106,
                a.entryShapeIndex,
                "Sortie RP1 → entrée RP2 : ${testDistanceLabel89(gap103)} • mesure V106"
            )
        }

        // Deux vraies actions séparées de <= 250 m. Pour une action de rond-point,
        // utiliser sa vraie sortie plutôt qu'un endShapeIndex potentiellement lointain.
        fun testCompletionShape103(indexed: IndexedValue<RouteManeuver>): Int {
            val matchingRoundabout103 = roundaboutGroups103.firstOrNull { group ->
                indexed.index in group.enterManeuverIndex..group.exitManeuverIndex
            }
            return matchingRoundabout103?.exitShapeIndex
                ?: indexed.value.endShapeIndex.coerceIn(0, cumulativeRouteMeters89.lastIndex)
        }

        logical.zipWithNext().firstOrNull { (a, b) ->
            val ia = testCompletionShape103(a).coerceIn(0, cumulativeRouteMeters89.lastIndex)
            val ib = b.value.beginShapeIndex.coerceIn(0, cumulativeRouteMeters89.lastIndex)
            (cumulativeRouteMeters89[ib] - cumulativeRouteMeters89[ia]) in 0.0..250.0
        }?.let { (a, b) ->
            val ia = testCompletionShape103(a).coerceIn(0, cumulativeRouteMeters89.lastIndex)
            val ib = b.value.beginShapeIndex.coerceIn(0, cumulativeRouteMeters89.lastIndex)
            val gap = (cumulativeRouteMeters89[ib] - cumulativeRouteMeters89[ia]).coerceAtLeast(0.0)
            val detail106 = if (gap < 3.0) {
                "Enchaînement immédiat • même point de transition Valhalla"
            } else {
                "Écart réel ${testDistanceLabel89(gap)}"
            }
            tests += RealGpsTest89("1 • Deux manœuvres rapprochées", a.value.beginShapeIndex, detail106)
        }

        // ETAPE 106 : le numéro affiché ici est le même `roundaboutExitCount` que le guidage.
        // Sur le moteur local, cette valeur a déjà été corrigée par la topologie V105.
        // ETAPE 103 : le lancement est désormais ancré sur l'ENTREE du rond-point et non
        // sur la manœuvre de sortie, afin de toujours voir l'approche complète.
        roundaboutGroups103
            .filter { it.exitCount > 0 }
            .distinctBy { it.exitCount }
            .take(4)
            .forEach { group ->
                tests += RealGpsTest89(
                    "Rond-point • ${roundaboutExitVisualLabel(group.exitCount)} sortie",
                    group.entryShapeIndex,
                    "Compteur actif V105 : ${roundaboutExitVisualLabel(group.exitCount)} sortie • topologie locale prioritaire"
                )
            }

        // Rond-point suivi rapidement d'une autre vraie action, mesuré à partir de la
        // vraie sortie type 27 du rond-point.
        roundaboutGroups103.firstNotNullOfOrNull { group ->
            val next = route.maneuvers.withIndex()
                .drop(group.exitManeuverIndex + 1)
                .firstOrNull { indexed ->
                    val m = indexed.value
                    !isValhallaStart(m.type) && !isValhallaArrival(m.type) &&
                        !isValhallaRoundabout(m.type) && m.beginShapeIndex in route.points.indices
                }
                ?: return@firstNotNullOfOrNull null
            val ia = group.exitShapeIndex.coerceIn(0, cumulativeRouteMeters89.lastIndex)
            val ib = next.value.beginShapeIndex.coerceIn(0, cumulativeRouteMeters89.lastIndex)
            val gap = cumulativeRouteMeters89[ib] - cumulativeRouteMeters89[ia]
            if (gap in 0.0..300.0) Triple(group, next, gap) else null
        }?.let { (group, _, gap) ->
            val nextLabel114 = if (gap <= 120.0) {
                "Rond-point → action à moins de 120 m"
            } else {
                "Rond-point → manœuvre suivante"
            }
            tests += RealGpsTest89(
                nextLabel114,
                group.entryShapeIndex,
                "Enchaînement réel ${testDistanceLabel89(gap.coerceAtLeast(0.0))}"
            )
        }

        // ETAPE 107 : tests de VRAIS virages de rue seulement. Les types StayLeft/StayRight,
        // Ramp*, Exit* et Merge* sont volontairement exclus : le test 6 de V106 avait
        // choisi un StayLeft (24) et l'avait présenté à tort comme « Virage à gauche ».
        // Virages simples utiles pour contrôler flèche, caméra et annonce.
        logical.firstOrNull { isValhallaLeftTurn(it.value.type) }?.let {
            tests += RealGpsTest89("Virage à gauche", it.value.beginShapeIndex, "Cas réel du trajet")
        }
        logical.firstOrNull { isValhallaRightTurn(it.value.type) }?.let {
            tests += RealGpsTest89("Virage à droite", it.value.beginShapeIndex, "Cas réel du trajet")
        }

        // ETAPE 114 : ajouter les consignes latérales sans les appeler « virages ».
        // Elles couvrent les cas Gardez la gauche/droite, bretelles, sorties et fusions
        // qui avaient justement motivé la correction V107.
        logical.firstOrNull { isValhallaLeftLateral(it.value.type) }?.let {
            tests += RealGpsTest89(
                "Consigne latérale à gauche",
                it.value.beginShapeIndex,
                compactVisualInstruction(it.value.instruction).ifBlank { "Garder / bretelle / fusion à gauche" }
            )
        }
        logical.firstOrNull { isValhallaRightLateral(it.value.type) }?.let {
            tests += RealGpsTest89(
                "Consigne latérale à droite",
                it.value.beginShapeIndex,
                compactVisualInstruction(it.value.instruction).ifBlank { "Garder / bretelle / fusion à droite" }
            )
        }
        logical.firstOrNull { isValhallaUTurn(it.value.type) }?.let {
            tests += RealGpsTest89("Demi-tour", it.value.beginShapeIndex, "Cas réel du trajet")
        }

        // Deux vrais virages de rue rapprochés : utile pour contrôler que la deuxième
        // instruction remplace la première sans retard et que l'encart « Ensuite » reste cohérent.
        val streetTurns114 = logical.filter {
            isValhallaLeftTurn(it.value.type) || isValhallaRightTurn(it.value.type)
        }
        streetTurns114.zipWithNext().firstOrNull { (a, b) ->
            val ia = a.value.endShapeIndex.coerceIn(0, cumulativeRouteMeters89.lastIndex)
            val ib = b.value.beginShapeIndex.coerceIn(0, cumulativeRouteMeters89.lastIndex)
            (cumulativeRouteMeters89[ib] - cumulativeRouteMeters89[ia]) in 0.0..180.0
        }?.let { (a, b) ->
            val ia = a.value.endShapeIndex.coerceIn(0, cumulativeRouteMeters89.lastIndex)
            val ib = b.value.beginShapeIndex.coerceIn(0, cumulativeRouteMeters89.lastIndex)
            val gap = (cumulativeRouteMeters89[ib] - cumulativeRouteMeters89[ia]).coerceAtLeast(0.0)
            tests += RealGpsTest89(
                "Deux virages rapprochés",
                a.value.beginShapeIndex,
                "Écart réel ${testDistanceLabel89(gap)}"
            )
        }

        // Dédoublonnage par zone réelle. L'ordre ci-dessus est volontaire : le test
        // critique « Deux ronds-points successifs » est ajouté en premier et ne peut
        // donc plus être éliminé par un test générique ancré sur la même zone.
        val uniqueTests = mutableListOf<RealGpsTest89>()
        tests.forEach { candidate ->
            val candidateIdx = candidate.shapeIndex.coerceIn(0, cumulativeRouteMeters89.lastIndex)
            val candidateMeters = cumulativeRouteMeters89[candidateIdx]
            val sameZoneAlreadyKept = uniqueTests.any { kept ->
                val keptIdx = kept.shapeIndex.coerceIn(0, cumulativeRouteMeters89.lastIndex)
                kotlin.math.abs(candidateMeters - cumulativeRouteMeters89[keptIdx]) < 80.0
            }
            if (!sameZoneAlreadyKept) uniqueTests += candidate
        }
        uniqueTests.take(12)
    }

    // ETAPE 93 : une seule action prépare un scénario réel et place la simulation
    // ~220 m avant la manœuvre. Le même mécanisme sert au lancement depuis la liste
    // et au bouton « Test suivant », sans modifier Valhalla ni le guidage.
    val launchRealGpsTest93: (Int) -> Unit = { requestedIndex ->
        if (realGpsTests89.isNotEmpty()) {
            val testIndex = requestedIndex.coerceIn(0, realGpsTests89.lastIndex)
            val test = realGpsTests89[testIndex]
            val idx = test.shapeIndex.coerceIn(0, cumulativeRouteMeters89.lastIndex)
            simulationMeters = (cumulativeRouteMeters89[idx] - 220.0).coerceAtLeast(0.0)
            simulationRouteSegment = cumulativeRouteMeters89.indices
                .lastOrNull { pi -> pi <= idx && cumulativeRouteMeters89[pi] <= simulationMeters }
                ?.coerceAtMost((route.points.lastIndex - 1).coerceAtLeast(0))
                ?: 0
            simulationMultiplier = 8
            simulationPaused = true
            simulationRewinding = false
            simulationActive = true
            mapAutoFollow = true
            currentRealGpsTestIndex93 = testIndex
            showRealGpsTests89 = false
        }
    }

    if (showRealGpsTests89) {
        AlertDialog(
            onDismissRequest = { showRealGpsTests89 = false },
            title = { Text("Tests GPS réels") },
            text = {
                Column(
                    modifier = Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("Choisis un test ou lance le lot. La simulation est préparée en ×8 et mise en pause juste avant la zone : démarre l’enregistrement, puis appuie sur Reprendre.", fontSize = 12.sp)
                    if (realGpsTests89.isEmpty()) Text("Aucun scénario intéressant détecté sur ce trajet.")
                    realGpsTests89.forEach { test ->
                        OutlinedButton(
                            onClick = { launchRealGpsTest93(realGpsTests89.indexOf(test)) },
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Column(Modifier.fillMaxWidth()) {
                                Text(test.label, fontSize = 12.sp)
                                Text(test.detail, fontSize = 10.sp, color = Color(0xFF9EB8D8))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (realGpsTests89.isNotEmpty()) {
                        TextButton(onClick = { launchRealGpsTest93(0) }) { Text("▶ Lancer le lot") }
                    }
                    TextButton(onClick = { showRealGpsTests89 = false }) { Text("Fermer") }
                }
            }
        )
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF07182E)).padding(if (navigationLandscape) 8.dp else 12.dp)) {
        if (!navigationLandscape) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("‹ Itinéraire") }
                Spacer(Modifier.weight(1f))
            }
        }
        // ETAPE 80 : la carte devient l’élément principal en portrait.
        // Le grand cartouche destination de l’étape 79 est supprimé : destination,
        // ETA et distance restent disponibles dans la barre basse et la feuille Étapes.
        if (!navigationLandscape) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = {
                    simulationActive = !simulationActive
                    if (!simulationActive) {
                        simulationMeters = 0.0
                        simulationRewinding = false
                        simulationPaused = false
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(if (simulationActive) "■ Arrêter le test" else "▶ Mode test", fontSize = 12.sp)
            }
            OutlinedButton(
                onClick = { showRealGpsTests89 = true },
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text("🧪 Tests GPS réels (${realGpsTests89.size})", fontSize = 12.sp)
            }
            if (currentRealGpsTestIndex93 in realGpsTests89.indices) {
                val activeTest93 = realGpsTests89[currentRealGpsTestIndex93]
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        "TEST ${currentRealGpsTestIndex93 + 1}/${realGpsTests89.size} • ${activeTest93.label}",
                        color = Color(0xFF7CC4FF),
                        fontSize = 10.sp,
                        modifier = Modifier.weight(1f)
                    )
                    if (currentRealGpsTestIndex93 < realGpsTests89.lastIndex) {
                        OutlinedButton(
                            onClick = { launchRealGpsTest93(currentRealGpsTestIndex93 + 1) },
                            contentPadding = PaddingValues(horizontal = 7.dp, vertical = 1.dp)
                        ) { Text("Test suivant ›", fontSize = 10.sp) }
                    } else {
                        Text("LOT TERMINÉ ✓", color = Color(0xFF67D391), fontSize = 10.sp)
                    }
                }
                Text(
                    activeTest93.detail,
                    color = Color(0xFFB8C7D9),
                    fontSize = 9.sp,
                    modifier = Modifier.fillMaxWidth().padding(top = 1.dp)
                )
            }
            if (simulationActive) {
                Text(
                    when {
                        simulationPaused -> "MODE TEST — PAUSE • position conservée"
                        simulationRewinding -> "MODE TEST — marche arrière ×2"
                        else -> if (simulationMultiplier >= 16) {
                            "MODE TEST — position GPS simulée • ×16 intelligent (ralentissement auto)"
                        } else {
                            "MODE TEST — position GPS simulée • accélération ×$simulationMultiplier"
                        }
                    },
                    color = Color(0xFFFFC857),
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
                // ETAPE 57 : Pause/Reprendre rejoint la rangée des commandes de test.
                // On supprime ainsi une rangée complète afin de rendre davantage de hauteur
                // à la carte, sans modifier le moteur de simulation ni le guidage.
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            simulationPaused = !simulationPaused
                            if (simulationPaused) {
                                simulationRewinding = false
                                if (ttsReady) textToSpeech.stop()
                            }
                        },
                        modifier = Modifier.weight(1.35f),
                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp)
                    ) {
                        Text(if (simulationPaused) "▶ Reprendre" else "⏸ Pause", fontSize = 11.sp)
                    }
                    if (simulationRewinding) {
                        Button(
                            onClick = { simulationRewinding = false },
                            modifier = Modifier.weight(1.15f),
                            contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp)
                        ) { Text("⏪ ×2") }
                    } else {
                        OutlinedButton(
                            onClick = { if (!simulationPaused) simulationRewinding = true },
                            modifier = Modifier.weight(1.15f),
                            contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp)
                        ) { Text("⏪ ×2") }
                    }
                    listOf(1, 2, 4, 8, 16).forEach { multiplier ->
                        if (!simulationRewinding && simulationMultiplier == multiplier) {
                            Button(
                                onClick = { if (!simulationPaused) { simulationRewinding = false; simulationMultiplier = multiplier } },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp)
                            ) { Text("×$multiplier") }
                        } else {
                            OutlinedButton(
                                onClick = { if (!simulationPaused) { simulationRewinding = false; simulationMultiplier = multiplier } },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp)
                            ) { Text("×$multiplier") }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(if (navigationLandscape) 0.dp else 10.dp))
        Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(22.dp)) {
            Box(Modifier.fillMaxSize()) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        MapView(ctx).apply {
                            // V386 : après rotation, le nouveau MapView doit réactiver explicitement
                            // son fournisseur de tuiles. Sinon certains appareils affichent uniquement
                            // le fond bleu clair jusqu’à une nouvelle ouverture de l’écran.
                            setTileSource(TileSourceFactory.MAPNIK)
                            onResume()
                            setMultiTouchControls(true)
                            // V127 : en navigation, les gros boutons + / - d’osmdroid
                            // masquaient une partie de la route. Le zoom tactile reste disponible.
                            setBuiltInZoomControls(false)
                            controller.setZoom(17.0)
                            setOnTouchListener { _, event ->
                                if (event.actionMasked == android.view.MotionEvent.ACTION_MOVE) {
                                    mapAutoFollow = false
                                    lastManualMapTouchAt = android.os.SystemClock.elapsedRealtime()
                                }
                                false
                            }
                        }
                    },
                    update = { map ->
                        // V388 : ne plus réinitialiser le MapView ni supprimer/recréer ses
                        // overlays à chaque recomposition Compose. V387 pouvait recomposer
                        // plusieurs fois par seconde (GPS, distance, ETA, précision...) :
                        // onResume(), setTileSource() et removeAll() forçaient alors le rendu
                        // natif osmdroid à se reconstruire, d'où le clignotement en paysage.
                        // La tuile est configurée une seule fois dans factory ; ici on met à
                        // jour les objets existants en place.
                        val routeOverlay = map.overlays
                            .filterIsInstance<Polyline>()
                            .firstOrNull()
                            ?: Polyline().also { polyline ->
                                polyline.outlinePaint.strokeWidth = 13f
                                polyline.outlinePaint.color = android.graphics.Color.rgb(35, 126, 255)
                                map.overlays.add(0, polyline)
                            }
                        routeOverlay.setPoints(route.points)

                        // ETAPE 129 : afficher l’endroit où le trajet Valhalla se termine
                        // réellement. Pour un POI situé au centre d’un bâtiment (mairie,
                        // magasin, hôpital…), ce repère correspond au point routable utilisé
                        // depuis l’étape 128 pour valider l’arrivée, pas au centre du bâtiment.
                        route.points.lastOrNull()?.let { routedEnd ->
                            val arrivalMarker = map.overlays
                                .filterIsInstance<Marker>()
                                .firstOrNull { it.title?.startsWith("Arrivée routière") == true }
                                ?: Marker(map).apply {
                                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                                    map.overlays.add(this)
                                }
                            arrivalMarker.position = GeoPoint(routedEnd.latitude, routedEnd.longitude)
                            arrivalMarker.title = "Arrivée routière • ${destination.label}"
                            arrivalMarker.snippet = "Fin du trajet calculé sur le réseau routier"
                        }

                        val position = liveLocation?.let {
                            GeoPoint(it.latitude, it.longitude)
                        }

                        position?.let { point ->
                            val positionMarker = map.overlays
                                .filterIsInstance<Marker>()
                                .firstOrNull { it.title == "Ma position" }
                                ?: Marker(map).apply {
                                    title = "Ma position"
                                    rotation = 0f
                                    icon = ContextCompat.getDrawable(
                                        map.context,
                                        R.drawable.ic_navigation_arrow
                                    )
                                    setAnchor(
                                        Marker.ANCHOR_CENTER,
                                        Marker.ANCHOR_CENTER
                                    )
                                    map.overlays.add(this)
                                }

                            val previousCameraPoint = positionMarker.position
                            positionMarker.position = point
                            // ETAPE 82 : la carte et la flèche partagent désormais un seul repère.
                            // En suivi « cap en haut », la carte est déjà tournée de -liveBearing :
                            // appliquer liveBearing une seconde fois au Marker provoquait la flèche
                            // oblique/perpendiculaire observée à l'étape 81. La flèche reste donc à
                            // 0° écran pendant l'auto-suivi (elle pointe vers le haut, donc vers le
                            // segment parcouru). Hors auto-suivi, elle reprend le cap réel sur la
                            // carte libre afin de conserver l'information de direction.
                            positionMarker.rotation = if (mapAutoFollow) 0f else liveBearing

                            if (mapAutoFollow) {
                                // ETAPE 84 : cadrage automobile anticipé. On conserve la caméra
                                // fluide de l'étape 83, mais on descend davantage le véhicule dans
                                // la fenêtre : environ le tiers inférieur en portrait et légèrement
                                // sous le centre en paysage. L'espace ainsi libéré au-dessus montre
                                // davantage de route AVANT le véhicule sans déplacer sa position GPS.
                                // Le décalage reste purement visuel : route, guidage, Valhalla et
                                // calcul des manoeuvres ne sont pas modifiés.
                                // ETAPE 86 : caméra contextuelle. Un rond-point bénéficie d'un
                                // cadrage un peu plus anticipé qu'un virage simple : le véhicule est
                                // légèrement plus bas et le zoom augmente plus tôt afin de rendre
                                // l'îlot et surtout la branche de sortie lisibles avant l'entrée.
                                // Dès que le rond-point est terminé, cameraRoundaboutPhase redevient
                                // null et la caméra retrouve automatiquement le comportement V85.
                                val roundaboutPhase86 = maneuver.cameraRoundaboutPhase
                                val roundaboutCamera86 = roundaboutPhase86 != null
                                val centerOffset86 = if (navigationLandscape) {
                                    if (roundaboutCamera86) 165 else 145
                                } else {
                                    if (roundaboutCamera86) 365 else 325
                                }
                                map.setMapCenterOffset(0, centerOffset86)
                                val targetOrientation = (360f - liveBearing) % 360f

                                val maneuverMeters85 = maneuver.distanceMeters
                                val portraitZoom85 = if (roundaboutCamera86) {
                                    when {
                                        roundaboutPhase86 == "inside" || roundaboutPhase86 == "exit" -> 18.90
                                        maneuverMeters85 == null -> 18.45
                                        maneuverMeters85 <= 80.0 -> 19.00
                                        maneuverMeters85 <= 180.0 -> 18.78
                                        maneuverMeters85 <= 350.0 -> 18.48
                                        maneuverMeters85 <= 800.0 -> 18.02
                                        maneuverMeters85 <= 1500.0 -> 17.68
                                        else -> 17.40
                                    }
                                } else {
                                    when {
                                        maneuverMeters85 == null -> 18.25
                                        maneuverMeters85 <= 80.0 -> 18.75
                                        maneuverMeters85 <= 180.0 -> 18.55
                                        maneuverMeters85 <= 350.0 -> 18.25
                                        maneuverMeters85 <= 800.0 -> 17.85
                                        maneuverMeters85 <= 1500.0 -> 17.55
                                        else -> 17.35
                                    }
                                }
                                val targetZoom = if (navigationLandscape) {
                                    (portraitZoom85 - 0.20).coerceIn(17.15, 18.80)
                                } else {
                                    portraitZoom85
                                }
                                val movedMeters = previousCameraPoint?.distanceToAsDouble(point)
                                    ?: Double.POSITIVE_INFINITY
                                var orientationDelta = (targetOrientation - map.mapOrientation + 540f) % 360f - 180f
                                if (kotlin.math.abs(orientationDelta) < 0.8f) orientationDelta = 0f
                                val zoomDelta = kotlin.math.abs(targetZoom - map.zoomLevelDouble)

                                // Les recompositions Compose peuvent être plus fréquentes que les
                                // nouveaux fixes GPS. On ne relance donc pas l'animation pour un
                                // même point, sauf si le palier de zoom vient réellement de changer.
                                if (movedMeters >= 1.5 || kotlin.math.abs(orientationDelta) >= 0.8f || zoomDelta >= 0.12) {
                                    map.controller.animateTo(
                                        point,
                                        targetZoom,
                                        520L,
                                        targetOrientation
                                    )
                                }
                            }
                        }

                        // Un seul rafraîchissement après les mises à jour en place.
                        map.invalidate()
                    }
                )

                // ETAPE 79 : bandeau de navigation principal inspiré de la maquette VSP GPS.
                // La consigne devient lisible d’un seul coup d’œil : grande flèche, action,
                // distance et rue. La logique de guidage/voix reste strictement inchangée.
                if (!navigationLandscape) {
                    val guidanceParts79 = maneuver.distanceText.split(" • ", limit = 2)
                    val guidanceDistance79 = guidanceParts79.firstOrNull().orEmpty()
                    val guidanceStreet79 = guidanceParts79.getOrNull(1).orEmpty()
                    Card(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(start = 12.dp, top = 12.dp, end = 12.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xF0102A46))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = maneuver.arrow,
                                color = Color.White,
                                fontSize = 38.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                // ETAPE 87 : pendant le rond-point, l'information la plus
                                // importante n'est plus la distance mais la sortie à viser.
                                // On la rend dominante sans modifier la machine d'états ni le TTS.
                                if (maneuver.cameraRoundaboutPhase == "inside" && maneuver.visualRoundaboutExitLabel != null) {
                                    Text(
                                        text = "DANS LE ROND-POINT",
                                        color = Color(0xFF65D68A),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                    Text(
                                        text = "${maneuver.visualRoundaboutExitLabel} SORTIE",
                                        color = Color.White,
                                        fontSize = 25.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        maxLines = 1
                                    )
                                    if (guidanceDistance79.isNotBlank()) {
                                        Text(
                                            text = guidanceDistance79,
                                            color = Color(0xFFB9D9FF),
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1
                                        )
                                    }
                                } else {
                                    if (guidanceDistance79.isNotBlank()) {
                                        Text(
                                            text = guidanceDistance79,
                                            color = Color(0xFF65D68A),
                                            fontSize = 22.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            maxLines = 1
                                        )
                                    }
                                    Text(
                                        text = if (maneuver.cameraRoundaboutPhase == "exit") "Prenez la sortie" else maneuver.title,
                                        color = Color.White,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 2
                                    )
                                    if (guidanceStreet79.isNotBlank()) {
                                        Text(
                                            text = guidanceStreet79,
                                            color = Color(0xFFB9D9FF),
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // ETAPE 88 : petit encart de préparation. Il reste volontairement
                    // discret pour ne jamais concurrencer la consigne principale.
                    maneuver.nextVisualText?.let { nextText ->
                        Card(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                // ETAPE 111 : en portrait, réserver la zone occupée par le
                                // badge GPS à droite. Sur les consignes « Ensuite » longues,
                                // le badge pouvait masquer la fin du nom de rue. En paysage
                                // il reste en haut de l’écran et ne chevauche pas cet encart.
                                .padding(
                                    start = 24.dp,
                                    top = 112.dp,
                                    end = if (navigationLandscape) 24.dp else 124.dp
                                ),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xDC173A5B))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = maneuver.nextVisualArrow ?: "→",
                                    color = Color(0xFF65D68A),
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = nextText,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }

                // V140 : avertissement discret sans masquer ni supprimer le trajet actif.
                networkWarning?.let { warning ->
                    Card(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            // V396 : en paysage, placer l’avertissement réseau au-dessus
                            // de la barre Arrivée/Restant/Distance. Jusqu’ici les deux
                            // panneaux occupaient la même zone basse et le message réseau
                            // pouvait être masqué au moment où il était le plus utile.
                            // V438 : Compose ne propose pas de surcharge padding
                            // combinant horizontal + top + bottom. On sépare donc
                            // les marges horizontales et verticales pour conserver
                            // exactement le même placement sans erreur de compilation.
                            .padding(horizontal = 92.dp)
                            .padding(
                                top = 12.dp,
                                bottom = if (navigationLandscape) 72.dp else 12.dp
                            ),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xE6102A46))
                    ) {
                        Text(
                            text = "⚠ $warning",
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                            color = Color(0xFFFFC857),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // V124 : compteur de vitesse GPS permanent, directement sur la carte.
                // Il reste visible sans ouvrir un écran séparé, comme sur un GPS automobile.
                Card(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(12.dp)
                        .size(76.dp)
                        .border(3.dp, Color.White, RoundedCornerShape(50)),
                    shape = RoundedCornerShape(50),
                    colors = CardDefaults.cardColors(containerColor = Color(0xE6102A46))
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = speedKmh.toString(),
                            color = Color.White,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1
                        )
                        Text(
                            text = "km/h",
                            color = Color(0xFFB9D9FF),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // V402 : un seul badge GPS pour tous les états (acquisition, imprécis,
                // perdu ou position exploitable). Les versions précédentes utilisaient deux
                // branches Compose distinctes ; lors d’un changement d’état Android pouvait
                // retirer un Card puis en créer un autre. Ce badge unique évite cette transition
                // visuelle et garde exactement la même position en mode portrait/paysage.
                run {
                    val location = liveLocation
                    val hasUsableAccuracy = location?.hasAccuracy() == true
                    val accuracyMeters = if (hasUsableAccuracy) {
                        location!!.accuracy.coerceAtLeast(0f)
                    } else {
                        null
                    }

                    // V406 : stabiliser la valeur affichée dans le badge GPS.
                    // Android peut faire varier la précision de 1 ou 2 mètres à chaque fix,
                    // ce qui changeait le texte en permanence alors que la qualité réelle
                    // du signal restait identique. L'affichage est arrondi au pas de 5 m ;
                    // les seuils de qualité continuent, eux, d'utiliser la valeur GPS brute.
                    val displayAccuracyMeters = accuracyMeters?.let { accuracy ->
                        ((accuracy / 5f).roundToInt() * 5).coerceAtLeast(5)
                    }

                    val gpsLabel: String
                    val gpsDetail: String
                    val gpsColor: Color

                    when {
                        location == null -> {
                            gpsLabel = "GPS recherche…"
                            gpsDetail = "Acquisition de la position"
                            gpsColor = Color(0xFFFFC857)
                        }
                        !hasUsableAccuracy -> {
                            gpsLabel = "GPS imprécis"
                            gpsDetail = "Précision indisponible"
                            gpsColor = Color(0xFFFFC857)
                        }
                        !gpsFixFresh && !stationaryPreciseFix -> {
                            // V409 : « GPS perdu » signifie désormais réellement qu'aucun fix
                            // suffisamment récent n'est disponible. Auparavant !gpsFixReliable
                            // mélangeait ancienneté et mauvaise précision : un fix frais à ±80 m
                            // pouvait donc être annoncé comme perdu au lieu de « GPS très faible ».
                            // La qualité du fix frais est traitée par les seuils juste en dessous.
                            gpsLabel = "GPS perdu"
                            gpsDetail = displayAccuracyMeters?.let { "Recherche… • dernière ± $it m" }
                                ?: "Recherche…"
                            gpsColor = Color(0xFFFF7A7A)
                        }
                        // V408 : le niveau visuel du badge utilise la même précision arrondie
                        // que celle affichée. Une oscillation brute autour de 15/35/65 m ne fait
                        // donc plus alterner le libellé à chaque fix GPS. Le moteur de navigation
                        // conserve toujours accuracyMeters (valeur brute) pour ses calculs.
                        (displayAccuracyMeters ?: accuracyMeters!!.toInt()) <= 15 -> {
                            gpsLabel = "GPS précis"
                            gpsDetail = "± ${displayAccuracyMeters ?: accuracyMeters.toInt()} m"
                            gpsColor = Color(0xFF65D68A)
                        }
                        (displayAccuracyMeters ?: accuracyMeters!!.toInt()) <= 35 -> {
                            gpsLabel = "GPS moyen"
                            gpsDetail = "± ${displayAccuracyMeters ?: accuracyMeters.toInt()} m"
                            gpsColor = Color(0xFFFFC857)
                        }
                        (displayAccuracyMeters ?: accuracyMeters!!.toInt()) <= 65 -> {
                            // V404 : 36–65 m reste une position exploitable par le moteur
                            // de guidage. Le badge reste donc en avertissement (orange) au lieu
                            // de rouge, réservé désormais aux fixes réellement hors tolérance.
                            gpsLabel = "GPS faible"
                            gpsDetail = "± ${displayAccuracyMeters ?: accuracyMeters.toInt()} m"
                            gpsColor = Color(0xFFFFC857)
                        }
                        else -> {
                            gpsLabel = "GPS très faible"
                            gpsDetail = "± ${displayAccuracyMeters ?: accuracyMeters.toInt()} m"
                            gpsColor = Color(0xFFFF7A7A)
                        }
                    }

                    Card(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .then(if (navigationLandscape) Modifier.statusBarsPadding() else Modifier)
                            .padding(top = if (navigationLandscape) 12.dp else 104.dp, end = 10.dp)
                            // ETAPE 80 : en portrait, le badge GPS passe sous le grand bandeau
                            // de consigne afin que celui-ci puisse occuper toute la largeur.
                            // V405 : largeur minimale stable pour éviter que le badge GPS
                            // se contracte/s’agrandisse à chaque changement de libellé ou précision.
                            // Cela réduit les micro-déplacements visuels sur la carte en navigation.
                            .widthIn(min = if (navigationLandscape) 156.dp else 104.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xE6102A46))
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = if (navigationLandscape) 12.dp else 9.dp, vertical = if (navigationLandscape) 7.dp else 5.dp),
                            horizontalAlignment = Alignment.End
                        ) {
                            Text(
                                text = gpsLabel,
                                color = gpsColor,
                                fontSize = if (navigationLandscape) 13.sp else 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = gpsDetail,
                                color = Color.White,
                                fontSize = if (navigationLandscape) 12.sp else 10.sp
                            )
                        }
                    }
                }

                if (!mapAutoFollow) {
                    Button(
                        onClick = {
                            lastManualMapTouchAt = 0L
                            mapAutoFollow = true
                        },
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = 14.dp)
                            .size(58.dp),
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF102B49),
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        // Cible de recentrage originale : viseur blanc + centre bleu.
                        Box(
                            modifier = Modifier.size(38.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .width(4.dp)
                                    .height(10.dp)
                                    .background(Color.White, RoundedCornerShape(2.dp))
                            )
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .width(4.dp)
                                    .height(10.dp)
                                    .background(Color.White, RoundedCornerShape(2.dp))
                            )
                            Box(
                                modifier = Modifier
                                    .align(Alignment.CenterStart)
                                    .width(10.dp)
                                    .height(4.dp)
                                    .background(Color.White, RoundedCornerShape(2.dp))
                            )
                            Box(
                                modifier = Modifier
                                    .align(Alignment.CenterEnd)
                                    .width(10.dp)
                                    .height(4.dp)
                                    .background(Color.White, RoundedCornerShape(2.dp))
                            )
                            Box(
                                modifier = Modifier
                                    .size(22.dp)
                                    .border(3.dp, Color.White, RoundedCornerShape(50))
                            )
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(Color(0xFF3D6BFF), RoundedCornerShape(50))
                            )
                        }
                    }
                }

                // V387 : interface paysage inspirée de l'ergonomie des GPS automobiles :
                // carte dominante, consigne compacte, vitesse dégagée et barre basse plus fine.
                // Les informations essentielles sont superposées dans des panneaux compacts
                // afin de ne plus réserver un gros bloc sous la carte.
                if (navigationLandscape) {
                    Card(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            // V393 : la consigne reste en surimpression sur la carte, mais
                            // respecte désormais la zone de la barre d’état en paysage.
                            .statusBarsPadding()
                            .padding(start = 12.dp, top = 12.dp)
                            .fillMaxWidth(0.58f),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xE6102A46))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(maneuver.arrow, color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(maneuver.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                if (maneuver.distanceText.isNotBlank()) {
                                    val landscapeGuidanceParts = maneuver.distanceText.split(" • ", limit = 2)
                                    val landscapeDistance = landscapeGuidanceParts.firstOrNull().orEmpty()
                                    val landscapeStreet = landscapeGuidanceParts.getOrNull(1).orEmpty()
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(landscapeDistance, color = Color(0xFF65D68A), fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                                        if (landscapeStreet.isNotBlank()) {
                                            Text("  •  $landscapeStreet", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Card(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            // V397 : la barre d’informations paysage respecte aussi la zone
                            // de navigation système Android. Sur les appareils qui affichent
                            // les boutons système sur le bord droit en paysage, Distance et
                            // sa valeur ne peuvent plus se retrouver dessous. La carte reste
                            // plein écran : seul le panneau superposé reçoit cette marge sûre.
                            .navigationBarsPadding()
                            .padding(start = 104.dp, end = 12.dp, bottom = 10.dp)
                            .fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xE6102A46))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(displayedTripDestination.label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text("Destination finale", color = Color.LightGray, fontSize = 9.sp)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(formatEtaFromMinutes(minutes), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Arrivée", color = Color.LightGray, fontSize = 9.sp)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(if (minutes < 60) "$minutes min" else "${minutes / 60} h ${minutes % 60} min", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Restant", color = Color.LightGray, fontSize = 9.sp)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(formatGpsDistance(remainingMeters), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Distance", color = Color.LightGray, fontSize = 9.sp)
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(if (navigationLandscape) 0.dp else 10.dp))
        if (!navigationLandscape) Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = if (navigationLandscape) 4.dp else 24.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF102A46))
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // ETAPE 80 : suppression de la seconde copie de la manœuvre.
                // La consigne principale est désormais uniquement dans le bandeau sur la carte.
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = {
                            if (manualReplayAvailable) {
                                val replayText = if (voiceAccuracyWeak) {
                                    "Prochaine instruction : ${maneuver.spokenTitle}"
                                } else maneuver.spokenTitle
                                textToSpeech.speak(replayText, TextToSpeech.QUEUE_FLUSH, null, "vsp_manual_replay_${System.currentTimeMillis()}")
                            }
                        },
                        enabled = manualReplayAvailable
                    ) { Text("↻ Répéter", color = if (manualReplayAvailable) Color.White else Color.Gray, fontSize = 12.sp) }
                    TextButton(onClick = {
                        voiceEnabled = !voiceEnabled
                        voicePrefs.edit().putBoolean("voice_enabled", voiceEnabled).apply()
                        if (!voiceEnabled) textToSpeech.stop()
                    }) { Text(if (voiceEnabled) "🔊" else "🔇", fontSize = 20.sp) }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 18.dp, end = 18.dp, bottom = if (navigationLandscape) 5.dp else 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(formatEtaFromMinutes(minutes), color = Color.White,
                            fontWeight = FontWeight.Bold, fontSize = if (navigationLandscape) 13.sp else 16.sp)
                        Text("Arrivée", color = Color.LightGray, fontSize = if (navigationLandscape) 9.sp else 10.sp)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            if (minutes < 60) "$minutes min"
                            else "${minutes / 60} h ${minutes % 60} min",
                            color = Color.White, fontWeight = FontWeight.Bold, fontSize = if (navigationLandscape) 13.sp else 16.sp
                        )
                        Text("Restant", color = Color.LightGray, fontSize = if (navigationLandscape) 9.sp else 10.sp)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(formatGpsDistance(remainingMeters), color = Color.White,
                            fontWeight = FontWeight.Bold, fontSize = if (navigationLandscape) 13.sp else 16.sp)
                        Text("Distance", color = Color.LightGray, fontSize = if (navigationLandscape) 9.sp else 10.sp)
                    }
                }
            }
        }
    }


    Box(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .then(if (navigationLandscape) Modifier.navigationBarsPadding() else Modifier)
            .padding(
                // ETAPE 94 : la V93 ajoute une ligne TEST n/N au-dessus des commandes,
                // donc l'ancien décalage 218 dp pouvait de nouveau recouvrir ×8.
                // En mode simulation on fixe Étapes plus bas, dans la zone carte,
                // indépendamment de la hauteur du bandeau de tests.
                top = if (navigationLandscape) 88.dp else if (simulationActive) 300.dp else 78.dp,
                end = if (navigationLandscape) 14.dp else 18.dp
            ),
        contentAlignment = Alignment.TopEnd
    ) {
        Button(
            onClick = { showRoadmap = true },
            modifier = if (navigationLandscape) Modifier.size(52.dp) else Modifier,
            shape = if (navigationLandscape) RoundedCornerShape(50) else ButtonDefaults.shape,
            contentPadding = if (navigationLandscape) PaddingValues(0.dp) else PaddingValues(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text(if (navigationLandscape) "☰" else "☰ Étapes", fontSize = if (navigationLandscape) 21.sp else 13.sp)
        }
    }

    // V407 : la commande de répétition paysage suit désormais gpsFixReliable,
    // comme le guidage vocal automatique et le bouton portrait.
    // V390 : en paysage, remettre les commandes vocales directement sur la carte.
    // Elles étaient restées dans le panneau portrait, donc invisibles depuis le passage
    // à l'interface plein écran. Les boutons compacts restent sur le bord droit afin de
    // ne pas masquer la route ni agrandir les bandeaux d'information.
    if (navigationLandscape) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(top = 148.dp, end = 14.dp),
            contentAlignment = Alignment.TopEnd
        ) {
            // V392 : commandes vocales paysage plus discrètes, tout en restant accessibles.
            // Leur diamètre et leur espacement sont réduits pour libérer davantage la carte.
            // V391 : empiler les commandes vocales verticalement sur le bord droit.
            // En paysage, une rangée horizontale empiétait davantage sur la carte et pouvait
            // se rapprocher du bandeau de guidage sur les écrans moins larges. Une colonne
            // compacte garde les deux actions accessibles sans masquer la trajectoire.
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = {
                        if (manualReplayAvailable) {
                            val replayImmediateDistanceMeters = when (voiceSpeedBand) {
                                2 -> 40.0
                                1 -> 37.0
                                else -> 35.0
                            }
                            val replayText = if (voiceAccuracyWeak) {
                                "Prochaine instruction : ${maneuver.spokenTitle}"
                            } else maneuver.distanceMeters?.let { meters ->
                                when {
                                    meters <= replayImmediateDistanceMeters -> maneuver.spokenTitle
                                    meters < 100.0 -> {
                                        val rounded = ((meters / 10.0).roundToInt() * 10).coerceAtLeast(40)
                                        "Dans $rounded mètres, ${maneuver.spokenTitle}"
                                    }
                                    meters < 1000.0 -> {
                                        val rounded = ((meters / 50.0).roundToInt() * 50).coerceAtLeast(100)
                                        "Dans $rounded mètres, ${maneuver.spokenTitle}"
                                    }
                                    else -> {
                                        val roundedKm = kotlin.math.round((meters / 1000.0) * 10.0) / 10.0
                                        "Dans ${String.format(Locale.FRANCE, "%.1f", roundedKm)} kilomètres, ${maneuver.spokenTitle}"
                                    }
                                }
                            } ?: maneuver.spokenTitle
                            textToSpeech.speak(replayText, TextToSpeech.QUEUE_FLUSH, null, "vsp_landscape_replay_${System.currentTimeMillis()}")
                        }
                    },
                    // V414 : ne jamais présenter le bouton de répétition comme actif lorsqu'il n'y a
                        // encore aucune consigne vocale à répéter. L'ancien état permettait un appui
                        // sans aucun effet au démarrage/recalcul d'un itinéraire.
                        enabled = manualReplayAvailable,
                    modifier = Modifier.size(40.dp),
                    shape = RoundedCornerShape(50),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("↻", fontSize = 18.sp)
                }
                Button(
                    onClick = {
                        voiceEnabled = !voiceEnabled
                        voicePrefs.edit().putBoolean("voice_enabled", voiceEnabled).apply()
                        if (!voiceEnabled) textToSpeech.stop()
                    },
                    modifier = Modifier.size(40.dp),
                    shape = RoundedCornerShape(50),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(if (voiceEnabled) "🔊" else "🔇", fontSize = 17.sp)
                }
            }
        }
    }

}


/** Carte expérimentale : itinéraires auto (bleu) et scooter (orange).
 * Points fixes de comparaison de l'étape 14. Ne modifie jamais le trajet actif.
 */
@Composable
private fun ProfileComparisonDialog(
    previews: List<LocalValhallaRouter.ProfilePreview>,
    onDismiss: () -> Unit
) {
    var selected by remember { mutableIntStateOf(0) }
    val preview = previews.getOrNull(selected)
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier.fillMaxWidth().fillMaxHeight(0.94f)
                .background(Color(0xFF0B1E33), RoundedCornerShape(18.dp))
                .padding(12.dp)
        ) {
            Text("Comparaison des tracés", color = Color.White, fontSize = 20.sp)
            Text("Aix-Noulette → secteur Lens • test non certifié VSP", color = Color(0xFFFFC857), fontSize = 11.sp)
            Row {
                previews.forEachIndexed { index, item ->
                    TextButton(onClick = { selected = index }) {
                        Text(item.label, color = if (selected == index) Color(0xFFFFC857) else Color.LightGray)
                    }
                }
            }
            Text(preview?.info ?: "", color = Color.White)
            val shapes = remember(previews) { previews.map { sanitizeComparisonShape(decodeComparisonPolyline6(it.encodedShape)) } }
            AndroidView(
                modifier = Modifier.fillMaxWidth().height(165.dp),
                factory = { ctx ->
                    MapView(ctx).apply {
                        setMultiTouchControls(true)
                        controller.setZoom(12.0)
                        controller.setCenter(GeoPoint(50.425, 2.77))
                    }
                },
                update = { map ->
                    map.overlays.removeAll { it is Polyline }
                    shapes.forEachIndexed { index, points ->
                        if (points.size >= 2) map.overlays.add(Polyline().apply {
                            setPoints(points)
                            outlinePaint.strokeWidth = if (index == selected) 11f else 5f
                            outlinePaint.color = if (index == 0) android.graphics.Color.BLUE else android.graphics.Color.rgb(255, 150, 0)
                        })
                    }
                    // Étape 20 : conserver le cadrage robuste hérité de l’étape 18.
                    // On conserve le calcul manuel, plus stable que zoomToBoundingBox sur les appareils testés.
                    val visiblePoints = shapes.flatten()
                    if (visiblePoints.size >= 2) {
                        val minLat = visiblePoints.minOf { it.latitude }
                        val maxLat = visiblePoints.maxOf { it.latitude }
                        val minLon = visiblePoints.minOf { it.longitude }
                        val maxLon = visiblePoints.maxOf { it.longitude }
                        map.controller.setCenter(GeoPoint((minLat + maxLat) / 2.0, (minLon + maxLon) / 2.0))
                        val span = maxOf(maxLat - minLat, maxLon - minLon)
                        val zoom = when {
                            span < 0.015 -> 14.5
                            span < 0.030 -> 13.5
                            span < 0.060 -> 12.5
                            span < 0.120 -> 11.5
                            span < 0.240 -> 10.5
                            else -> 9.5
                        }
                        map.controller.setZoom(zoom)
                    }
                    map.invalidate()
                }
            )
            Text("Bleu : auto • Orange : motor_scooter", color = Color.LightGray, fontSize = 12.sp)
            // Étape 20 : séparer attributs confirmés et simples indices textuels.
            // On inspecte à la fois les noms de rues et les instructions ; cela reste un diagnostic,
            // car la réponse de route standard n'expose pas forcément highway/access/maxspeed par arête.
            val flagged = remember(preview) { preview?.maneuvers?.mapIndexedNotNull { index, maneuver ->
                val diagnosticText = (maneuver.streetNames + maneuver.instruction).joinToString(" ")
                val classification = comparisonRoadClassification(diagnosticText, maneuver.nativeFields)
                if (classification != null) "${index + 1}. ${classification.label} — ${maneuver.streetNames.joinToString(" / ").ifBlank { maneuver.instruction }}" else null
            }.orEmpty() }
            val strictCandidateAccepted = flagged.isEmpty()
            Text(
                if (strictCandidateAccepted)
                    "🟡 Aucun attribut bloquant ni indice textuel détecté (trajet NON certifié VSP)."
                else
                    "⚠ ${flagged.size} tronçon(s) à contrôler dans les données réellement exposées.",
                color = if (strictCandidateAccepted) Color(0xFFFFC857) else Color(0xFFFF8A80),
                fontSize = 12.sp
            )
            Text(
                "Étape 28 : recalcul local automatique anti-motorway. Un candidat contenant motorway est rejeté, des points du tronçon sont exclus, puis Valhalla recalcule et trace_attributes revalide chaque nouveau candidat. Un trajet n’est accepté qu’à 0 arête motorway. Trunk et bretelles restent à contrôler.",
                color = Color.LightGray, fontSize = 10.sp
            )
            Text("↕ Faites défiler le diagnostic ci-dessous", color = Color(0xFF80CBC4), fontSize = 10.sp)
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(end = 4.dp)
            ) {
                Text(preview?.traceStatus ?: "trace_attributes : aucun profil", color = Color(0xFF80CBC4), fontSize = 11.sp)
                val traceDiagnostics = preview?.traceEdges?.map { it to classifyTraceEdgeVsp(it) }.orEmpty()
                if (traceDiagnostics.isNotEmpty()) {
                    val incompatibleCount = traceDiagnostics.count { it.second.level == TraceVspLevel.INCOMPATIBLE }
                    val controlCount = traceDiagnostics.count { it.second.level == TraceVspLevel.CONTROL }
                    val compatibleCount = traceDiagnostics.count { it.second.level == TraceVspLevel.COMPATIBLE }
                    Text(
                        "BILAN VSP : ✓ $compatibleCount compatible(s) • ⚠ $controlCount à contrôler • ⛔ $incompatibleCount incompatible(s)",
                        color = if (incompatibleCount > 0) Color(0xFFFF8A80) else if (controlCount > 0) Color(0xFFFFC857) else Color(0xFF81C784),
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 4.dp, bottom = 3.dp)
                    )
                    val problematic = traceDiagnostics.filter { it.second.level != TraceVspLevel.COMPATIBLE }
                    val incompatible = traceDiagnostics.filter { it.second.level == TraceVspLevel.INCOMPATIBLE }
                    val controls = traceDiagnostics.filter { it.second.level == TraceVspLevel.CONTROL }
                    val motorwayCount = incompatible.count { it.first.roadClass?.equals("motorway", ignoreCase = true) == true }
                    val explicitAccessFields = traceDiagnostics.flatMap { it.first.exposedFields }.distinct().filter { it.contains("access", ignoreCase = true) }
                    Text("MOTIFS ⛔ : motorway=$motorwayCount • autres=${incompatible.size - motorwayCount}", color = Color(0xFFFF8A80), fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
                    Text(
                        if (explicitAccessFields.isEmpty()) "ACCÈS : aucun champ access explicite exposé par ce trace_attributes local — aucune interdiction d’accès n’est déduite."
                        else "ACCÈS exposé : ${explicitAccessFields.joinToString(", ")}",
                        color = Color(0xFF80CBC4), fontSize = 9.sp, modifier = Modifier.padding(bottom = 4.dp)
                    )
                    Text("⛔ ARÊTES INCOMPATIBLES (${incompatible.size})", color = Color(0xFFFF8A80), fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp, bottom = 2.dp))
                    incompatible.forEach { (edge, diag) ->
                        val name = edge.names.joinToString(" / ").ifBlank { "voie non nommée" }
                        val roadClass = edge.roadClass ?: "?"
                        val use = edge.use ?: "?"
                        val speed = edge.speed?.let { "${it.toInt()} km/h" } ?: "?"
                        val limit = edge.speedLimit?.let { "${it.toInt()} km/h" } ?: "?"
                        val length = edge.lengthKm?.let { String.format(java.util.Locale.FRANCE, "%.3f km", it) } ?: "?"
                        Text("${edge.index}. ${diag.symbol} $name", color = Color(0xFFFF8A80), fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp))
                        Text("   classe=$roadClass • usage=$use • vitesse=$speed • limite=$limit • longueur=$length", color = Color.LightGray, fontSize = 9.sp)
                        Text("   motif ⛔ : ${diag.reason}", color = Color(0xFFFF8A80), fontSize = 9.sp, modifier = Modifier.padding(bottom = 2.dp))
                    }
                    Text("⚠ ARÊTES À CONTRÔLER (${controls.size})", color = Color(0xFFFFC857), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp, bottom = 2.dp))
                    controls.forEach { (edge, diag) ->
                        val name = edge.names.joinToString(" / ").ifBlank { "voie non nommée" }
                        val roadClass = edge.roadClass ?: "?"
                        val use = edge.use ?: "?"
                        val speed = edge.speed?.let { "${it.toInt()} km/h" } ?: "?"
                        val limit = edge.speedLimit?.let { "${it.toInt()} km/h" } ?: "?"
                        val length = edge.lengthKm?.let { String.format(java.util.Locale.FRANCE, "%.3f km", it) } ?: "?"
                        val edgeColor = if (diag.level == TraceVspLevel.INCOMPATIBLE) Color(0xFFFF8A80) else Color(0xFFFFC857)
                        Text("${edge.index}. ${diag.symbol} $name", color = edgeColor, fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp))
                        Text("   classe=$roadClass • usage=$use • vitesse=$speed • limite=$limit • longueur=$length", color = Color.LightGray, fontSize = 9.sp)
                        Text("   motif : ${diag.reason}", color = edgeColor, fontSize = 9.sp, modifier = Modifier.padding(bottom = 2.dp))
                    }
                    Text("TOUTES LES ARÊTES VALHALLA (diagnostic complet)", color = Color(0xFF80CBC4), fontSize = 11.sp, modifier = Modifier.padding(top = 7.dp))
                    traceDiagnostics.take(108).forEach { (edge, diag) ->
                        val name = edge.names.joinToString(" / ").ifBlank { "voie non nommée" }
                        val attrs = listOfNotNull(
                            edge.roadClass?.let { "classe=$it" },
                            edge.use?.let { "usage=$it" },
                            edge.speed?.let { "vitesse=${it.toInt()}" },
                            edge.speedLimit?.let { "limite=${it.toInt()}" },
                            edge.lengthKm?.let { "longueur=$it" },
                            edge.toll?.let { "péage=$it" },
                            edge.traversability?.let { "traversabilité=$it" }
                        ).joinToString(" • ")
                        val edgeColor = when (diag.level) {
                            TraceVspLevel.INCOMPATIBLE -> Color(0xFFFF8A80)
                            TraceVspLevel.CONTROL -> Color(0xFFFFC857)
                            TraceVspLevel.COMPATIBLE -> Color(0xFFB2DFDB)
                        }
                        Text("${edge.index}. ${diag.symbol} $name • ${diag.reason}${if (attrs.isBlank()) " • champs=${edge.exposedFields.joinToString(",")}" else " • $attrs"}", color = edgeColor, fontSize = 9.sp, modifier = Modifier.padding(vertical = 1.dp))
                    }
                }
                if (flagged.isNotEmpty()) {
                    Text("TRONÇONS À CONTRÔLER", color = Color(0xFFFFC857), fontSize = 12.sp)
                    flagged.forEach { Text(it, color = Color(0xFFFFC857), fontSize = 12.sp, modifier = Modifier.padding(vertical = 3.dp)) }
                }
                Text("DIAGNOSTIC DES VOIES", color = Color(0xFF80CBC4), fontSize = 12.sp)
                preview?.maneuvers?.forEachIndexed { i, maneuver ->
                    val names = maneuver.streetNames.joinToString(" / ").ifBlank { "voie non nommée" }
                    val diagnosticText = (maneuver.streetNames + maneuver.instruction).joinToString(" ")
                    val classification = comparisonRoadClassification(diagnosticText, maneuver.nativeFields)
                    val km = if (maneuver.lengthKm.isFinite()) String.format(java.util.Locale.FRANCE, "%.2f km", maneuver.lengthKm) else "distance ?"
                    val sec = if (maneuver.timeSeconds.isFinite()) "${maneuver.timeSeconds.toInt()} s" else "durée ?"
                    val type = if (maneuver.maneuverType >= 0) "type ${maneuver.maneuverType}" else "type ?"
                    Text(
                        "${i + 1}. $names • $km • $sec • $type${if (classification != null) " • ${classification.symbol} ${classification.label}" else " • ✓ aucun indice exposé"}",
                        color = when (classification?.level) {
                            RoadDiagnosticLevel.CONFIRMED_BLOCK -> Color(0xFFFF8A80)
                            RoadDiagnosticLevel.SUSPECT -> Color(0xFFFFC857)
                            else -> Color(0xFFB2DFDB)
                        },
                        fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp)
                    )
                    Text("   ${maneuver.instruction}", color = Color.LightGray, fontSize = 10.sp)
                    Text("   champs: ${maneuver.exposedFields.joinToString(", ")}", color = Color.Gray, fontSize = 9.sp)
                    val attrs = maneuver.nativeFields.entries
                        .filter { (k, _) -> k.lowercase() in setOf("roadclass", "highway", "use", "access", "vehicleaccess", "motorvehicle", "maxspeed", "speed", "toll") }
                        .joinToString(" • ") { "${it.key}=${it.value}" }
                    Text("   attributs route: ${attrs.ifBlank { "non exposés par ce modèle" }}", color = Color.Gray, fontSize = 9.sp, modifier = Modifier.padding(bottom = 3.dp))
                }
            }
            Text("Comparaison uniquement : ne pas utiliser pour conduire.", color = Color(0xFFFFC857), fontSize = 11.sp)
            TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text("Fermer") }
        }
    }
}

private fun decodeComparisonPolyline6(encoded: String): List<GeoPoint> {
    val points = ArrayList<GeoPoint>()
    var i = 0
    var lat = 0L
    var lon = 0L
    fun read(): Long {
        var shift = 0
        var value = 0L
        var digit: Int
        do {
            require(i < encoded.length && shift < 60) { "Polyline tronquée" }
            digit = encoded[i++].code - 63
            value = value or ((digit and 31).toLong() shl shift)
            shift += 5
        } while (digit >= 32)
        return if (value and 1L != 0L) -(value shr 1) - 1 else value shr 1
    }
    while (i < encoded.length && points.size < 50000) {
        lat += read(); lon += read()
        points.add(GeoPoint(lat / 1e6, lon / 1e6))
    }
    return points
}

/** Étape 18 : nettoyage d'affichage uniquement. Un saut de plusieurs dizaines de kilomètres
 * entre deux points successifs ne doit pas forcer la carte à dézoomer sur toute la région.
 * Aucun point n'est supprimé du calcul de navigation : cette fonction ne sert qu'au comparateur.
 */
private fun sanitizeComparisonShape(points: List<GeoPoint>): List<GeoPoint> {
    if (points.size < 3) return points
    val result = ArrayList<GeoPoint>(points.size)
    result.add(points.first())
    for (point in points.drop(1)) {
        val previous = result.last()
        if (distanceMetersBetween(previous, point) <= 25_000.0) result.add(point)
    }
    return if (result.size >= 2) result else points
}

private enum class RoadDiagnosticLevel { CONFIRMED_BLOCK, SUSPECT }

private enum class TraceVspLevel { COMPATIBLE, CONTROL, INCOMPATIBLE }
private data class TraceVspDiagnostic(val level: TraceVspLevel, val reason: String) {
    val symbol: String get() = when (level) {
        TraceVspLevel.COMPATIBLE -> "✓"
        TraceVspLevel.CONTROL -> "⚠"
        TraceVspLevel.INCOMPATIBLE -> "⛔"
    }
}

/** Étape 23 : classement prudent à partir des attributs d'arête réellement renvoyés.
 * Important : trunk, une vitesse élevée ou une rampe ne prouvent pas à eux seuls une
 * interdiction VSP en France. Seule une classe motorway est bloquée automatiquement ici.
 * Les autres cas restent à contrôler tant qu'un attribut réglementaire explicite
 * (par ex. route pour automobiles / accès spécifique) n'est pas disponible. */
private fun classifyTraceEdgeVsp(edge: LocalValhallaRouter.TraceEdgeDiagnostic): TraceVspDiagnostic {
    val roadClass = edge.roadClass?.lowercase(java.util.Locale.ROOT).orEmpty()
    val use = edge.use?.lowercase(java.util.Locale.ROOT).orEmpty()
    return when {
        roadClass == "motorway" -> TraceVspDiagnostic(TraceVspLevel.INCOMPATIBLE, "classe motorway")
        use == "ramp" -> TraceVspDiagnostic(TraceVspLevel.CONTROL, "bretelle : statut réglementaire à confirmer")
        roadClass == "trunk" -> TraceVspDiagnostic(TraceVspLevel.CONTROL, "classe trunk : pas une interdiction VSP automatique")
        (edge.speedLimit ?: 0.0) >= 90.0 -> TraceVspDiagnostic(TraceVspLevel.CONTROL, "limite élevée : contrôle, pas interdiction automatique")
        else -> TraceVspDiagnostic(TraceVspLevel.COMPATIBLE, "aucun attribut bloquant exposé")
    }
}
private data class RoadDiagnostic(val level: RoadDiagnosticLevel, val label: String) {
    val symbol: String get() = if (level == RoadDiagnosticLevel.CONFIRMED_BLOCK) "⛔" else "⚠"
}

/** Étape 20 : une interdiction n'est dite confirmée que si un attribut natif explicite
 * l'indique. Les noms/instructions ne produisent que des suspicions. */
private fun comparisonRoadClassification(textSource: String, nativeFields: Map<String, String>): RoadDiagnostic? {
    val attrs = nativeFields.mapKeys { it.key.lowercase(java.util.Locale.ROOT) }
        .mapValues { it.value.lowercase(java.util.Locale.ROOT) }
    val highway = attrs["highway"].orEmpty()
    val roadClass = attrs["roadclass"].orEmpty()
    val use = attrs["use"].orEmpty()
    val accessValues = listOf("access", "vehicleaccess", "motorvehicle").mapNotNull { attrs[it] }
    if (highway in setOf("motorway", "motorway_link") || roadClass == "motorway")
        return RoadDiagnostic(RoadDiagnosticLevel.CONFIRMED_BLOCK, "TYPE AUTOROUTIER exposé par Valhalla")
    if (use in setOf("ramp", "turn_channel"))
        return RoadDiagnostic(RoadDiagnosticLevel.SUSPECT, "SUSPECT : bretelle / canalisation de mouvement")
    if (accessValues.any { it in setOf("no", "private") })
        return RoadDiagnostic(RoadDiagnosticLevel.CONFIRMED_BLOCK, "ACCÈS véhicule interdit exposé par Valhalla")

    val text = textSource.lowercase(java.util.Locale.ROOT)
    return when {
        Regex("\\b(?:a\\s?\\d{1,3}|autoroute|motorway)\\b", RegexOption.IGNORE_CASE).containsMatchIn(textSource) -> RoadDiagnostic(RoadDiagnosticLevel.SUSPECT, "SUSPECT : mention d'autoroute")
        "rocade" in text || "voie rapide" in text || "expressway" in text -> RoadDiagnostic(RoadDiagnosticLevel.SUSPECT, "SUSPECT : rocade / voie rapide")
        "ramp" in text || "bretelle" in text -> RoadDiagnostic(RoadDiagnosticLevel.SUSPECT, "SUSPECT : bretelle")
        else -> null
    }
}
