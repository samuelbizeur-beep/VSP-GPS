package fr.vspgps.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Étape 121 : gestion des packs cartographiques isolée du gros écran GPS.
 * Rien n'est importé ni initialisé au démarrage de l'application : ces actions
 * n'existent qu'après ouverture de l'écran carte et action explicite de l'utilisateur.
 */
@Composable
fun MapPackControls(
    router: LocalValhallaRouter,
    externallyBusy: Boolean,
    startLocation: android.location.Location?,
    destination: Destination?,
    onDiagnostic: (String) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var importRunning by remember { mutableStateOf(false) }
    var targetFrance by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }

    // La lecture de refresh force seulement le rafraîchissement du texte après une action.
    @Suppress("UNUSED_EXPRESSION")
    refresh

    fun selectedFileSize(uri: android.net.Uri): Long? = runCatching {
        context.contentResolver.query(
            uri,
            arrayOf(android.provider.OpenableColumns.SIZE),
            null, null, null
        )?.use { cursor ->
            if (!cursor.moveToFirst()) return@use null
            val index = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE)
            if (index >= 0 && !cursor.isNull(index)) cursor.getLong(index) else null
        }
    }.getOrNull()

    fun formatStorage(bytes: Long): String {
        val gib = bytes / (1024.0 * 1024.0 * 1024.0)
        val mib = bytes / (1024.0 * 1024.0)
        return if (gib >= 1.0) String.format(java.util.Locale.FRANCE, "%.2f Gio", gib)
        else String.format(java.util.Locale.FRANCE, "%.0f Mio", mib)
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && !importRunning) {
            val label = if (targetFrance) "France" else "régional"
            val incomingBytes = selectedFileSize(uri)
            if (incomingBytes != null && incomingBytes > 0L) {
                val available = router.availableMapStorageBytes()
                val required = router.requiredFreeBytesForImport(targetFrance, incomingBytes)
                if (available < required) {
                    onDiagnostic(
                        "✗ Import $label annulé : fichier ${formatStorage(incomingBytes)} • " +
                            "espace libre ${formatStorage(available)} • environ ${formatStorage(required)} requis avec la sauvegarde de sécurité."
                    )
                    return@rememberLauncherForActivityResult
                }
            }
            importRunning = true
            onDiagnostic(
                "Import du pack $label en cours…" +
                    (incomingBytes?.takeIf { it > 0L }?.let { " • ${formatStorage(it)}" } ?: "")
            )
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val input = context.contentResolver.openInputStream(uri)
                            ?: error("Impossible d’ouvrir le fichier sélectionné")
                        if (targetFrance) {
                            router.installFrancePack(input).getOrThrow()
                        } else {
                            router.installRegionalPack(input).getOrThrow()
                        }
                    }
                }
                onDiagnostic(result.fold(
                    onSuccess = { "✓ Pack $label installé et moteur relancé\n$it" },
                    onFailure = { "✗ Import $label : ${it.message ?: it.javaClass.simpleName}" }
                ))
                importRunning = false
                refresh++
            }
        }
    }

    Text("Carte locale : ${router.activePackDescription()}", color = Color(0xFFB8C7D9), fontSize = 12.sp)

    OutlinedButton(
        onClick = {
            targetFrance = false
            picker.launch(arrayOf("application/x-tar", "application/octet-stream", "*/*"))
        },
        enabled = !importRunning && !externallyBusy,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(if (importRunning && !targetFrance) "Import régional en cours…" else "Importer un pack régional (.tar)")
    }

    OutlinedButton(
        onClick = {
            targetFrance = true
            picker.launch(arrayOf("application/x-tar", "application/octet-stream", "*/*"))
        },
        enabled = !importRunning && !externallyBusy,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(if (importRunning && targetFrance) "Import France en cours…" else "Importer le pack France (.tar)")
    }

    Text("Le bouton France ne télécharge rien : il importe un fichier .tar déjà présent sur le téléphone.", color = Color(0xFFFFC857), fontSize = 11.sp)

    OutlinedButton(
        onClick = {
            if (!importRunning) {
                importRunning = true
                onDiagnostic("Test hors ligne de la couverture du pack actuel…")
                scope.launch {
                    val result = withContext(Dispatchers.IO) { router.currentFranceCoverageDiagnostic() }
                    onDiagnostic(result.fold(
                        onSuccess = { it },
                        onFailure = { "✗ Test couverture : ${it.message ?: it.javaClass.simpleName}" }
                    ))
                    importRunning = false
                }
            }
        },
        enabled = !importRunning && !externallyBusy,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text("Tester la couverture France du pack actuel")
    }

    OutlinedButton(
        onClick = {
            if (!importRunning) {
                importRunning = true
                onDiagnostic("Diagnostic complet du pack hors ligne…")
                scope.launch {
                    val result = withContext(Dispatchers.IO) { router.currentPackReadinessDiagnostic() }
                    onDiagnostic(result.fold(
                        onSuccess = { it },
                        onFailure = { "✗ Diagnostic pack : ${it.message ?: it.javaClass.simpleName}" }
                    ))
                    importRunning = false
                }
            }
        },
        enabled = !importRunning && !externallyBusy,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text("Diagnostic complet du pack hors ligne")
    }

    OutlinedButton(
        onClick = {
            if (!importRunning) {
                importRunning = true
                onDiagnostic("Test hors ligne des liaisons France longue distance…")
                scope.launch {
                    val result = withContext(Dispatchers.IO) { router.currentFranceContinuityDiagnostic() }
                    onDiagnostic(result.fold(
                        onSuccess = { it },
                        onFailure = { "✗ Continuité France : ${it.message ?: it.javaClass.simpleName}" }
                    ))
                    importRunning = false
                }
            }
        },
        enabled = !importRunning && !externallyBusy,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text("Tester la continuité France (trajets longs)")
    }

    if (destination != null && startLocation != null) {
        OutlinedButton(
            onClick = {
                if (!importRunning) {
                    importRunning = true
                    onDiagnostic("Vérification hors ligne de ${destination.label}…")
                    scope.launch {
                        val result = withContext(Dispatchers.IO) {
                            router.currentDestinationOfflineDiagnostic(
                                startLatitude = startLocation.latitude,
                                startLongitude = startLocation.longitude,
                                endLatitude = destination.point.latitude,
                                endLongitude = destination.point.longitude
                            )
                        }
                        onDiagnostic(result.fold(
                            onSuccess = { it },
                            onFailure = {
                                "✗ Destination non disponible hors ligne avec le pack actuel : " +
                                    (it.message ?: it.javaClass.simpleName)
                            }
                        ))
                        importRunning = false
                    }
                }
            },
            enabled = !importRunning && !externallyBusy,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Tester cette destination hors ligne")
        }
    }

    if (router.francePackInstalled()) {
        OutlinedButton(
            onClick = {
                if (!importRunning) {
                    importRunning = true
                    onDiagnostic("Retour au pack régional en cours…")
                    scope.launch {
                        val result = withContext(Dispatchers.IO) { router.removeFrancePack() }
                        onDiagnostic(result.fold(
                            onSuccess = { "✓ Pack France désactivé\n$it" },
                            onFailure = { "✗ Retour régional : ${it.message ?: it.javaClass.simpleName}" }
                        ))
                        importRunning = false
                        refresh++
                    }
                }
            },
            enabled = !importRunning && !externallyBusy,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Revenir au pack régional")
        }
    }
}
